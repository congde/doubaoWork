# 备份策略参考

## 两种备份模式的选择

| 场景 | 推荐模式 | 理由 |
|------|----------|------|
| 代码仓库、文档工作区（可接受"回到最新状态"） | mirror | 目标盘占用最小，始终与源一致 |
| 重要资料、防误删/防勒索（需要"回到任意时间点"） | snapshot | 每次快照独立，误删源文件后仍可从旧快照恢复 |
| 磁盘空间紧张 | mirror，或 snapshot + Retain 3~5 | 每份快照都是完整副本，保留越多占用越大 |

注意：本脚本的 snapshot 模式是"变更检测 + 全量快照"——每次运行先用 robocopy /L 空跑对比最新快照，源目录无任何变化（含修改与删除）则跳过本次备份，有变化才生成新的完整快照。恢复时直接进入对应快照目录取文件即可，无需解包。

## 推荐保留策略（Retain）

- 每日备份：Retain 7（保留一周）
- 每小时备份：Retain 24（保留一天）
- 每周备份：Retain 4~8（保留一至两个月）

## 频率与 automation_update 的 RRULE 映射

| 用户说法 | scheduleType | rrule |
|----------|--------------|-------|
| 每天早上 8 点 | recurring | FREQ=DAILY;BYHOUR=8 |
| 每小时一次 | recurring | FREQ=HOURLY |
| 每周一上午 | recurring | FREQ=WEEKLY;BYDAY=MO |
| 每月 1 号 | recurring | FREQ=MONTHLY;BYMONTHDAY=1 |
| 明天下午 3 点备份一次 | once | （用 scheduledAt，无需 rrule） |

## 恢复流程

1. mirror 模式：备份内容位于 `<Destination>\latest\`，直接复制需要的文件回源目录。
2. snapshot 模式：`<Destination>\<Name>-<时间戳>\` 目录按时间排列，找到误删/误改之前的那份。
3. 恢复属于写操作，覆盖源文件前必须先向用户确认。

## 常见问题排查

- **robocopy 退出码 8 及以上**：真正的失败（文件被占用、权限不足）。退出码 0~7 都是成功（1=有文件复制，2=有多余文件，0=无变化）。
- **执行策略报错（UnauthorizedAccess）**：Windows 默认禁止直接运行 .ps1 脚本，必须用 `powershell.exe -NoProfile -ExecutionPolicy Bypass -File <脚本路径> <参数>` 调起，不要用 `& <脚本>` 直接调用。
- **路径嵌套拒绝执行**：源目录和目标目录互相包含会形成无限复制，脚本会直接报 `path_conflict`，换一个目标目录。
- **文件被占用**：关闭占用程序后重试；robocopy 已配置失败重试 2 次、每次等待 2 秒。
- **日志位置**：`<Destination>\_logs\<任务名>-<时间戳>.log`，包含 robocopy 完整输出。
- **任务名会被净化**：`-Name` 参数中的中文及特殊字符会自动替换为下划线，用于快照目录命名与匹配，请优先使用英文/数字命名。

## 安全红线

- 备份脚本只允许写入 `<Destination>`，绝不触碰源目录的任何文件（不删、不改、不重命名）。
- 快照清理只针对备份目录内匹配 `<Name>-YYYYMMDD-HHMMSS` 命名的目录，绝不会匹配到用户其他文件。
- 恢复（反向覆盖源目录）必须逐次经用户确认，不可自动执行。
