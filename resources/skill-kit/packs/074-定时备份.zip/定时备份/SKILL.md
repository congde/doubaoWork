---
name: scheduled-backup
description: 定时备份自动化技能。当用户要求"定时备份、自动备份、定期备份某个文件夹、设置备份计划、备份数据、恢复备份文件"时使用。支持一次性或周期性（每天/每周/每小时/每月）备份，提供镜像（mirror）与日期快照（snapshot）两种模式，带保留策略、日志与恢复指引。适用于 Windows 环境下通过 automation_update 调度执行。
---

# Scheduled Backup（定时备份）

## 概述

本技能用于为用户建立"定时备份"能力：确定源目录、备份目标、备份模式与频率后，用 `scripts/backup.ps1` 执行备份，并用 automation_update 工具注册定时任务实现自动周期执行。全程遵循"只写备份目录、绝不动源目录"的安全红线。

## 工作流程（按顺序执行）

### 第 1 步：确认需求（信息不全时必须先问）

向用户确认以下四项，缺一项就问一项，不要猜：

1. **源目录**：要备份哪个文件夹？
2. **备份目标**：备份到哪里？（建议不同磁盘，如 `D:\Backups\...`）
3. **备份模式**：
   - `mirror`（镜像）：目标始终与源保持一致，占空间最小，但无法回到历史状态；
   - `snapshot`（快照，默认推荐）：每次生成带时间戳的独立快照，可恢复到任意时间点，支持自动清理旧快照。
   - 拿不准就推荐 `snapshot`。模式选择依据见 `references/backup-strategies.md`。
4. **频率**：每天/每周/每小时/每月，还是只备份一次？

### 第 2 步：首次执行备份（先手动跑一次，验证可用）

Windows 默认执行策略禁止直接运行 .ps1，必须通过 `powershell.exe -ExecutionPolicy Bypass -File` 调起（用 PowerShell 工具执行）：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<skill目录>/scripts/backup.ps1" -Source "C:\path\to\data" -Destination "D:\Backups\data" -Mode snapshot -Retain 7 -Name "data"
```

- 读取输出的 JSON：`status=success` 即成功，向用户报告 `backup` 路径、文件数（`srcStats/backupStats`）与日志位置。
- `unchanged=true` 表示源目录自上次快照以来无变化，本次未产生新快照，属正常情况。
- `status=error` 时按 `reason` 排查（`source_not_found` / `path_conflict` / `backup_failed`），常见问题见 `references/backup-strategies.md`。
- 执行前检查：源目录与目标目录不能相同或互相嵌套，脚本会自动拦截，但应在选择目标时就提醒用户。

### 第 3 步：注册定时任务（automation_update 工具）

用 automation_update 工具创建自动化，让备份按计划重复执行：

- `mode`: "create"
- `scheduleType`: "recurring"（周期备份）或 "once"（一次性备份）
- `rrule`: 按频率映射，常用值：
  - 每天：`FREQ=DAILY`（可加 `BYHOUR=8` 指定早 8 点）
  - 每小时：`FREQ=HOURLY`
  - 每周一：`FREQ=WEEKLY;BYDAY=MO`
  - 每月 1 号：`FREQ=MONTHLY;BYMONTHDAY=1`
- `prompt`: 写清楚备份任务本身，例如：
  「用 powershell.exe -NoProfile -ExecutionPolicy Bypass -File 运行 scheduled-backup 技能的 scripts/backup.ps1，参数：-Source 'C:\path\to\data' -Destination 'D:\Backups\data' -Mode snapshot -Retain 7 -Name 'data'。执行后检查 JSON 输出的 status 是否为 success，失败时报告日志内容。」
  （注意：prompt 中只写任务本身，不要写调度信息；调度由 rrule/scheduledAt 提供。）
- `cwds`: 填 skill 所在的工作目录路径。
- 用户要求"备份到什么时候为止"时，用 `validUntil` 设置结束日期。

### 第 4 步：汇报与验证

创建完成后向用户说明：

- 备份内容现在在哪里、怎么查看；
- 定时任务什么时间执行下一次；
- 如何恢复：mirror 模式取 `<目标>\latest\`；snapshot 模式进入对应时间戳目录。完整恢复流程见 `references/backup-strategies.md`。

用户之后想调整频率、改保留份数、暂停或删除任务时，用 automation_update 的 view/update/delete 模式处理，不要重复创建。

## 安全红线（任何情况下不可违反）

1. **绝不删除、修改、重命名源目录中的任何文件**。备份脚本只写入目标目录。
2. 旧快照清理只发生在备份目标目录内、且只匹配 `<Name>-YYYYMMDD-HHMMSS` 命名的目录。
3. **恢复（把备份覆盖回源目录）是高危操作**：必须先列出将受影响的文件并向用户明确确认后，才执行恢复。
4. 目标目录必须与源目录位于不同路径，且不能互相嵌套。
5. 不把包含密码、密钥等敏感信息的目录备份到公共/共享位置；发现此类文件时提醒用户。

## 资源说明

- `scripts/backup.ps1`：备份执行脚本（PowerShell + robocopy），参数 `-Source / -Destination / -Mode / -Retain / -Name`，输出 JSON 摘要，日志写在 `<目标>\_logs\`。
- `references/backup-strategies.md`：备份模式选择、保留策略建议、RRULE 映射表、恢复流程、故障排查。
