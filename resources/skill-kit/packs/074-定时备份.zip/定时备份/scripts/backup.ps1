# scheduled-backup backup script (PowerShell)
# Modes: mirror (incremental mirror to 'latest') or snapshot (timestamped copies with retention).
# Safety: writes ONLY into the backup destination; never touches source files.
# Output: single-line JSON summary on stdout; full log under <Destination>\_logs\

param(
    [Parameter(Mandatory = $true)]
    [string]$Source,            # source directory to back up

    [Parameter(Mandatory = $true)]
    [string]$Destination,       # backup destination root (must differ from source)

    [Parameter(Mandatory = $false)]
    [ValidateSet("mirror", "snapshot")]
    [string]$Mode = "snapshot", # mirror = mirror to latest; snapshot = dated copies + retention

    [Parameter(Mandatory = $false)]
    [int]$Retain = 7,           # number of snapshots to keep (snapshot mode)

    [Parameter(Mandatory = $false)]
    [string]$Name = ""          # task name (used for log file and snapshot prefix)
)

$ErrorActionPreference = "Stop"

# ---------- validation ----------
$Source = [System.IO.Path]::GetFullPath($Source)
$Destination = [System.IO.Path]::GetFullPath($Destination)

if (-not (Test-Path -LiteralPath $Source -PathType Container)) {
    Write-Output (ConvertTo-Json -Compress @{ status = "error"; reason = "source_not_found"; message = "Source directory not found: $Source" })
    exit 1
}
$sep = [IO.Path]::DirectorySeparatorChar
if ($Source -eq $Destination -or $Destination.StartsWith($Source + $sep) -or $Source.StartsWith($Destination + $sep)) {
    Write-Output (ConvertTo-Json -Compress @{ status = "error"; reason = "path_conflict"; message = "Source and destination are identical or nested; refusing to run" })
    exit 1
}
if ($Retain -lt 1) { $Retain = 1 }
if ($Name -eq "") { $Name = (Split-Path $Source -Leaf) }
# sanitize task name so it is safe for file names and regex
$Name = ($Name -replace '[^A-Za-z0-9_\-\.]', '_')

if (-not (Test-Path -LiteralPath $Destination)) {
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null
}

# ---------- logging ----------
$LogDir = Join-Path $Destination "_logs"
if (-not (Test-Path -LiteralPath $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$LogFile = Join-Path $LogDir "$Name-$Stamp.log"

function Write-Log([string]$Msg) {
    $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Msg
    Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
}

Write-Log "==== backup start ===="
Write-Log "source: $Source"
Write-Log "destination: $Destination"
Write-Log "mode: $Mode (retain $Retain)"

# ---------- run backup ----------
$sw = [System.Diagnostics.Stopwatch]::StartNew()
$BackupPath = $null
$unchanged = $false

try {
    if ($Mode -eq "mirror") {
        $BackupPath = Join-Path $Destination "latest"
        # /MIR mirror; /COPY:DAT data+attrs+timestamps; /R:2 /W:2 retry; /NFL /NDL less noise
        & robocopy $Source $BackupPath /MIR /COPY:DAT /DCOPY:DAT /R:2 /W:2 /NP /NDL /LOG+:$LogFile | Out-Null
        $rc = $LASTEXITCODE
        if ($rc -ge 8) { throw "robocopy failed with exit code $rc" }
    }
    else {
        # change detection: dry-run compare against the newest existing snapshot
        $pattern = "^" + [regex]::Escape($Name) + "-\d{8}-\d{6}$"
        $prev = Get-ChildItem -LiteralPath $Destination -Directory -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match $pattern } |
                Sort-Object Name -Descending | Select-Object -First 1
        if ($prev) {
            # /L list-only: exit code 0 means source and latest snapshot are identical
            & robocopy $prev.FullName $Source /E /L /NJH /NJS /NP /NDL /LOG+:$LogFile | Out-Null
            $rc = $LASTEXITCODE
            if ($rc -lt 8 -and $rc -eq 0) {
                $sw.Stop()
                $unchanged = $true
                Write-Log "no changes since snapshot $($prev.Name); skip"
                $srcFiles = Get-ChildItem -LiteralPath $Source -Recurse -File -Force -ErrorAction SilentlyContinue
                $bkFiles = Get-ChildItem -LiteralPath $prev.FullName -Recurse -File -Force -ErrorAction SilentlyContinue
                Write-Output (ConvertTo-Json -Compress -Depth 3 @{
                    status      = "success"
                    mode        = $Mode
                    source      = $Source
                    backup      = $prev.FullName
                    unchanged   = $true
                    duration    = $sw.Elapsed.ToString("hh\:mm\:ss")
                    log         = $LogFile
                    srcStats    = @{ files = $srcFiles.Count; bytes = ($srcFiles | Measure-Object Length -Sum).Sum }
                    backupStats = @{ files = $bkFiles.Count; bytes = ($bkFiles | Measure-Object Length -Sum).Sum }
                })
                exit 0
            }
        }
        $BackupPath = Join-Path $Destination "$Name-$Stamp"
        # /E all subdirs incl. empty; full copy into the new timestamped snapshot
        & robocopy $Source $BackupPath /E /COPY:DAT /DCOPY:DAT /R:2 /W:2 /NP /NDL /LOG+:$LogFile | Out-Null
        $rc = $LASTEXITCODE
        if ($rc -ge 8) { throw "robocopy failed with exit code $rc" }
    }
    $sw.Stop()

    # ---------- retention: prune old snapshots inside destination only ----------
    if ($Mode -eq "snapshot" -and -not $unchanged) {
        $pattern = "^" + [regex]::Escape($Name) + "-\d{8}-\d{6}$"
        $snapshots = Get-ChildItem -LiteralPath $Destination -Directory -ErrorAction SilentlyContinue |
                     Where-Object { $_.Name -match $pattern } |
                     Sort-Object Name -Descending
        if ($snapshots.Count -gt $Retain) {
            foreach ($old in ($snapshots | Select-Object -Skip $Retain)) {
                Write-Log "prune old snapshot: $($old.FullName)"
                Remove-Item -LiteralPath $old.FullName -Recurse -Force
            }
        }
    }

    # language-neutral stats: count files/bytes in source and in the backup
    $srcFiles = Get-ChildItem -LiteralPath $Source -Recurse -File -Force -ErrorAction SilentlyContinue
    $srcStats = @{ files = $srcFiles.Count; bytes = ($srcFiles | Measure-Object Length -Sum).Sum }
    $bkFiles = @()
    if (-not $unchanged -and $BackupPath -and (Test-Path -LiteralPath $BackupPath)) {
        $bkFiles = Get-ChildItem -LiteralPath $BackupPath -Recurse -File -Force -ErrorAction SilentlyContinue
    } elseif ($Mode -eq "mirror") {
        $bkFiles = Get-ChildItem -LiteralPath (Join-Path $Destination "latest") -Recurse -File -Force -ErrorAction SilentlyContinue
    }
    $bkStats = @{ files = $bkFiles.Count; bytes = ($bkFiles | Measure-Object Length -Sum).Sum }

    Write-Log "==== backup done ($($sw.Elapsed.ToString('hh\:mm\:ss'))) ===="

    $resultBackup = if ($unchanged) { "no changes; existing snapshots kept" } else { $BackupPath }
    Write-Output (ConvertTo-Json -Compress -Depth 3 @{
        status     = "success"
        mode       = $Mode
        source     = $Source
        backup     = $resultBackup
        unchanged  = $unchanged
        duration   = $sw.Elapsed.ToString("hh\:mm\:ss")
        log        = $LogFile
        srcStats   = $srcStats
        backupStats = $bkStats
    })
    exit 0
}
catch {
    $sw.Stop()
    Write-Log "==== backup failed: $($_.Exception.Message) ===="
    Write-Output (ConvertTo-Json -Compress @{ status = "error"; reason = "backup_failed"; message = $_.Exception.Message; log = $LogFile })
    exit 1
}
