#!/usr/bin/env python3
import argparse
import html
import json
import shutil
from pathlib import Path


TEMPLATES = {"resume", "portfolio", "creator"}


def esc(value):
    return html.escape(str(value or ""), quote=True)


def list_items(items, class_name="tag"):
    return "\n".join(f'<span class="{class_name}">{esc(item)}</span>' for item in items or [])


def project_cards(projects):
    if not projects:
        return '<p class="muted">作品信息待补充。</p>'
    cards = []
    for project in projects:
        tags = list_items(project.get("tags", []), "mini-tag")
        impact = f'<p class="impact">{esc(project.get("impact"))}</p>' if project.get("impact") else ""
        cards.append(
            f"""
            <article class="card project-card">
              <h3>{esc(project.get("title", "未命名项目"))}</h3>
              <p>{esc(project.get("description", ""))}</p>
              {impact}
              <div class="tag-row">{tags}</div>
            </article>
            """
        )
    return "\n".join(cards)


def experience_items(items):
    if not items:
        return '<p class="muted">经历信息待补充。</p>'
    out = []
    for item in items:
        out.append(
            f"""
            <article class="timeline-item">
              <div>
                <h3>{esc(item.get("title", "经历"))}</h3>
                <p class="meta">{esc(item.get("company", ""))} · {esc(item.get("period", ""))}</p>
              </div>
              <p>{esc(item.get("description", ""))}</p>
            </article>
            """
        )
    return "\n".join(out)


def service_cards(services):
    if not services:
        return '<p class="muted">内容栏目待补充。</p>'
    return "\n".join(
        f"""
        <article class="card">
          <h3>{esc(item.get("title", "栏目"))}</h3>
          <p>{esc(item.get("description", ""))}</p>
        </article>
        """
        for item in services
    )


def base_data(data):
    return {
        "name": data.get("name", "你的名字"),
        "role": data.get("role", "个人网站"),
        "tagline": data.get("tagline", "用一个清晰页面介绍你是谁、做过什么、能提供什么价值。"),
        "location": data.get("location", ""),
        "bio": data.get("bio") or ["这里放一段自然的个人介绍。"],
        "highlights": data.get("highlights") or [],
        "skills": data.get("skills") or [],
        "experience": data.get("experience") or [],
        "projects": data.get("projects") or [],
        "sections": data.get("sections") or data.get("services") or [],
        "style": data.get("style") or {},
        "resume": data.get("resume", ""),
    }


def render_html(data, template):
    d = base_data(data)
    accent = esc(d["style"].get("accent", "#2563eb"))
    title = f"{d['name']} - {d['role']}"
    description = d["tagline"]
    body_class = f"theme-{template}"
    bio = "\n".join(f"<p>{esc(p)}</p>" for p in d["bio"])
    resume = (
        f'<a class="button primary" href="{esc(d["resume"])}">查看简历</a>'
        if d["resume"]
        else ""
    )

    if template == "resume":
        main = f"""
        <section class="hero compact">
          <p class="eyebrow">{esc(d["location"] or "Personal Site")}</p>
          <h1>{esc(d["name"])}</h1>
          <p class="lead">{esc(d["role"])} · {esc(d["tagline"])}</p>
          <div class="actions">{resume}</div>
        </section>
        <section><h2>关于我</h2><div class="prose">{bio}</div></section>
        <section><h2>亮点</h2><div class="tag-row">{list_items(d["highlights"])}</div></section>
        <section><h2>经历</h2><div class="timeline">{experience_items(d["experience"])}</div></section>
        <section><h2>项目</h2><div class="grid">{project_cards(d["projects"])}</div></section>
        <section><h2>技能</h2><div class="tag-row">{list_items(d["skills"])}</div></section>
        """
    elif template == "portfolio":
        main = f"""
        <section class="hero split">
          <div>
            <p class="eyebrow">{esc(d["role"])}</p>
            <h1>{esc(d["name"])}</h1>
            <p class="lead">{esc(d["tagline"])}</p>
            <div class="actions">{resume}</div>
          </div>
          <div class="hero-panel">
            <h2>精选能力</h2>
            <div class="tag-row">{list_items(d["skills"][:8])}</div>
          </div>
        </section>
        <section><h2>代表作品</h2><div class="grid projects">{project_cards(d["projects"])}</div></section>
        <section><h2>经历与背景</h2><div class="timeline">{experience_items(d["experience"])}</div></section>
        <section><h2>关于我</h2><div class="prose">{bio}</div></section>
        """
    else:
        main = f"""
        <section class="hero creator-hero">
          <p class="eyebrow">{esc(d["role"])}</p>
          <h1>{esc(d["name"])}</h1>
          <p class="lead">{esc(d["tagline"])}</p>
          <div class="actions">{resume}</div>
        </section>
        <section><h2>内容栏目</h2><div class="grid">{service_cards(d["sections"])}</div></section>
        <section><h2>背景与观点</h2><div class="prose">{bio}</div></section>
        <section><h2>案例和作品</h2><div class="grid">{project_cards(d["projects"])}</div></section>
        <section><h2>技能和方向</h2><div class="tag-row">{list_items(d["skills"])}</div></section>
        """

    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1, width=device-width">
  <title>{esc(title)}</title>
  <meta name="description" content="{esc(description)}">
  <meta property="og:title" content="{esc(title)}">
  <meta property="og:description" content="{esc(description)}">
  <meta name="twitter:card" content="summary">
  <link rel="stylesheet" href="styles.css">
  <style>:root{{--accent:{accent};}}</style>
</head>
<body class="{body_class}">
  <a class="skip-link" href="#main">跳到正文</a>
  <header class="site-header">
    <a class="brand" href="#main">{esc(d["name"])}</a>
    <nav aria-label="主导航">
      <a href="#work">作品</a>
      <a href="#about">简介</a>
    </nav>
  </header>
  <main id="main">
    {main}
    <section id="about"><h2>个人简介</h2><div class="prose">{bio}</div></section>
  </main>
  <footer>
    <p>{esc(d["name"])} · {esc(d["role"])}</p>
  </footer>
  <script src="script.js"></script>
</body>
</html>
"""


CSS = """
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#f7f7f4;color:#171717;line-height:1.6}a{color:inherit}.skip-link{position:absolute;left:-999px}.skip-link:focus{left:16px;top:16px;background:#fff;padding:10px 14px;border:2px solid var(--accent);z-index:9}.site-header{position:sticky;top:0;z-index:3;display:flex;justify-content:space-between;align-items:center;padding:18px clamp(18px,4vw,56px);background:rgba(247,247,244,.86);backdrop-filter:blur(12px);border-bottom:1px solid #e6e4dc}.brand{font-weight:800;text-decoration:none}.site-header nav{display:flex;gap:18px}.site-header nav a,.links a,.text-link{font-weight:700;text-decoration:none;border-bottom:1px solid currentColor}main{max-width:1120px;margin:0 auto;padding:0 clamp(18px,4vw,56px)}section{padding:56px 0;border-bottom:1px solid #e8e6de}.hero{min-height:62vh;display:grid;align-items:center;padding:80px 0}.hero.split{grid-template-columns:1.25fr .75fr;gap:28px}.hero h1{font-size:clamp(44px,8vw,96px);line-height:.96;margin:8px 0 18px;letter-spacing:0}.lead{font-size:clamp(20px,3vw,32px);max-width:760px;color:#363636}.eyebrow{text-transform:uppercase;font-size:13px;letter-spacing:.12em;color:var(--accent);font-weight:800}.actions{display:flex;flex-wrap:wrap;gap:12px;margin-top:26px}.button{display:inline-flex;min-height:44px;align-items:center;padding:11px 16px;border:1px solid #222;text-decoration:none;font-weight:800;background:#fff}.button.primary{background:var(--accent);border-color:var(--accent);color:#fff}.button.disabled{opacity:.55}.hero-panel,.card{background:#fff;border:1px solid #e3e0d6;padding:24px;box-shadow:0 14px 40px rgba(0,0,0,.05)}h2{font-size:clamp(26px,4vw,44px);margin:0 0 22px}h3{margin:0 0 8px;font-size:22px}.prose{max-width:760px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}.timeline{display:grid;gap:16px}.timeline-item{display:grid;grid-template-columns:260px 1fr;gap:22px;padding:22px;background:#fff;border:1px solid #e3e0d6}.meta,.muted{color:#666}.tag-row{display:flex;flex-wrap:wrap;gap:10px}.tag,.mini-tag{display:inline-flex;align-items:center;border:1px solid #d8d5ca;background:#fff;padding:8px 11px;font-weight:700}.mini-tag{font-size:13px;padding:5px 8px}.impact{font-weight:800;color:var(--accent)}footer{padding:42px clamp(18px,4vw,56px);background:#111;color:#fff;display:grid;gap:18px}.links{display:flex;flex-wrap:wrap;gap:14px}.theme-portfolio{background:#0b1020;color:#eef2ff}.theme-portfolio .site-header{background:rgba(11,16,32,.85);border-bottom-color:#25304f}.theme-portfolio .lead,.theme-portfolio .meta,.theme-portfolio .muted{color:#b9c2dd}.theme-portfolio section{border-bottom-color:#25304f}.theme-portfolio .card,.theme-portfolio .hero-panel,.theme-portfolio .timeline-item,.theme-portfolio .tag,.theme-portfolio .mini-tag{background:#121a33;border-color:#293555}.theme-creator{background:#fffaf2}.theme-creator .hero h1{max-width:900px}.theme-creator .card{border-radius:0 28px 0 0}@media(max-width:760px){.site-header{position:static;align-items:flex-start;gap:12px;flex-direction:column}.hero,.hero.split{min-height:auto;grid-template-columns:1fr;padding:54px 0}.grid{grid-template-columns:1fr}.timeline-item{grid-template-columns:1fr}.actions{flex-direction:column}.button{justify-content:center;width:100%}}
"""


JS = """
document.querySelectorAll('a[href^="#"]').forEach((link) => {
  link.addEventListener("click", (event) => {
    const target = document.querySelector(link.getAttribute("href"));
    if (target) {
      event.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  });
});
"""


def write_site(data, template, out_dir):
    out = Path(out_dir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    (out / "assets").mkdir(exist_ok=True)
    (out / "index.html").write_text(render_html(data, template), encoding="utf-8")
    (out / "styles.css").write_text(CSS.strip() + "\n", encoding="utf-8")
    (out / "script.js").write_text(JS.strip() + "\n", encoding="utf-8")
    (out / "site-brief.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def make_zip(out):
    zip_base = out.with_suffix("")
    archive = shutil.make_archive(str(zip_base), "zip", root_dir=out)
    return Path(archive)


def main():
    parser = argparse.ArgumentParser(description="Build a static personal website from a JSON brief.")
    parser.add_argument("--brief", required=True, help="Path to site brief JSON.")
    parser.add_argument("--template", choices=sorted(TEMPLATES), default="resume")
    parser.add_argument("--out", required=True, help="Output site directory.")
    parser.add_argument("--zip", action="store_true", help="Create a zip archive next to the output directory.")
    args = parser.parse_args()

    brief_path = Path(args.brief).expanduser()
    data = json.loads(brief_path.read_text(encoding="utf-8"))
    out = write_site(data, args.template, args.out)
    print(f"Site written: {out}")
    print(f"Preview: cd {out} && python3 -m http.server 8000")
    if args.zip:
        print(f"Zip written: {make_zip(out)}")


if __name__ == "__main__":
    main()
