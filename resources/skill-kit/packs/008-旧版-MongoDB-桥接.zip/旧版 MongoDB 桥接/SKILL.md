---
name: mongodb-legacy-mcp
description: Set up a working MongoDB MCP server / client connection for LEGACY MongoDB servers (3.x, especially 3.4) that are incompatible with the official MongoDB MCP (npx) and modern MongoDB Compass. Use when the user has an old MongoDB (< 4.2) and needs to query it via MCP, Compass, or any driver.
color: amber
emoji: 🍃
agent_created: true
vibe: Old MongoDB won't die, but the new tools won't talk to it. Bridge the gap.
---

# Legacy MongoDB MCP & Client Setup

## When to use this skill

- User needs to **query MongoDB via MCP** but the server is **3.x** (confirmed common case: **3.4.24**).
- Official `mongodb-mcp-server` (npx) and **MongoDB Compass 1.40+** refuse to connect to MongoDB < 4.2.
- Symptom in Compass: `connection <monitor> to <host>:27017 closed` even though the same
  connection string works from a Python/pymongo script.

## Root cause

- MongoDB 3.4 reached End-of-Life in **April 2018**.
- `mongodb-mcp-server` bundles a Node.js driver requiring MongoDB **>= 4.2**.
- MongoDB Compass **1.40+** requires MongoDB **>= 4.0**; **1.44+** requires **>= 4.2**.
  (Last version that fully supports 3.4 is **Compass 1.32.x**.)
- Modern `mongosh` (new shell) also requires MongoDB **>= 4.0** — use the legacy `mongo` shell for 3.4.

## Solution A — Custom Python MCP server (for MCP access)

`server.py` is a pure-Python MCP server implementing JSON-RPC 2.0 over stdio, driven by
`pymongo` (NOT the `mcp` SDK — the SDK is heavy and unnecessary for a read-only bridge).
It exposes 8 read-only tools: `list-databases`, `list-collections`, `find`, `count`,
`collection-schema`, `aggregate`, `indexes`, `distinct`.

**Critical: pin pymongo to 3.x** (last version supporting MongoDB 3.4):
```bash
pip install "pymongo==3.13.0"   # 4.x requires MongoDB >= 4.2 and WILL fail
```
If C-extension compilation is blocked in a sandbox, install pure-Python:
```bash
NO_EXT=1 pip install --no-cache-dir --no-build-isolation "pymongo==3.13.0"
```

**mcp.json entry** (command = venv python, args = [server.py], connection string via env):
```json
{
  "mcpServers": {
    "MongoDB": {
      "command": "/path/to/venv/bin/python3",
      "args": ["/path/to/server.py"],
      "env": {
        "MDB_MCP_CONNECTION_STRING": "mongodb://USER:PASS@HOST:27017/DB?authSource=DB&authMechanism=SCRAM-SHA-1"
      },
      "disabled": false
    }
  }
}
```

## Solution B — Compass GUI (if user insists on GUI)

Install **Compass 1.32.6** (last to support 3.4):
- macOS: `mongodb-compass-1.32.6-darwin-x64.dmg`
- Windows: `mongodb-compass-1.32.6-win32-x64.msi`
- GitHub releases: `https://github.com/mongodb-js/compass/releases/tag/v1.32.6`

## Connection string format (MongoDB 3.4)

```
mongodb://<user>:<password>@<host>:27017/<db>?authSource=<db>&authMechanism=SCRAM-SHA-1
```
- **authMechanism MUST be `SCRAM-SHA-1`** (3.4 default; SCRAM-SHA-256 needs 4.0+, MONGODB-CR is deprecated).
- URL-encode the password: `@` → `%40`, `!` → `%21`.
- `authSource` = the database used in `--authenticationDatabase` on the `mongo` CLI.

## Portable deployment package (reuse across machines)

The venv (with compiled binaries) **cannot** be copied across machines/OSes. Ship a
self-contained folder instead and run an installer per machine:

- `server.py` — the MCP server above
- `requirements.txt` — `pymongo==3.13.0`
- `install.py` — stdlib-only installer: creates `./venv`, installs pymongo, **merges**
  the MongoDB entry into `~/.workbuddy/mcp.json` (backs up existing first). No third-party
  deps needed to run the installer itself.
- `setup.sh` (macOS/Linux) / `setup.ps1` (Windows) — bootstrap wrappers.

Deploy on a new machine:
```bash
# macOS / Linux
cd ~/mongo-mcp && ./setup.sh --connection-string "mongodb://..."
# Windows (PowerShell)
cd C:\mongo-mcp && .\setup.ps1 -ConnectionString "mongodb://..."
```
Then in WorkBuddy → Connectors → find **MongoDB** → **Trust**.

## Quick diagnostics

| Symptom | Cause | Fix |
|---------|-------|-----|
| `connection <monitor> closed` (Compass) | Compass too new for 3.4 | Downgrade to 1.32.6 or use MCP |
| `Authentication failed` | wrong password / authSource | recheck creds + `authSource` |
| wire version / `Server at ... reports maximum wire version` | driver too new | use pymongo 3.x |
| `No suitable servers` | DNS / firewall | use IP, test `nc -zv host 27017` |
| port refused | security group / bindIp | whitelist client IP on server |

## Gotchas

- Don't waste time trying `mongodb-mcp-server` (npx) against 3.x — it cannot work.
- The `mcp` Python SDK is unnecessary for a thin read-only bridge; pure stdlib + pymongo is lighter and installs faster in sandboxes.
- Always back up `~/.workbuddy/mcp.json` before merging new entries.
