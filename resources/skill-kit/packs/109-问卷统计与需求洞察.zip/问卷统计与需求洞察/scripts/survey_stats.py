#!/usr/bin/env python3
"""问卷分析：选择题频次/NPS/交叉表 + 开放题关键词归类。输入为问卷导出 CSV（首行题目，每行一份答卷）。"""
import argparse
import csv
import re
from collections import Counter, defaultdict
from pathlib import Path

STOPWORDS = set("的了和是我就都也很还你要不看有没有什么怎么这个那个觉得因为所以但是可能比较非常真的现在时候问题建议可以应该需要这样那样使用用于以及而且或者如果虽然然后因此没有之一一下进行通过对于".split())


def load(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def question_type(headers, rows, idx):
    vals = [r[idx].strip() for r in rows if idx < len(r) and r[idx].strip()]
    if not vals:
        return "empty", vals
    uniq = set(vals)
    if len(uniq) <= 12 and len(uniq) < len(vals) * 0.6:
        nums = all(re.fullmatch(r"\d+(\.\d+)?", v) for v in vals)
        return ("scale" if nums and uniq and max(float(v) for v in vals) <= 10 and len(uniq) >= 5 else "choice"), vals
    return "text", vals


def nps(vals):
    """0-10 打分列 → NPS。"""
    try:
        scores = [int(float(v)) for v in vals]
    except ValueError:
        return None
    if not scores or not all(0 <= s <= 10 for s in scores):
        return None
    promoters = sum(1 for s in scores if s >= 9)
    detractors = sum(1 for s in scores if s <= 6)
    return {"n": len(scores), "nps": round((promoters - detractors) / len(scores) * 100),
            "promoter_pct": promoters / len(scores), "passive_pct": sum(1 for s in scores if 7 <= s <= 8) / len(scores),
            "detractor_pct": detractors / len(scores), "mean": sum(scores) / len(scores)}


def keywords(vals, topn=8):
    """开放题：中文按 2-gram 提取高频词组，去停用词。"""
    cnt = Counter()
    for v in vals:
        tokens = [t for t in re.split(r"[^\w\u4e00-\u9fff]+", v) if t]
        words = []
        for t in tokens:
            for i in range(len(t) - 1):
                g = t[i:i + 2]
                if not any(c in STOPWORDS for c in g) and re.fullmatch(r"[\u4e00-\u9fff]{2}", g):
                    words.append(g)
        cnt.update(words)
    return cnt.most_common(topn)


def crosstab(headers, rows, q1, q2):
    i1, i2 = headers.index(q1), headers.index(q2)
    table = defaultdict(Counter)
    for r in rows:
        if max(i1, i2) < len(r) and r[i1].strip() and r[i2].strip():
            table[r[i1].strip()][r[i2].strip()] += 1
    return table


DEMO = """使用频率,满意度(1-5),推荐意愿(0-10),最希望改进的地方
每天用,5,10,导出大文件的时候会卡住，希望优化性能
每天用,4,9,太贵了 能不能便宜点
每周几次,4,8,界面挺好 性能一般 导出慢
每周几次,3,7,客服响应太慢
每天用,2,4,经常闪退 数据丢了两次 很难信任
每月一次,5,9,功能全 就是有点重
每周几次,4,8,性能优化一下就好了
每天用,5,10,性能 性能 性能 大文件必卡
每月一次,4,8,价格偏贵
每天用,3,6,闪退了一次 希望稳定
每周几次,5,9,挺好 改进下导出速度
每天用,4,8,贵 加个便宜档位
"""


def main():
    ap = argparse.ArgumentParser(description="问卷结果统计分析")
    ap.add_argument("input", nargs="?", help="问卷导出 CSV")
    ap.add_argument("--cross", help="交叉分析的两个题目，如 '使用频率,满意度(1-5)'")
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()

    if args.demo:
        skill_root = Path(__file__).resolve().parent.parent
        src = skill_root / "examples" / "survey_demo.csv"
        src.parent.mkdir(parents=True, exist_ok=True)
        src.write_text(DEMO.strip() + "\n", encoding="utf-8")
        args.input, args.cross = str(src), "使用频率,推荐意愿(0-10)"

    headers, rows = load(args.input)
    lines = [f"# 问卷分析报告（{Path(args.input).name}）",
             f"有效样本：{len(rows)} 份", ""]

    for idx, q in enumerate(headers):
        qtype, vals = question_type(headers, rows, idx)
        if qtype == "empty":
            continue
        lines.append(f"## {q}")
        if qtype == "scale":
            score = nps(vals)
            top2 = sum(1 for v in vals if float(v) >= 4) / len(vals)
            max_v = max(float(v) for v in vals)
            top2_line = f" ｜ 选择 4-5 的比例 {top2:.0%}" if max_v <= 5 else ""
            lines.append(f"- 均值 {sum(map(float, vals)) / len(vals):.2f}{top2_line}")
            if score and "推荐" in q:
                lines.append(f"- NPS = {score['nps']}（推荐者 {score['promoter_pct']:.0%} / 中立 {score['passive_pct']:.0%} / 贬损者 {score['detractor_pct']:.0%}）"
                             + ("｜ ⚠️ 贬损者占比偏高，需优先处理" if score["detractor_pct"] > 0.2 else ""))
        elif qtype == "choice":
            cnt = Counter(vals)
            lines += [f"- {v}：{c} 份（{c / len(vals):.0%}）" for v, c in cnt.most_common()]
        else:
            kws = keywords(vals)
            lines.append(f"- 高频关注点：{'、'.join(f'{k}({c} 次)' for k, c in kws)}")
        lines.append("")

    if args.cross:
        q1, q2 = [x.strip() for x in args.cross.split(",", 1)]
        if q1 in headers and q2 in headers:
            table = crosstab(headers, rows, q1, q2)
            i2 = headers.index(q2)
            _, vals2 = question_type(headers, rows, i2)
            is_score = all(re.fullmatch(r"\d+(\.\d+)?", v) for v in vals2) if vals2 else False
            lines += ["## 交叉分析：" + f"{q1} × {q2}"]
            if is_score:
                groups = defaultdict(list)
                for r in rows:
                    if i2 < len(r) and r[headers.index(q1)].strip() and r[i2].strip():
                        groups[r[headers.index(q1)].strip()].append(float(r[i2]))
                stats = [(g, len(vs), sum(vs) / len(vs)) for g, vs in groups.items() if len(vs) >= 2]
                stats.sort(key=lambda x: x[2])
                if len(stats) >= 2:
                    lo, hi = stats[0], stats[-1]
                    lines.append(f"- 差异最大：{lo[0]}（均值 {lo[2]:.1f}，n={lo[1]}） vs {hi[0]}（均值 {hi[2]:.1f}，n={hi[1]}）")
                    lines.append(f"- ⚠️ 高频用户打分反而更低时，通常意味着核心体验有硬伤（性能/稳定性），优先看开放题高频词")
            lines += [f"- 明细：{ {g: dict(c) for g, c in table.items()} }"]
            lines.append("")

    lines += ["## 下一步建议",
              "- 把开放题高频词与低分组交叉：贬损者都在抱怨什么，那就是 P0 改进项",
              "- 样本若来自单一渠道，注明'结论受样本偏差影响'"]
    out = Path(args.input).with_name(Path(args.input).stem + "_分析报告.md")
    out.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    print(f"\n报告已写入：{out}")


if __name__ == "__main__":
    main()
