#!/usr/bin/env python3
"""Extract PDF text layer and OCR text page by page for PPT-to-MD cleanup."""

from __future__ import annotations

import argparse
import io
import json
import re
from pathlib import Path

import fitz
import pytesseract
from PIL import Image


def parse_pages(spec: str | None, page_count: int) -> list[int]:
    if not spec:
        return list(range(1, page_count + 1))

    pages: set[int] = set()
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            start_s, end_s = part.split("-", 1)
            start, end = int(start_s), int(end_s)
            if start > end:
                raise ValueError(f"Invalid page range: {part}")
            pages.update(range(start, end + 1))
        else:
            pages.add(int(part))

    bad = [p for p in pages if p < 1 or p > page_count]
    if bad:
        raise ValueError(f"Page(s) out of range 1-{page_count}: {bad}")
    return sorted(pages)


def normalize_text(text: str) -> str:
    lines = []
    for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = re.sub(r"[ \t]+", " ", line).strip()
        lines.append(line)
    return "\n".join(lines).strip()


def ocr_page(page: fitz.Page, lang: str, zoom: float, config: str) -> str:
    pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
    img = Image.open(io.BytesIO(pix.tobytes("png")))
    return normalize_text(pytesseract.image_to_string(img, lang=lang, config=config))


def page_markdown(page_no: int, pdf_text: str, ocr_text: str) -> str:
    return (
        f"# Page {page_no}\n\n"
        f"## PDF text\n\n{pdf_text}\n\n"
        f"## OCR text\n\n{ocr_text}\n"
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Extract text layer and OCR text from a PPT-style PDF."
    )
    parser.add_argument("pdf", type=Path, help="Input PDF path.")
    parser.add_argument("--out", type=Path, required=True, help="Output directory.")
    parser.add_argument("--lang", default="chi_sim+eng", help="Tesseract languages.")
    parser.add_argument("--zoom", type=float, default=2.5, help="Render zoom for OCR.")
    parser.add_argument(
        "--pages",
        help="Optional 1-based pages/ranges, e.g. '1,3-5'. Defaults to all pages.",
    )
    parser.add_argument(
        "--tesseract-config",
        default="--psm 6",
        help="Extra Tesseract config. Default: '--psm 6'.",
    )
    args = parser.parse_args()

    if not args.pdf.exists():
        raise FileNotFoundError(args.pdf)

    args.out.mkdir(parents=True, exist_ok=True)
    pages_dir = args.out / "pages"
    pages_dir.mkdir(parents=True, exist_ok=True)

    doc = fitz.open(args.pdf)
    page_numbers = parse_pages(args.pages, doc.page_count)

    records = []
    for page_no in page_numbers:
        page = doc[page_no - 1]
        pdf_text = normalize_text(page.get_text("text"))
        ocr_text = ocr_page(page, args.lang, args.zoom, args.tesseract_config)

        record = {
            "page": page_no,
            "pdf_chars": len(pdf_text),
            "ocr_chars": len(ocr_text),
            "pdf_text": pdf_text,
            "ocr_text": ocr_text,
        }
        records.append(record)

        (pages_dir / f"page-{page_no:03d}.md").write_text(
            page_markdown(page_no, pdf_text, ocr_text),
            encoding="utf-8",
        )
        print(f"page {page_no:03d}: pdf={len(pdf_text):4d} ocr={len(ocr_text):4d}")

    summary_lines = [
        f"# Extraction Summary",
        "",
        f"- Source: `{args.pdf}`",
        f"- Pages in PDF: {doc.page_count}",
        f"- Pages extracted: {', '.join(str(r['page']) for r in records)}",
        f"- OCR language: `{args.lang}`",
        f"- OCR zoom: `{args.zoom}`",
        "",
        "| Page | PDF chars | OCR chars |",
        "|---:|---:|---:|",
    ]
    for record in records:
        summary_lines.append(
            f"| {record['page']} | {record['pdf_chars']} | {record['ocr_chars']} |"
        )

    (args.out / "records.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (args.out / "summary.md").write_text("\n".join(summary_lines) + "\n", encoding="utf-8")
    print(f"wrote {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
