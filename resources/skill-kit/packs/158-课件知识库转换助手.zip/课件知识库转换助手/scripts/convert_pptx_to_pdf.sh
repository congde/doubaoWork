#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo "Usage: $0 INPUT.pptx [OUTPUT.pdf]" >&2
  exit 2
fi

input=$1
if [[ ! -f "$input" ]]; then
  echo "Input file not found: $input" >&2
  exit 1
fi

case "${input,,}" in
  *.pptx|*.ppt) ;;
  *)
    echo "Input must be a .pptx or .ppt file: $input" >&2
    exit 2
    ;;
esac

if [[ $# -eq 2 ]]; then
  output=$2
else
  dir=$(dirname "$input")
  base=$(basename "$input")
  output="$dir/${base%.*}.pdf"
fi

mkdir -p "$(dirname "$output")"
if [[ -e "$output" ]]; then
  echo "拒绝覆盖已经存在的输出文件：$output" >&2
  exit 1
fi

temp_dir=$(mktemp -d)
trap 'rm -rf "$temp_dir"' EXIT

if command -v soffice >/dev/null 2>&1; then
  soffice --headless --convert-to pdf --outdir "$temp_dir" "$input" >/dev/null
  generated="$temp_dir/$(basename "${input%.*}.pdf")"
  if [[ ! -s "$generated" ]]; then
    echo "PDF 导出失败或生成了空文件：$generated" >&2
    exit 1
  fi
  mv "$generated" "$output"
elif [[ -d "/Applications/Microsoft PowerPoint.app" ]]; then
  /usr/bin/osascript - "$input" "$output" <<'APPLESCRIPT'
on run argv
  set inputPath to item 1 of argv
  set outputPath to item 2 of argv
  tell application "Microsoft PowerPoint"
    activate
    open POSIX file inputPath
    delay 1
    save active presentation in POSIX file outputPath as save as PDF
    close active presentation saving no
  end tell
end run
APPLESCRIPT
else
  echo "没有找到 PPTX 转 PDF 工具；请安装 LibreOffice，或在 macOS 安装 Microsoft PowerPoint。" >&2
  exit 1
fi

if [[ ! -s "$output" ]]; then
  echo "PDF 导出失败或生成了空文件：$output" >&2
  exit 1
fi

echo "$output"
