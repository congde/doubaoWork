#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 3 || $# -gt 4 || "$1" != "--confirm-delete-source" ]]; then
  echo "用法：$0 --confirm-delete-source SOURCE.pptx OUTPUT.md [SOURCE.pdf]" >&2
  echo "此脚本会删除源文件，必须显式提供 --confirm-delete-source。" >&2
  exit 2
fi

source_file=$2
md_file=$3

case "${source_file,,}" in
  *.pptx|*.ppt) ;;
  *)
    echo "Refusing to delete non-PowerPoint source: $source_file" >&2
    exit 2
    ;;
esac

if [[ ! -f "$source_file" ]]; then
  echo "Source file already absent: $source_file"
  exit 0
fi

if [[ $# -eq 4 ]]; then
  pdf_file=$4
else
  pdf_file="${source_file%.*}.pdf"
fi

if [[ ! -s "$pdf_file" ]]; then
  echo "Refusing to delete source because PDF is missing or empty: $pdf_file" >&2
  exit 1
fi

if [[ ! -s "$md_file" ]]; then
  echo "Refusing to delete source because Markdown is missing or empty: $md_file" >&2
  exit 1
fi

if grep -Eq '<!-- source:' "$md_file"; then
  echo "Refusing to delete source because Markdown still contains page-source comments: $md_file" >&2
  exit 1
fi

rm -- "$source_file"
echo "Deleted source PowerPoint file: $source_file"
