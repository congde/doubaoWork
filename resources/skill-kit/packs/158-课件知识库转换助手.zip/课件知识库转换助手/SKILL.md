---
name: convert-ppt-pdf-to-md
description: 将 PPT、PPTX 或 PDF 幻灯片整理成结构清晰、可搜索的 Markdown 知识文档，支持 PDF 文本层、OCR、表格与流程重构，并在证据不足时标记待核对。适用于课程资料、培训课件和演讲幻灯片归档；不默认删除源文件，也不适用于需要保留原版视觉排版的逐像素转换。
---

# PPT/PDF 转 Markdown

目标不是把每页 OCR 原文直接拼起来，而是生成读得懂、搜得到、可继续维护的知识文档。

## 第一次使用

引导用户阅读 [使用指南.md](使用指南.md)，确认系统、输入文件、输出目录、OCR 语言和是否允许安装依赖。源文件默认保留。

## 标准流程

### 1. 明确范围

确定输入文件、输出 Markdown 路径、批量或单文件、目标语言、是否保留页码锚点，以及图表是否允许转写为文字。用户只指定一个文件时，不扩大到整个目录。

### 2. PPTX 转 PDF

如果输入是 PPT/PPTX，优先生成同名 PDF。脚本会拒绝覆盖已有 PDF：

```bash
bash scripts/convert_pptx_to_pdf.sh "/path/to/source.pptx"
```

脚本优先使用 LibreOffice；在 macOS 也可使用 Microsoft PowerPoint。已有 PDF 时先询问是否复用，不要自行删除或覆盖。

### 3. 检查 OCR 环境

```bash
tesseract --list-langs
```

中文常用 `chi_sim+eng`，英文使用 `eng`。缺少语言包时说明安装方法，未获得授权不要修改系统环境。

### 4. 提取页面级中间文本

```bash
uv run --with pymupdf --with pillow --with pytesseract \
  python scripts/extract_ppt_pdf_pages.py "/path/to/source.pdf" \
  --out "/path/to/intermediate" \
  --lang chi_sim+eng \
  --zoom 2.5
```

中间目录包含页面记录、文本层、OCR 和摘要。可以先用 `--pages 1,3-5` 小范围测试。

### 5. 判断可信文本

优先级：正常 PDF 文本层 → OCR 补充 → 有证据支持的版式推断。文本冲突时回到原页核对；仍不确定就写“待核对”，不能猜。

### 6. 整理 Markdown

- 按主题逻辑组织标题，不必机械照搬页码。
- 把图示转成表格、清单、步骤或公式。
- 代码、Prompt 和命令使用合适的代码块。
- 保留来源文件和转换日期。
- 只有文字无法表达关键信息时才保留图片，并明确图片来源。
- 不写未经文本层、OCR 或原页支持的内容。

推荐 frontmatter：

```yaml
---
title: "文档标题"
source_file: "/path/to/source.pdf"
source_type: "PDF"
converted_at: "YYYY-MM-DD"
conversion_note: "基于 PDF 文本层与 OCR 整理；不确定内容已标记待核对。"
---
```

### 7. 验证

检查空文件、OCR 乱码、重复标题、断裂表格、错误链接和意外图片引用。抽查开头、中间、结尾，并对关键数字回看原页。

### 8. 可选删除源 PPT

默认不删除。只有用户明确要求、PDF 和 Markdown 都已验证，并再次确认删除源文件时，才运行：

```bash
bash scripts/delete_pptx_after_success.sh \
  --confirm-delete-source "/path/to/source.pptx" "/path/to/output.md" "/path/to/source.pdf"
```

删除不可由“完成转换”自动推导。

## 失败边界

- 加密、损坏或无法渲染的文件：报告具体页面和错误。
- OCR 语言缺失：停止相关 OCR，不用错误语言硬识别。
- 视觉信息无法可靠文字化：保留必要图片或标记待核对。
- 输出已存在：先询问覆盖、改名或合并，不能擅自覆盖。

