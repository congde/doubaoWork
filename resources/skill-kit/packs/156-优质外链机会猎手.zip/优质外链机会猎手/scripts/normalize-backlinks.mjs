#!/usr/bin/env node

import { createHash } from "node:crypto";
import { createReadStream, createWriteStream } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { once } from "node:events";
import { createInterface } from "node:readline";
import { resolve } from "node:path";

function usage() {
  return `
用法：
  node normalize-backlinks.mjs --input ./run/backlinks.raw.ndjson --output-dir ./run/normalized [--keyword "keyword"]

选项：
  --input <文件>        符合 references/输入数据格式.md 的 NDJSON
  --output-dir <目录>   输出目录
  --keyword <关键词>    可重复指定，用于标记完全匹配锚文本
  --help                显示帮助

说明：此脚本只做确定性去重和风险预筛，不会自动把任何候选归类为“保留”。
`.trim();
}

function parseArgs(argv) {
  const options = { keywords: [] };
  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    if (argument === "--help" || argument === "-h") options.help = true;
    else if (argument === "--input") options.input = requireValue(argv, ++index, argument);
    else if (argument === "--output-dir") options.outputDir = requireValue(argv, ++index, argument);
    else if (argument === "--keyword") options.keywords.push(requireValue(argv, ++index, argument));
    else throw new Error(`未知参数：${argument}`);
  }
  if (!options.help && (!options.input || !options.outputDir)) {
    throw new Error("必须提供 --input 和 --output-dir。");
  }
  return options;
}

function requireValue(argv, index, optionName) {
  const value = argv[index];
  if (!value || value.startsWith("--")) throw new Error(`${optionName} 缺少值。`);
  return value;
}

function sourceDomain(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (!["http:", "https:"].includes(url.protocol)) return "";
    return url.hostname.replace(/^www\./i, "").toLowerCase();
  } catch {
    return "";
  }
}

function linkType(record) {
  if (record.image) return "图片";
  if (record.form) return "表单";
  if (record.frame) return "框架";
  return "文本";
}

function followStatus(record) {
  const values = [];
  if (record.nofollow) values.push("Nofollow");
  if (record.sponsored) values.push("Sponsored");
  if (record.ugc) values.push("UGC");
  return values.length ? values.join("+") : "Follow";
}

function exactKeywordAnchor(anchor, keywords) {
  const normalized = String(anchor || "").trim().toLocaleLowerCase();
  return keywords.some((keyword) => normalized === keyword.trim().toLocaleLowerCase());
}

function prefilter(record, domain, keywords) {
  if (!domain) return { category: "未核实", reasons: ["来源 URL 无效或协议不受支持"] };

  const reasons = [];
  const text = `${record.source_url || ""} ${record.source_title || ""} ${record.anchor || ""}`;
  const sellerRisk = /(buy|sell|cheap|purchase).{0,24}(backlink|link)|aged\s+domains?|pbn/i.test(text);
  const autoRisk = /(website|domain|url).{0,20}(worth|stats|report|checker)|webworth|siteprice|backlinks?-checker/i.test(text);
  const responseCode = Number(record.response_code) || 0;

  if (sellerRisk) reasons.push("存在链接售卖或 PBN 风险信号");
  if (autoRisk) reasons.push("存在自动生成统计或估值页面风险");
  if (responseCode >= 400) reasons.push(`来源页返回 HTTP ${responseCode}`);
  if (record.lostlink) reasons.push("链接已丢失，可能是恢复或替代机会");
  if (record.sitewide) reasons.push("站点级重复链接");
  if ((Number(record.external_link_num) || 0) >= 1000) reasons.push("页面出站链接异常多");
  if (exactKeywordAnchor(record.anchor, keywords)) reasons.push("锚文本与目标关键词完全一致，需检查过度优化风险");

  if (sellerRisk || autoRisk) return { category: "淘汰", reasons };
  if (responseCode >= 400 && !record.lostlink) return { category: "未核实", reasons };
  return { category: "待复核", reasons };
}

function isoDate(value) {
  const number = Number(value);
  if (!Number.isFinite(number) || number <= 0) return "";
  const date = new Date(number > 1e12 ? number : number * 1000);
  return Number.isNaN(date.getTime()) ? "" : date.toISOString();
}

function csvCell(value) {
  let text = value === null || value === undefined ? "" : String(value);
  if (/^[=+@-]/.test(text)) text = `'${text}`;
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function csvRow(normalized) {
  return [
    normalized.分类,
    normalized.原因.join("；"),
    normalized.来源域名,
    normalized.来源URL,
    normalized.来源标题,
    normalized.目标URL,
    normalized.目标标题,
    normalized.锚文本,
    normalized.链接类型,
    normalized.Follow状态,
    normalized.域名分数,
    normalized.页面分数,
    normalized.HTTP状态,
    normalized.出站链接数,
    normalized.站内链接数,
    normalized.站点级,
    normalized.已丢失,
    normalized.首次发现,
    normalized.最后发现,
    normalized.语言
  ];
}

async function writeLine(stream, line) {
  if (!stream.write(line)) await once(stream, "drain");
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    console.log(usage());
    return;
  }

  const outputDir = resolve(options.outputDir);
  await mkdir(outputDir, { recursive: true, mode: 0o700 });
  const ndjsonPath = resolve(outputDir, "backlinks.normalized.ndjson");
  const csvPath = resolve(outputDir, "backlinks.normalized.csv");
  const summaryPath = resolve(outputDir, "normalize-summary.json");
  const ndjson = createWriteStream(ndjsonPath, { flags: "wx", mode: 0o600 });
  const csv = createWriteStream(csvPath, { flags: "wx", mode: 0o600 });
  const columns = [
    "预筛分类", "预筛原因", "来源域名", "来源 URL", "来源标题", "目标 URL", "目标标题",
    "锚文本", "链接类型", "Follow 状态", "域名分数", "页面分数", "HTTP 状态",
    "出站链接数", "站内链接数", "站点级", "已丢失", "首次发现", "最后发现", "语言"
  ];
  await writeLine(csv, `${columns.map(csvCell).join(",")}\r\n`);

  const seen = new Set();
  const counts = {
    input: 0,
    unique: 0,
    duplicate: 0,
    damaged: 0,
    保留: 0,
    待复核: 0,
    未核实: 0,
    淘汰: 0
  };
  const reader = createInterface({
    input: createReadStream(resolve(options.input), { encoding: "utf8" }),
    crlfDelay: Infinity
  });

  try {
    for await (const line of reader) {
      if (!line.trim()) continue;
      counts.input += 1;
      let record;
      try {
        record = JSON.parse(line);
        if (!record || typeof record !== "object" || Array.isArray(record)) {
          throw new Error("记录不是对象");
        }
      } catch {
        counts.damaged += 1;
        counts.unique += 1;
        counts.未核实 += 1;
        const key = createHash("sha256").update(`damaged\u0000${counts.input}\u0000${line}`).digest("hex");
        const damaged = {
          分类: "未核实",
          原因: [`原始记录损坏（第 ${counts.input} 行）`],
          来源域名: "",
          来源URL: "",
          来源标题: "",
          目标URL: "",
          目标标题: "",
          锚文本: "",
          链接类型: "未知",
          Follow状态: "未知",
          域名分数: "",
          页面分数: "",
          HTTP状态: "",
          出站链接数: "",
          站内链接数: "",
          站点级: false,
          已丢失: false,
          首次发现: "",
          最后发现: "",
          语言: "",
          去重键: key
        };
        await writeLine(ndjson, `${JSON.stringify(damaged)}\n`);
        await writeLine(csv, `${csvRow(damaged).map(csvCell).join(",")}\r\n`);
        continue;
      }

      const type = linkType(record);
      const key = createHash("sha256")
        .update(`${record.source_url || ""}\u0000${record.target_url || ""}\u0000${record.anchor || ""}\u0000${type}`)
        .digest("hex");
      if (seen.has(key)) {
        counts.duplicate += 1;
        continue;
      }
      seen.add(key);
      counts.unique += 1;

      const domain = sourceDomain(record.source_url);
      const prefilterResult = prefilter(record, domain, options.keywords);
      counts[prefilterResult.category] += 1;
      const normalized = {
        分类: prefilterResult.category,
        原因: prefilterResult.reasons,
        来源域名: domain,
        来源URL: record.source_url || "",
        来源标题: record.source_title || "",
        目标URL: record.target_url || "",
        目标标题: record.target_title || "",
        锚文本: record.anchor || "",
        链接类型: type,
        Follow状态: followStatus(record),
        域名分数: record.domain_ascore ?? "",
        页面分数: record.page_ascore ?? "",
        HTTP状态: record.response_code ?? "",
        出站链接数: record.external_link_num ?? "",
        站内链接数: record.internal_link_num ?? "",
        站点级: Boolean(record.sitewide),
        已丢失: Boolean(record.lostlink),
        首次发现: isoDate(record.first_seen),
        最后发现: isoDate(record.last_seen),
        语言: record.lang || "",
        去重键: key
      };
      await writeLine(ndjson, `${JSON.stringify(normalized)}\n`);
      await writeLine(csv, `${csvRow(normalized).map(csvCell).join(",")}\r\n`);
    }
  } finally {
    ndjson.end();
    csv.end();
    await Promise.all([once(ndjson, "close"), once(csv, "close")]);
  }

  const summary = {
    status: "已完成",
    input_records: counts.input,
    unique_records: counts.unique,
    duplicate_records: counts.duplicate,
    damaged_records: counts.damaged,
    categories: {
      保留: counts.保留,
      待复核: counts.待复核,
      未核实: counts.未核实,
      淘汰: counts.淘汰
    },
    note: "确定性预筛不会自动产生“保留”；最终分类必须结合真实来源页、数据来源范围和项目匹配度。"
  };
  await writeFile(summaryPath, `${JSON.stringify(summary, null, 2)}\n`, { mode: 0o600 });
  console.log(`已完成：输入 ${counts.input}，去重后 ${counts.unique}，重复 ${counts.duplicate}。`);
  console.log(`规范化数据：${ndjsonPath}`);
  console.log(`CSV：${csvPath}`);
}

main().catch((error) => {
  console.error(`已暂停：${error instanceof Error ? error.message : String(error)}`);
  process.exitCode = 1;
});
