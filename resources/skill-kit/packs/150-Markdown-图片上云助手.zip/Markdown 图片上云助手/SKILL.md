---
name: upload-markdown-images
description: 使用用户已经配置好的 PicGo-Core 上传本地图片，验证公开 HTTPS 地址，并生成或替换 Markdown、Obsidian 图片链接。适用于把本地截图、附件和生成图片变成可移植网络链接；不自动上传敏感图片，不修改 PicGo 凭据，也不在没有文件修改授权时执行上传。
---

# Markdown 图片上传

复用用户已有的 PicGo-Core 上传配置，不在 Skill 中保存云厂商密钥。上传是把文件公开到远程存储的外部动作，必须先确认图片范围和隐私风险。

## 第一次使用

引导用户阅读 [使用指南.md](使用指南.md)。确认 PicGo-Core 已安装并配置了可用的上传器。可以从 Obsidian 图片自动上传插件发现 PicGo 路径，也可以直接提供 `--picgo-path`。

## 标准流程

### 1. 确认范围与隐私

列出要上传的每张本地图片和要修改的 Markdown 文件。已有可用 HTTPS 图片默认保持不变。身份证件、私人邮件、健康记录、访问令牌、后台截图或包含敏感信息的图片，必须先脱敏并得到明确确认。

### 2. 只读检查

通过 Obsidian Vault 发现 PicGo：

```bash
python3 scripts/upload_images.py --check --vault-root "/path/to/vault"
```

或直接指定 PicGo-Core：

```bash
python3 scripts/upload_images.py --check --picgo-path "/path/to/picgo"
```

检查不会上传图片，也不会输出 PicGo 凭据。

### 3. 预演

```bash
python3 scripts/upload_images.py \
  --dry-run \
  --picgo-path "/path/to/picgo" \
  "/path/to/image.png"
```

确认源文件、MIME 类型和基于内容哈希的临时对象名。

### 4. 上传并验证

```bash
python3 scripts/upload_images.py \
  --picgo-path "/path/to/picgo" \
  "/path/to/first.png" "/path/to/second.jpg"
```

每项结果必须满足 `ok: true`、存在 HTTPS `url` 且 `verified: true`，才允许把链接写进 Markdown。`--no-verify` 只能在用户明确接受未验证链接时使用。

### 5. 修改 Markdown

- 使用与正文含义相符的替代文本，不直接采用无意义文件名。
- 多图上传出现部分失败时，默认不批量修改 Markdown；报告成功 URL，并只重试失败项。
- 保留本地源图片，不删除、不移动、不修改 PicGo 配置。
- 写后重新读取 Markdown，检查链接、括号、替代文本和远程访问。

## 配置发现顺序

1. `--picgo-path` 明确指定的 PicGo-Core。
2. `--vault-root` 对应 Obsidian 插件配置中的 `picgoCorePath`。
3. 当前系统 `PATH` 中的 `picgo`。

Skill 不绑定 Cloudflare R2、S3、GitHub、又拍云或其他厂商；具体上传目标由用户自己的 PicGo 配置决定。

## 停止条件

- PicGo、上传器、网络或公开 URL 验证不可用。
- 图片可能泄露敏感数据且用户未确认。
- 用户只要求草稿、审查或计划，没有授权文件修改和公开上传。
- 上传返回内容不包含 HTTPS URL。

失败时隐藏原始 PicGo 日志中可能包含的凭据，只报告安全、可行动的错误摘要。

