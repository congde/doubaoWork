#!/usr/bin/env python3
"""通过用户已有的 PicGo-Core 配置上传本地图片并返回 Markdown。"""

from __future__ import annotations

import argparse
import hashlib
import json
import mimetypes
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


PLUGIN_SETTINGS = Path(
    ".obsidian/plugins/obsidian-image-auto-upload-plugin/data.json"
)
URL_RE = re.compile(r"https://[^\s<>\"]+")
UPLOAD_TIMEOUT_SECONDS = 180
VERIFY_TIMEOUT_SECONDS = 20


class UploadError(RuntimeError):
    """A safe-to-report upload error."""


def is_vault_root(candidate: Path) -> bool:
    return (
        candidate.is_dir()
        and (candidate / ".obsidian").is_dir()
    )


def find_vault_root(explicit_root: str | None = None) -> Path:
    if explicit_root:
        requested = Path(explicit_root).expanduser().resolve()
        if is_vault_root(requested):
            return requested
        raise UploadError(f"指定路径不是有效知识库：{requested}")

    starts = (Path.cwd().resolve(), Path(__file__).resolve().parent)
    for start in starts:
        for candidate in (start, *start.parents):
            if is_vault_root(candidate):
                return candidate
    raise UploadError("无法自动定位 Obsidian Vault；请使用 --vault-root 指定")


def load_picgo_integration(
    vault_root: Path | None,
    explicit_picgo: str | None = None,
) -> tuple[Path, dict[str, Any]]:
    settings: dict[str, Any] = {}
    settings_path: Path | None = None
    if vault_root is not None:
        settings_path = vault_root / PLUGIN_SETTINGS
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            settings = {}
        except (OSError, json.JSONDecodeError) as exc:
            raise UploadError("无法读取 Obsidian 图片上传配置") from exc

    candidates: list[Path] = []
    if explicit_picgo:
        candidates.append(Path(explicit_picgo).expanduser())

    configured = str(settings.get("picgoCorePath") or "").strip()
    try:
        if configured:
            configured_path = Path(configured).expanduser()
            if not configured_path.is_absolute():
                configured_on_path = shutil.which(configured)
                if configured_on_path:
                    configured_path = Path(configured_on_path)
            candidates.append(configured_path)
    except (OSError, RuntimeError) as exc:
        raise UploadError("Obsidian 中配置的 PicGo 路径无效") from exc
    path_picgo = shutil.which("picgo")
    if path_picgo:
        candidates.append(Path(path_picgo))

    picgo_path = next((path for path in candidates if path.is_file()), None)
    if picgo_path is None:
        raise UploadError("未找到 PicGo-Core 可执行文件")

    integration = {
        "obsidian_auto_paste_enabled": bool(
            settings.get("uploadByClipSwitch")
        ),
        "obsidian_uploader": settings.get("uploader"),
        "obsidian_settings_path": str(settings_path) if settings_path else None,
        "configured_picgo_path_exists": bool(
            configured and candidates and candidates[0].is_file()
        ),
    }
    return picgo_path.resolve(), integration


def run_picgo_read_only(picgo_path: Path, *arguments: str) -> str:
    try:
        process = subprocess.run(
            [str(picgo_path), *arguments],
            check=False,
            capture_output=True,
            text=True,
            timeout=20,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise UploadError("PicGo-Core 只读检查失败") from exc
    output = "\n".join((process.stdout, process.stderr)).strip()
    if process.returncode != 0 or not output:
        raise UploadError("PicGo-Core 无法正常执行只读检查")
    return output


def inspect_picgo(picgo_path: Path) -> str:
    version_output = run_picgo_read_only(picgo_path, "--version")
    version = version_output.splitlines()[-1]
    return version


def inspect_credential_permissions() -> dict[str, Any]:
    config_path = Path.home() / ".picgo/config.json"
    if not config_path.is_file():
        return {
            "config_path": str(config_path),
            "exists": False,
            "mode": None,
            "secure": False,
            "warning": "PicGo 默认配置文件不存在",
        }

    mode = config_path.stat().st_mode & 0o777
    secure = mode & 0o077 == 0
    return {
        "config_path": str(config_path),
        "exists": True,
        "mode": oct(mode),
        "secure": secure,
        "warning": (
            None
            if secure
            else "PicGo 凭证文件可被其他本地用户读取；未自动修改权限"
        ),
    }


def detect_mime(path: Path) -> str:
    file_bin = shutil.which("file")
    if file_bin:
        process = subprocess.run(
            [file_bin, "--brief", "--mime-type", str(path)],
            check=False,
            capture_output=True,
            text=True,
        )
        if process.returncode == 0:
            return process.stdout.strip()
    return mimetypes.guess_type(path.name)[0] or "application/octet-stream"


def validate_source(raw_path: str) -> tuple[Path, str, str]:
    source = Path(raw_path).expanduser().resolve()
    if not source.is_file():
        raise UploadError(f"图片文件不存在：{source}")
    if source.stat().st_size == 0:
        raise UploadError(f"图片文件为空：{source}")

    mime = detect_mime(source)
    if not mime.startswith("image/"):
        raise UploadError(f"不是可识别的图片文件：{source}（{mime}）")

    digest = hashlib.sha256()
    with source.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)

    suffix = source.suffix.lower()
    if not suffix:
        suffix = mimetypes.guess_extension(mime) or ".img"
    staged_name = f"codex-{digest.hexdigest()[:16]}{suffix}"
    return source, mime, staged_name


def extract_url(output: str) -> str:
    candidates = []
    for match in URL_RE.findall(output):
        candidate = match.rstrip(".,;:!?)']}")
        if candidate.startswith("https://"):
            candidates.append(candidate)
    if not candidates:
        raise UploadError("PicGo 未返回 HTTPS 图片链接")
    return candidates[-1]


def verify_public_image(url: str) -> dict[str, Any]:
    headers = {"User-Agent": "Markdown-Image-Verifier/1.0"}
    attempts = (
        Request(url, headers=headers, method="HEAD"),
        Request(url, headers={**headers, "Range": "bytes=0-0"}, method="GET"),
    )
    last_error = ""
    for request in attempts:
        try:
            with urlopen(request, timeout=VERIFY_TIMEOUT_SECONDS) as response:
                status = int(getattr(response, "status", 200))
                content_type = response.headers.get_content_type()
                if 200 <= status < 400 and content_type.startswith("image/"):
                    return {
                        "verified": True,
                        "status": status,
                        "content_type": content_type,
                    }
                last_error = f"HTTP {status}, Content-Type {content_type}"
        except HTTPError as exc:
            last_error = f"HTTP {exc.code}"
        except (URLError, TimeoutError, OSError) as exc:
            last_error = exc.__class__.__name__
    return {
        "verified": False,
        "status": None,
        "content_type": None,
        "verification_error": last_error or "未知网络错误",
    }


def upload_one(
    picgo_path: Path,
    source: Path,
    mime: str,
    staged_name: str,
    verify: bool,
    temp_dir: Path,
) -> dict[str, Any]:
    staged_path = temp_dir / staged_name
    shutil.copy2(source, staged_path)
    try:
        process = subprocess.run(
            [str(picgo_path), "upload", str(staged_path)],
            check=False,
            capture_output=True,
            text=True,
            timeout=UPLOAD_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired as exc:
        raise UploadError(f"PicGo 上传超时：{source}") from exc
    except OSError as exc:
        raise UploadError(f"PicGo 无法启动：{source}") from exc

    combined = "\n".join((process.stdout, process.stderr))
    if process.returncode != 0 or "PicGo ERROR" in combined:
        raise UploadError(
            f"PicGo 上传失败：{source}（原始日志已隐藏，避免泄露凭证）"
        )

    url = extract_url(combined)
    verification: dict[str, Any]
    if verify:
        verification = verify_public_image(url)
    else:
        verification = {
            "verified": False,
            "status": None,
            "content_type": None,
            "verification_error": "按用户要求跳过公开 URL 验证",
        }

    alt = source.stem.replace("\\", "\\\\").replace("]", "\\]")
    return {
        "source": str(source),
        "mime": mime,
        "object_name": staged_name,
        "url": url,
        "markdown": f"![{alt}]({url})",
        **verification,
    }


def emit(payload: dict[str, Any], exit_code: int = 0) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    raise SystemExit(exit_code)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="通过用户已有的 PicGo-Core 配置上传图片并返回 Markdown"
    )
    parser.add_argument("images", nargs="*", help="一个或多个本地图片绝对路径")
    parser.add_argument(
        "--check",
        action="store_true",
        help="只检查 Obsidian 与 PicGo-Core 集成，不上传",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="校验图片并显示计划对象名，不上传",
    )
    parser.add_argument(
        "--no-verify",
        action="store_true",
        help="上传后不检查公开 URL（仅在用户明确接受时使用）",
    )
    parser.add_argument(
        "--vault-root",
        help="Obsidian Vault 根目录；用于发现插件中的 PicGo 路径",
    )
    parser.add_argument(
        "--picgo-path",
        help="PicGo-Core 可执行文件路径；提供后可不依赖 Obsidian 插件",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    completed: list[dict[str, Any]] = []
    try:
        vault_root = find_vault_root(args.vault_root) if args.vault_root else None
        if vault_root is None and not args.picgo_path:
            try:
                vault_root = find_vault_root()
            except UploadError:
                vault_root = None
        picgo_path, obsidian_integration = load_picgo_integration(
            vault_root, args.picgo_path
        )
        version = inspect_picgo(picgo_path)
        credential_permissions = inspect_credential_permissions()

        if args.check:
            emit(
                {
                    "ok": True,
                    "mode": "check",
                    "vault_root": str(vault_root) if vault_root else None,
                    "picgo_path": str(picgo_path),
                    "picgo_version": version,
                    "picgo_ready": True,
                    "obsidian_integration": obsidian_integration,
                    "credential_permissions": credential_permissions,
                    "uploaded": False,
                }
            )

        if not args.images:
            raise UploadError("请至少提供一个本地图片路径")

        validated = [validate_source(raw_path) for raw_path in args.images]
        if args.dry_run:
            emit(
                {
                    "ok": True,
                    "mode": "dry-run",
                    "uploaded": False,
                    "results": [
                        {
                            "source": str(source),
                            "mime": mime,
                            "object_name": staged_name,
                        }
                        for source, mime, staged_name in validated
                    ],
                }
            )

        with tempfile.TemporaryDirectory(
            prefix="markdown-image-upload-"
        ) as temp_dir_name:
            temp_dir = Path(temp_dir_name)
            for source, mime, staged_name in validated:
                result = upload_one(
                    picgo_path=picgo_path,
                    source=source,
                    mime=mime,
                    staged_name=staged_name,
                    verify=not args.no_verify,
                    temp_dir=temp_dir,
                )
                completed.append(result)
                if not args.no_verify and not result["verified"]:
                    raise UploadError(
                        f"图片已上传，但公开链接验证失败：{result['url']}"
                    )

        emit(
            {
                "ok": True,
                "mode": "upload",
                "uploaded": True,
                "all_verified": all(item["verified"] for item in completed),
                "results": completed,
            }
        )
    except UploadError as exc:
        emit(
            {
                "ok": False,
                "error": str(exc),
                "completed": completed,
            },
            exit_code=1,
        )


if __name__ == "__main__":
    main()
