' Silent launcher template for watchdog.py
' Copy this file into the Windows Startup folder and edit the 2 paths below.
' Kept pure ASCII on purpose to avoid VBS codepage issues with CJK comments.

Option Explicit

Dim ws, fso, py, cands, c, cmd, workdir, script

' ===== EDIT THESE TWO LINES =====
script  = "D:\myapp\watchdog.py"
workdir = "D:\myapp"
' ================================

Set ws  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' pythonw.exe preferred: it never opens a console window.
' Falls back to python.exe, which VBS still hides via the 0 window style.
py = ""
cands = Array( _
  "C:\Users\xjl\.workbuddy\binaries\python\versions\3.13.12\pythonw.exe", _
  "C:\Users\xjl\.workbuddy\binaries\python\versions\3.13.12\python.exe", _
  "C:\Python313\pythonw.exe", _
  "C:\Python313\python.exe", _
  "C:\Python312\python.exe", _
  "C:\Python311\python.exe" _
)
For Each c In cands
  If fso.FileExists(c) Then
    py = c
    Exit For
  End If
Next

If py = "" Then WScript.Quit
If Not fso.FileExists(script) Then WScript.Quit

cmd = Chr(34) & py & Chr(34) & " " & Chr(34) & script & Chr(34)
ws.CurrentDirectory = workdir
ws.Run cmd, 0, False
