# -*- coding: utf-8 -*-
r"""
通用用户态看门狗模板 —— Windows / 无需管理员权限

让任意后台进程常驻，并在崩溃后自动拉起。
由「启动」目录（Startup）里的 VBS 在登录时拉起，父进程是 explorer.exe，
因此不会随某个命令行会话退出而被杀（这是本方案的关键）。

────────────────────────────────────────────────────────
使用方式：只改下面「配置区」的 8 个常量，其余不用动。
然后用 scripts/start-silent.vbs 复制到启动目录即可。
────────────────────────────────────────────────────────
"""
import ctypes
import io
import os
import subprocess
import sys
import time
import urllib.request

# ══════════════════════════ 配置区（改这里） ══════════════════════════

APP_NAME = "MyApp"                       # 用于互斥体名与日志前缀，同机器上唯一
APP_DIR = r"D:\myapp"                    # 工作目录
APP_EXE = r"D:\myapp\app.exe"            # 被守护的程序
APP_ARGS = ["--serve"]                   # 启动参数（无参数就写 []）

HEALTH_MODE = "http"                     # "http"    = 探测 URL 是否有响应
                                         # "process" = 只判断进程是否存在
HEALTH_TARGET = "http://127.0.0.1:8080/"  # http 模式：URL
                                         # process 模式：进程名，如 "app.exe"

LOG_PATH = r"D:\myapp\watchdog.log"
CHECK_INTERVAL = 20          # 探测间隔（秒）
STARTUP_WAIT = 30            # 拉起后最多等多少秒判定就绪
KILL_AFTER_FAILS = 3         # 连续失败几次后强杀僵尸进程再拉起
LOG_MAX_BYTES = 1024 * 1024  # 日志超过 1MB 自动截断

# ════════════════════════════════════════════════════════════════════

MUTEX_NAME = "Global\\Watchdog_%s" % APP_NAME
ERROR_ALREADY_EXISTS = 183
CREATE_NO_WINDOW = 0x08000000


def log(msg):
    line = "%s  [%s] %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), APP_NAME, msg)
    try:
        if os.path.exists(LOG_PATH) and os.path.getsize(LOG_PATH) > LOG_MAX_BYTES:
            os.remove(LOG_PATH)
        d = os.path.dirname(LOG_PATH)
        if d and not os.path.isdir(d):
            os.makedirs(d)
        with io.open(LOG_PATH, "a", encoding="utf-8", newline="\n") as f:
            f.write(line + "\n")
    except Exception:
        pass
    print(line, flush=True)


def single_instance():
    """返回 True 表示本进程是唯一实例。非管理员也能创建 Global\\ 互斥体。"""
    ctypes.windll.kernel32.CreateMutexW(None, False, MUTEX_NAME)
    return ctypes.windll.kernel32.GetLastError() != ERROR_ALREADY_EXISTS


def health_http():
    """探测 URL。必须用 ProxyHandler({}) 绕开系统代理，
    否则本机 127.0.0.1 的请求也会被送进代理而失败。"""
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        opener.open(HEALTH_TARGET, timeout=3).read()
        return True
    except Exception:
        return False


def health_process():
    """判断进程是否存在。"""
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq " + HEALTH_TARGET],
                             capture_output=True, text=True,
                             creationflags=CREATE_NO_WINDOW)
        return HEALTH_TARGET.lower() in out.stdout.lower()
    except Exception:
        return False


def is_alive():
    return health_http() if HEALTH_MODE == "http" else health_process()


def kill_stale():
    """清掉「进程还在但服务不响应」的僵尸实例。"""
    target = HEALTH_TARGET if HEALTH_MODE == "process" else os.path.basename(APP_EXE)
    try:
        out = subprocess.run(["taskkill", "/F", "/IM", target],
                             capture_output=True, text=True,
                             creationflags=CREATE_NO_WINDOW)
        if "SUCCESS" in out.stdout.upper() or "成功" in out.stdout:
            log("killed stale process: %s" % target)
            time.sleep(1)
    except Exception:
        pass


def start_app():
    try:
        subprocess.Popen([APP_EXE] + list(APP_ARGS), cwd=APP_DIR,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=CREATE_NO_WINDOW)
        return True
    except Exception as e:
        log("start failed: %s" % e)
        return False


def main():
    if not single_instance():
        log("another watchdog instance is running, exit")
        return 0

    log("watchdog started (pid=%s, mode=%s, interval=%ss)"
        % (os.getpid(), HEALTH_MODE, CHECK_INTERVAL))

    if not os.path.exists(APP_EXE):
        log("ERROR: target not found: %s" % APP_EXE)
        return 1

    consecutive_fail = 0
    while True:
        try:
            if is_alive():
                if consecutive_fail:
                    log("service recovered")
                consecutive_fail = 0
            else:
                consecutive_fail += 1
                log("service is DOWN (fail #%d) - restarting ..." % consecutive_fail)
                if consecutive_fail >= KILL_AFTER_FAILS:
                    kill_stale()
                if start_app():
                    ticks = int(STARTUP_WAIT / 0.5)
                    for _ in range(ticks):
                        time.sleep(0.5)
                        if is_alive():
                            log("service is UP again")
                            break
                    else:
                        log("restart attempt timed out after %ss" % STARTUP_WAIT)
        except KeyboardInterrupt:
            log("watchdog stopped by user")
            return 0
        except Exception as e:
            log("unexpected error: %s" % e)
        time.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    sys.exit(main())
