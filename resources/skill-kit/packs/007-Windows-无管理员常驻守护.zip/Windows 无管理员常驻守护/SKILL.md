---
name: windows-userland-daemon
description: 在 Windows 无管理员权限下让后台进程常驻并实现崩溃自愈。用「启动」目录（Startup）在登录时拉起看门狗脚本，父进程是 explorer.exe 因而不会随命令行会话退出被杀；配合 Windows 命名互斥体做单实例保护，周期性探测 HTTP 端口或进程名，挂了自动拉起。当用户提出「让 XX 后台一直跑」「进程开机自启」「崩溃后自动重启」「没有管理员怎么建守护进程」「常驻服务保活」「AList / 本地服务挂了自动拉起」等需求时触发。
agent_created: true
---

# Windows 用户态常驻守护（windows-userland-daemon）

## 用途

在没有管理员权限的 Windows 机器上，让任意后台进程**登录即启动、崩溃后自动重启**。
典型场景：本地 Web 服务（AList、自研 server.py、内网工具）、需要长期跑的脚本。

## 核心原理（先理解这个，否则会走弯路）

**由命令行会话启动的进程，活不过那个会话。** 已实测三种方式全部失效：

| 启动方式 | 结果 |
|---|---|
| Bash `run_in_background` | 工具调用结束后子进程被杀 |
| Bash `(cmd &)` | 同上 |
| PowerShell `Start-Process` | 同上 |

**正解**：把启动器放进 **Startup 目录**，由 Windows 在登录时拉起。
此时父进程是 `explorer.exe`，不依赖任何命令行会话，因此可长期存活——
**崩溃自愈也就顺带成为可能**，不需要计划任务、不需要管理员。

```
Startup 目录的 VBS（登录时，explorer.exe 拉起）
        │
        └─► watchdog.py（常驻，每 N 秒探测一次）
                 │  发现服务挂了
                 └─► 重新拉起目标进程
```

## 三步部署

### 第 1 步：改 watchdog 配置

复制 `scripts/watchdog.py` 到目标目录，只改顶部的 8 个常量：

```python
APP_NAME = "MyApp"                        # 同机器上唯一，用于互斥体名
APP_DIR  = r"D:\myapp"                    # 工作目录
APP_EXE  = r"D:\myapp\app.exe"
APP_ARGS = ["--serve"]

HEALTH_MODE   = "http"                    # "http" 或 "process"
HEALTH_TARGET = "http://127.0.0.1:8080/"  # http 模式填 URL；process 模式填进程名
LOG_PATH      = r"D:\myapp\watchdog.log"
```

`HEALTH_MODE` 怎么选：服务有 HTTP 端口就用 `"http"`（更可靠，能识破"进程在但已卡死"）；
没有端口的纯后台脚本用 `"process"`。

### 第 2 步：装进启动目录

复制 `scripts/start-silent.vbs` 到 Startup 目录，改文件里那 2 行路径：

```
%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\
```

VBS 里改：

```vbs
script  = "D:\myapp\watchdog.py"
workdir = "D:\myapp"
```

> VBS 会优先找 `pythonw.exe`（永不弹控制台窗口），找不到才退回 `python.exe`。
> 已确认本机 managed Python 带 `pythonw.exe`：
> `C:\Users\xjl\.workbuddy\binaries\python\versions\3.13.12\pythonw.exe`

### 第 3 步：验证自愈（必做，别跳过）

杀掉目标进程，看它是否自己回来：

```bash
taskkill //F //IM app.exe
sleep 5
tasklist | grep -i app || echo "still down - 检查 watchdog.log"
```

预期：在 `CHECK_INTERVAL`（默认 20 秒）+ 启动时间内自动恢复。
AList 实测：**2 秒发现、4 秒恢复**。

## 已验证的环境限制（本机账户非 Administrators）

这些路都堵死过，**不要重复尝试**：

| 方案 | 结果 |
|---|---|
| `Register-ScheduledTask` | 拒绝访问（需管理员） |
| `schtasks.exe` | 被安全策略拦截（Known LOLBin） |
| UAC 提权 `Start-Process -Verb RunAs` | UAC 弹窗根本不出现 |
| WMI / CIM `Win32_Process.Create` | 被拦截，等同 Start-Process |
| 注册为 Windows 服务 | 需管理员 |

**可用的**：读写用户目录与 D 盘、Startup 目录自启、读写 HKCU、PowerShell 原生 cmdlet、
**创建 `Global\` 命名空间互斥体**（非管理员也返回 GetLastError=0，可用于单实例保护）。

## 踩坑清单

- **探测本地端口必须绕开代理**：`urllib.request.build_opener(urllib.request.ProxyHandler({}))`。
  本机有代理环境变量，直接 `urlopen("http://127.0.0.1:...")` 会被送进代理而失败，
  误判成"服务挂了"。
- **Python 模块文档字符串里的 Windows 路径要写成 raw**（`r"""..."""`）。
  `\N` 之类会被当转义符，导致脚本静默异常。
- **VBS 内容保持纯 ASCII**。中文注释遇代码页问题会炸；注释用英文。
- **写日志用 `io.open(..., encoding="utf-8", newline="\n")`**，避免 BOM。
- **被守护的进程要用 `creationflags=0x08000000`**（CREATE_NO_WINDOW），否则会弹出控制台窗口。
- 看门狗自己要用 `pythonw.exe` 启动，否则桌面常驻一个黑框。

## 什么时候不该用这套

- 目标程序**自带服务模式**（能注册为 Windows 服务）→ 优先用那个，更稳。
- 需要在**用户登录前**就运行 → 这套不行，必须是服务 + 管理员。
- **Linux 服务器** → 用 systemd，本技能不适用。

## 关联

本模式已用于 `D:\NetDiskMount\alist-guard.py`（AList 看门狗，生产运行中）。
那份是 AList 专用版；新项目请从本技能的通用模板改，不要直接复制专用版。
