# AI Image Generator Plugin

[中文](README_CN.md) | English

Generate high-quality AI images using ModelScope's Tongyi Wanxiang (通义万相) model.

> 💡 适用于 Claude Code、Cursor、VS Code Copilot、Windsurf、Trae 等支持 Claude Code 插件的 AI 编程工具

## Usage

### Method 1: Natural Language

Simply describe the image you want, and Claude will automatically recognize and invoke this skill:

- "画一张图，一只可爱的猫咪坐在月亮上"
- "生成一张日落山景的图片"
- "Generate an image of a sunset over mountains"
- "Draw me a futuristic city"

### Method 2: Slash Command

```
/ai-image-gen:ai-image-gen <image description>
```

## Prerequisites

### 1. Configure API Key

Set the ModelScope API Key environment variable:

```bash
# macOS / Linux
export MODELSCOPE_API_KEY=<your-key>

# Windows (CMD)
set MODELSCOPE_API_KEY=<your-key>

# Windows (PowerShell)
$env:MODELSCOPE_API_KEY='<your-key>'
```

Get your API Key from the ModelScope platform (modelscope.cn)

### 2. Install Python Dependencies

```bash
pip install requests Pillow
```

## Available Models

| Model ID | Description |
|----------|-------------|
| `Tongyi-MAI/Z-Image-Turbo` | Fast generation (default) |
| `Tongyi-MAI/Z-Image` | Higher quality, slower |

## Tips for Better Results

1. **Be specific**: "A golden retriever puppy playing in autumn leaves" is better than "a dog"
2. **Add style**: Specify style like "Studio Ghibli style", "photorealistic", "oil painting"
3. **Include details**: Describe lighting, mood, composition, colors
4. **Use English**: The model works better with English prompts; Claude will help translate and optimize

## Example

**User input:**
> 帮我画一只在月亮上的猫

**Claude will:**
1. Optimize the prompt to English
2. Call the generation script
3. Display the generated image
4. Ask if adjustments are needed

## License

MIT License
