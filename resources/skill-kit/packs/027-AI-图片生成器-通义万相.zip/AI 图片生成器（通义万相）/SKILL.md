---
name: ai-image-gen
author: 雪见
description: Generate AI images using ModelScope's Tongyi Wanxiang (通义万相) model. Use this skill whenever the user asks to generate an image, create a picture, draw something, or mentions AI image generation - even if they don't explicitly say "generate image". Triggers on phrases like "画一张图", "生成图片", "create an image", "draw me", "generate a picture", "make an illustration", etc.
---

# AI Image Generator

Generate high-quality AI images using ModelScope's Tongyi Wanxiang (通义万相) model.

## When to use this skill

Use this skill when the user wants to:
- Generate an AI image from a text description
- Create artwork or illustrations
- Visualize concepts or ideas
- Generate photos or pictures

**Trigger phrases (examples):**
- "生成一张图片" / "画一张图"
- "Create an image of..."
- "Draw me a..."
- "Generate a picture showing..."
- "Make an illustration of..."
- "我想要一张...的图"

## How to use

### Step 1: Understand the user's request

Extract the image description from the user's request. If the description is vague, ask clarifying questions:
- What style? (realistic, cartoon, oil painting, etc.)
- What mood? (bright, dark, dramatic, etc.)
- Any specific details? (colors, composition, etc.)

### Step 2: Enhance the prompt (optional but recommended)

For better results, you can enhance the user's prompt with additional details:
- Add style modifiers (e.g., "in the style of...", "photorealistic", "digital art")
- Add quality modifiers (e.g., "highly detailed", "4k", "professional")
- Keep the prompt in English for best results with the model

### Step 3: Run the generation script

Execute the image generation script:

```bash
python ${CLAUDE_SKILL_DIR}/scripts/generate_image.py "your enhanced prompt" --output <output-path>
```

**Parameters:**
- `prompt` (required): Text description of the image
- `--output, -o`: Output file path (default: generated_image.jpg)
- `--model, -m`: Model ID (default: Tongyi-MAI/Z-Image-Turbo)

**Example:**
```bash
python ${CLAUDE_SKILL_DIR}/scripts/generate_image.py \
  "A majestic golden cat sitting on a velvet throne, photorealistic, dramatic lighting" \
  --output ./cat_throne.jpg
```

### Step 4: Show the result

After generation:
1. Confirm the image was saved successfully
2. Use the Read tool to display the image to the user
3. Ask if they want any modifications or additional images

## Prerequisites

**Required environment variable:**
```bash
export MODELSCOPE_API_KEY=<your-key>
```

The user needs a ModelScope API key. If not set, the script will prompt the user to configure it.

**Required Python packages:**
- `requests`
- `Pillow` (PIL)

Install with:
```bash
pip install requests Pillow
```

## Available models

| Model ID | Description |
|----------|-------------|
| `Tongyi-MAI/Z-Image-Turbo` | Fast generation (default) |
| `Tongyi-MAI/Z-Image` | Higher quality, slower |

## Tips for better results

1. **Be specific**: "A golden retriever puppy playing in autumn leaves" > "a dog"
2. **Add style**: "in the style of Studio Ghibli", "photorealistic", "oil painting"
3. **Include details**: lighting, mood, composition, colors
4. **Use English**: The model works best with English prompts
5. **Avoid negative phrasing**: Say what you want, not what you don't want

## Example workflow

**User:** "帮我画一只在月亮上的猫"

**Your response:**
1. Enhance prompt: "A fluffy white cat sitting on the crescent moon, starry night sky background, dreamy atmosphere, digital art style"
2. Run script:
   ```bash
   python ${CLAUDE_SKILL_DIR}/scripts/generate_image.py \
     "A fluffy white cat sitting on the crescent moon, starry night sky background, dreamy atmosphere, digital art style" \
     --output moon_cat.jpg
   ```
3. Show the generated image to the user
4. Ask: "这是生成的图片，你觉得怎么样？需要调整吗？"
