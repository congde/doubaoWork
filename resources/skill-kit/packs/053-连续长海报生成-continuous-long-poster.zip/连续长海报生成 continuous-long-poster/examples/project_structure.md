# 项目产物结构

```text
项目名称/
├── input/
│   └── 用户素材
├── plans/
│   ├── poster_plan.json
│   └── stitch_plan.json
├── segments/
│   ├── 01_开场.png
│   ├── 02_发展.png
│   ├── 03_收束.png
│   └── generation_manifest.json
├── previews/
│   ├── contact_sheet.jpg
│   └── seam_01_02.png
├── final/
│   ├── final_long_poster.png
│   └── stitch_manifest.json
└── qc/
    ├── qc_report.json
    └── final_preview.jpg
```
