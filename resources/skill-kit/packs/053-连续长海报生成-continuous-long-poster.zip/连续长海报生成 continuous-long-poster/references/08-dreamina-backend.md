# 即梦（Dreamina）CLI 后端使用说明

`generate_segments.py` 是 continuous-long-poster 的生图后端，调用本地 `dreamina` 命令行
（即梦 / Dreamina）生成连续分段图。它读取 `poster_plan.json` 并应用同一套构图 / 连续性 /
文字白名单约束，把"一段段画出来"这一步交给即梦完成。

## 前置条件

> `dreamina` 命令来自 WorkBuddy 的 **`dreamina-cli`** 技能（Connector）。
> 接收者若还没有，请先在 WorkBuddy 中安装并启用该技能，再继续本步骤。

1. `dreamina` CLI 已安装并在 PATH 中：

   ```bash
   dreamina -h
   ```

2. 已登录（OAuth Device Flow）：

   ```bash
   dreamina login        # 打印 verification_uri / user_code，浏览器授权后自动完成
   dreamina relogin      # 重新登录
   ```

3. 额度充足（即梦生图消耗 credits）：

   ```bash
   dreamina user_credit  # 查看 total_credit
   ```

   生成前务必确认，并在回复中向用户说明本次会消耗额度。

## 支持的组合（以 CLI `-h` 为准，不要凭记忆硬编码）

- `model_version`：`4.0 / 4.1 / 4.5 / 4.6 / 4.7 / 5.0 / 5.0Pro`
- `ratio`：`21:9 / 16:9 / 3:2 / 4:3 / 1:1 / 3:4 / 2:3 / 9:16`
- `resolution_type`：4.0~5.0 支持 `2k / 4k`；**5.0Pro 支持 `1k / 2k / 4k`**
- `--resolution_type` 必填
- `image2image --images`：一次最多 **10 张**本地图片（逗号分隔）

长海报推荐默认值：`--ratio 9:16 --resolution-type 2k --model-version 5.0Pro`
（5.0Pro + 9:16 + 2K 输出约 1440×2560；最终尺寸以 `query_result` 返回为准）。

## 运行方式

```bash
python "{baseDir}/scripts/generate_segments.py" \
  --plan "<项目目录>/plans/poster_plan.json" \
  --output-dir "<项目目录>/segments" \
  --ratio 9:16 --resolution-type 2k --model-version 5.0Pro \
  --resume
```

常用参数：

| 参数 | 说明 |
|------|------|
| `--plan` | `poster_plan.json` |
| `--output-dir` | 分段图输出目录 |
| `--ratio` | 默认 `9:16` |
| `--resolution-type` | 默认 `2k` |
| `--model-version` | 默认 `5.0Pro` |
| `--session` | 即梦会话 id（默认 0） |
| `--resume` | 跳过已存在的分段 |
| `--force` | 忽略已存在，强制重做 |
| `--only 3,4` | 仅生成指定序号 |
| `--poll-timeout` | 单段轮询上限（秒），默认 360 |
| `--dry-run` | 只写各段 prompt，不调用即梦 |
| `--no-credit-check` | 跳过启动时的额度检查 |

## 参考图规则（关键）

脚本按以下顺序收集每张分段图的参考图：

1. **上一段成图**（连续性最强，必须保留）；
2. 本段 `segment.reference_images`（可选，适合放该段专属配图，如项目案例图）；
3. 全局 `assets.reference_images` / `assets.character_images` / `assets.brand_images`
   （Logo、吉祥物三视图、统一品牌素材）。

即梦 `image2image` 单次最多 10 张。超出时脚本自动裁剪：**优先保留上一段成图**，再按
“分段级配图 > 全局品牌/人物”的顺序保留，直到 10 张。

第一段若没有任何参考图，则改用 `text2image`（纯文字生图）；只要有 1 张参考图就走
`image2image`。

> 实践建议：把 Logo、吉祥物三视图放进 `assets.brand_images`；把每段的项目配图放进对应
> 分段的 `reference_images`，能显著提升品牌一致性与信息保真。

## 异步流程（脚本内部已封装，无需手动干预）

1. `dreamina image2image/text2image ...` 提交，返回 `submit_id` + `gen_status=querying`；
2. 循环 `dreamina query_result --submit_id=<id>` 直到 `success` / `fail`（默认每 12 秒一次，
   超时由 `--poll-timeout` 控制）；
3. `gen_status=fail` 时读取 `fail_reason` 并抛出，便于定位；
4. 成功后 `dreamina query_result --submit_id=<id> --download_dir <segments>` 下载结果；
5. 把 `<submit_id>_image_1.<ext>` 重命名为 `poster_plan.json` 中指定的 `filename`。

## 输出

- `<output-dir>/NN_*.png`（或即梦实际返回的扩展名，脚本会自动对齐后缀）；
- `<output-dir>/generation_manifest.json`，其中：
  - `backend`: `"dreamina"`
  - 每段记录 `mode`（image2image / text2image）、`reference_count`、`elapsed_seconds`；
  - 失败的段标记为 `status: "failed"` 并附带 `error`，不会中断整批，便于 `--force` 重试。

后续拼接（`stitch_long_poster.py`）、质检（`qc_report.py`）与具体生图引擎无关——它们只读取
本地图片文件。

## 故障排查

| 现象 | 处理 |
|------|------|
| `未检测到 dreamina CLI` | 安装即梦命令行并确认在 PATH；`dreamina -h` 可运行 |
| `submit 未返回 submit_id` | 检查 `--images` 路径是否存在、是否超过 10 张、prompt 是否过短 |
| `即梦任务失败 ...` | 查看 `fail_reason`：多为额度不足（user_credit）、模型/比例不支持、图片格式问题 |
| `AigcComplianceConfirmationRequired` | 需要在即梦网页端完成一次性合规授权，再重试 |
| 下载未产生文件 | 确认 `query_result --download_dir` 目录可写；网络正常 |
| 中文错字 / 文字重叠 | 属 AI 生图通病，按 Skill 流程逐张检查并 `--only N --force` 重做该段 |
