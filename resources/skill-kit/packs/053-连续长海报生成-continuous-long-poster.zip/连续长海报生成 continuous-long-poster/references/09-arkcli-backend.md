# 火山引擎 Ark CLI 后端使用说明

`generate_segments.py` 支持以**火山引擎 Ark CLI**（`arkcli +gen`）作为生图后端，生成
连续的 long-poster 分段图。它与即梦（Dreamina）CLI 二选一，通过 `--backend arkcli` 启用。

arkcli 走的是火山方舟（Volcano Ark）数据面：调用 `arkcli +gen --modality image`，使用
Doubao-Seedream 系列图片大模型同步生成图片，并把上一段成图与品牌素材作为 `--input` 参考图，
以延续同一张长画布的视觉。

> 本文档不涉及任何个人账号信息。所有 Key / 接入点 id 均需由使用者自行在本地配置，
> 技能脚本与文档只使用公开模型 id 与 `<占位符>`。

## 1. 支持的图片模型

本技能兼容火山方舟**全部 Seedream 图片模型**，通过 `--arkcli-model` 选择：

| 模型（市场名） | `--arkcli-model` 友好名 | callable_model_id（公开） |
|------|------|------|
| Doubao-Seedream-5.0-pro | `doubao-seedream-5-0-pro` | `doubao-seedream-5-0-pro-260628` |
| Doubao-Seedream-5.0-lite | `doubao-seedream-5-0` | `doubao-seedream-5-0-260128` |
| Doubao-Seedream-4.5 | `doubao-seedream-4-5` | `doubao-seedream-4-5-251128` |
| Doubao-Seedream-4.0 | `doubao-seedream-4-0` | `doubao-seedream-4-0-250828` |

- 上述 `callable_model_id` 是火山方舟公开模型标识，**所有账号一致，非个人凭证**；
- 也可直接传**推理接入点 id** `ep-xxxx`（自建，见第 6 节），由 `--arkcli-endpoint` 指定；
- 脚本会把友好名 / 展示名自动解析为 `callable_model_id`（见第 5.2 节），**无需手抄版本后缀**。

### 1.1 模型能力对照（决定脚本的默认行为）

| 能力 | 5.0 pro | 5.0 lite | 4.5 | 4.0 |
|------|:---:|:---:|:---:|:---:|
| 单图生成 | ✅ | ✅* | ✅* | ✅* |
| 组图（`sequential=auto`） | ❌ 不支持 | ✅ 默认可能走组图 | ✅ | ✅ |
| 参考图上限 | 10 张 | 14 张 | 14 张 | 14 张 |
| `output_format=png` | ✅ | ✅ | ❌ | ❌ |
| `output_format=jpeg` | ✅ | ✅ | ✅ | ✅ |
| `prompt-mode=fast` | ✅ | ❌ | ❌ | ❌ |
| `tools=web_search` | ❌ | ✅ | ❌ | ❌ |
| 尺寸下限（总像素） | 921,600 | 3,686,400 | 3,686,400 | 921,600 |
| 尺寸上限（总像素） | 4,624,220 | 16,777,216 | 16,777,216 | 16,777,216 |

> \* 5.0 lite 默认可能走「组图」（`sequential=auto`），长海报要求**一段一图**，故脚本对
> **5.0 pro / 5.0 lite** 强制 `--sequential disabled` + `--output-format png`，确保每张分段只生成 1 张图且为无损 PNG。
> **4.5 / 4.0 完全不支持 `sequential` 与 `output_format` 参数**（传则报 `param_not_supported` / `not supported`），
> 其默认即为单张输出，脚本对这两族自动跳过这两个参数（由模型决定输出格式，通常为 jpeg）。
> 若使用 `ep-xxxx` 接入点且脚本无法判断族，可用 `--arkcli-family 4.5|4.0|lite|pro` 显式指定。
> 另外脚本把参考图统一裁剪到 **8 张**（满足所有模型的参考图上限），优先保留上一段成图。

## 2. 安装 Ark CLI

```bash
npm i -g @volcengine/ark-cli
```

安装后二进制位于（以 WorkBuddy 托管 Node 为例）：

```
~/.workbuddy/binaries/node/versions/<ver>/node_modules/@volcengine/ark-cli/bin/arkcli-windows-amd64.exe
```

> 脚本会自动探测 arkcli：依次尝试 `--arkcli-path` 显式路径 → 环境变量 `ARKCLI_BIN` →
> 系统 `PATH`（`arkcli` / `arkcli.exe`）→ WorkBuddy 托管 Node 目录。只要上述任一命中即可，
> 无需手动加 PATH。也可用 `--arkcli-path` 直接指定，或设置 `ARKCLI_BIN` 环境变量。

## 3. 登录（跨设备无浏览器模式）

arkcli 默认 `auth login volc-sso` 走「本机浏览器 → localhost 回调」，但在沙箱 / 远程 / 无
桌面环境下回调无法到达，会超时失败。改用跨设备模式：

```bash
arkcli auth login volc-sso --no-browser
```

- 命令会打印一个**授权链接**，在任意设备（手机 / 本机浏览器）打开；
- 用火山引擎账号登录并授权；
- 授权成功后浏览器页面会显示一段 **base64 授权码**；
- 把该授权码回传给：

```bash
arkcli auth login --no-browser --code "<base64 授权码>"
```

登录态验证：

```bash
arkcli auth status        # 应显示 logged_in: true 与默认 profile
```

## 4. 配置 API Key（数据面必需）

生图走数据面，需要 API Key。先到方舟控制台创建：
`https://console.volcengine.com/ark/region:ark+cn-beijing/apiKey`

通过管道写入本地 `~/.arkcli/.env`（避免明文进命令行历史）：

```bash
echo "<你的 API Key>" | arkcli auth apikey
```

> Key 形如 `ark-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx-xxxxx`。写入后
> `arkcli models list` 应返回可调用模型列表（验证数据面已通）。

### 4.1 脚本自动载入 Key（无需手动 export）

`generate_segments.py` 会**自动**解析并注入数据面 Key，你**不需要每次手动 `export ARK_API_KEY`**。
查找顺序：

1. 环境变量 `ARK_API_KEY`；
2. 环境变量 `VOLCENGINE_ARK_API_KEY`；
3. 用户级 `~/.arkcli/.env` 中的 `ARK_API_KEY` / `VOLCENGINE_ARK_API_KEY`（脚本会自动剥离 Windows 下常见的双引号包裹与 `\r` 污染）。

找到后写入本进程环境变量 `ARK_API_KEY`，`arkcli +gen` 子进程继承即可被数据面读取。

> **关键陷阱（曾导致反复踩坑 40 分钟）**：方舟数据面**只认环境变量 `ARK_API_KEY`**，
> `--api-key` 命令行旗标对数据面**无效**（传了反而会让数据面静默失败、退出码 0 却无图）。
> 脚本已移除该旗标、改为注入环境变量；同时**优先调用原生 `arkcli-windows-amd64.exe`**
> 而非 `arkcli.cmd` 包装脚本——后者经 `cmd.exe` 解析含中文/换行的 prompt 时会吞掉后续
> `--save-to` / `--output-format`，导致图片落到 cwd 且强制 jpeg。这两处修复后，正常调用
> 不会再出现「参数错位 / 没图」问题。

## 5. 前置：在方舟控制台开通所用模型（必做）

`arkcli +gen` 调用的图片模型**必须先在方舟控制台“开通”**，否则会报
`model_activation_required` / 未开通 错误。这一步没有命令行捷径（控制台开通是硬前置）：

1. 打开火山方舟控制台 → **模型管理 / 模型广场**；
2. 找到你要用的目标图片模型（**Doubao-Seedream-5.0 pro / 5.0 lite / 4.5 / 4.0** 任一）；
3. 点击**开通 / 激活**，按页面完成开通。

开通后再继续后续步骤。可在开通页直接看到「创建推理接入点」入口（见第 7 节）。
**注意：不同模型需分别开通**——若切换 `--arkcli-model` 后报未开通，回到这里开通对应模型即可。

## 6. 选模型与解析模型 id（关键）

`arkcli +gen --model` 接受两类标识：

- **可调用模型 id（callable_model_id）**：形如 `doubao-seedream-5-0-pro-260628`，
  由模型名 + 版本日期后缀组成，是 `+gen` 直接可用的标识；
- **推理接入点 id（endpoint id）**：形如 `ep-xxxx`，由你自建（见第 7 节）。

注意：**不能直接传市场展示名**（如 `doubao-seedream-5-0-pro` 这种“漂亮名字”），
否则会报 `requires an endpoint id, not a plan model name`。

### 6.1 查看可调用模型 id

```bash
arkcli models list --modality image
```

在输出里找目标模型的 `callable_model_id` 字段（见第 1 节表格）。
这些 `callable_model_id` 是火山方舟的公开模型标识，所有账号一致，非个人凭证。

### 6.2 脚本自动解析（无需记忆后缀）

`generate_segments.py` 已内置解析：把 `--arkcli-model` 传成**友好名**、**callable id**
或**接入点 id** 均可，脚本会自动把友好名 / 展示名解析成 `callable_model_id`：

- `doubao-seedream-5-0-pro` / `seedream-5.0-pro` → `doubao-seedream-5-0-pro-260628`
- `doubao-seedream-5-0` / `seedream-5.0-lite` → `doubao-seedream-5-0-260128`
- `doubao-seedream-4-5` → `doubao-seedream-4-5-251128`
- `doubao-seedream-4-0` → `doubao-seedream-4-0-250828`
- 已经是 `ep-xxxx` 或 `doubao-seedream-5-0-pro-260628` 则原样使用

所以大多数情况直接传友好名即可，不必手抄版本后缀。

## 7. 创建推理接入点（可选，但更稳妥）

如果 `+gen` 提示需要接入点 id，或你希望固定一个长期复用的端点，可用 `+deploy` 创建：

```bash
arkcli +deploy \
  --model <callable_model_id> \
  --name seedream5-pro \
  --set-default image \
  --yes
```

- `--model` 填第 6.1 节的 `callable_model_id`；
- 成功后命令会返回 `ep-xxxx` 接入点 id；
- `--set-default image` 会把它设为图片默认资源，之后 `+gen` 甚至可省略 `--model`；
- 若你的账号要求必须先开通模型，这一步也会提示开通（回到第 5 节）。

拿到 `ep-xxxx` 后，也可直接传给脚本：

```bash
python generate_segments.py ... --backend arkcli --arkcli-endpoint ep-xxxx
```

> 无论用 `--arkcli-model` 还是 `--arkcli-endpoint`，**脚本都不会把你的接入点 id 写进任何
> 文档或脚本里**——它只接受你运行时传入的参数。分享技能包时无需担心凭证泄露。

## 8. 脚本调用方式

```bash
python "{baseDir}/scripts/generate_segments.py" \
  --plan "<项目目录>/plans/poster_plan.json" \
  --output-dir "<项目目录>/segments" \
  --backend arkcli \
  --arkcli-model doubao-seedream-5-0-pro \   # 也可 5-0 / 4-5 / 4-0 或 ep-xxxx
  --size 1440x2560 \
  --resume
```

- `--arkcli-model`：友好名 / callable id / 接入点 id 均可（脚本自动解析）；
- `--arkcli-endpoint`：直接指定 `ep-xxxx`，优先级高于 `--arkcli-model`；
- `--size`：默认 `1440x2560`（9:16，四款模型通用安全值）；详见第 10 节。

脚本内部实际执行的等效命令（供理解，无需手动敲；`--output-format` 按模型族自动选择）：

```bash
arkcli +gen "<prompt>" \
  --modality image \
  --model <callable_model_id 或 ep-xxxx> \
  --size 1440x2560 \
  --output-format <png: pro/lite | jpeg: 4.5/4.0/未知> \
  --sequential disabled \          # 强制单图，避免 lite/4.5/4.0 走组图
  --watermark false \              # 默认不加水印，保持海报干净
  --save-to "<项目目录>/segments" \
  --no-open \
  --input "ref:@<上一段成图.png>" \
  --input "ref:@<品牌素材.png>"
```

常用参数：

| 参数 | 说明 |
|------|------|
| `--backend arkcli` | 切换到火山 Ark CLI 后端（默认 dreamina） |
| `--arkcli-path` | arkcli 可执行文件绝对路径；缺省自动探测 |
| `--arkcli-model` | 图片模型，友好名 / callable id / ep-id 均可，**默认 `doubao-seedream-5-0-260128`（5.0 Lite，免费额度约 50 张）**；5.0 Pro 仅 1 张，请勿作默认 |
| `--arkcli-endpoint` | 推理接入点 id（`ep-xxxx`），**可逗号分隔多个构成 fallback 链**，如 `ep-lite,ep-45,ep-40`：默认先用 Lite（约 50 张），额度耗尽/暂停时**自动切换**到 4.5/4.0 续跑，绝不先耗 5.0 Pro（仅 1 张）；指定后优先于 `--arkcli-model` |
| `--size` | 图片尺寸 `宽x高`，默认 `1440x2560`（9:16）；详见第 10 节 |
| `--optimize-prompt` | 启用服务端提示词优化（可选） |
| `--prompt-mode` | 优化模式 `standard` / `fast`（需配合 `--optimize-prompt`；`fast` 仅 5.0 pro 支持） |
| `--output-format` | 输出格式 `auto`(默认，按模型选) / `png`(仅 pro/lite) / `jpeg` |
| `--watermark` / `--no-watermark` | 是否加「AI 生成」水印，默认不加 |
| `--seed` | 固定随机种子（可选，提升可复现性） |
| `--resume` / `--force` / `--only` / `--dry-run` | 与即梦后端一致；**默认即跳过已存在的段**（等价于 `--resume`），`--force` 强制重跑 |
| `--parallel` | arkcli 并行生成段数（默认 1 串行）。`>1` 时各段独立生成（不引用上一段成图）以提速；会牺牲相邻段 image2image 连续性，仅建议追求速度或已有底图时开启 |

arkcli 图片任务为**同步生成**：命令阻塞直到图片产出并保存到 `--save-to`，脚本再自动重命名为
`poster_plan.json` 指定的 `filename`。无需像即梦那样轮询。

## 9. 参考图与连续性（关键）

脚本按以下顺序收集每张分段图的参考图，作为 `arkcli +gen --input` 传入（每张前缀 `ref:@`）：

1. **上一段成图**（连续性最强，必须保留）；
2. 本段 `segment.reference_images`（可选，该段专属配图）；
3. 全局 `assets.reference_images` / `assets.character_images` / `assets.brand_images`
   （Logo、吉祥物三视图、统一品牌素材）。

脚本把参考图统一裁剪到 **8 张**（即梦为 10 张），满足所有 Seedream 模型的参考图上限
（5.0 pro 上限 10、其余 14），超出时自动裁剪：**优先保留上一段成图**，
再按「分段级配图 > 全局品牌 / 人物」顺序保留。

第一段若无任何参考图则走纯文字生图（text2image）；只要有 1 张参考图就走 image2image。

> 实践建议：把 Logo、吉祥物三视图放进 `assets.brand_images`；把每段项目配图放进对应分段的
> `reference_images`，能显著提升品牌一致性与信息保真。Seedream 对中文排版支持较好，但仍建议
> 逐张检查错字并按需 `--only N --force` 重做。

## 10. 尺寸说明（按模型）

`--size` 接受 `宽x高` 像素值。**长宽比范围均为 [1/16, 16]**，总像素须落在各模型区间内。
各模型的**总像素取值范围**（对单张图宽×高乘积的限制）：

| 模型 | 像素下限 | 像素上限 | 推荐的 `--size` 档位（分辨率档位，可选） |
|------|---------|---------|------|
| 5.0 pro | 921,600（如 1280x720） | 4,624,220（约 2048x2256） | 1K / 1.5K / 2K（推荐用自然语言描述比例） |
| 5.0 lite | 3,686,400（2560x1440） | 16,777,216（4096x4096） | 2K / 3K / 4K |
| 4.5 | 3,686,400（2560x1440） | 16,777,216（4096x4096） | 2K / 4K |
| 4.0 | 921,600（1280x720） | 16,777,216（4096x4096） | 1K / 2K / 4K |

**通用安全默认：`1440x2560`（= 3,686,400 像素，9:16）同时满足四款模型的像素下限**，
可作为统一默认尺寸，保证各模型都能跑通、且长海报各段比例一致便于无缝拼接。

- 若用 5.0 pro，也推荐用**分辨率档位**方式（`--resolution 1K/1.5K/2K`）并在 prompt 里用自然语言
  描述宽高比/用途，效果更可控；但脚本默认用精确像素值以固定拼接尺寸；
- 若用 5.0 lite / 4.5 / 4.0 且想要更高清，可上调至 `2048x2048`、`2816x1584` 等（≤ 4096x4096）；
- **不要使用 `1024x1792`（约 184 万像素）**——低于 lite/4.5/4.0 下限会被拒绝。

若某尺寸被模型拒绝（报 size / pixel / resolution 相关错误），换用更大尺寸或调整 `--size` 重试。

## 11. 提示词长度

方舟建议提示词 **≤ 300 个中文字符或 ≤ 600 个英文单词**。超出后模型可能忽略细节、丢失元素。
脚本在生图前会**自动检测中文字符数**，超过 300 时打印 `[警告]`（仍继续生成），便于你精简文案。

> 与即梦后端的区别：即梦官方上限约 **800 字**，火山方舟（Seedream）官方上限约 **300 字**，
> 两者后端不同、限制不同，不要混用。
>
> 这是**软性质量建议**（"建议不超过"），不是硬上限：超出不会被 API 拒绝，也不会触发任何 CLI
> 报错。长 prompt 实测可正常生成。控字数的目的只是"减少细节丢失"，**与 CLI 稳定性无关**。
>
> 若 arkcli 报 `--model 未传` / 参数错位等 CLI 解析异常，**不是 prompt 太长**，根因是：
> **(1) 数据面只认环境变量 `ARK_API_KEY`，`--api-key` 旗标对数据面无效**；**(2) `~/.arkcli/.env`
> 里的 Key 常带双引号包裹或 `\r` 污染**；**(3) `arkcli.cmd` 包装脚本经 `cmd.exe` 解析含中文
> prompt 时会吞掉后续参数**。脚本已统一修复（移除 `--api-key` 旗标、改注入环境变量、自动剥离
> 引号/`\r`、优先调用原生 `.exe`），正常调用不会再出现。若仍出现，检查 `ARK_API_KEY` 是否被写入了
> 换行符，或直接 `arkcli auth apikey` 重新拉取。

## 12. 成本与额度

- 生图消耗**火山方舟账号额度**（credits / 调用计费），由你的火山引擎账号负责；
- 运行前必须向用户说明本次会消耗额度，并确认余额充足；
- **「安心体验」免费额度各模型相互独立、互不影响**：5.0 Pro 仅 1 张、5.0 Lite 约 50 张、
  Seedream-4.5 / 4.0 各为独立额度。推荐策略：**默认先用 5.0 Lite（50 张）**，耗尽后改用
  **Seedream-4.5 / 4.0**（独立额度）续跑；**5.0 Pro 仅 1 张，请勿作为默认**，否则一张用尽即整批中断。
  脚本支持 `--arkcli-endpoint ep-lite,ep-45,ep-40`（配合 `--arkcli-family lite,4.5,4.0`）自动续跑，无需手动干预。
- 失败段写入 manifest 且不中断整批，可用 `--only N --force` 重做，避免重复消耗；
- 脚本默认跳过已生成的段（除非 `--force`），重跑整批不会重复消耗已完成段的额度。

## 13. 故障排查

| 现象 | 处理 |
|------|------|
| `未检测到 arkcli` | 安装 `npm i -g @volcengine/ark-cli`；或用 `--arkcli-path` 指定，或设 `ARKCLI_BIN` |
| `arkcli ... 失败 (exit=...)` | 查看 stderr：多为未登录、API Key 缺失、模型未开通、模型 id 写法错误或 `--size` 不被支持 |
| `requires an endpoint id, not a plan model name` | 不能用市场展示名。传 callable id（如 `doubao-seedream-5-0-pro-260628`）或 `ep-xxxx`；或直接用友好名交给脚本自动解析 |
| `model_activation_required` / 未开通 | 到方舟控制台**开通**对应 Seedream 模型（第 5 节），再 `arkcli +deploy` 建接入点 |
| `logged_in: false` | 重新 `arkcli auth login volc-sso --no-browser` 并回传授权码 |
| `models list` 为空 / 调用提示无权限 | 到方舟控制台开通对应 Seedream 模型，并确认 `echo '<KEY>' | arkcli auth apikey` 已写入 Key |
| size / pixel / resolution 报错 | 尺寸低于模型下限；改 `--size 1440x2560` 或更大尺寸（见第 10 节） |
| output_format=png 被拒 | `png` 仅 5.0 pro / lite 支持；4.5 / 4.0 请改用 jpeg（脚本 auto 模式已自动按模型选择，也可显式 `--output-format jpeg`） |
| 意外生成多张（组图） | 脚本已默认 `--sequential disabled` 强制单图；若仍出组图，确认未手动传 `--sequential auto` 或 `--image-count > 1` |
| 提示词过长警告 | 精简到 ≤ 300 中文字符（第 11 节），避免元素缺失（与 CLI 稳定性无关） |
| `--model 未传` / 参数错位（CLI 解析异常） | **与 prompt 长度无关**；根因是数据面只认 `ARK_API_KEY` 环境变量（非 `--api-key` 旗标）、`.env` 的 Key 带引号/`\r`、或 `arkcli.cmd` 包装吞参数。脚本已自动修复（注入环境变量 + 剥离引号 + 优先原生 `.exe`），正常调用不会再出现 |
| 退出码 0 但 save-to 未产出图片 | 多为数据面静默失败。脚本会扫描 stdout 给出诊断（Key / 额度 / 模型未开通 / 内容审核 / 参数不支持）；按提示处理 |
| 额度不足 / 模型未开通 / "安心体验"已暂停 | 方舟"安心体验"免费额度耗尽会**暂停但不扣费**（不扣费）。各模型额度独立：5.0 Pro 1 张、5.0 Lite 约 50 张、4.5/4.0 各独立。脚本默认先用 5.0 Lite，耗尽时**自动切换到下一个终点（`--arkcli-endpoint ep-lite,ep-45,ep-40`）续跑**；或手动改用 **Seedream-4.5 / 4.0**。5.0 Pro 仅 1 张，勿作默认 |
| 提示词触发内容安全审核（无图产出） | 改写涉及**军事番号、政府文件编号/批准、具体人物**等敏感表述，保留事实主干即可；重跑该段（`--only N --force`，已生成段会自动跳过） |
| 未在 save-to 产出图片 | 确认目录可写、网络正常；检查 stderr 中的具体错误 |
| 中文错字 / 文字重叠 | 属 AI 生图通病，按流程逐张检查并 `--only N --force` 重做该段 |
| 参考图过多报错 | 已自动裁剪到 8 张；仍报错则减少 `brand_images` / `reference_images` 数量 |
