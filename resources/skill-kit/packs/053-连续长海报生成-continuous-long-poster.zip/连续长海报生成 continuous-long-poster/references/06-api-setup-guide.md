# 生图 API 配置引导（openai / opc 后端）

> 本引导仅适用于 `--backend openai` / `--backend opc`。使用即梦 CLI 或火山 Ark CLI 后端时无需配置 API。

## 首次运行提示

本 Skill 需要接入支持图片生成的 API。推荐使用 GPT Image 2，或兼容 OpenAI Images API 的第三方服务。

### 用户已有 API

请提供：

- API Key；
- Base URL；
- 模型名称；
- 可选：生成路径、编辑路径、图片尺寸和质量。

智能体取得用户明确提供的配置后，可运行：

```bash
python "{baseDir}/scripts/configure.py" set \
  --api-key "<API_KEY>" \
  --base-url "<BASE_URL>" \
  --model "<MODEL>"
```

执行后不得在回复里重复 API Key。

### 用户没有 API

读取：

```text
{baseDir}/config/recommended_provider.json
```

- 若 `enabled: true`，展示推荐服务商、配置入口地址和默认 base_url / 模型；
- 若未启用，展示 OpenAI 官方或让用户选择自己的兼容服务；
- 不替用户购买、充值或创建第三方账户；
- 不承诺第三方服务稳定、合法或永久可用。

**配置引导**：用户需自行向所选 OpenAI 兼容 API 服务商申请 base_url / api_key / model（支持 gpt-image-2、即梦 5.0 Pro / Lite 等任意模型名），然后：

```bash
python "{baseDir}/scripts/configure.py" set \
  --api-key "<OPC_API_KEY>" \
  --base-url "<你的 API base_url>" \
  --model "gpt-image-2"
```

base_url 指向 `<你的 API 服务地址>` 时，脚本会自动识别为 OPC 异步接口并切换为异步客户端
（也可显式 `--backend opc` 强制指定）。

建议提示文案：

> 当前尚未配置生图 API。本 Skill 需要支持 GPT Image 或兼容 OpenAI Images API 的服务。
> 已有 API 可直接填写；**用户需自行向所选 OpenAI 兼容 API 服务商申请并配置 base_url / api_key / model
> （支持 gpt-image-2、即梦 5.0 Pro / Lite 等模型）**；也可改用即梦 CLI 或火山
> Ark CLI 后端（无需 API Key）。

## 环境变量方式

推荐用户自行在系统环境中设置：

```text
LONG_POSTER_API_KEY
LONG_POSTER_BASE_URL
LONG_POSTER_IMAGE_MODEL
```

## OPC 异步接口说明

OPC（OpenAI 兼容聚合 API）（<你的 API 服务地址>）为异步生图服务（与 OpenAI 同步 Images API 不同）：

- 提交任务：`POST /v1/media/generate` → 返回 `task_id`；
- 轮询状态：`GET /v1/media/status?task_id=...` → 直至成功；
- 下载成品图并落盘。

`opc_image_client.py` 已内置上述「提交 → 轮询 → 下载」全流程，用户无需手动干预：
- `--backend opc`：强制使用 OPC 异步客户端；
- `--backend openai`：base_url 命中异步聚合 API（含 `/media` 路径或 provider=opc）时自动切换为 OPC 异步客户端。

## 能力分级

### 完整模式

接口同时支持：

- 文字生图；
- 图片输入；
- 图片编辑或参考图生成。

可以稳定执行上一张参考下一张的连续生成流程。

### 降级模式

接口只有文字生图。此时必须提示：

> 当前接口不支持图片输入或编辑。Skill 可以继续生成多张同风格图片，但上下结构和人物一致性可能明显下降。

除非用户接受，不得自动开启降级模式（`allow_text_only_fallback` 默认关闭）。

## 安全规则

- 不在 `SKILL.md`、项目 JSON、日志、截图或最终报告中写入完整 Key；
- 不把用户 Key 发给推荐服务商或其他第三方；
- 只向用户配置的 Base URL 发送请求；
- 用户更换服务商时，覆盖旧配置前应提醒；
- 出售 Skill 时必须保持 `recommended_provider.json` 中不含作者自己的密钥。
