# 无字底图模式 + 代码叠字工作流（根治 AI 中文错字）

## 何时启用

只要长海报**含一定量的中文文案**（标题、年份、事件描述、品牌名、网址等），AI 生图就**必然**出现
错字、漏字、乱码、镜像字。Seedream 系模型对中文小字的还原能力极弱。与其反复重跑祈祷，不如：

> **让 AI 只画纯净插画底图，真实文字用代码（PIL + 黑体）精准叠加。**

这就是「无字底图模式（textless）+ 代码叠字（overlay）」。

## 两段式管线

```
poster_plan.json
   ├─ segment.textless_composition   # 描述「预留留白区」，不写真实文字
   ├─ segment.text_overlay           # 真实文字 + 版式（坐标块/字号/颜色/对齐/面板/logo）
   └─ global.text_policy.render_mode = "textless"
        │
        ▼  (1) generate_segments.py --textless
   segments/01_*.jpeg ...            # AI 只画插画，画面无文字无 logo
        │
        ▼  (2) overlay_text.py
   segments_texted/01_*.jpeg ...     # 代码精准叠加中文 + logo 到留白区
        │
        ▼  (3) stitch_long_poster.py --images-dir segments_texted
   final/final_long_poster.jpeg
```

## 第 1 步：生成无字底图

`build_prompt()` 在 `textless=True` 时走独立分支：

- **不读** `segment.content` 的真实文字（避免 AI 照抄画错）；
- 用 `segment.textless_composition`（你写的「预留留白区」描述）替代 `composition`；
- 强制禁令：画面严禁任何文字/数字/字母/符号/logo/印章/二维码/水印；
- 衔接带约束（上下边缘 10% 收束、禁硬竖边）照常生效；
- **参考图过滤**：`assets.reference_images`（旧信息图常带文字/竖时间轴）、`assets.brand_images`
  （带字 logo）被跳过；只保留 `character_images`（吉祥物等纯插画）。这是为挡住「旧图把文字/竖线
  泄漏进新底图」这一最常见的污染源。

启用方式（二选一）：

- 命令行 `--textless`（优先级最高）；
- 或 `global.text_policy.render_mode = "textless"`。

提示词长度：textless 分支已尽量精简（目标 < 300 中文），但多卡段仍可能偏长；若控制台提示超 300，
可接受（底图禁字由「严禁」指令保证，且留白区会被白色面板盖住 AI 误画的淡字）。

## 第 2 步：plan 里写好 text_overlay 版式

`text_overlay` 是叠字脚本的**唯一输入**，决定真实文字落在哪里。结构：

```json
"text_overlay": {
  "defaults": { "panel": {"fill":"#FFFFFF","opacity":0.88,"radius":24,"border":"#005BAC","border_width":3} },
  "blocks": [
    {"role":"title",  "box":[0.08,0.145,0.92,0.22], "text":"中冶武勘历史沿革", "size":78, "align":"center"},
    {"role":"era",    "box":[0.08,0.105,0.92,0.165], "text":"奠基期 · 1952—1955", "size":52},
    {"role":"node",   "box":[0.09,0.18,0.91,0.305], "year":"1952年5月", "desc":"……", "size":40, "min_size":22},
    {"role":"body",   "box":[0.10,0.235,0.90,0.425], "text":"……", "size":40, "min_size":24},
    {"role":"brand",  "box":[0.36,0.77,0.92,0.90], "align":"left",
       "name":"中冶武勘工程技术有限公司", "url":"官网 https://www.wsgri.com", "size":30, "url_size":22}
  ],
  "logos": [
    {"plate":{"fill":"#005BAC","radius":18}, "box":[0.10,0.03,0.90,0.13]},
    {"asset":"assets/logo_cropped.png", "box":[0.10,0.03,0.90,0.13], "padding":0.10}
  ]
}
```

字段说明：

- **坐标 `box`**：相对比例 `[x1,y1,x2,y2]`，0~1。文字块集中在段中部 **0.10~0.90**，避开上下 10% 接缝带，
  否则拼接羽化会切到字。
- **`role`**：`title`/`era`/`node`/`body`/`brand` 决定字号与配色默认值（可在块内用 `color` 覆盖）。
  - `node` 为「年份 + 描述」卡片：year 用金色加粗，desc 用深灰。
  - `brand` 为品牌区「名称 + 网址」双行。
- **`size`**：起始字号（相对像素，脚本按图高换算）。`min_size` 为自动缩放下限，防止长文被压到看不清
  （建议节点卡 `min_size≥22`、正文 `min_size≥24`）。
- **`panel`**：半透明白色圆角面板 + 品牌色描边，提升文字在复杂底图上的可读性。不需要面板设 `"panel":false`。
- **`logos`**：先画底色板（plate）再合成 logo PNG（白字 logo 配品牌蓝板）。`asset` 为透明背景 logo 路径；
  不带 `asset` 的纯 plate 用于品牌区色块。logo 太宽会被整体缩进 padding 留白，故封面/品牌区建议用
  **已裁剪的紧凑版 logo**（见下）。

> 字体：脚本自带 `assets/fonts/simhei.ttf`（黑体）与 `NotoSansSC-VF.ttf`，无需系统字体。

## 第 3 步：运行叠字

```bash
python "{baseDir}/scripts/overlay_text.py" \
  --plan "<项目目录>/plans/poster_plan.json" \
  --segments-dir "<项目目录>/segments" \
  --output-dir "<项目目录>/segments_texted" \
  [--only 1,3]        # 可选：只叠指定段
```

叠字脚本自动：按 box 缩放字号适配、自动换行、画面板、画 logo 合成、写回 jpeg。输出与底图同名，
放在独立 `segments_texted/` 目录，**不污染原始底图**（便于返工重叠）。

## 第 4 步：用叠字图拼接

拼接时 `--images-dir` 指向 `segments_texted/`（已是带字终稿），后续 `stitch_long_poster.py` /
`qc_report.py` 流程不变。

## 常见坑

1. **logo 太小**：超宽横幅 logo 缩进窄框会字小。解决——提前裁成紧凑版（如保留 `MCC + 中冶武堪`，
   去「中国五矿」前缀），并适当放大 `logo box` 高度。
2. **文字落在 AI 误画的淡字上**：textless 模式下 AI 极少画字，且白色面板会盖住淡色背景；若仍担心，
   把面板 `opacity` 调到 1.0。
3. **提示词超 300 字**：底图质量微调，不影响禁字（禁字是硬指令 + 面板遮挡双保险）。
4. **上下边缘竖边**：再强调一次——`textless_composition` 与 `composition` 都须遵循衔接带约束，
   上下 10% 收束为曲线/流体，否则拼接处断裂。
5. **生成时报 `output_format` 不支持**：说明该 `--arkcli-endpoint` 实际不是 5.0 Pro/Lite，而是 4.5/4.0。
   把对应 `--arkcli-family` 设为 `4.5`（或 `4.0`），脚本即不再传 `output_format`/`--sequential`。
