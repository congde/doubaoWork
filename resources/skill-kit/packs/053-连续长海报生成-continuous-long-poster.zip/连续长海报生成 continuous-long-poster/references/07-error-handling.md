# 错误处理与恢复策略

## 即梦 CLI / 任务错误

按类型提示：

- `dreamina` 命令未安装或不在 PATH；
- 未登录 / 登录态失效（`dreamina login` 或 `dreamina relogin`）；
- 即梦额度不足（`dreamina user_credit` 为 0 或不足）；
- 任务提交失败（`submit` 未返回 `submit_id`）：检查参考图路径、是否超过 10 张、prompt 是否过短；
- 任务失败 `gen_status=fail`：读取 `fail_reason`（多为额度不足、模型/比例不支持、图片格式问题）；
- `AigcComplianceConfirmationRequired`：需在即梦网页端完成一次性合规授权；
- 下载未产生文件：确认 `query_result --download_dir` 目录可写、网络正常；
- 请求超时或被限速。

不要笼统回复“生成失败”。保留即梦返回的状态码、`fail_reason` 或不含敏感信息的错误摘要。

## 火山 Ark CLI / 任务错误

按类型提示（详见 `references/09-arkcli-backend.md`）：

- `未检测到 arkcli`：未安装或不在探测路径；`npm i -g @volcengine/ark-cli`，或 `--arkcli-path` 指定，或设 `ARKCLI_BIN`；
- `arkcli ... 失败 (exit=...)`：查看 stderr；多为未登录、API Key 缺失、`--size` 不被该模型支持、模型 id 写法错误或模型未开通；
- `requires an endpoint id, not a plan model name`：`+gen --model` 传了市场展示名。改用 callable id（如 `doubao-seedream-5-0-pro-260628`）或 `ep-xxxx`；或直接用友好名交给脚本自动解析；
- `model_activation_required` / 未开通：所用 Seedream 模型尚未在方舟控制台开通。先到控制台**开通**模型，再 `arkcli +deploy` 建接入点，然后重跑；
- size / pixel / resolution 报错：图片尺寸低于模型下限（5.0 lite/4.5/4.0 约 368 万像素、5.0 pro/4.0 约 92 万），改用 `--size 1440x2560`（四款通用安全值）或更大尺寸（见 09 文档第 10 节尺寸表）；
- `output_format` / png 不被支持：png 仅 5.0 pro / lite 支持；4.5 / 4.0 请改用 jpeg（脚本 auto 模式已按模型自动选，也可显式 `--output-format jpeg`）；
- 意外生成多张（组图）：脚本默认 `--sequential disabled` 强制单图；若仍出组图，确认未手动传 `--sequential auto` 或 `--image-count > 1`；
- 提示词过长警告：提示词超 300 中文字符会导致元素缺失，精简文案至 ≤ 300 字（09 文档第 11 节）；
- `logged_in: false`：重新 `arkcli auth login volc-sso --no-browser` 并打印授权码后 `arkcli auth login --no-browser --code <code>`；
- `models list` 为空 / 调用提示无权限：到方舟控制台开通对应 Seedream 模型（不同模型分别开通），并确认 `echo '<KEY>' | arkcli auth apikey` 已写入；
- save-to 未产出图片：确认目录可写、网络正常，检查 stderr 具体错误；
- 参考图过多报错：脚本已自动裁剪到 8 张，仍报错则减少 `brand_images` / `reference_images` 数量；
- 中文错字 / 文字重叠：属 AI 生图通病，按流程逐张检查并 `--only N --force` 重做该段。

不要笼统回复“生成失败”。保留 arkcli 返回的 stderr 摘要（不含 Key / token）。

## 分段生成失败

1. 当前段最多按配置重试；
2. 重试时使用相同文字白名单与视觉基准；
3. 若即梦任务失败，默认停止并提示，附上 `fail_reason` 便于定位；
4. 已成功生成的分段不得重复消耗额度，使用 `--resume` 继续；
5. 单段重做：`--only <序号> --force`。

## 文字错误

- 优先重做当前分段；
- 多次失败后缩短文字；
- 或生成无字底图，另行排字；
- 不应为了容纳错误文字而缩小字号。

## 拼接失败

- 参数越界时自动限制到安全范围并记录警告；
- 图片宽度不同，按目标宽度等比缩放；
- 重叠区过大，限制为两张图较短高度的合理比例；
- 局部遮罩配置错误，退回羽化模式并在清单中记录；
- 输出前保留原始分段图，不覆盖用户素材。

## 质量不达标

按最低成本顺序修复：

1. 调整裁切；
2. 调整重叠高度；
3. 调整羽化范围；
4. 开启或调整色彩匹配；
5. 使用局部遮罩；
6. 小范围重做相邻分段；
7. 最后才考虑全部重做。
