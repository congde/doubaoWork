from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def run(command: list[str]) -> None:
    print("$", " ".join(command))
    subprocess.run(command, check=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="连续长海报 Skill 辅助流水线")
    parser.add_argument("--poster-plan", required=True)
    parser.add_argument("--project-dir", required=True)
    parser.add_argument("--stitch-plan")
    parser.add_argument("--generate-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    project = Path(args.project_dir)
    segments = project / "segments"
    final = project / "final" / "final_long_poster.png"
    previews = project / "previews"
    qc = project / "qc"

    cmd = [sys.executable, str(base / "generate_segments.py"), "--plan", args.poster_plan, "--output-dir", str(segments)]
    if args.resume:
        cmd.append("--resume")
    run(cmd)

    if args.generate_only or not args.stitch_plan:
        print("分段图已生成。请由智能体检查图片并创建 stitch_plan.json 后继续。")
        return 0

    run([
        sys.executable, str(base / "stitch_long_poster.py"),
        "--images-dir", str(segments),
        "--plan", args.stitch_plan,
        "--output", str(final),
        "--preview-dir", str(previews),
    ])
    run([
        sys.executable, str(base / "qc_report.py"),
        "--segments-dir", str(segments),
        "--final", str(final),
        "--stitch-manifest", str(final.parent / "stitch_manifest.json"),
        "--output-dir", str(qc),
    ])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
