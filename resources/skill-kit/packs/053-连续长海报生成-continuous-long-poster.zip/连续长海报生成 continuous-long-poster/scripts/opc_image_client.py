from __future__ import annotations

"""OPC（OpenAI 兼容聚合 API）（OpenAI 兼容聚合 API）异步图片 API 适配器。

continuous-long-poster 内置的 ImageClient 面向 OpenAI 兼容的同步
/images/generations 接口；而 OPC 的 GPT Image 2 是异步接口：

    POST /v1/media/generate  -> 返回 task_id（或立即可用 url）
    GET  /v1/media/status?task_id=...  -> 轮询直到 is_final/state=success

本适配器把 skill 期望的同步接口 `generate(prompt, path, size=)` /
`edit(prompt, images, path, size=)` 翻译成 OPC 的「创建 + 轮询 + 下载」流程，
并保持与 image_client.ImageApiError 相同的异常类型，使 generate_segments.py
的现有错误处理逻辑无需改动。

参考图（本地路径）会按 OPC 规范内联为 data:<mime>;base64,<数据> 传入。
"""

import base64
import mimetypes
import os
import time
from pathlib import Path
from typing import Any, Iterable

import requests

try:
    from .image_client import ImageApiError
except ImportError:
    from image_client import ImageApiError

POLL_INTERVAL_SECONDS = 4
MAX_REFERENCE_IMAGES = 14


class OpcImageClient:
    """兼容 skill 调用约定的 OPC 异步图片客户端。"""

    def __init__(self, config: Any) -> None:
        errors = self._validate(config)
        if errors:
            raise ImageApiError("；".join(errors))
        self.config = config
        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"Bearer {config.api_key}"})

    # ---- 配置/校验 -------------------------------------------------------
    @staticmethod
    def _validate(config: Any) -> list[str]:
        errors: list[str] = []
        if not getattr(config, "api_key", ""):
            errors.append(
                "缺少 API Key（请设置环境变量 LONG_POSTER_API_KEY，"
                "或运行 configure.py set --api-key <KEY>）"
            )
        if not getattr(config, "base_url", ""):
            errors.append("缺少 Base URL（OPC 应为 <你的 API base_url>）")
        if not getattr(config, "model", ""):
            errors.append("缺少 model（OPC GPT Image 2 应为 gpt-image-2）")
        return errors

    # ---- 端点 -----------------------------------------------------------
    def _generate_url(self) -> str:
        return self.config.base_url.rstrip("/") + "/media/generate"

    def _status_url(self, task_id: Any) -> str:
        return self.config.base_url.rstrip("/") + "/media/status?task_id=" + str(task_id)

    # ---- 入参构造 -------------------------------------------------------
    @staticmethod
    def _to_data_uri(path: Path) -> str:
        mime = mimetypes.guess_type(path.name)[0] or "image/png"
        raw = path.read_bytes()
        b64 = base64.b64encode(raw).decode("ascii")
        return f"data:{mime};base64,{b64}"

    def _build_params(self, size: str | None, reference_images: Iterable[Any] | None) -> dict[str, Any]:
        params: dict[str, Any] = {
            "size": size or getattr(self.config, "size", None) or "1024x1536",
            "quality": getattr(self.config, "quality", None) or "auto",
            "response_format": "url",
            "n": 1,
        }
        if reference_images:
            uris: list[str] = []
            for p in reference_images:
                pp = Path(p)
                if pp.exists():
                    uris.append(self._to_data_uri(pp))
            if len(uris) > MAX_REFERENCE_IMAGES:
                print(
                    f"warn: 参考图 {len(uris)} 张超过 OPC 上限 {MAX_REFERENCE_IMAGES}，已截断",
                    file=__import__("sys").stderr,
                )
                uris = uris[:MAX_REFERENCE_IMAGES]
            if uris:
                params["images"] = uris
        return params

    # ---- 对外接口（与 ImageClient 同签名） ------------------------------
    def generate(self, prompt: str, output_path: str | Path, *, size: str | None = None) -> Path:
        return self._call(prompt, output_path, size=size, reference_images=None)

    def edit(
        self,
        prompt: str,
        images: Iterable[str | Path],
        output_path: str | Path,
        *,
        size: str | None = None,
    ) -> Path:
        return self._call(prompt, output_path, size=size, reference_images=images)

    # ---- 核心流程 -------------------------------------------------------
    def _call(
        self,
        prompt: str,
        output_path: str | Path,
        *,
        size: str | None,
        reference_images: Iterable[Any] | None,
    ) -> Path:
        body = {
            "model": self.config.model,
            "prompt": prompt,
            "params": self._build_params(size, reference_images),
        }
        resp = self._request_with_retry("POST", self._generate_url(), json=body)
        data = resp.json()

        task_id = self._extract_task_id(data)
        if task_id is not None:
            url, b64 = self._poll_resolve(task_id)
        else:
            url, b64 = self._resolve(data)

        if url:
            return self._download(url, output_path)
        if b64 is not None:
            return self._write_bytes(b64, output_path)
        raise ImageApiError(f"OPC 接口未返回可用结果：{str(data)[:500]}")

    # ---- 响应解析 -------------------------------------------------------
    @staticmethod
    def _extract_task_id(data: Any) -> Any:
        if isinstance(data, dict):
            # Direct key
            tid = data.get("task_id")
            if tid is not None:
                return tid
            # Wrapped: {"code":200, "data":{"task_id": N, ...}}
            d_inner = data.get("data")
            if isinstance(d_inner, dict):
                tid2 = d_inner.get("task_id")
                if tid2 is not None:
                    return tid2
            # List form: {"data": [{"task_id": N}, ...]}
            d0 = data.get("data")
            if isinstance(d0, list) and d0 and isinstance(d0[0], dict) and d0[0].get("task_id") is not None:
                return d0[0]["task_id"]
        return None

    @staticmethod
    def _extract_result_url(data: Any) -> str | None:
        if not isinstance(data, dict):
            return None
        d0 = data.get("data")
        if isinstance(d0, list):
            for item in d0:
                if isinstance(item, dict):
                    for key in ("url", "result_url"):
                        v = item.get(key)
                        if isinstance(v, str) and v.startswith(("http://", "https://")):
                            return v
        for key in ("result_url", "url"):
            v = data.get(key)
            if isinstance(v, str) and v.startswith(("http://", "https://")):
                return v
        return None

    @staticmethod
    def _extract_b64(data: Any) -> bytes | None:
        if not isinstance(data, dict):
            return None
        d0 = data.get("data")
        if isinstance(d0, list):
            for item in d0:
                if isinstance(item, dict) and isinstance(item.get("b64_json"), str) and item["b64_json"]:
                    try:
                        return base64.b64decode(item["b64_json"], validate=False)
                    except Exception:
                        return None
        return None

    def _resolve(self, data: Any) -> tuple[str | None, bytes | None]:
        url = self._extract_result_url(data)
        if url:
            return url, None
        return None, self._extract_b64(data)

    def _poll_resolve(self, task_id: Any) -> tuple[str | None, bytes | None]:
        deadline = time.time() + max(1, getattr(self.config, "timeout_seconds", 300))
        while True:
            resp = self._request_with_retry("GET", self._status_url(task_id))
            data = resp.json()
            is_final = data.get("is_final")
            state = data.get("state")
            if is_final is True or state in ("success", "failed"):
                if state == "failed":
                    raise ImageApiError(f"OPC 任务失败：{data.get('error') or data.get('status') or '未知错误'}")
                url, b64 = self._resolve(data)
                if url or b64 is not None:
                    return url, b64
                # 终态但未拿到结果，继续等一拍（部分平台结果稍后回填）
            if time.time() > deadline:
                raise ImageApiError("OPC 任务轮询超时（is_final 未达成）")
            time.sleep(POLL_INTERVAL_SECONDS)

    # ---- 网络/落盘 ------------------------------------------------------
    def _request_with_retry(
        self,
        method: str,
        url: str,
        *,
        json: Any = None,
        max_retries: int | None = None,
    ) -> requests.Response:
        attempts = max(1, (max_retries if max_retries is not None else getattr(self.config, "max_retries", 2)) + 1)
        last_error: Exception | None = None
        for attempt in range(attempts):
            try:
                if json is not None:
                    r = self.session.request(method, url, json=json, timeout=getattr(self.config, "timeout_seconds", 300))
                else:
                    r = self.session.request(method, url, timeout=getattr(self.config, "timeout_seconds", 300))
                if r.status_code >= 400:
                    raise ImageApiError(f"OPC 返回 {r.status_code}: {r.text[:500]}")
                return r
            except (requests.RequestException, ImageApiError) as exc:
                last_error = exc
                if attempt + 1 >= attempts:
                    break
                time.sleep(min(8, 2 ** attempt))
        raise ImageApiError(str(last_error) if last_error else "OPC 请求失败")

    def _download(self, url: str, output_path: str | Path) -> Path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        r = self.session.get(url, timeout=getattr(self.config, "timeout_seconds", 300))
        if r.status_code >= 400:
            raise ImageApiError(f"下载 OPC 结果图失败：{r.status_code}")
        out.write_bytes(r.content)
        return out

    @staticmethod
    def _write_bytes(b64: bytes, output_path: str | Path) -> Path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(b64)
        return out


def is_opc_config(config: Any) -> bool:
    """判断当前配置是否指向异步聚合 API（用于 generate_segments 选择客户端）。

    识别规则（与具体服务商无关）：
    - 用户显式声明 provider=opc（环境变量 LONG_POSTER_PROVIDER）；
    - 或 base_url 路径包含异步 API 特征 `media`（异步聚合 API 暴露 /media/generate 端点）。
    """
    base_url = (getattr(config, "base_url", "") or "").lower()
    if os.getenv("LONG_POSTER_PROVIDER", "").strip().lower() == "opc":
        return True
    if "/media" in base_url:
        return True
    return False
