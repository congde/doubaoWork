from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image, ImageDraw

try:
    from .utils import clamp_int, image_files, open_rgb, read_json, resize_to_width, write_json
except ImportError:
    from utils import clamp_int, image_files, open_rgb, read_json, resize_to_width, write_json


def color_match(source: Image.Image, reference: Image.Image, strength: float = 0.5) -> Image.Image:
    strength = max(0.0, min(1.0, float(strength)))
    src = np.asarray(source).astype(np.float32)
    ref = np.asarray(reference).astype(np.float32)
    src_mean = src.reshape(-1, 3).mean(axis=0)
    ref_mean = ref.reshape(-1, 3).mean(axis=0)
    src_std = src.reshape(-1, 3).std(axis=0) + 1e-6
    ref_std = ref.reshape(-1, 3).std(axis=0) + 1e-6
    matched = (src - src_mean) * (ref_std / src_std) + ref_mean
    mixed = src * (1.0 - strength) + matched * strength
    return Image.fromarray(np.clip(mixed, 0, 255).astype(np.uint8), "RGB")


def _rect_to_pixels(rect: dict[str, Any], width: int, height: int) -> tuple[int, int, int, int]:
    def cv(value: Any, total: int) -> int:
        f = float(value)
        return int(round(f * total)) if 0.0 <= f <= 1.0 else int(round(f))
    x1 = max(0, min(width, cv(rect.get("x1", 0), width)))
    x2 = max(0, min(width, cv(rect.get("x2", width), width)))
    y1 = max(0, min(height, cv(rect.get("y1", 0), height)))
    y2 = max(0, min(height, cv(rect.get("y2", height), height)))
    return min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)


def make_alpha(width: int, overlap: int, feather: int, method: str, pair: dict[str, Any]) -> Image.Image:
    feather = max(1, min(overlap, feather or overlap))
    arr = np.zeros((overlap, width), dtype=np.float32)
    start = max(0, overlap - feather)
    if method in {"overlap", "crop"}:
        arr[:, :] = 1.0
    else:
        if start > 0:
            arr[:start, :] = 0.0
        ramp = np.linspace(0.0, 1.0, overlap - start, dtype=np.float32)
        arr[start:, :] = ramp[:, None]

    if method == "local_mask":
        local = np.zeros_like(arr)
        regions = pair.get("blend_regions") or []
        if not regions:
            regions = [{"x1": 0, "x2": 1, "y1": 0, "y2": 1}]
        for rect in regions:
            x1, y1, x2, y2 = _rect_to_pixels(rect, width, overlap)
            local[y1:y2, x1:x2] = arr[y1:y2, x1:x2]
        # Outside blend regions, use a hard switch in the middle rather than ghosting.
        local[overlap // 2 :, :] = np.maximum(local[overlap // 2 :, :], 1.0)
        arr = local

    for rect in pair.get("protected_regions") or []:
        x1, y1, x2, y2 = _rect_to_pixels(rect, width, overlap)
        keep = rect.get("keep", "base")
        arr[y1:y2, x1:x2] = 0.0 if keep == "base" else 1.0

    return Image.fromarray(np.clip(arr * 255, 0, 255).astype(np.uint8), "L")


def merge_pair(base: Image.Image, nxt: Image.Image, pair: dict[str, Any]) -> tuple[Image.Image, dict[str, Any]]:
    method = str(pair.get("method", "feather")).lower()
    if method not in {"direct", "crop", "overlap", "feather", "local_mask"}:
        method = "feather"

    crop_bottom = clamp_int(pair.get("crop_bottom", 0), 0, max(0, base.height - 1))
    crop_top = clamp_int(pair.get("crop_top", 0), 0, max(0, nxt.height - 1))
    if crop_bottom:
        base = base.crop((0, 0, base.width, base.height - crop_bottom))
    if crop_top:
        nxt = nxt.crop((0, crop_top, nxt.width, nxt.height))

    if method in {"direct", "crop"}:
        out = Image.new("RGB", (base.width, base.height + nxt.height), "white")
        out.paste(base, (0, 0))
        seam_y = base.height
        out.paste(nxt, (0, seam_y))
        return out, {
            "method": method,
            "seam_y": seam_y,
            "crop_bottom": crop_bottom,
            "crop_top": crop_top,
            "overlap": 0,
            "feather": 0,
        }

    requested_overlap = int(pair.get("overlap", 120) or 120)
    max_overlap = max(1, min(base.height, nxt.height) // 2)
    overlap = max(1, min(requested_overlap, max_overlap))
    feather = max(1, min(int(pair.get("feather", overlap) or overlap), overlap))

    base_overlap = base.crop((0, base.height - overlap, base.width, base.height))
    next_overlap = nxt.crop((0, 0, nxt.width, overlap))
    if pair.get("color_match", False):
        next_overlap = color_match(next_overlap, base_overlap, float(pair.get("color_match_strength", 0.5)))
        # Apply a milder correction to the complete next image for continuity.
        nxt = color_match(nxt, base_overlap.resize(nxt.size), min(0.25, float(pair.get("color_match_strength", 0.5)) / 2))
        next_overlap = nxt.crop((0, 0, nxt.width, overlap))

    alpha = make_alpha(base.width, overlap, feather, method, pair)
    blended = Image.composite(next_overlap, base_overlap, alpha)

    seam_y = base.height - overlap
    out = Image.new("RGB", (base.width, base.height + nxt.height - overlap), "white")
    out.paste(base.crop((0, 0, base.width, seam_y)), (0, 0))
    out.paste(blended, (0, seam_y))
    out.paste(nxt.crop((0, overlap, nxt.width, nxt.height)), (0, seam_y + overlap))
    return out, {
        "method": method,
        "seam_y": seam_y,
        "crop_bottom": crop_bottom,
        "crop_top": crop_top,
        "overlap": overlap,
        "feather": feather,
    }


def auto_plan(paths: list[Path], target_width: int) -> dict[str, Any]:
    images = [resize_to_width(open_rgb(p), target_width) for p in paths]
    pairs = []
    for i in range(len(images) - 1):
        h = min(images[i].height, images[i + 1].height)
        overlap = max(64, min(180, round(h * 0.08)))
        pairs.append({
            "from": i + 1,
            "to": i + 2,
            "method": "feather",
            "crop_bottom": 0,
            "crop_top": 0,
            "overlap": overlap,
            "feather": overlap,
            "color_match": True,
            "color_match_strength": 0.35,
            "blend_regions": [],
            "protected_regions": [],
            "notes": "自动生成的保守候选参数，正式拼接前应由智能体查看实际画面并修正"
        })
    return {"target_width": target_width, "output_format": "PNG", "background_color": "#FFFFFF", "pairs": pairs}


def create_contact_sheet(paths: list[Path], output: Path, thumb_width: int = 280) -> None:
    thumbs = [resize_to_width(open_rgb(p), thumb_width) for p in paths]
    gap = 16
    width = sum(x.width for x in thumbs) + gap * (len(thumbs) - 1)
    height = max(x.height for x in thumbs)
    canvas = Image.new("RGB", (width, height), "white")
    x = 0
    for thumb in thumbs:
        canvas.paste(thumb, (x, 0))
        x += thumb.width + gap
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output, quality=90)


def main() -> int:
    parser = argparse.ArgumentParser(description="按逐对拼接方案合成长海报")
    parser.add_argument("--images-dir", required=True)
    parser.add_argument("--plan")
    parser.add_argument("--output")
    parser.add_argument("--preview-dir")
    parser.add_argument("--auto-plan-output")
    parser.add_argument("--target-width", type=int, default=1024)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    paths = image_files(args.images_dir)
    if len(paths) < 2:
        print("至少需要两张分段图片", file=sys.stderr)
        return 2

    if args.plan:
        plan = read_json(args.plan)
    else:
        plan = auto_plan(paths, args.target_width)

    if args.auto_plan_output:
        write_json(args.auto_plan_output, auto_plan(paths, int(plan.get("target_width", args.target_width))))

    preview_dir = Path(args.preview_dir) if args.preview_dir else None
    if preview_dir:
        create_contact_sheet(paths, preview_dir / "contact_sheet.jpg")

    if args.dry_run:
        print(json.dumps({"ok": True, "dry_run": True, "plan": plan, "images": [str(p) for p in paths]}, ensure_ascii=False, indent=2))
        return 0

    if not args.output:
        print("非 dry-run 模式必须提供 --output", file=sys.stderr)
        return 2

    target_width = int(plan.get("target_width", args.target_width))
    images = [resize_to_width(open_rgb(p), target_width) for p in paths]
    pair_plans = plan.get("pairs", [])
    if len(pair_plans) < len(images) - 1:
        auto = auto_plan(paths, target_width)["pairs"]
        pair_plans = list(pair_plans) + auto[len(pair_plans):]

    composite = images[0]
    joins = []
    for i, nxt in enumerate(images[1:]):
        pair = pair_plans[i]
        composite, info = merge_pair(composite, nxt, pair)
        info.update({"from": i + 1, "to": i + 2})
        joins.append(info)

        if preview_dir:
            y = info["seam_y"]
            top = max(0, y - 160)
            bottom = min(composite.height, y + max(240, info.get("overlap", 0) + 160))
            crop = composite.crop((0, top, composite.width, bottom))
            crop.save(preview_dir / f"seam_{i+1:02d}_{i+2:02d}.png")

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fmt = str(plan.get("output_format", output.suffix.lstrip(".") or "PNG")).upper()
    if fmt in {"JPG", "JPEG"}:
        composite.save(output, "JPEG", quality=95, optimize=True)
    else:
        composite.save(output, "PNG", optimize=True)

    manifest = {
        "output": str(output),
        "width": composite.width,
        "height": composite.height,
        "source_images": [str(p) for p in paths],
        "joins": joins,
    }
    manifest_path = output.parent / "stitch_manifest.json"
    write_json(manifest_path, manifest)
    print(json.dumps({"ok": True, "output": str(output), "manifest": str(manifest_path), "size": [composite.width, composite.height]}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
