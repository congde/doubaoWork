from __future__ import annotations

import argparse
import importlib.util
import json
import os
import platform
import shutil
import sys
from pathlib import Path

# 保证本目录内的同模块可被导入，无论运行时的 cwd 在哪。
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _find_arkcli() -> bool:
    """按与 generate_segments.py 相同的优先级探测 arkcli 是否可用。"""
    if os.environ.get("ARKCLI_BIN") and Path(os.environ["ARKCLI_BIN"]).exists():
        return True
    if shutil.which("arkcli") or shutil.which("arkcli.exe"):
        return True
    base = Path.home() / ".workbuddy" / "binaries" / "node" / "versions"
    if base.exists():
        for ver_dir in base.iterdir():
            bin_dir = ver_dir / "node_modules" / "@volcengine" / "ark-cli" / "bin"
            if bin_dir.exists():
                if (bin_dir / "arkcli-windows-amd64.exe").exists():
                    return True
                if (bin_dir / "arkcli.exe").exists():
                    return True
    return False


def _api_state(config_path: str | None = None):
    """探测 OpenAI 兼容 API 配置状态（不回显任何 Key）。

    返回 (ready, backend_name, errors, masked_config, config_path_str)。
    """
    try:
        from config_manager import configuration_status, load_config
        from opc_image_client import is_opc_config
    except ImportError:
        return False, None, ["API 模块不可用（config_manager / opc_image_client）"], None, ""
    try:
        config = load_config(config_path)
    except Exception as exc:
        return False, None, [f"读取 API 配置失败：{exc}"], None, ""
    status = configuration_status(config)
    if not status["ready"]:
        return False, None, status["errors"], status["config"], str(status["config_path"])
    return True, ("opc" if is_opc_config(config) else "openai"), [], status["config"], str(status["config_path"])


def main() -> int:
    parser = argparse.ArgumentParser(description="检查连续长海报 Skill 运行环境")
    parser.add_argument("--json", action="store_true", dest="as_json")
    parser.add_argument("--config", help="API 配置文件路径（openai/opc 后端，可选）")
    args = parser.parse_args()

    # requests 仅 openai/opc 后端需要；未配置 API 的 CLI 用户可以不装。
    required_core = ["PIL", "numpy"]
    missing_core = [name for name in required_core if importlib.util.find_spec(name) is None]
    requests_ok = importlib.util.find_spec("requests") is not None
    py_ok = sys.version_info >= (3, 10)

    api_ready, api_backend, api_errors, api_masked, api_path = _api_state(args.config)
    dreamina_ok = shutil.which("dreamina") is not None
    arkcli_ok = _find_arkcli()

    # 四后端：API（openai/opc）或任一 CLI 可用即视为生图后端就绪
    backend_ok = api_ready or dreamina_ok or arkcli_ok
    available: list[str] = []
    if api_ready and api_backend:
        available.append(api_backend)
    if dreamina_ok:
        available.append("dreamina")
    if arkcli_ok:
        available.append("arkcli")
    # 推荐后端：API 已配置时默认 API（openai 为默认后端）；仅一个 CLI 时为该 CLI；
    # 多个可用时不推荐（建议显式指定）。
    if api_ready and api_backend:
        recommended_backend = api_backend
    elif len(available) == 1:
        recommended_backend = available[0]
    else:
        recommended_backend = None
    both_cli_installed = dreamina_ok and arkcli_ok

    report = {
        "ready": py_ok and not missing_core and backend_ok,
        "python_ok": py_ok,
        "python_version": platform.python_version(),
        "missing_dependencies": missing_core,
        "api_configured": api_ready,
        "api_backend": api_backend if api_ready else None,
        "api_configuration_errors": api_errors if not api_ready else [],
        "api_config": api_masked,
        "api_config_path": api_path,
        "requests_installed": requests_ok,
        "dreamina_cli_installed": dreamina_ok,
        "arkcli_installed": arkcli_ok,
        "available_backends": available,
        "both_cli_backends_installed": both_cli_installed,
        "recommended_backend": recommended_backend,
        "recommended_actions": [],
    }
    if not py_ok:
        report["recommended_actions"].append("安装 Python 3.10 或更高版本")
    if missing_core:
        requirements = Path(__file__).resolve().parents[1] / "requirements.txt"
        report["recommended_actions"].append(f"运行: python -m pip install -r \"{requirements}\"")
    if api_ready and not requests_ok:
        report["recommended_actions"].append(
            "已配置 API 后端但缺少 requests 依赖：python -m pip install requests"
        )
    if not backend_ok:
        report["recommended_actions"].append(
            "配置或安装任一可用生图后端："
            "(1) OpenAI 兼容 API（默认后端）—— 运行 configure.py set --api-key <KEY> "
            "--base-url <URL> --model <MODEL>（支持 gpt-image-2、即梦 5.0 Pro/Lite 等任意模型名，"
            "凭据由用户自行向所选 OpenAI 兼容 API 服务商申请）；"
            "(2) 即梦 CLI —— 启用 WorkBuddy 的 dreamina-cli 技能并 dreamina login；"
            "(3) 火山 Ark CLI —— npm i -g @volcengine/ark-cli 后 arkcli auth login "
            "volc-sso --no-browser 并配置 API Key"
        )
    elif both_cli_installed and not api_ready:
        report["recommended_actions"].append(
            "即梦 CLI 与火山 Ark CLI 均已安装且未配置 API：二者分属不同平台（模型命名、额度、"
            "登录方式互不相同），请先与用户确认使用哪个平台，再显式指定 --backend dreamina 或 "
            "--backend arkcli（或配置 API 后端后使用 --backend openai / opc）。"
        )

    if args.as_json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("连续长海报 Skill 环境检查")
        print(f"- Python: {report['python_version']} ({'通过' if py_ok else '不通过'})")
        print(f"- 核心依赖: {'通过' if not missing_core else '缺少 ' + ', '.join(missing_core)}"
              + ("" if not api_ready or requests_ok else "（API 后端另需 requests）"))
        print(f"- API 后端（openai/opc）: "
              f"{'已配置（' + api_backend + '）' if api_ready else '未配置'}")
        print(f"- 即梦 CLI: {'已安装' if dreamina_ok else '未检测到'}")
        print(f"- 火山 Ark CLI: {'已安装' if arkcli_ok else '未检测到'}")
        print(f"- 可用后端: {', '.join(available) or '无'}")
        if report["recommended_backend"]:
            print(f"- 推荐后端: {report['recommended_backend']}"
                  + ("（API 为默认后端）" if api_ready else "（仅该后端可用）"))
        if both_cli_installed and not api_ready:
            print("- 注意: 即梦 CLI 与火山 Ark CLI 均已安装且未配置 API，二者分属不同平台"
                  "（模型命名、额度、登录方式互不相同），需先与用户确认使用哪个平台，"
                  "再显式指定 --backend。")
        for action in report["recommended_actions"]:
            print(f"  建议: {action}")

    return 0 if report["ready"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
