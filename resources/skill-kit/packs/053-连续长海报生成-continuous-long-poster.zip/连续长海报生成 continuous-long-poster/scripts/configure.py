from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

try:
    from .config_manager import ApiConfig, configuration_status, load_config, save_config
except ImportError:
    from config_manager import ApiConfig, configuration_status, load_config, save_config


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="配置连续长海报 Skill 的图片 API")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("show", help="显示当前配置（密钥脱敏）")

    set_parser = sub.add_parser("set", help="写入或更新配置")
    set_parser.add_argument("--api-key")
    set_parser.add_argument("--base-url")
    set_parser.add_argument("--model")
    set_parser.add_argument("--generation-path")
    set_parser.add_argument("--edit-path")
    set_parser.add_argument("--size")
    set_parser.add_argument("--quality")
    set_parser.add_argument("--provider-name")
    set_parser.add_argument("--allow-text-only-fallback", action="store_true")
    set_parser.add_argument("--config-path")

    clear_parser = sub.add_parser("clear", help="删除本地配置")
    clear_parser.add_argument("--config-path")
    return parser


def main() -> int:
    args = build_parser().parse_args()

    if args.command == "show":
        print(json.dumps(configuration_status(load_config()), ensure_ascii=False, indent=2))
        return 0

    if args.command == "clear":
        path = Path(args.config_path).expanduser() if args.config_path else Path.home() / ".workbuddy-long-poster" / "config.json"
        if path.exists():
            path.unlink()
        print(json.dumps({"ok": True, "removed": str(path)}, ensure_ascii=False))
        return 0

    config = load_config(args.config_path)
    updates = {
        "api_key": args.api_key,
        "base_url": args.base_url,
        "model": args.model,
        "generation_path": args.generation_path,
        "edit_path": args.edit_path,
        "size": args.size,
        "quality": args.quality,
        "provider_name": args.provider_name,
    }
    for key, value in updates.items():
        if value is not None:
            setattr(config, key, value)
    if args.allow_text_only_fallback:
        config.allow_text_only_fallback = True

    target = save_config(config, args.config_path)
    status = configuration_status(config)
    status.update({"saved": True, "saved_to": str(target)})
    print(json.dumps(status, ensure_ascii=False, indent=2))
    return 0 if status["ready"] else 2


if __name__ == "__main__":
    sys.exit(main())
