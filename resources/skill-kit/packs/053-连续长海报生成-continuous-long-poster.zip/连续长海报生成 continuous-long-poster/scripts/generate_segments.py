from __future__ import annotations

"""连续长海报生图后端：把 continuous-long-poster 的 poster_plan.json 翻译成一连串
生图调用，处理提交、轮询/下载、参考图裁剪，并产出 segments/ 与 generation_manifest.json。

本脚本支持四个后端，通过 --backend 选择：

- openai（OpenAI 兼容 API，默认后端）：同步生图服务（GPT Image 2 等），调用用户配置的
  images API（文生图 + 图片编辑）。配置存于 ~/.workbuddy-long-poster/config.json，用
  configure.py 或环境变量设置。当 base_url 指向 OPC（OpenAI 兼容聚合 API）（<你的 API 服务地址>）等异步服务时，
  自动切换为异步客户端轮询取图。详见 references/06-api-setup-guide.md。

- opc（OPC（OpenAI 兼容聚合 API） <你的 API 服务地址>）：强制使用 OPC 异步客户端（POST /v1/media/generate →
  轮询 /v1/media/status → 下载）。与 openai 后端共用同一份配置；适合调用 gpt-image-2、
  即梦 5.0 Pro / Lite 等聚合模型。详见 references/06-api-setup-guide.md。

- dreamina（即梦 / Dreamina CLI）：异步生图服务，支持 9:16 长图、2K 分辨率、
  最多 10 张参考图，能用上一段成图做 image2image，连续性更强；消耗即梦额度（credits），
  无需配置任何 OpenAI 兼容 API Key。详见 references/08-dreamina-backend.md。

- arkcli（火山引擎 Ark CLI）：同步生图服务，调用 `arkcli +gen`（Doubao-Seedream 等
  图片模型），支持 --input 参考图、--size 自定义尺寸、--save-to 本地落盘；消耗火山
  方舟账号额度，需已登录 Ark CLI 并配置 API Key。详见 references/09-arkcli-backend.md。

拼接（stitch_long_poster.py）、质检（qc_report.py）与具体生图引擎无关——它们只读取
本地图片文件。
"""

import argparse
import glob as _glob
import json
import os
import re
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

# 保证本目录内的同模块可被导入，无论运行时的 cwd 在哪。
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils import read_json, safe_filename, write_json


# --------------------------------------------------------------------------- #
# 提示词构建（与配方规划强绑定，所有分段复用同一份逻辑）
# --------------------------------------------------------------------------- #
# 【重要·段间线状体衔接：策划阶段决策约束，绝不注入生图提示词】
# 这是长海报拼接质量的关键经验：贯穿全图的「衔接带」（时间线/光带/丝带/历程带）
# 在生图前的方案策划（头脑风暴）阶段就必须定好走向，且必须满足：
#   - 不允许一根「竖直硬线」从上边缘贯穿到下边缘；
#   - 要么整条都是曲线/流体物（飘带、光晕、河流、云气、能量流）；
#   - 要么只允许在衔接带「中段」竖直走向，但在距上/下边缘约 10% 的区域内必须收束为
#     曲线/流体物。严禁在上下边缘出现竖直柱子/树干/竖杆/硬直线出口入口。
# 原因：AI 生图无法保证相邻两段的竖直线在精确坐标对齐，硬竖边会造成拼接处错位断裂。
# 该约束的落点：写入 poster_plan.json 的 global.visual_baseline（visual_anchor /
# transition）以及每个 segment 的 composition / transition_in / transition_out；
# 由智能体在「步骤 2 规划整张长海报」的头脑风暴中应用。生图提示词只引用 plan 中
# 已确定的构图与过渡，绝不把上面的约束原文塞进每段提示词。完整规则见
# references/03-continuity-rules.md。


def build_prompt(plan: dict[str, Any], segment: dict[str, Any], previous: Path | None,
                 textless: bool = False) -> str:
    global_plan = plan.get("global", {})
    baseline = global_plan.get("visual_baseline", {})
    text_policy = global_plan.get("text_policy", {})
    role = segment.get("role", "middle")
    content = segment.get("content", [])
    content_text = "\n".join(f"- {x}" for x in content) if isinstance(content, list) else str(content)
    include = segment.get("must_include", [])
    avoid = segment.get("must_avoid", [])

    # 提示词保持精简：方舟 Seedream 官方建议中文 ≤300 字（即梦官方为 ≤800 字，
    # 两者后端不同、上限不同）。300 是「软性质量建议」——超出后模型可能忽略细节，
    # 但不会硬截断、也绝不会触发 CLI 报错。注：arkcli 的 "--model 未传" 等 CLI 解析
    # 异常与 prompt 长度无关，根因是 --api-key 注入位置/env 变量 \r 污染（已在
    # _generate_one_arkcli 中修复：api_key 紧跟 --model 注入并 .strip()）。
    # 因此此处只按「质量」控字数，无需为 CLI 稳定性压缩。不 dump 冗长 JSON，给紧凑中文指令即可。
    # 视觉基准优先从 plan 读取，避免把某次项目的硬编码视觉泄漏到通用 Skill。
    palette = baseline.get("palette", global_plan.get("palette", ["品牌主色"]))
    anchor = baseline.get("visual_anchor", "")
    transition = baseline.get("transition", "")
    layout = baseline.get("layout", "")
    background = baseline.get("background", "")
    visual_baseline_str = "；".join(filter(None, [
        f"背景：{background}",
        f"版式：{layout}",
        f"贯穿视觉：{anchor}",
        f"过渡：{transition}",
        f"配色：{', '.join(palette) if isinstance(palette, list) else palette}",
    ]))

    total_segments = len(plan.get("segments", []))
    if textless:
        # 无字底图模式：提示词必须极简（<350 字为佳），否则 AI 会忽略"禁字"指令。
        # 只给最关键的风格、构图、过渡、配色，以及一句强禁令；真实文字由 overlay_text.py 叠加。
        comp = segment.get("textless_composition") or segment.get("composition", "")
        # 无字模式要求提示词极简（<350 字），避免 AI 忽略禁字指令。
        # 优先用 plan 提供的 textless_style / textless_palette；没有则取原字段。
        style = global_plan.get("textless_style") or global_plan.get("style", "")
        concise_palette = global_plan.get("textless_palette") or palette
        concise_palette_str = ", ".join(concise_palette) if isinstance(concise_palette, list) else str(concise_palette)
        concise_visual = "；".join(filter(None, [
            f"贯穿视觉：{anchor}",
            f"过渡：{transition}",
            f"配色：{concise_palette_str}",
        ]))
        prompt = (
            f"竖向长海报第{segment.get('index')}段（共{total_segments}段，{role}），连续长卷的一段，非独立图。\n"
            f"主题：{global_plan.get('title', '')}；风格：{style}。\n"
            f"构图：{comp}\n"
            f"顶承接：{segment.get('transition_in', '')}；底延伸：{segment.get('transition_out', '')}。\n"
            f"{concise_visual}。\n"
            f"【严禁】任何文字/数字/字母/符号/logo/图标/印章/二维码/水印；"
            f"上下边缘10%内用曲线/光晕/云雾收束，禁止竖直硬边入口/出口；"
            f"标题/事件卡/品牌区只留干净浅色留白。"
        )
    else:
        prompt = (
            f"竖向长海报第{segment.get('index')}段（共{total_segments}段，{role}），不是独立图。\n"
            f"主题：{global_plan.get('title', '')}；风格：{global_plan.get('style', '')}。\n"
            f"本段指定文字（禁止自加文案）：\n{content_text}\n"
            f"构图：{segment.get('composition', '')}\n"
            f"顶承接：{segment.get('transition_in', '')}；底延伸：{segment.get('transition_out', '')}\n"
            f"必含：{', '.join(include)}；避：{', '.join(avoid)}。\n"
            f"统一视觉：{visual_baseline_str}。\n"
            f"文字：中文无衬线、清晰锐利、零错字乱码，须与本段指定文字逐字一致。"
        )

    if previous is not None:
        prompt += "\n严格继承上段底部背景/配色/贯穿视觉走向，像同画布向下续画。"
    elif role == "first" and not textless:
        prompt += "\n首段放唯一总标题与开场，底部向下延伸不收尾。"
    if not textless:
        if role == "middle":
            prompt += "\n中段勿重复总标题/开场/页脚/总结/结尾。"
        if role == "last":
            prompt += "\n末段顶部承接上段，底部才收束。"
    return prompt


# 即梦（Dreamina）后端常量
DREAMINA_MAX_IMAGES = 10
DEFAULT_RATIO = "9:16"
DEFAULT_RESOLUTION = "2k"
DEFAULT_MODEL = "5.0Pro"
POLL_INTERVAL = 12
DEFAULT_TIMEOUT = 360

# 火山引擎 Ark CLI 后端常量
ARKCLI_MAX_IMAGES = 8
ARKCLI_DEFAULT_MODEL = "doubao-seedream-5-0-260128"  # 5.0 Lite 的 callable id：安心体验免费额度约 50 张（远多于 Pro 仅 1 张），故作为 arkcli 默认，避免误耗 Pro 额度导致整批中断
# 9:16 竖图，通用安全默认：1440x2560 = 3,686,400 像素，同时满足
# Seedream-5.0 pro(≥921,600)、5.0 lite/4.5(≥3,686,400)、4.0(≥921,600) 的最低像素要求，
# 故可作为四款模型的统一默认尺寸（lite/4.5/4.0 还可上调至 4096x4096，pro 上限约 4,624,220）。
ARKCLI_DEFAULT_SIZE = "1440x2560"

# OpenAI 兼容 / OPC API 后端常量
# 图片编辑接口（/images/edits）的参考图上限：gpt-image-2 的 image[] 支持多图，
# 取 8 张为保守安全值（优先保留上一段成图，与 arkcli 一致）。
API_MAX_IMAGES = 8


# --------------------------------------------------------------------------- #
# 即梦（Dreamina）CLI 封装
# --------------------------------------------------------------------------- #
def _parse_json(text: str) -> dict:
    """从 subprocess 输出中提取首个完整 JSON 对象（容忍前后杂文与转义字符串）。"""
    text = (text or "").strip()
    start = text.find("{")
    if start < 0:
        raise ValueError(f"dreamina 输出中未找到 JSON 对象：{text[:200]}")
    decoder = json.JSONDecoder()
    obj, _ = decoder.raw_decode(text[start:])
    return obj


def _run_dreamina(args: list[str], timeout: int = 120) -> dict:
    proc = subprocess.run(
        ["dreamina", *args],
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=timeout,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"dreamina {' '.join(args)} 失败 (exit={proc.returncode}): "
            f"{proc.stderr.strip() or proc.stdout.strip()}"
        )
    return _parse_json(proc.stdout)


def _ensure_dreamina() -> None:
    if shutil.which("dreamina") is None:
        raise RuntimeError(
            "未检测到 dreamina CLI。请先安装即梦命令行并登录：\n"
            "  dreamina login\n"
            "运行前确认额度：dreamina user_credit"
        )


def _check_credit() -> None:
    try:
        data = _run_dreamina(["user_credit"], timeout=60)
        credit = data.get("total_credit")
        print(f"[dreamina] 当前剩余额度：{credit}", file=sys.stderr)
    except Exception as exc:  # 非致命：仅提醒
        print(f"[dreamina] 无法读取额度（不影响生成）：{exc}", file=sys.stderr)


# --------------------------------------------------------------------------- #
# 火山引擎 Ark CLI 封装
# --------------------------------------------------------------------------- #
def _resolve_arkcli_bin(explicit: str | None) -> str:
    """按优先级定位 arkcli 可执行文件：显式路径 → 原生 .exe → PATH(非包装) → WorkBuddy 托管 Node 原生 .exe → ARKCLI_BIN。

    关键：务必优先使用原生可执行文件（arkcli-windows-amd64.exe / arkcli.exe），
    不要用 arkcli.cmd / arkcli.ps1 包装脚本——后者经 Windows cmd.exe 解析参数，
    当 prompt 含中文/换行时，后续 --save-to / --output-format 等旗标会被吞掉，
    导致图片落到 cwd、且强制 jpeg。原生 .exe 由 Go 直接解析 argv，无此问题。
    """
    def _is_wrapper(p: str) -> bool:
        return p.lower().endswith((".cmd", ".ps1"))

    def _native_sibling(wrapper: str) -> str | None:
        # arkcli.cmd / arkcli.ps1 通常旁边有原生 exe：arkcli-windows-amd64.exe / arkcli.exe
        d = Path(wrapper).parent
        for name in ("arkcli-windows-amd64.exe", "arkcli.exe"):
            cand = d / name
            if cand.exists():
                return str(cand)
        return None

    if explicit:
        if not Path(explicit).exists():
            raise RuntimeError(f"指定的 arkcli 路径不存在：{explicit}")
        if _is_wrapper(explicit):
            sib = _native_sibling(explicit)
            if sib:
                return sib
        return explicit

    # 1) WorkBuddy 托管 Node 目录下的原生 .exe（最可靠，跨版本 glob）
    base = Path.home() / ".workbuddy" / "binaries" / "node" / "versions"
    if base.exists():
        for ver_dir in base.iterdir():
            bin_dir = ver_dir / "node_modules" / "@volcengine" / "ark-cli" / "bin"
            if bin_dir.exists():
                for name in ("arkcli-windows-amd64.exe", "arkcli.exe"):
                    cand = bin_dir / name
                    if cand.exists():
                        return str(cand)

    # 2) PATH 中的 arkcli（跳过 .cmd / .ps1 包装，优先找 .exe）
    for which_name in ("arkcli.exe", "arkcli"):
        found = shutil.which(which_name)
        if found and not _is_wrapper(found):
            return found

    # 3) ARKCLI_BIN 环境变量
    env_bin = os.environ.get("ARKCLI_BIN")
    if env_bin and Path(env_bin).exists():
        if _is_wrapper(env_bin):
            sib = _native_sibling(env_bin)
            if sib:
                return sib
        return env_bin

    raise RuntimeError(
        "未检测到 arkcli。请确认已安装火山引擎 Ark CLI 并登录：\n"
        "  npm i -g @volcengine/ark-cli\n"
        "  arkcli auth login volc-sso --no-browser  # 跨设备授权后回传授权码\n"
        "  echo '<API_KEY>' | arkcli auth apikey    # 写入数据面 Key\n"
        "也可通过 --arkcli-path 显式指定，或设置环境变量 ARKCLI_BIN 指向可执行文件。"
    )


def _load_ark_key() -> str | None:
    """解析火山方舟数据面 API Key 并写入本进程环境变量 ARK_API_KEY（供 arkcli 子进程继承）。

    这是「40 分钟反复踩坑」的首要根因修复：脚本必须**自动**找到 Key，而不是要求用户每次
    手动 export。查找顺序：
      1. 环境变量 ARK_API_KEY
      2. 环境变量 VOLCENGINE_ARK_API_KEY
      3. 用户级 ~/.arkcli/.env 中的 VOLCENGINE_ARK_API_KEY / ARK_API_KEY
         （arkcli 在 Windows 下会把 Key 写成带双引号的 "ark-xxxx"，需剥离引号与 \r）
    返回 Key 字符串；若都找不到返回 None（调用方据此给出清晰报错，而非静默失败）。
    """
    for env_name in ("ARK_API_KEY", "VOLCENGINE_ARK_API_KEY"):
        v = os.environ.get(env_name, "").strip().strip('"').strip("'")
        if v:
            os.environ["ARK_API_KEY"] = v
            return v
    env_path = Path.home() / ".arkcli" / ".env"
    if env_path.exists():
        try:
            text = env_path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            text = ""
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            k = k.strip()
            v = v.strip().strip('"').strip("'").strip()
            if k in ("ARK_API_KEY", "VOLCENGINE_ARK_API_KEY") and v:
                os.environ["ARK_API_KEY"] = v
                return v
    return None


def _arkcli_available() -> bool:
    """探测 arkcli 是否可用（与 _resolve_arkcli_bin 同优先级，仅判断不报错）。"""
    try:
        _resolve_arkcli_bin(None)
        return True
    except Exception:
        return False


def _api_config_state(config_path: str | None = None):
    """探测 OpenAI 兼容 API 配置状态（不回显任何 Key）。

    返回 (ready: bool, backend_name: 'openai' | 'opc' | None, errors: list)。
    - 未配置 / 配置不完整 → ready=False；
    - 配置有效且 base_url 命中异步聚合 API（含 `/media` 或 provider=opc）→ 'opc'；否则 → 'openai'。
    - requests 依赖缺失时同样返回 ready=False（CLI 后端用户无需安装 requests）。
    """
    try:
        from config_manager import load_config
        from opc_image_client import is_opc_config
    except ImportError:
        return False, None, ["API 后端依赖（config_manager / opc_image_client）不可用"]
    try:
        config = load_config(config_path)
        errors = config.validate()
    except Exception as exc:
        return False, None, [f"读取 API 配置失败：{exc}"]
    if errors:
        return False, None, errors
    return True, ("opc" if is_opc_config(config) else "openai"), []


def _load_api_client(backend: str, config_path: str | None = None):
    """按后端加载 API 客户端：openai（自动识别同步/异步）/ opc（强制异步）。

    - backend == 'opc' → 强制 OpcImageClient（异步 create+poll+download）；
    - backend == 'openai' → base_url 指向 OPC 等异步服务时自动切 OpcImageClient，
      否则用同步 ImageClient（POST /images/generations 与 /images/edits）。
    """
    from config_manager import load_config
    from image_client import ImageClient
    from opc_image_client import OpcImageClient, is_opc_config

    config = load_config(config_path)
    errors = config.validate()
    if errors:
        raise RuntimeError(
            "生图 API 尚未配置完整：" + "；".join(errors) +
            "\n请运行 configure.py set --api-key <KEY> --base-url <URL> --model <MODEL> 完成配置，"
            "或参见 references/06-api-setup-guide.md（凭据由用户自行向所选 OpenAI 兼容 API 服务商申请，"
            "支持 gpt-image-2 / 即梦 5.0 Pro/Lite 等模型）。"
        )
    if backend == "opc" or (backend == "openai" and is_opc_config(config)):
        if backend == "openai":
            print("[api] 检测到 base_url 为 OPC（异步接口），已自动切换为 OPC 异步客户端。",
                  file=sys.stderr)
        return OpcImageClient(config), config
    return ImageClient(config), config


def _generate_one_api(prompt: str, refs: list[Path], output_path: Path,
                      client, config, size: str | None) -> tuple[Path, str]:
    """用 OpenAI 兼容 / OPC API 客户端生成一段图片。

    有参考图（上一段成图 + 永久素材）时优先走图片编辑（edit）以延续同一画布；
    编辑失败且 allow_text_only_fallback 开启时退化为纯文生图并在 manifest 记 warning
    （由调用方通过 ImageApiError 判定，见主循环）。
    """
    if refs:
        try:
            target = client.edit(prompt, refs, output_path, size=size)
            return Path(target), "edit"
        except Exception as exc:
            if not getattr(config, "allow_text_only_fallback", False):
                raise
            print(f"[api] 第 {output_path.stem} 段编辑接口失败（{exc}），按配置退化为纯文生图。",
                  file=sys.stderr)
    target = client.generate(prompt, output_path, size=size)
    return Path(target), ("text_fallback" if refs else "generate")


def _detect_installed_backends() -> list[str]:
    """返回已就绪的后端列表：可能含 'openai'/'opc'（API 已配置）、'dreamina'、'arkcli'。

    顺序固定：API 后端（openai/opc）→ dreamina → arkcli。
    注意：只探测公开安装/配置状态，绝不读取或回显任何 API Key / token / 接入点 id。
    """
    installed: list[str] = []
    api_ready, api_name, _ = _api_config_state()
    if api_ready and api_name:
        installed.append(api_name)
    if shutil.which("dreamina") is not None:
        installed.append("dreamina")
    if _arkcli_available():
        installed.append("arkcli")
    return installed


def _norm_model_key(s: str) -> str:
    """归一化模型名：转小写、去 doubao- 前缀、统一分隔符为连字符。"""
    s = (s or "").lower().replace("doubao-", "")
    return s.replace(".", "-").replace("_", "-")


def _norm_model_alias(s: str) -> str:
    """把中英文口语化写法归一为技能内部的友好名。无法识别则原样返回。

    例：
      '火山方舟Seedream 图片模型5.0 lite' -> 'doubao-seedream-5-0'
      'seedream 5.0 pro'                  -> 'doubao-seedream-5-0-pro'
      'Seedream 4.5'                       -> 'doubao-seedream-4-5'

    已是正确的友好名 / callable id / 接入点 id（ep-xxxx）时直接返回，不做改动。
    注意：只映射火山方舟公开模型名，绝不引入任何个人 API Key / 接入点 id。
    """
    raw = (s or "").strip()
    if not raw:
        return raw
    low = raw.lower()
    # 已是接入点 id，或带版本后缀的 callable id，或已知友好名：原样返回
    if low.startswith("ep-") or re.search(r"\d-\d(-\d{4,})?$", low) or low in (
        "doubao-seedream-5-0-pro", "doubao-seedream-5-0",
        "doubao-seedream-4-5", "doubao-seedream-4-0",
    ):
        return raw
    # 噪声词剥离：中文平台名 / 类别词 / 厂商前缀等
    t = low
    for noise in ("火山方舟", "火山", "方舟", "图片模型", "图片", "模型",
                  "doubao", "image", "volc", "ark"):
        t = t.replace(noise, " ")
    t = t.replace(".", "-").replace("_", "-")
    t = re.sub(r"\s+", " ", t).strip()
    # 归一数字写法：'5 0' -> '5-0'
    t = t.replace("5 0", "5-0").replace("4 5", "4-5").replace("4 0", "4-0")
    # 去掉空格，统一做后缀匹配（如 '5-0 pro' -> '5-0pro'）
    t = t.replace(" ", "")
    if "seedream" not in t:
        return raw
    if "5-0-pro" in t or "5-0pro" in t:
        return "doubao-seedream-5-0-pro"
    if "5-0" in t:
        # 5.0：显式 lite / 轻量 或 默认都走 lite 友好名
        return "doubao-seedream-5-0"
    if "4-5" in t:
        return "doubao-seedream-4-5"
    if "4-0" in t:
        return "doubao-seedream-4-0"
    return raw


def _resolve_arkcli_model(exe: str, model_arg: str) -> str:
    """把用户给的模型标识解析为 +gen 可用的标识。

    - 若已是接入点 id（ep-xxxx），原样返回；
    - 否则先把中英文口语写法（如「火山方舟 Seedream 图片模型 5.0 lite」）
      归一为友好名，再查 `arkcli models list --modality image`，按 name /
      display_name / callable_model_id 归一化匹配，返回其 callable_model_id
      （如 doubao-seedream-5-0-pro -> doubao-seedream-5-0-pro-260628）；
    - 若无法解析（未登录 / 列表失败），原样返回，交 +gen 报错。

    注意：只解析火山方舟公开模型 id，绝不引入任何个人 API Key / 接入点 id。
    """
    m = (model_arg or "").strip()
    if not m:
        return m
    if m.lower().startswith("ep-"):
        return m

    # 先把中英文口语写法归一为友好名 / callable id
    m = _norm_model_alias(m)

    target = _norm_model_key(m)
    try:
        proc = subprocess.run(
            [exe, "models", "list", "--modality", "image", "--format", "json"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=60,
        )
        if proc.returncode == 0:
            data = json.loads(proc.stdout)
            for it in data.get("items", []):
                for key in ("name", "display_name", "callable_model_id"):
                    if _norm_model_key(it.get(key, "")) == target:
                        return it["callable_model_id"]
    except Exception:
        pass
    return m


def _arkcli_model_family(model_id: str, explicit: str = "auto") -> str:
    """根据可调用模型 id 推断模型族，用于决定与模型强相关的参数默认值。

    返回 'pro' | 'lite' | '4.5' | '4.0' | 'unknown'。
    - pro / lite  : 支持 output_format 与 sequential 参数（png / 单图）
    - 4.5 / 4.0   : 不支持 output_format / sequential 参数，默认单张 jpeg 输出
    - unknown(如 ep-xxxx 自定义接入点): 无法判断族，保守兜底（不传生成参数）
    explicit 参数优先：传入 --arkcli-family 时直接采用，避免 ep- 接入点被误判。
    """
    if explicit and explicit != "auto":
        return explicit
    s = (model_id or "").lower()
    if "5-0-pro" in s:
        return "pro"
    if "5-0" in s:
        return "lite"
    if "4-5" in s:
        return "4.5"
    if "4-0" in s:
        return "4.0"
    return "unknown"


def _arkcli_output_format(args: argparse.Namespace, family: str) -> str:
    """决定图片输出格式：用户显式指定优先；否则按模型族自动选。

    png 仅 Seedream-5.0 pro / lite 支持；其余族（4.5 / 4.0 / 未知接入点）
    由模型自行决定输出格式（通常为 jpeg），脚本不向其传 output_format 参数。
    """
    if family in ("pro", "lite") and getattr(args, "output_format", "auto") not in (None, "", "auto"):
        return args.output_format
    return "png" if family in ("pro", "lite") else "jpeg"


def _enhance_arkcli_error(msg: str) -> str:
    """把 arkcli 的典型报错转化为可操作建议，降低他人使用时的排查成本。"""
    tips: list[str] = []
    low = (msg or "").lower()
    if "endpoint id" in low or "plan model name" in low:
        tips.append(
            "arkcli +gen 的 --model 需要『可调用模型 id』（如 doubao-seedream-5-0-pro-260628）"
            "或『接入点 id』（ep-xxxx），不能是市场展示名。可先创建接入点："
            "arkcli +deploy --model <callable_model_id> --name seedream5 --set-default image --yes"
        )
    if "activation" in low or "未开通" in msg or "model_activation" in low:
        tips.append(
            "该模型尚未在方舟控制台开通（model_activation_required）。请到火山方舟控制台『模型管理』"
            "开通对应 Seedream 模型后重新运行。"
        )
    if "size" in low or "pixel" in low or "resolution" in low or "dimensions" in low:
        tips.append(
            "图片尺寸不被支持。Seedream-5.0 要求最低约 368 万像素，建议使用 1440x2560；"
            "若仍被拒请换用更大尺寸或查阅模型支持的尺寸列表。"
        )
    if "output_format" in low or "png" in low and "not" in low or "unsupported" in low and "format" in low:
        tips.append(
            "output_format=png 仅 Seedream-5.0 pro / lite 支持；4.5 / 4.0 请改用 jpeg"
            "（脚本在 auto 模式下已自动按模型选择，也可显式传 --output-format jpeg）。"
        )
    if tips:
        return f"{msg}\n[排查建议] " + "；".join(tips)
    return msg


def _scan_arkcli_failure(stdout: str, stderr: str) -> str | None:
    """arkcli +gen 有时退出码为 0 但数据面实际失败（无图产出）。扫描 stdout/stderr 中的
    典型失败特征，返回可读错误原因；无特征则返 None。用于「退出码 0 但没图」的一次性诊断，
    避免像之前那样反复重试却只看到静默失败。"""
    blob = f"{stdout}\n{stderr}".lower()
    if any(k in blob for k in ("api key", "api_key", "data-plane", "data plane", "missing: api_key")):
        return ("数据面 API Key 缺失或格式不正确。Skill 已自动从环境变量与 ~/.arkcli/.env 读取并注入 "
                "ARK_API_KEY；若仍报此错，请运行 `arkcli auth apikey` 重新拉取 Key，或手动 "
                "export ARK_API_KEY=<你的Key>。注意：方舟数据面只认环境变量 ARK_API_KEY，--api-key "
                "旗标对数据面无效，脚本也不会再传该旗标。")
    if any(k in blob for k in ("quota", "额度", "exceed", "limit", "activation", "未开通", "安心体验", "suspend", "suspended")):
        return ("方舟额度不足 / 模型未开通 / 已被「安心体验」暂停（不扣费，但免费额度已耗尽）。\n"
                "各模型免费额度相互独立、互不影响：5.0 Pro 仅 1 张、5.0 Lite 约 50 张、Seedream-4.5 / 4.0 各为独立额度。"
                "推荐策略：默认先用 5.0 Lite（50 张）；耗尽后改用 4.5 / 4.0 续跑；"
                "5.0 Pro 仅 1 张，请勿作为默认以免整批中断。"
                "若已配置多终点 fallback 链（--arkcli-endpoint ep-lite,ep-45,ep-40），脚本会自动切换，无需手动干预。")
    if any(k in blob for k in ("sensitive", "content", "审核", "违规", "reject", "block", "risk", "敏感", "政治", "military")):
        return ("提示词触发内容安全审核被拦截。请改写涉及军事番号、政府文件编号/批准、具体人物等敏感表述，"
                "保留事实主干即可，然后重新运行该段（已生成段会自动跳过）。")
    if any(k in blob for k in ("param", "not supported", "unsupported", "not_supported")):
        return "存在模型不支持的参数。请检查 --size / --output-format / --sequential 是否与所选模型族匹配。"
    return None


def _run_arkcli(exe: str, args: list[str], timeout: int = 300):
    """arkcli +gen 图片任务同步返回并以文件落盘，无需解析 stdout JSON。

    返回 CompletedProcess，由调用方检查退出码与产出文件（arkcli 数据面失败时可能退出码 0 但无图）。
    """
    return subprocess.run(
        [exe, *args],
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=timeout,
    )


def _find_new_image(save_dir: Path, before_names: set[str]) -> Path:
    """在 save_dir 中找到 arkcli 新写入的图片（优先用 before/after 差值，兜底取最新图片）。"""
    allowed = {".png", ".jpg", ".jpeg", ".webp"}
    after = sorted(
        (p for p in save_dir.glob("*") if p.is_file() and p.suffix.lower() in allowed),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    new = [p for p in after if p.name not in before_names]
    if new:
        return new[0]
    if after:
        return after[0]
    raise RuntimeError(f"arkcli +gen 未在 {save_dir} 产出图片文件")


# --------------------------------------------------------------------------- #
# 参考图解析（含上限裁剪）
# --------------------------------------------------------------------------- #
def _resolve_refs(plan: dict, segment: dict, previous_path: Path | None,
                  max_images: int = DREAMINA_MAX_IMAGES,
                  textless: bool = False) -> list[Path]:
    """合并：上一段成图 + 分段级 reference_images + 全局固定参考图，去重并裁剪到 max_images。

    裁剪策略：上一段成图（连续性最优先）必须保留；其余按“分段级配图 > 全局品牌/人物”
    的顺序保留，直到达到上限。
    """
    raw: list[Path] = []
    if previous_path and previous_path.exists():
        raw.append(previous_path)

    seg_extra = segment.get("reference_images") or []
    if isinstance(seg_extra, list):
        raw.extend(Path(x) for x in seg_extra if str(x).strip())

    assets = plan.get("assets") if isinstance(plan.get("assets"), dict) else {}
    for key in ("reference_images", "character_images", "brand_images"):
        # 无字底图模式下，参考图里的源信息图和 logo 图往往本身含文字，会污染底图，
        # 因此只保留 character_images（吉祥物/人物）以保证角色一致性；文字由代码叠加。
        if textless and key in ("reference_images", "brand_images"):
            continue
        for x in assets.get(key, []) or []:
            if str(x).strip():
                raw.append(Path(x))

    # 去重、剔除非存在文件
    seen: set[str] = set()
    unique: list[Path] = []
    for p in raw:
        if not p.exists():
            continue
        key = str(p)
        if key in seen:
            continue
        seen.add(key)
        unique.append(p)

    if len(unique) > max_images:
        must_keep = unique[0] if (previous_path and unique and unique[0] == previous_path) else None
        trimmed: list[Path] = []
        if must_keep is not None:
            trimmed.append(must_keep)
        for p in unique:
            if p == must_keep:
                continue
            if len(trimmed) >= max_images:
                break
            trimmed.append(p)
        unique = trimmed[:max_images]

    return unique


# --------------------------------------------------------------------------- #
# 单段生成（即梦：提交 -> 轮询 -> 下载 -> 重命名）
# --------------------------------------------------------------------------- #
def _generate_one_dreamina(prompt: str, refs: list[Path], output_path: Path, args: argparse.Namespace):
    if refs:
        gen_args = [
            "image2image",
            "--images", ",".join(str(p) for p in refs),
            "--prompt", prompt,
        ]
    else:
        gen_args = [
            "text2image",
            "--prompt", prompt,
        ]
    gen_args += [
        "--ratio", args.ratio,
        "--resolution_type", args.resolution_type,
        "--model_version", args.model_version,
    ]
    if args.session:
        gen_args += ["--session", str(args.session)]

    # 1) 提交
    submit = _run_dreamina(gen_args, timeout=120)
    submit_id = submit.get("submit_id")
    if not submit_id:
        raise RuntimeError(f"submit 未返回 submit_id：{json.dumps(submit, ensure_ascii=False)[:300]}")
    status = submit.get("gen_status")

    # 2) 轮询直到终态
    deadline = time.time() + args.poll_timeout
    while status == "querying" and time.time() < deadline:
        time.sleep(POLL_INTERVAL)
        res = _run_dreamina(["query_result", "--submit_id", submit_id], timeout=120)
        status = res.get("gen_status")
        if status == "success":
            break
        if status == "fail":
            reason = res.get("fail_reason") or json.dumps(res, ensure_ascii=False)[:300]
            raise RuntimeError(f"即梦任务失败 submit_id={submit_id}: {reason}")
    if status != "success":
        raise RuntimeError(f"即梦任务超时未终态 submit_id={submit_id}, 最后状态={status}")

    # 3) 下载（query_result --download_dir 将结果保存到 output_path.parent）
    _run_dreamina(
        ["query_result", "--submit_id", submit_id, "--download_dir", str(output_path.parent)],
        timeout=180,
    )

    # 4) 重命名：dreamina 下载文件名为 <submit_id>_image_1.<ext>
    downloaded = sorted(
        output_path.parent.glob(f"{submit_id}*"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if not downloaded:
        raise RuntimeError(f"即梦下载未产生文件 submit_id={submit_id} in {output_path.parent}")
    src = downloaded[0]
    target = output_path.with_suffix(src.suffix)
    if src.resolve() != target.resolve():
        # os.replace/Path.replace 在 Windows 下以 MOVEFILE_REPLACE_EXISTING 原子覆盖，
        # 避免沙箱对普通 unlink 的回收站依赖。
        src.replace(target)
    return target, ("image2image" if refs else "text2image")


# --------------------------------------------------------------------------- #
# 单段生成（arkcli：同步生图 -> 落盘 -> 重命名）
# --------------------------------------------------------------------------- #
def _generate_one_arkcli(prompt: str, refs: list[Path], output_path: Path,
                         args: argparse.Namespace, exe: str, model: str, family: str = "auto"):
    family = _arkcli_model_family(model, family)
    out_fmt = _arkcli_output_format(args, family)
    # 提示词长度提醒：方舟建议 ≤300 中文字符 / 600 英文词，超出可能被忽略细节
    cjk = sum(1 for ch in prompt if "一" <= ch <= "鿿")
    if cjk > 300:
        print(f"[arkcli][警告] 提示词含 {cjk} 个中文字符，超过建议上限 300，"
              "模型可能忽略部分细节，建议精简。", file=sys.stderr)

    save_dir = output_path.parent
    save_dir.mkdir(parents=True, exist_ok=True)
    before_names = {p.name for p in save_dir.glob("*") if p.is_file()}

    # 数据面 API Key：仅从环境变量读取（ARK_API_KEY / VOLCENGINE_ARK_API_KEY），
    # 绝不硬编码任何个人 Key。strip() 去除可能的 \r\n 污染（Windows 下 env 偶发），
    # 否则尾部 --api-key 值带 \r 会导致 arkcli 的 argparse 后续参数错位（曾偶发
    # "--model 未传" 误报）。统一在 --model 之后注入，远离参数末端以提升稳定性。
    # 同时去除首尾双/单引号：Windows 下 arkcli 写入 ~/.arkcli/.env 的
    # VOLCENGINE_ARK_API_KEY 常被双引号包裹（如 "ark-xxxx"），若不剥离，
    # 引号会进入 --api-key 值，导致数据面报 "api key format is incorrect" 或
    # "data-plane context is missing: api_key"。
    api_key = (os.environ.get("ARK_API_KEY") or os.environ.get("VOLCENGINE_ARK_API_KEY") or "").strip().strip('"').strip("'")

    cmd = [
        "+gen", prompt,
        "--modality", "image",
        "--model", model,
        "--size", args.size,
    ]
    # 仅 5.0 pro / lite 支持 output_format 与 sequential 生成参数。
    # 4.5 / 4.0 / ep- 未知接入点 完全不支持这些参数（传则报
    # param_not_supported / not supported），其默认即为单张 jpeg 输出，故跳过。
    if family in ("pro", "lite"):
        cmd += ["--output-format", out_fmt]
        # 5.0 lite 默认可能走组图（sequential=auto），显式关闭以保证「一段一图」；
        # 5.0 pro 默认单图，传 disabled 亦无害。
        cmd += ["--sequential", "disabled"]
    cmd += [
        # 水印默认关闭，保持海报画面干净；如需合规水印可传 --watermark。
        "--watermark", "true" if args.watermark else "false",
        "--save-to", str(save_dir),
        "--no-open",
    ]
    for r in refs:
        cmd += ["--input", f"ref:@{r}"]
    if args.optimize_prompt:
        cmd += ["--optimize-prompt", "--prompt-mode", args.prompt_mode]
    if args.seed is not None:
        cmd += ["--seed", str(args.seed)]

    # 数据面（arkruntime）只从环境变量 ARK_API_KEY 读取 Key，--api-key 旗标对
    # 数据面无效；因此把 Key 写入本进程环境变量，subprocess 继承后即可被数据面读取。
    # 关键：不要通过 subprocess(env=child_env) 整体替换环境变量——arkcli 是 .CMD 包装脚本，
    # 在「替换后的环境」下会丢失路径/配置上下文，导致 --save-to / --output-format 被忽略、
    # 图片落到 cwd 而非指定目录。沿用父进程环境（仅追加 ARK_API_KEY）可完全复现手动调用行为。
    if api_key:
        os.environ["ARK_API_KEY"] = api_key
    proc = _run_arkcli(exe, cmd, timeout=max(args.poll_timeout, 120))
    if proc.returncode != 0:
        base = _enhance_arkcli_error(proc.stderr.strip() or proc.stdout.strip())
        raise RuntimeError(f"arkcli +gen 失败 (exit={proc.returncode}):\n{base}")
    # arkcli 数据面失败时可能退出码为 0 但未落图，需二次诊断
    try:
        src = _find_new_image(save_dir, before_names)
    except RuntimeError:
        fail = _scan_arkcli_failure(proc.stdout, proc.stderr)
        extra = f"\n[诊断] {fail}" if fail else ""
        raise RuntimeError(
            f"arkcli +gen 在 {save_dir} 未产出图片（退出码 0 但无图，多为数据面失败）。{extra}\n"
            f"原始输出：{(proc.stdout or proc.stderr)[:600]}"
        )
    target = output_path.with_suffix(src.suffix)
    if src.resolve() != target.resolve():
        # os.replace/Path.replace 在 Windows 下以 MOVEFILE_REPLACE_EXISTING 原子覆盖，
        # 避免沙箱对普通 unlink 的回收站依赖。
        src.replace(target)
    return target, ("image2image" if refs else "text2image")


def _gen_worker_arkcli(job: tuple) -> dict:
    """线程池工作函数：生成单段 arkcli 图。job = (index, prompt, refs, output_path, args, exe, model, family)。"""
    index, prompt, refs, output_path, args, exe, model, family = job
    try:
        target, mode = _generate_one_arkcli(prompt, refs, output_path, args, exe, model, family)
        return {"index": index, "file": str(target), "status": "success", "mode": mode,
                "reference_count": len(refs)}
    except Exception as exc:
        return {"index": index, "file": str(output_path), "status": "failed", "error": str(exc)}


# --------------------------------------------------------------------------- #
# 主流程
# --------------------------------------------------------------------------- #
def _find_existing(output_dir: Path, stem: str) -> Path | None:
    for p in output_dir.glob(f"{stem}.*"):
        if p.is_file():
            return p
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="连续长海报分段图生图后端（即梦CLI / 火山Ark CLI）")
    parser.add_argument("--plan", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--backend", choices=["openai", "opc", "dreamina", "arkcli", "auto"],
                        default="auto",
                        help="生图后端：auto（默认，优先用已配置的 OpenAI 兼容 API；"
                             "未配置 API 时自动选用已安装的唯一 CLI 后端）/ openai（OpenAI 兼容 API，"
                             "默认后端，base_url 为 OPC 时自动切异步客户端）/ opc（强制 OPC（OpenAI 兼容聚合 API）"
                             " <你的 API 服务地址> 异步客户端）/ dreamina（即梦 CLI）/ arkcli（火山引擎 Ark CLI）。"
                             "各平台模型命名、额度、登录方式互不相同，多后端可用时建议显式指定。")
    parser.add_argument("--config", default=None,
                        help="openai/opc 后端：API 配置文件路径（默认 ~/.workbuddy-long-poster/config.json，"
                             "也可用环境变量 LONG_POSTER_API_KEY / LONG_POSTER_BASE_URL / LONG_POSTER_IMAGE_MODEL）")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--only", help="仅生成指定序号，逗号分隔，例如 2,3")
    # 即梦后端参数
    parser.add_argument("--ratio", default=DEFAULT_RATIO)
    parser.add_argument("--resolution-type", dest="resolution_type", default=DEFAULT_RESOLUTION)
    parser.add_argument("--model-version", dest="model_version", default=DEFAULT_MODEL)
    parser.add_argument("--session", type=int, default=0)
    # 火山 Ark CLI 后端参数
    parser.add_argument("--arkcli-path", dest="arkcli_path", default=None,
                        help="arkcli 可执行文件绝对路径；缺省时自动在 PATH / ARKCLI_BIN / WorkBuddy 托管 Node 目录查找")
    parser.add_argument("--arkcli-model", dest="arkcli_model", default=ARKCLI_DEFAULT_MODEL,
                        help="arkcli 图片模型。支持：友好名（doubao-seedream-5-0-pro / doubao-seedream-5-0 / "
                             "doubao-seedream-4-5 / doubao-seedream-4-0）、callable id"
                             "（如 doubao-seedream-5-0-pro-260628）、接入点 id（ep-xxxx），"
                             "以及中英文口语写法（如 '火山方舟 Seedream 图片模型 5.0 lite'、'seedream 5.0 pro'、"
                             "'Seedream 4.5'）；脚本会自动归一并解析为可调用 id；四款 Seedream 模型均兼容")
    parser.add_argument("--arkcli-endpoint", dest="arkcli_endpoint", default=None,
                        help="arkcli 推理接入点 id（ep-xxxx），可逗号分隔多个构成 fallback 链。"
                             "例如 'ep-lite,ep-45,ep-40'：默认先用 Lite（约 50 张免费额度），"
                             "额度耗尽/被暂停时自动切换到 4.5 / 4.0 续跑；绝不会先消耗 5.0 Pro（仅 1 张）。"
                             "提供后优先于 --arkcli-model 使用；不传则默认用 --arkcli-model（5.0 Lite）。")
    parser.add_argument("--arkcli-family", dest="arkcli_family", default="auto",
                        help="arkcli 模型族，可逗号分隔，与 --arkcli-endpoint 一一对应（顺序一致）；"
                             "取值：auto（按 id 自动推断）/ lite / pro / 4.5 / 4.0。"
                             "使用 ep- 接入点时用于明确底层模型（避免被误判为 unknown）："
                             "pro/lite 会传 output_format+sequential 参数，4.5/4.0 则跳过（模型默认单张 jpeg）；"
                             "不传则按 id 自动推断（ep- 接入点回退为 unknown→jpeg，安全但不输出 png）。")
    parser.add_argument("--size", default=ARKCLI_DEFAULT_SIZE,
                        help="arkcli 后端图片尺寸（宽x高像素值）。默认 1440x2560（9:16）为四款模型的通用安全值："
                             "5.0 pro 下限 921,600、5.0 lite/4.5 下限 3,686,400、4.0 下限 921,600 像素；"
                             "lite/4.5/4.0 可上调至 4096x4096，pro 上限约 4,624,220")
    parser.add_argument("--optimize-prompt", dest="optimize_prompt", action="store_true",
                        help="arkcli：启用服务端提示词优化（配合 --prompt-mode）")
    parser.add_argument("--prompt-mode", dest="prompt_mode", default="standard",
                        choices=["standard", "fast"],
                        help="arkcli：提示词优化模式 standard|fast（需配合 --optimize-prompt；"
                             "fast 模式仅 Seedream-5.0 pro 支持，lite/4.5 请勿使用")
    parser.add_argument("--output-format", dest="output_format", default="auto",
                        choices=["auto", "png", "jpeg"],
                        help="arkcli：输出格式。auto(默认)按模型自动选择：pro/lite 用 png，4.5/4.0 用 jpeg；"
                             "也可显式指定 png(仅 pro/lite 支持) 或 jpeg")
    parser.add_argument("--watermark", dest="watermark", action="store_true",
                        help="arkcli：在生成图上添加『AI 生成』水印（默认关闭，保持海报干净）")
    parser.add_argument("--no-watermark", dest="watermark", action="store_false",
                        help="arkcli：不添加水印（默认）")
    parser.set_defaults(watermark=False)
    parser.add_argument("--seed", type=int, default=None, help="arkcli：固定随机种子（可选，提升可复现性）")
    parser.add_argument("--parallel", type=int, default=1,
                        help="arkcli 并行生成段数（默认 1 串行）。>1 时各段独立生成（不引用上一段成图）以提速；"
                             "会牺牲相邻段 image2image 连续性，仅建议在追求速度或已有底图、可接受后续顺序精修时开启。")
    # 通用
    parser.add_argument("--poll-timeout", type=int, default=DEFAULT_TIMEOUT)
    parser.add_argument("--textless", action="store_true",
                        help="无字底图模式：AI 只生成纯净插画（不含任何文字/logo），"
                             "文字由 overlay_text.py 代码精准叠加。也可在 plan 的 "
                             "global.text_policy.render_mode 设为 'textless' 自动启用。")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-credit-check", action="store_true")
    args = parser.parse_args()

    backend = args.backend
    api_client = None
    api_config = None

    # --backend auto：优先用已配置的 OpenAI 兼容 API（默认后端）；未配置 API 时，
    # 若只有一个 CLI 后端已安装则自动选用；两个 CLI 后端都装则要求显式指定。
    if backend == "auto":
        installed = _detect_installed_backends()
        api_installed = [b for b in installed if b in ("openai", "opc")]
        cli_installed = [b for b in installed if b in ("dreamina", "arkcli")]
        if api_installed:
            backend = api_installed[0]
            print(f"[backend] auto 检测到已配置生图 API（{backend}），默认选用该后端。"
                  f"如需切换请显式指定 --backend。", file=sys.stderr)
        elif len(cli_installed) == 1:
            backend = cli_installed[0]
            print(f"[backend] auto 未检测到 API 配置，检测到仅安装 {backend} CLI，自动选用该后端。",
                  file=sys.stderr)
        elif len(cli_installed) == 0:
            raise RuntimeError(
                "未检测到任何可用生图后端。请先完成以下其一：\n"
                "  (1) 配置 OpenAI 兼容 API（默认后端）：运行 configure.py set --api-key <KEY> "
                "--base-url <URL> --model <MODEL>（支持 gpt-image-2、即梦 5.0 Pro/Lite 等模型，"
                "凭据由用户自行向所选 OpenAI 兼容 API 服务商申请）；\n"
                "  (2) 即梦 CLI：启用 WorkBuddy 的 dreamina-cli 技能并运行 `dreamina login` 完成授权；\n"
                "  (3) 火山 Ark CLI：运行 `npm i -g @volcengine/ark-cli` 后 "
                "`arkcli auth login volc-sso --no-browser` 并配置 API Key。\n"
                "可先运行 doctor.py 查看环境状态。"
            )
        else:
            raise RuntimeError(
                "检测到即梦 CLI 与火山 Ark CLI 均已安装（且未配置 API），二者分属不同平台，"
                "无法自动二选一：\n"
                "  · 即梦 CLI  —— 即梦/剪映生态的自有图片模型（如 --model-version 5.0Pro），消耗即梦 credits；\n"
                "  · 火山 Ark CLI —— 火山引擎方舟平台的 Doubao Seedream 系列（5.0 pro / 5.0 lite / 4.5 / 4.0），"
                "消耗方舟额度。\n"
                "两者模型命名、额度、登录方式互不相同。请显式指定 --backend dreamina 或 --backend arkcli"
                "（建议先与用户确认到底用哪个平台），或配置 API 后端（--backend openai / opc）。"
            )

    if backend in ("openai", "opc"):
        try:
            api_client, api_config = _load_api_client(backend, args.config)
            model_desc = f"{getattr(api_config, 'model', '')} @ {getattr(api_config, 'base_url', '')}"
            print(f"[{backend}] API 客户端就绪（{model_desc}）。", file=sys.stderr)
        except RuntimeError as exc:
            if args.dry_run:
                # dry-run 只预览提示词，不真正调用 API；配置不全时降级为无客户端模式。
                print(f"[{backend}] dry-run 模式：API 配置未就绪，仅预览提示词（{exc}）。",
                      file=sys.stderr)
                api_config = None
            else:
                raise
        exe = None
    elif backend == "dreamina":
        _ensure_dreamina()
        if not args.no_credit_check:
            _check_credit()
        exe = None
    elif backend == "arkcli":
        exe = _resolve_arkcli_bin(args.arkcli_path)
        # 解析「终点候选链」（callable id 或 ep- 接入点 id，逗号分隔）：
        #   - 未传 --arkcli-endpoint 时，用 --arkcli-model（默认 5.0 Lite）作为唯一终点；
        #   - 传了多个时（如「ep-lite,ep-45,ep-40」）按序构成 fallback 链：
        #     先用第一个（Lite），额度耗尽/被暂停时自动切换到下一个（4.5/4.0）续跑，
        #     绝不会先消耗 5.0 Pro（仅 1 张免费额度）而导致整批中断。
        arkcli_ids = [e.strip() for e in (args.arkcli_endpoint or "").split(",") if e.strip()]
        if not arkcli_ids:
            arkcli_ids = [_resolve_arkcli_model(exe, args.arkcli_model)]
        fam_list = [f.strip() for f in (args.arkcli_family or "").split(",") if f.strip()]
        while len(fam_list) < len(arkcli_ids):
            fam_list.append("auto")
        primary_model = arkcli_ids[0]
        primary_family = fam_list[0]
        print(f"[arkcli] 使用后端：{exe}", file=sys.stderr)
        key = _load_ark_key()
        if not key:
            print("[arkcli][错误] 未找到方舟数据面 API Key。已尝试：环境变量 ARK_API_KEY / "
                  "VOLCENGINE_ARK_API_KEY，以及 ~/.arkcli/.env。请运行 `arkcli auth apikey` "
                  "拉取并写入 Key（基于当前 SSO 登录直接从控制台获取），或手动 "
                  "export ARK_API_KEY=<你的Key>。", file=sys.stderr)
            return 2
        print("[arkcli] 已自动载入数据面 API Key（无需手动 export）。", file=sys.stderr)
        print(f"[arkcli] 终点候选链：{arkcli_ids}（family：{fam_list}）\n"
              f"[arkcli] 默认先用 {primary_model}（{primary_family}）；额度耗尽时自动切换到下一终点续跑。",
              file=sys.stderr)
    else:
        raise RuntimeError(f"未知后端：{backend}")

    plan = read_json(args.plan)
    # 无字底图模式：显式 --textless 优先；否则读 plan 的 text_policy.render_mode
    _rp = plan.get("global", {}).get("text_policy", {}).get("render_mode", "")
    textless = bool(args.textless) or str(_rp).lower() == "textless"
    if textless:
        print("[textless] 已启用无字底图模式：AI 不绘制文字/logo，文字由 overlay_text.py 叠加。",
              file=sys.stderr)
    segments = plan.get("segments")
    if not isinstance(segments, list) or not segments:
        print("poster_plan.json 缺少非空 segments[]", file=sys.stderr)
        return 2

    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = output_dir / "generation_manifest.json"
    manifest: dict[str, Any] = {
        "project_name": plan.get("project_name", ""),
        "backend": backend,
        "model_version": (primary_model if backend == "arkcli" else
                          getattr(api_config, "model", "") if backend in ("openai", "opc")
                          else args.model_version),
        "ratio": (args.size if backend == "arkcli" else
                  getattr(api_config, "size", "") if backend in ("openai", "opc")
                  else args.ratio),
        "resolution_type": (args.size if backend == "arkcli" else
                            getattr(api_config, "size", "") if backend in ("openai", "opc")
                            else args.resolution_type),
        "segments": [],
        "warnings": [],
    }
    # API 后端的生图尺寸：优先 plan.global.size，其次 API 配置 size
    api_size: str | None = None
    if backend in ("openai", "opc"):
        api_size = plan.get("global", {}).get("size") or getattr(api_config, "size", None)

    selected = {int(x) for x in args.only.split(",")} if args.only else None
    previous_path: Path | None = None
    sorted_segments = sorted(segments, key=lambda x: int(x.get("index", 0)))

    # ---- 并行生成分支（arkcli 专用提速，--parallel>1 且非 dry-run 时启用）----
    # 并行时各段相互独立生成，不引用上一段成图（避免线程竞态），因此牺牲了 image2image 的
    # 相邻段连续性；仅建议在追求速度或已有底图、可接受后续顺序精修时使用。
    if backend == "arkcli" and args.parallel > 1 and not args.dry_run:
        max_images = ARKCLI_MAX_IMAGES
        jobs: list[tuple] = []
        for segment in sorted_segments:
            index = int(segment.get("index", 0))
            filename = safe_filename(segment.get("filename") or f"{index:02d}_segment.png")
            if not Path(filename).suffix:
                filename += ".png"
            stem = Path(filename).stem
            suffix = Path(filename).suffix or ".png"
            if selected is not None and index not in selected:
                continue
            existing = _find_existing(output_dir, stem)
            if existing and not args.force:
                manifest["segments"].append({"index": index, "file": str(existing), "status": "skipped_existing"})
                continue
            prompt = build_prompt(plan, segment, None, textless=textless)
            refs = _resolve_refs(plan, segment, None, max_images, textless=textless)  # 独立：不引用上一段
            output_path = output_dir / f"{stem}{suffix}"
            jobs.append((index, prompt, refs, output_path, args, exe, primary_model, primary_family))
        if not jobs:
            write_json(manifest_path, manifest)
            print(json.dumps({"ok": True, "backend": backend,
                              "note": "无待生成段（均已存在，--force 可强制重跑）"}, ensure_ascii=False, indent=2))
            return 0
        results: dict[int, dict] = {}
        with ThreadPoolExecutor(max_workers=min(args.parallel, len(jobs))) as pool:
            futures = {pool.submit(_gen_worker_arkcli, j): j[0] for j in jobs}
            for fut in as_completed(futures):
                r = fut.result()
                results[r["index"]] = r
                print(f"[arkcli][并行] 第 {r['index']} 段 -> {r['status']}", file=sys.stderr)
        for j in jobs:
            r = results.get(j[0])
            manifest["segments"].append(r)
            if r["status"] == "failed":
                write_json(manifest_path, manifest)
                print(f"第 {j[0]} 段生成失败: {r.get('error')}", file=sys.stderr)
                return 1
        write_json(manifest_path, manifest)
        print(json.dumps({"ok": True, "backend": backend, "parallel": args.parallel,
                          "manifest": str(manifest_path), "segments": manifest["segments"]},
                         ensure_ascii=False, indent=2))
        return 0

    for segment in sorted_segments:
        index = int(segment.get("index", 0))
        filename = safe_filename(segment.get("filename") or f"{index:02d}_segment.png")
        if not Path(filename).suffix:
            filename += ".png"
        stem = Path(filename).stem
        output_path = output_dir / filename
        existing = _find_existing(output_dir, stem)

        # 即使在 --only 范围外，也要维护 previous_path 链
        if selected is not None and index not in selected:
            if existing:
                previous_path = existing
            continue

        if existing and not args.force:
            # 默认跳过已存在的段（等价于 --resume），避免重复消耗额度；--force 可强制重跑。
            manifest["segments"].append(
                {"index": index, "file": str(existing), "status": "skipped_existing"}
            )
            previous_path = existing
            continue

        prompt = build_prompt(plan, segment, previous_path, textless=textless)

        if args.dry_run:
            (output_dir / f"{index:02d}_prompt.txt").write_text(prompt, encoding="utf-8")
            manifest["segments"].append(
                {"index": index, "file": str(output_path), "status": "dry_run"}
            )
            if existing:
                previous_path = existing
            continue

        max_images = (ARKCLI_MAX_IMAGES if backend == "arkcli" else
                      API_MAX_IMAGES if backend in ("openai", "opc") else DREAMINA_MAX_IMAGES)
        refs = _resolve_refs(plan, segment, previous_path, max_images, textless=textless)
        started = time.time()
        try:
            if backend in ("openai", "opc"):
                target, mode = _generate_one_api(prompt, refs, output_path,
                                                 api_client, api_config, api_size)
            elif backend == "arkcli":
                # 终点候选链 fallback：当前终点额度耗尽/被暂停时自动切换到下一个续跑本段，
                # 不浪费已生成的段，也绝不会因 Pro 仅 1 张额度而整批中断。
                target = mode = None
                gen_idx = 0
                while gen_idx < len(arkcli_ids):
                    cur_model = arkcli_ids[gen_idx]
                    cur_family = fam_list[gen_idx]
                    try:
                        target, mode = _generate_one_arkcli(
                            prompt, refs, output_path, args, exe, cur_model, cur_family)
                        if gen_idx > 0:
                            print(f"[arkcli][fallback] 第 {index} 段已用终点 {cur_model}（{cur_family}）生成成功。",
                                  file=sys.stderr)
                        break
                    except RuntimeError as e:
                        fail = _scan_arkcli_failure(str(e), "")
                        exhausted = bool(fail) and any(
                            k in fail for k in ("额度", "暂停", "quota", "suspend", "exceed", "limit"))
                        if exhausted and gen_idx < len(arkcli_ids) - 1:
                            gen_idx += 1
                            print(f"[arkcli][fallback] 终点 {cur_model} 额度耗尽/已被暂停，"
                                  f"自动切换到 {arkcli_ids[gen_idx]} 续跑。", file=sys.stderr)
                            continue
                        raise
                if target is None:
                    raise RuntimeError(f"所有终点均不可用：{arkcli_ids}")
            else:
                target, mode = _generate_one_dreamina(prompt, refs, output_path, args)
            manifest["segments"].append({
                "index": index,
                "file": str(target),
                "status": "success",
                "mode": mode,
                "reference_count": len(refs),
                "elapsed_seconds": round(time.time() - started, 2),
            })
            previous_path = target
        except Exception as exc:
            manifest["segments"].append({
                "index": index,
                "file": str(output_path),
                "status": "failed",
                "error": str(exc),
            })
            write_json(manifest_path, manifest)
            print(f"第 {index} 段生成失败: {exc}", file=sys.stderr)
            return 1

    write_json(manifest_path, manifest)
    print(json.dumps(
        {"ok": True, "backend": backend, "manifest": str(manifest_path), "segments": manifest["segments"]},
        ensure_ascii=False, indent=2,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
