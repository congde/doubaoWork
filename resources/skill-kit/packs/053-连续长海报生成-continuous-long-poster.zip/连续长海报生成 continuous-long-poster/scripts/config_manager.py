from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

DEFAULT_CONFIG_DIR = Path.home() / ".workbuddy-long-poster"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.json"


@dataclass
class ApiConfig:
    api_key: str = ""
    provider_name: str = "OpenAI or compatible provider"
    base_url: str = "https://api.openai.com/v1"
    model: str = "gpt-image-2"
    generation_path: str = "/images/generations"
    edit_path: str = "/images/edits"
    size: str = "1024x1536"
    quality: str = "medium"
    timeout_seconds: int = 300
    max_retries: int = 2
    allow_text_only_fallback: bool = False
    multipart_image_field: str = "image"
    extra_headers: dict[str, str] = field(default_factory=dict)
    extra_body: dict[str, Any] = field(default_factory=dict)

    def generation_url(self) -> str:
        return join_url(self.base_url, self.generation_path)

    def edit_url(self) -> str:
        return join_url(self.base_url, self.edit_path)

    def validate(self) -> list[str]:
        errors: list[str] = []
        if not self.api_key:
            errors.append("缺少 API Key")
        parsed = urlparse(self.base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            errors.append("Base URL 不是有效的 HTTP/HTTPS 地址")
        if not self.model.strip():
            errors.append("模型名称不能为空")
        if not self.generation_path.strip():
            errors.append("生成接口路径不能为空")
        if not self.edit_path.strip():
            errors.append("编辑接口路径不能为空")
        if self.timeout_seconds <= 0:
            errors.append("timeout_seconds 必须大于 0")
        return errors

    def masked(self) -> dict[str, Any]:
        data = asdict(self)
        data["api_key"] = mask_secret(self.api_key)
        return data


def join_url(base_url: str, path: str) -> str:
    return base_url.rstrip("/") + "/" + path.lstrip("/")


def mask_secret(secret: str) -> str:
    if not secret:
        return ""
    if len(secret) <= 8:
        return "*" * len(secret)
    return secret[:4] + "*" * (len(secret) - 8) + secret[-4:]


def config_path() -> Path:
    custom = os.getenv("LONG_POSTER_CONFIG_PATH", "").strip()
    return Path(custom).expanduser() if custom else DEFAULT_CONFIG_PATH


def _load_file(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError(f"配置文件根节点必须是对象: {path}")
    return data


def load_config(override_path: str | Path | None = None) -> ApiConfig:
    path = Path(override_path).expanduser() if override_path else config_path()
    data = _load_file(path)

    env_map = {
        "api_key": "LONG_POSTER_API_KEY",
        "base_url": "LONG_POSTER_BASE_URL",
        "model": "LONG_POSTER_IMAGE_MODEL",
        "size": "LONG_POSTER_IMAGE_SIZE",
        "quality": "LONG_POSTER_IMAGE_QUALITY",
    }
    for field_name, env_name in env_map.items():
        value = os.getenv(env_name)
        if value:
            data[field_name] = value

    allowed = {f.name for f in ApiConfig.__dataclass_fields__.values()}
    clean = {k: v for k, v in data.items() if k in allowed}
    return ApiConfig(**clean)


def save_config(config: ApiConfig, path: str | Path | None = None) -> Path:
    target = Path(path).expanduser() if path else config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8") as f:
        json.dump(asdict(config), f, ensure_ascii=False, indent=2)
        f.write("\n")
    try:
        os.chmod(target, 0o600)
    except OSError:
        pass
    return target


def configuration_status(config: ApiConfig) -> dict[str, Any]:
    errors = config.validate()
    return {
        "ready": not errors,
        "needs_configuration": bool(errors),
        "errors": errors,
        "config": config.masked(),
        "config_path": str(config_path()),
    }
