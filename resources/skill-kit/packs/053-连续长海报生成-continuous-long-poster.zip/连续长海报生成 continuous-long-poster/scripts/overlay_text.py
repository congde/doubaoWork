from __future__ import annotations

"""代码叠字：把 poster_plan.json 中每段 text_overlay 里定义的精准中文，用 PIL 绘制到
无字底图上，根治 AI 生图中文错字/乱码的问题。

与 generate_segments.py 的关系：
- generate_segments.py（--textless 模式）负责生成「不含任何文字/logo」的纯净插画底图
  （历程光河、武小蚁、品牌色块等装饰元素）；
- 本脚本负责把 plan 里已经核实准确的文字，以矢量级清晰度绘制到底图指定位置，
  并可合成真实 logo 资源（白字 logo 置于 MCC 蓝底板，保证在浅色背景上清晰可见）。

坐标体系：text_overlay 里所有 box 用「相对比例 0~1」，乘以底图实际像素尺寸，
因此与生成尺寸（1440x2560 或其他）解耦，可移植。

文字块（blocks）支持角色：
- title / era / body / note：单行或自动换行文本，按角色取默认颜色/字号；
- node：年份 + 描述组合卡（金色年份标题 + 深色描述正文）；
- brand：品牌区（公司全称 + 官网，通常配合 logos 里的蓝底板 logo 使用）。

面板（panel）：每块可独立开关半透明圆角面板（fill/opacity/radius/border），
既保证文字在复杂底图上清晰可读，又让底图的历程光河纹理从边缘透出。

字体：默认使用技能内置 assets/fonts/simhei.ttf（黑体，无衬线、中文清晰）；
可通过 --font 覆盖。若需要更细的正文字重，可再指定 NotoSansSC。

用法示例：
  python overlay_text.py --plan plans/poster_plan.json \\
      --segments-dir segments --output-dir segments_texted
  python overlay_text.py --plan plans/poster_plan.json \\
      --segments-dir segments --output-dir segments_texted --only 1,8
  python overlay_text.py --plan plans/poster_plan.json \\
      --segments-dir segments --dry-run   # 只打印每段的版式，不落图
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont

# 保证同目录模块可导入（utils 与本脚本同在 scripts/）
sys.path.insert(0, str(Path(__file__).resolve().parent))
try:
    from utils import read_json, write_json, image_files
except Exception:  # 兜底：直接定义最小实现
    def read_json(p):  # type: ignore
        return json.load(open(p, encoding="utf-8"))

    def write_json(p, d):  # type: ignore
        json.dump(d, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    def image_files(d):  # type: ignore
        return sorted(Path(d).glob("*"), key=lambda x: x.name)


# --------------------------------------------------------------------------- #
# 默认样式（可被 plan 的 text_overlay.defaults 覆盖）
# --------------------------------------------------------------------------- #
DEFAULTS = {
    "title_color": "#005BAC",
    "era_color": "#005BAC",
    "year_color": "#C89B3C",
    "body_color": "#333333",
    "note_color": "#888888",
    "brand_color": "#FFFFFF",
    "brand_bar": "#005BAC",
    "panel": {"fill": "#FFFFFF", "opacity": 1.0, "radius": 24, "border": "#005BAC", "border_width": 3},
    "panel_extend": 18,      # 面板比文字框外扩像素，盖住 AI 画的假标签/网格线
    "font": None,            # None = 技能内置 simhei
    "body_font": None,       # None = 同 font
    "line_spacing": 1.28,
    "min_size": 18,
}


def _hex(c: str) -> tuple[int, int, int]:
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def _resolve_font(rel_path: str | None, base_dir: Path, fallback_name: str) -> Path:
    if rel_path:
        p = Path(rel_path)
        if not p.is_absolute():
            p = base_dir / p
        if p.exists():
            return p
    # 技能内置字体（scripts/../assets/fonts/）
    here = Path(__file__).resolve().parent
    cand = here.parent / "assets" / "fonts" / fallback_name
    if cand.exists():
        return cand
    # 系统回退
    for sys_p in ("/c/Windows/Fonts/simhei.ttf", "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"):
        if Path(sys_p).exists():
            return Path(sys_p)
    raise FileNotFoundError(f"未找到字体：{fallback_name}（也未在 {rel_path} 找到）")


# --------------------------------------------------------------------------- #
# 文本测量与自动适配
# --------------------------------------------------------------------------- #
def _wrap(text: str, font: ImageFont.FreeTypeFont, max_width: int) -> list[str]:
    """按字符换行（CJK 无空格），尊重已有换行符。"""
    lines: list[str] = []
    for para in str(text).split("\n"):
        if para == "":
            lines.append("")
            continue
        cur = ""
        for ch in para:
            if font.getlength(cur + ch) <= max_width:
                cur += ch
            else:
                if cur:
                    lines.append(cur)
                cur = ch
        lines.append(cur)
    return lines


def _fit_single(text: str, font_path: Path, box_w: int, box_h: int,
                max_size: int, min_size: int, line_spacing: float) -> tuple[ImageFont.FreeTypeFont, list[str], int, int]:
    """在 (box_w, box_h) 内为 text 寻找最大可容纳字号（从 max_size 递减到 min_size）。"""
    size = max_size
    while size >= min_size:
        font = ImageFont.truetype(str(font_path), size)
        lines = _wrap(text, font, box_w)
        line_h = max(1, int(size * line_spacing))
        total = len(lines) * line_h
        if total <= box_h:
            return font, lines, line_h, size
        size -= 2
    font = ImageFont.truetype(str(font_path), min_size)
    lines = _wrap(text, font, box_w)
    return font, lines, max(1, int(min_size * line_spacing)), min_size


def _fit_node(year: str, desc: str, font_path: Path, box_w: int, box_h: int,
              max_year: int, min_year: int, line_spacing: float) -> dict:
    """年份卡：金底年份 + 正文描述，整体在 box 内自适应缩小。"""
    ysize = max_year
    while ysize >= min_year:
        yfont = ImageFont.truetype(str(font_path), ysize)
        ylines = _wrap(year, yfont, box_w)
        yh = len(ylines) * max(1, int(ysize * 1.18))
        dsize = max(min_year - 6, int(ysize * 0.58))
        dfont = ImageFont.truetype(str(font_path), dsize)
        dlines = _wrap(desc, dfont, box_w)
        dh = len(dlines) * max(1, int(dsize * line_spacing))
        gap = int(ysize * 0.42)
        if yh + gap + dh <= box_h:
            return {"yfont": yfont, "ylines": ylines, "yh": yh,
                    "dfont": dfont, "dlines": dlines, "dh": dh, "gap": gap, "ysize": ysize}
        ysize -= 2
    # 兜底最小
    yfont = ImageFont.truetype(str(font_path), min_year)
    ylines = _wrap(year, yfont, box_w)
    yh = len(ylines) * max(1, int(min_year * 1.18))
    dsize = max(14, int(min_year * 0.58))
    dfont = ImageFont.truetype(str(font_path), dsize)
    dlines = _wrap(desc, dfont, box_w)
    dh = len(dlines) * max(1, int(dsize * line_spacing))
    return {"yfont": yfont, "ylines": ylines, "yh": yh,
            "dfont": dfont, "dlines": dlines, "dh": dh, "gap": int(min_year * 0.42), "ysize": min_year}


# --------------------------------------------------------------------------- #
# 绘制基元
# --------------------------------------------------------------------------- #
def _rounded_panel_layer(size: tuple[int, int], box_px: tuple[int, int, int, int],
                         fill: tuple[int, int, int], opacity: float, radius: int,
                         border: tuple[int, int, int] | None, border_width: int) -> Image.Image:
    """生成一块带圆角的半透明面板 RGBA 图层（在 box 范围内）。"""
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    x1, y1, x2, y2 = box_px
    r = max(1, min(radius, (x2 - x1) // 2, (y2 - y1) // 2))
    a = int(255 * max(0.0, min(1.0, opacity)))
    d.rounded_rectangle([x1, y1, x2, y2], radius=r, fill=(*fill, a))
    if border is not None and border_width > 0:
        d.rounded_rectangle([x1, y1, x2, y2], radius=r,
                            outline=(*border, a), width=border_width)
    return layer


def _draw_multiline(d: ImageDraw.ImageDraw, lines: list[str], font: ImageFont.FreeTypeFont,
                    x: int, y: int, line_h: int, color: tuple[int, int, int], align: str,
                    box_w: int) -> int:
    cy = y
    for line in lines:
        if align == "center":
            lx = x + (box_w - int(font.getlength(line))) // 2
        elif align == "right":
            lx = x + (box_w - int(font.getlength(line)))
        else:
            lx = x
        d.text((lx, cy), line, font=font, fill=color)
        cy += line_h
    return cy


# --------------------------------------------------------------------------- #
# 单段叠字
# --------------------------------------------------------------------------- #
def overlay_segment(img: Image.Image, seg: dict[str, Any], defaults: dict[str, Any],
                    base_dir: Path) -> Image.Image:
    W, H = img.size
    overlay = seg.get("text_overlay") or {}
    cfg = {**defaults, **(overlay.get("defaults") or {})}
    font_path = _resolve_font(cfg.get("font"), base_dir, "simhei.ttf")
    body_font_path = _resolve_font(cfg.get("body_font"), base_dir, "simhei.ttf")
    line_spacing = float(cfg.get("line_spacing", 1.28))
    min_size = int(cfg.get("min_size", 18))
    panel_cfg = cfg["panel"]
    panel_extend = int(cfg.get("panel_extend", 0))

    def box2px(b) -> tuple[int, int, int, int]:
        x1, y1, x2, y2 = (float(v) for v in b)
        return (int(x1 * W), int(y1 * H), int(x2 * W), int(y2 * H))

    def expand_box(box_px: tuple[int, int, int, int], ext: int) -> tuple[int, int, int, int]:
        x1, y1, x2, y2 = box_px
        return (max(0, x1 - ext), max(0, y1 - ext), min(W, x2 + ext), min(H, y2 + ext))

    def draw_panel(box_px, pcfg=None):
        p = pcfg or panel_cfg
        fill = _hex(p.get("fill", "#FFFFFF"))
        op = float(p.get("opacity", 0.84))
        r = int(p.get("radius", 24))
        bw = int(p.get("border_width", 3))
        border = _hex(p["border"]) if p.get("border") else None
        layer = _rounded_panel_layer(img.size, box_px, fill, op, r, border, bw)
        img.paste(layer, (0, 0), layer)

    # ---- logos（先画底板+合成 logo，置于文字之下）----
    for logo in overlay.get("logos", []) or []:
        abox = box2px(logo["box"])
        plate = logo.get("plate")
        if plate:
            draw_panel(abox, {
                "fill": plate.get("fill", cfg.get("brand_bar", "#005BAC")),
                "opacity": float(plate.get("opacity", 1.0)),
                "radius": int(plate.get("radius", 14)),
                "border": None,
                "border_width": 0,
            })
        asset = logo.get("asset")
        if asset:
            ap = Path(asset)
            if not ap.is_absolute():
                ap = base_dir / ap
            if not ap.exists():
                print(f"[overlay][警告] logo 资源不存在：{ap}", file=sys.stderr)
                continue
            logo_img = Image.open(ap).convert("RGBA")
            pad = int((abox[2] - abox[0]) * float(logo.get("padding", 0.12)))
            tw = (abox[2] - abox[0]) - 2 * pad
            th = (abox[3] - abox[1]) - 2 * pad
            logo_img.thumbnail((max(1, tw), max(1, th)), Image.LANCZOS)
            lx = abox[0] + ((abox[2] - abox[0]) - logo_img.width) // 2
            ly = abox[1] + ((abox[3] - abox[1]) - logo_img.height) // 2
            img.paste(logo_img, (lx, ly), logo_img)

    # ---- 文字块 ----
    for blk in overlay.get("blocks", []) or []:
        text = blk.get("text", "")
        role = blk.get("role", "body")
        box_px = box2px(blk["box"])
        bx, by, bxx, byy = box_px
        bw = bxx - bx
        bh = byy - by
        align = blk.get("align", "center")
        use_panel = bool(blk.get("panel", False))
        pstyle = blk.get("panel_style") or (panel_cfg if use_panel else None)

        if use_panel and pstyle:
            ext = int(blk.get("panel_extend", panel_extend))
            panel_box = expand_box(box_px, ext) if ext > 0 else box_px
            draw_panel(panel_box, pstyle)

        txt_layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
        td = ImageDraw.Draw(txt_layer)

        if role in ("title", "era"):
            color = _hex(blk.get("color", cfg.get(f"{role}_color", "#005BAC")))
            max_sz = int(blk.get("size", 64))
            font, lines, lh, _ = _fit_single(text, font_path, bw, bh, max_sz, min_size, line_spacing)
            _draw_multiline(td, lines, font, bx, by, lh, color, align, bw)
        elif role == "body":
            color = _hex(blk.get("color", cfg.get("body_color", "#333333")))
            max_sz = int(blk.get("size", 38))
            font, lines, lh, _ = _fit_single(text, body_font_path, bw, bh, max_sz, min_size, line_spacing)
            _draw_multiline(td, lines, font, bx, by, lh, color, align, bw)
        elif role == "note":
            color = _hex(blk.get("color", cfg.get("note_color", "#888888")))
            max_sz = int(blk.get("size", 26))
            font, lines, lh, _ = _fit_single(text, body_font_path, bw, bh, max_sz, min_size, line_spacing)
            _draw_multiline(td, lines, font, bx, by, lh, color, align, bw)
        elif role == "node":
            year = blk.get("year", "")
            desc = blk.get("desc", "")
            max_y = int(blk.get("size", 40))
            fit = _fit_node(year, desc, font_path, bw, bh, max_y, min_size, line_spacing)
            ycolor = _hex(blk.get("year_color", cfg.get("year_color", "#C89B3C")))
            dcolor = _hex(blk.get("desc_color", cfg.get("body_color", "#333333")))
            cy = by
            cy = _draw_multiline(td, fit["ylines"], fit["yfont"], bx, cy, max(1, int(fit["ysize"] * 1.18)), ycolor, align, bw)
            cy += fit["gap"]
            _draw_multiline(td, fit["dlines"], fit["dfont"], bx, cy, max(1, int(int(fit["ysize"] * 0.58) * line_spacing)), dcolor, align, bw)
        elif role == "brand":
            name = blk.get("name", "")
            url = blk.get("url", "")
            if name:
                color = _hex(blk.get("color", cfg.get("brand_color", "#FFFFFF")))
                max_sz = int(blk.get("size", 34))
                font, lines, lh, _ = _fit_single(name, font_path, bw, bh // 2, max_sz, min_size, line_spacing)
                _draw_multiline(td, lines, font, bx, by, lh, color, align, bw)
            if url:
                ucolor = _hex(blk.get("url_color", "#DCE6F2"))
                umax = int(blk.get("url_size", 24))
                ufont, ulines, ulh, _ = _fit_single(url, body_font_path, bw, bh // 2, umax, 16, line_spacing)
                _draw_multiline(td, ulines, ufont, bx, by + bh // 2, ulh, ucolor, align, bw)
        else:
            print(f"[overlay][警告] 未知 block role：{role}，跳过", file=sys.stderr)
            continue

        img.paste(txt_layer, (0, 0), txt_layer)

    return img


# --------------------------------------------------------------------------- #
# 主流程
# --------------------------------------------------------------------------- #
def main() -> int:
    parser = argparse.ArgumentParser(description="代码叠字：把 plan 的 text_overlay 渲染到无字底图")
    parser.add_argument("--plan", required=True)
    parser.add_argument("--segments-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--only", help="仅处理指定序号，逗号分隔，例如 1,8")
    parser.add_argument("--font", default=None, help="覆盖默认字体路径（绝对或相对 plan 目录）")
    parser.add_argument("--dry-run", action="store_true", help="只打印每段的版式不落图")
    args = parser.parse_args()

    plan = read_json(args.plan)
    base_dir = Path(args.plan).resolve().parent
    segments = plan.get("segments", [])
    gdefaults = {**DEFAULTS}
    gp = plan.get("global", {}).get("text_overlay_defaults") or {}
    gdefaults.update(gp)
    if args.font:
        gdefaults["font"] = args.font

    seg_dir = Path(args.segments_dir)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    selected = {int(x) for x in args.only.split(",")} if args.only else None
    by_index = {int(s.get("index", 0)): s for s in segments}

    results = []
    for idx in sorted(by_index):
        if selected is not None and idx not in selected:
            continue
        seg = by_index[idx]
        if not seg.get("text_overlay"):
            print(f"[overlay] 第 {idx} 段无 text_overlay，跳过", file=sys.stderr)
            continue
        stem = Path(seg.get("filename", f"{idx:02d}_segment.png")).stem
        cand = list(seg_dir.glob(f"{stem}.*"))
        cand = [p for p in cand if p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")]
        if not cand:
            print(f"[overlay] 第 {idx} 段未找到底图（{stem}.*），跳过", file=sys.stderr)
            continue
        src = cand[0]
        if args.dry_run:
            nblk = len(seg["text_overlay"].get("blocks", []))
            nlogo = len(seg["text_overlay"].get("logos", []))
            print(f"[dry-run] 第 {idx} 段：底图={src.name} 文字块={nblk} logo={nlogo}")
            for b in seg["text_overlay"].get("blocks", []):
                print(f"    - {b.get('role')}: {b.get('text', b.get('year',''))[:30]}")
            continue
        img = Image.open(src).convert("RGB")
        img = overlay_segment(img, seg, gdefaults, base_dir)
        out_path = out_dir / src.name
        img.save(out_path, quality=95)
        results.append({"index": idx, "file": str(out_path)})
        print(f"[overlay] 第 {idx} 段 -> {out_path.name}", file=sys.stderr)

    if args.dry_run:
        print(json.dumps({"ok": True, "dry_run": True}, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({"ok": True, "overlaid": results}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
