from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from PIL import Image


def read_json(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    with p.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError(f"JSON 根节点必须是对象: {p}")
    return data


def write_json(path: str | Path, data: Any) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return p


def safe_filename(value: str, fallback: str = "image.png") -> str:
    value = value.strip().replace("\\", "_").replace("/", "_")
    value = re.sub(r"[<>:\"|?*\x00-\x1F]", "_", value)
    value = re.sub(r"\s+", "_", value)
    value = value.strip("._")
    return value or fallback


def image_files(directory: str | Path) -> list[Path]:
    p = Path(directory)
    allowed = {".png", ".jpg", ".jpeg", ".webp"}
    result = [x for x in p.iterdir() if x.is_file() and x.suffix.lower() in allowed]

    def sort_key(x: Path):
        match = re.match(r"(\d+)", x.stem)
        return (int(match.group(1)) if match else 10**9, x.name.lower())

    return sorted(result, key=sort_key)


def open_rgb(path: str | Path) -> Image.Image:
    with Image.open(path) as im:
        return im.convert("RGB")


def resize_to_width(image: Image.Image, width: int) -> Image.Image:
    if width <= 0:
        raise ValueError("目标宽度必须大于 0")
    if image.width == width:
        return image.copy()
    height = max(1, round(image.height * width / image.width))
    return image.resize((width, height), Image.Resampling.LANCZOS)


def clamp_int(value: Any, minimum: int, maximum: int, default: int = 0) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default
    return max(minimum, min(maximum, parsed))
