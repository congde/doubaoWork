from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image, ImageDraw, ImageFont

try:
    from .utils import image_files, open_rgb, read_json, resize_to_width, write_json
except ImportError:
    from utils import image_files, open_rgb, read_json, resize_to_width, write_json


def row_discontinuity(image: Image.Image, y: int) -> float | None:
    if y <= 0 or y >= image.height:
        return None
    arr = np.asarray(image).astype(np.float32)
    return float(np.mean(np.abs(arr[y] - arr[y - 1])))


def make_contact_sheet(paths: list[Path], output: Path, width: int = 260) -> None:
    thumbs = [resize_to_width(open_rgb(p), width) for p in paths]
    gap = 12
    label_h = 28
    canvas_w = sum(t.width for t in thumbs) + gap * (len(thumbs) - 1)
    canvas_h = max(t.height for t in thumbs) + label_h
    canvas = Image.new("RGB", (canvas_w, canvas_h), "white")
    draw = ImageDraw.Draw(canvas)
    x = 0
    for path, thumb in zip(paths, thumbs):
        canvas.paste(thumb, (x, label_h))
        draw.text((x + 4, 6), path.name, fill="black")
        x += thumb.width + gap
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output, "JPEG", quality=90)


def main() -> int:
    parser = argparse.ArgumentParser(description="生成长海报质量检查报告")
    parser.add_argument("--segments-dir", required=True)
    parser.add_argument("--final", required=True)
    parser.add_argument("--stitch-manifest")
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    segment_paths = image_files(args.segments_dir)
    final_path = Path(args.final)
    if not final_path.exists():
        raise SystemExit(f"最终长图不存在: {final_path}")

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    make_contact_sheet(segment_paths, out / "segments_contact_sheet.jpg")

    final = open_rgb(final_path)
    preview = resize_to_width(final, min(900, final.width))
    preview.save(out / "final_preview.jpg", "JPEG", quality=90)

    widths = []
    heights = []
    for path in segment_paths:
        with Image.open(path) as im:
            widths.append(im.width)
            heights.append(im.height)

    manifest: dict[str, Any] = {}
    if args.stitch_manifest and Path(args.stitch_manifest).exists():
        manifest = read_json(args.stitch_manifest)

    seams = []
    for join in manifest.get("joins", []):
        y = int(join.get("seam_y", -1))
        metric = row_discontinuity(final, y)
        seams.append({**join, "row_discontinuity": None if metric is None else round(metric, 3)})
        if 0 < y < final.height:
            top = max(0, y - 160)
            bottom = min(final.height, y + max(220, int(join.get("overlap", 0)) + 160))
            final.crop((0, top, final.width, bottom)).save(out / f"qc_seam_{join.get('from')}_{join.get('to')}.png")

    report = {
        "final_file": str(final_path),
        "final_size": [final.width, final.height],
        "segment_count": len(segment_paths),
        "segment_widths": widths,
        "segment_heights": heights,
        "width_consistent": len(set(widths)) <= 1,
        "seams": seams,
        "automated_checks": {
            "final_exists": True,
            "positive_dimensions": final.width > 0 and final.height > 0,
            "segment_order": [p.name for p in segment_paths],
        },
        "manual_review_required": [
            "中文文字是否准确、清晰、无乱码",
            "人物、Logo、产品是否保持一致",
            "是否存在可见水平接缝、背景或色温跳变",
            "文字、卡片、人物和关键数字是否被裁断",
            "从上到下是否像一张完整图片而不是多页拼接"
        ]
    }
    report_path = write_json(out / "qc_report.json", report)
    print(json.dumps({"ok": True, "report": str(report_path), "preview": str(out / 'final_preview.jpg')}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
