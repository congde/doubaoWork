"""Continuous long poster skill scripts."""
