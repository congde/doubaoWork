from __future__ import annotations

import base64
import mimetypes
import time
from pathlib import Path
from typing import Any, Iterable

import requests

try:
    from .config_manager import ApiConfig
except ImportError:
    from config_manager import ApiConfig


class ImageApiError(RuntimeError):
    pass


class ImageClient:
    def __init__(self, config: ApiConfig):
        errors = config.validate()
        if errors:
            raise ImageApiError("；".join(errors))
        self.config = config
        self.session = requests.Session()

    def _headers(self) -> dict[str, str]:
        headers = {"Authorization": f"Bearer {self.config.api_key}"}
        headers.update(self.config.extra_headers)
        return headers

    def generate(self, prompt: str, output_path: str | Path, *, size: str | None = None) -> Path:
        body: dict[str, Any] = {
            "model": self.config.model,
            "prompt": prompt,
            "size": size or self.config.size,
            "quality": self.config.quality,
            "n": 1,
        }
        body.update(self.config.extra_body)
        response = self._request_with_retry(
            "POST",
            self.config.generation_url(),
            headers={**self._headers(), "Content-Type": "application/json"},
            json=body,
        )
        return self._save_response_image(response, output_path)

    def edit(
        self,
        prompt: str,
        images: Iterable[str | Path],
        output_path: str | Path,
        *,
        size: str | None = None,
    ) -> Path:
        image_paths = [Path(p) for p in images]
        if not image_paths:
            raise ImageApiError("图片编辑请求至少需要一张输入图片")
        opened = []
        files = []
        try:
            for path in image_paths:
                if not path.exists():
                    raise ImageApiError(f"参考图片不存在: {path}")
                handle = path.open("rb")
                opened.append(handle)
                mime = mimetypes.guess_type(path.name)[0] or "image/png"
                files.append((self.config.multipart_image_field, (path.name, handle, mime)))

            data: dict[str, Any] = {
                "model": self.config.model,
                "prompt": prompt,
                "size": size or self.config.size,
                "quality": self.config.quality,
                "n": "1",
            }
            for key, value in self.config.extra_body.items():
                if isinstance(value, (str, int, float, bool)):
                    data[key] = str(value)

            response = self._request_with_retry(
                "POST",
                self.config.edit_url(),
                headers=self._headers(),
                data=data,
                files=files,
            )
            return self._save_response_image(response, output_path)
        finally:
            for handle in opened:
                handle.close()

    def _request_with_retry(self, method: str, url: str, **kwargs) -> requests.Response:
        last_error: Exception | None = None
        attempts = max(1, self.config.max_retries + 1)
        for attempt in range(attempts):
            try:
                response = self.session.request(
                    method,
                    url,
                    timeout=self.config.timeout_seconds,
                    **kwargs,
                )
                if response.status_code >= 400:
                    summary = response.text[:1000]
                    raise ImageApiError(f"图片 API 返回 {response.status_code}: {summary}")
                return response
            except (requests.RequestException, ImageApiError) as exc:
                last_error = exc
                if attempt + 1 >= attempts:
                    break
                time.sleep(min(8, 2 ** attempt))
        raise ImageApiError(str(last_error) if last_error else "未知图片 API 错误")

    def _save_response_image(self, response: requests.Response, output_path: str | Path) -> Path:
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)

        content_type = response.headers.get("Content-Type", "").lower()
        if content_type.startswith("image/"):
            output.write_bytes(response.content)
            return output

        try:
            payload = response.json()
        except ValueError as exc:
            raise ImageApiError("图片 API 返回的既不是图片，也不是可解析 JSON") from exc

        image_bytes = self._extract_image_bytes(payload)
        output.write_bytes(image_bytes)
        return output

    def _extract_image_bytes(self, payload: Any) -> bytes:
        candidates: list[Any] = []
        if isinstance(payload, dict):
            data = payload.get("data")
            if isinstance(data, list):
                candidates.extend(data)
            images = payload.get("images")
            if isinstance(images, list):
                candidates.extend(images)
            candidates.append(payload)

        for item in candidates:
            if not isinstance(item, dict):
                continue
            for key in ("b64_json", "base64", "image_base64", "image"):
                value = item.get(key)
                if isinstance(value, str) and value:
                    if value.startswith("data:image") and "," in value:
                        value = value.split(",", 1)[1]
                    try:
                        return base64.b64decode(value, validate=False)
                    except Exception:
                        pass
            url = item.get("url")
            if isinstance(url, str) and url.startswith(("http://", "https://")):
                r = self.session.get(url, timeout=self.config.timeout_seconds)
                if r.status_code >= 400:
                    raise ImageApiError(f"下载图片 URL 失败: {r.status_code}")
                return r.content

        raise ImageApiError("无法从 API 返回结构中找到图片。请检查服务商返回格式或修改适配器。")
