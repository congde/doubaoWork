from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from stitch_long_poster import auto_plan, merge_pair  # noqa: E402


class StitchingTests(unittest.TestCase):
    def gradient(self, width: int, height: int, offset: int = 0) -> Image.Image:
        y = np.arange(height, dtype=np.uint16)[:, None]
        x = np.arange(width, dtype=np.uint16)[None, :]
        r = np.broadcast_to((y + offset) % 256, (height, width))
        g = np.broadcast_to((x + offset) % 256, (height, width))
        b = ((r.astype(np.uint16) + g.astype(np.uint16)) // 2) % 256
        arr = np.stack([r, g, b], axis=2).astype(np.uint8)
        return Image.fromarray(arr, "RGB")

    def test_feather_merge_dimensions(self):
        a = self.gradient(200, 300)
        b = self.gradient(200, 280, offset=20)
        result, info = merge_pair(a, b, {
            "method": "feather",
            "crop_bottom": 10,
            "crop_top": 8,
            "overlap": 60,
            "feather": 50,
            "color_match": True,
            "color_match_strength": 0.3,
        })
        expected = (300 - 10) + (280 - 8) - 60
        self.assertEqual(result.size, (200, expected))
        self.assertEqual(info["overlap"], 60)

    def test_direct_merge_dimensions(self):
        a = self.gradient(120, 200)
        b = self.gradient(120, 150)
        result, info = merge_pair(a, b, {"method": "direct"})
        self.assertEqual(result.size, (120, 350))
        self.assertEqual(info["overlap"], 0)

    def test_auto_plan_pair_count(self):
        with tempfile.TemporaryDirectory() as td:
            paths = []
            for i in range(3):
                path = Path(td) / f"{i+1:02d}.png"
                self.gradient(100, 160 + i * 10).save(path)
                paths.append(path)
            plan = auto_plan(paths, 100)
            self.assertEqual(len(plan["pairs"]), 2)


if __name__ == "__main__":
    unittest.main()
