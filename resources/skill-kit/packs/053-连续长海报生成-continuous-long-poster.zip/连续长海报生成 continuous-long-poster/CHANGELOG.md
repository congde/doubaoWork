# 更新日志

## 3.0.0 - 四后端统一版（OpenAI 兼容 API 默认 + OPC + 即梦 CLI + 火山 Ark CLI）

### 新增：回植 API 后端，四后端统一入口
- **`--backend` 扩展为五选**：`openai`（OpenAI 兼容 API，**默认后端**）/ `opc`（OPC（OpenAI 兼容聚合 API）
  <你的 API 服务地址>，强制异步客户端）/ `dreamina`（即梦 CLI）/ `arkcli`（火山 Ark CLI）/ `auto`
  （默认：API 已配置优先用 openai/opc；未配置 API 且仅装一个 CLI 时自动选它；即梦与 Ark CLI
  都装且未配置 API 时报错强制用户选择）。
- **回植自 v1.2.0 的 API 体系**：`scripts/image_client.py`（OpenAI 同步 Images API）、
  `scripts/opc_image_client.py`（OPC 异步 create+poll+download，base_url 命中异步聚合 API（含 `/media` 路径或 provider=opc）时自动启用）、
  `scripts/config_manager.py` + `scripts/configure.py`（本地配置 ~/.workbuddy-long-poster/，
  权限 600，Key 脱敏展示）、`config/`（schema.md、settings.example.json、recommended_provider.json）。
- **`generate_segments.py`**：新增 `_api_config_state` / `_load_api_client` / `_generate_one_api`；
  API 后端复用统一 `build_prompt` 与 `_resolve_refs`（参考图上限 8，优先保留上一段成图）；
  图片编辑失败且 `allow_text_only_fallback` 开启时退化为纯文生图并记 warning；dry-run 在 API
  未配置时容错降级；`--config` 可指定配置文件路径。
- **`doctor.py` 四后端检测**：`api_configured` / `api_backend`（openai|opc）/ `dreamina_cli_installed` /
  `arkcli_installed` / `available_backends` / `recommended_backend`（API 优先）；`requests` 仅在
  使用 API 后端时必需。
- **无字底图模式（`--textless`）、衔接带方案头脑风暴、拼接与质检流程对四个后端全部通用。**

### 变更：API 配置入口（去引流化，适配技能商城）
- **移除旧第三方推荐购买入口**（原 v1.2.0 recommended_provider.json 与
  SKILL.md 中的购买引导）。
- **去引流化**：API 配置引导不再指向任何特定第三方服务商，统一改为「用户需自备任意
  OpenAI 兼容图片 API，自行向所选服务商申请 base_url / api_key / model（支持
  gpt-image-2、即梦 5.0 Pro / Lite 等任意模型名）」；SKILL.md、README.md、doctor.py、
  generate_segments.py 与 `references/06-api-setup-guide.md` 同步更新。
- `config/recommended_provider.json` 改写为通用 OpenAI 兼容 API 配置模板（无购买/外链语义）。

### 其他
- `requirements.txt` 恢复 `requests`（仅 API 后端需要）。
- 统一全包署名与许可证信息（SKILL.md metadata、LICENSE.txt、README）。
- 技能名回归通用名 `continuous-long-poster`。

## 2.3.0 - 无字底图模式（--textless）+ 代码精准叠字（overlay_text.py）

### 新增：无字底图 + 代码叠字两段式管线（根治 AI 中文错字）
- **根因**：Seedream 系模型对中文小字还原能力极弱，直接生图必错字/乱码，反复重跑也救不回。
- **方案**：AI 只画纯净插画底图（历程光河/吉祥物/品牌色块/留白区），真实文字由新增脚本
  `scripts/overlay_text.py`（PIL + 黑体 `assets/fonts/simhei.ttf`）按 `segment.text_overlay` 版式
  精准叠加，彻底规避错字。叠字输出到独立 `segments_texted/` 目录，不污染原始底图。
- **`generate_segments.py` 新增 `--textless` 旗标**：`build_prompt()` 走独立 textless 分支——
  不读 `segment.content` 真实文字、改用 `segment.textless_composition`（「预留留白区」描述）、
  强制禁画任何文字/数字/字母/符号/logo/印章/二维码，且**过滤带字来源参考图**
  （`assets.reference_images` / `assets.brand_images` 跳过，仅留吉祥物等纯插画），挡住旧信息图
  把文字/竖线泄漏进底图这一最常见污染源。plan 也可设 `global.text_policy.render_mode="textless"` 自动开启。
- **新增 `scripts/overlay_text.py`**：支持相对坐标块（title/era/node/body/brand）、自动缩放字号
  （含 `min_size` 下限防压垮）、自动换行、半透明白色圆角面板 + 品牌色描边、logo 合成（先画色板再贴
  透明 PNG）、单段/全段。`--only` 支持只叠指定段。自带 simhei / NotoSansSC 字体，无需系统字体。
- **新增 `references/10-textless-overlay.md`**：完整工作流（plan 字段、坐标/字号/面板/logo 说明、常见坑）。
- **`SKILL.md`**：步骤 4 补无字底图小节 + 三段式命令；步骤 7 拼接 `--images-dir` 指向 `segments_texted`；
  必读参考列表加入 10；版本 bump 2.2.6 → 2.3.0。
- 字体资源 `assets/fonts/simhei.ttf`、`NotoSansSC-VF.ttf` 随包发布。

### 修复：arkcli 第二接入点 output_format 不支持
- 报错 `output_format is not supported by the current model`：说明该 `--arkcli-endpoint` 实际不是
  5.0 Pro/Lite（而是 4.5/4.0）。已将 fallback 链用法文档化——把对应 `--arkcli-family` 设为 `4.5`
  （或 `4.0`），脚本即停传 `output_format`/`--sequential`。`references/09-arkcli-backend.md` 与
  `10-textless-overlay.md` 均补充此坑。

## 2.2.6 - 竖线衔接约束重定位为「策划阶段决策」，不再注入生图提示词

### 竖线衔接约束重定位（用户纠偏）
- **问题**：2.2.4 把 `VERTICAL_LINE_CONTINUITY` 原文注入**每一段生图提示词**。用户指出该段文字
  本质是「生图前的头脑风暴/方案策划阶段决策约束」，用来定整张长图的衔接带走向，不该原样塞进提示词。
- **修改**：移除 `generate_segments.py` 中 `VERTICAL_LINE_CONTINUITY` 常量及其在 `build_prompt()` 的注入。
  该约束改为：在「步骤 2 规划整张长海报」的头脑风暴中应用，结果落进 `poster_plan.json`
  （`global.visual_baseline.visual_anchor` / `transition` 与各段 `composition` / `transition_in` /
  `transition_out`）。生图提示词只引用 plan 中已确定的构图与过渡，**绝不注入约束原文**。
- `build_prompt()` 现从 plan 的 `visual_baseline` 读取视觉基准（背景/版式/贯穿视觉/过渡/配色），
  同时移除上次中冶武勘项目泄漏进通用 Skill 的硬编码「米白工程纸底纹+淡等高线，左侧1/4柔和水流纹理」。
- `references/03-continuity-rules.md` 整节改写为「策划阶段决策，非生图提示词注入」，给出衔接带
  两条合法路线（全曲线/流体；中段竖直+上下收束）与 plan 落地字段。
- `references/02-content-planning.md` 新增「衔接带方案头脑风暴」子节，作为策划阶段必做动作。
- `SKILL.md` 步骤 2 补「衔接带方案头脑风暴」引导段。

### 2.2.4 竖线衔接引导（已在本版重定位，保留根因说明）
- 原实现新增模块常量 `VERTICAL_LINE_CONTINUITY` 并注入每段提示词；**本版（2.2.6）已移除注入**，
  改为策划阶段决策约束（见上）。根因结论不变：硬竖边在上下边缘必断裂，衔接带须全曲线/流体或
  仅中段竖直且上下约 10% 收束。

## 2.2.5 - 修正额度模型误解 + 默认 Lite + 多终点自动续跑

### 修正「5.0 族额度共享」误解（事实澄清）
- 此前文档误称「5.0 Pro 与 5.0 Lite 同属 doubao-seedream-5-0 族、安心体验额度共享」——**事实错误**。
  各模型免费额度相互独立：5.0 Pro 仅 1 张、5.0 Lite 约 50 张、Seedream-4.5 / 4.0 各为独立额度，互不牵连。
  已删除全部「同族共享」表述，改为「相互独立」。

### 默认模型改 5.0 Lite（避免误耗 Pro 1 张额度）
- `ARKCLI_DEFAULT_MODEL` 由 `doubao-seedream-5-0-pro`（Pro，仅 1 张）改为 `doubao-seedream-5-0-260128`（5.0 Lite，约 50 张）。
- 不传 `--arkcli-endpoint` 时默认即用 Lite，绝不会先调 Pro 导致一张用尽即整批中断。

### 多终点 fallback 链（额度耗尽自动续跑）
- `--arkcli-endpoint` 支持逗号分隔多个终点（callable id 或 ep- id），如 `ep-lite,ep-45,ep-40`；
  配合 `--arkcli-family lite,4.5,4.0` 一一对应。
- 串行生成时，若当前终点报「额度耗尽 / 安心体验已暂停」，脚本**自动切换到下一终点续跑本段**，
  不浪费已完成段，也不会因 Pro 仅 1 张而中断。
- 并行（`--parallel>1`）时用链中第一个终点，不触发 fallback（追求速度时由用户预确保额度充足）。

## 2.2.4 - 修复「40 分钟反复踩坑」根因 + 竖线衔接引导 + 提速

### 根因修复（曾导致单次生图反复失败、累计耗时 40+ 分钟）
- **API Key 自动载入**：新增 `_load_ark_key()`，按「环境变量 ARK_API_KEY → VOLCENGINE_ARK_API_KEY
  → `~/.arkcli/.env`（自动剥离双引号与 `\r` 污染）」顺序解析，**无需用户每次手动 `export`**。
  缺失时给出清晰报错而非静默失败。这是此前最致命的时间黑洞。
- **数据面 Key 注入方式修正**：方舟数据面**只认环境变量 `ARK_API_KEY`**，`--api-key` 旗标对其无效
  （传了反而让数据面静默失败、退出码 0 却无图）。脚本已移除该旗标、改为注入本进程环境变量，子进程继承。
- **优先调用原生二进制**：新增 `_resolve_arkcli_bin()` 跳过 `arkcli.cmd` / `arkcli.ps1` 包装，优先用
  `arkcli-windows-amd64.exe` 等原生 Go 二进制。`.cmd` 经 `cmd.exe` 解析含中文/换行的 prompt 时会吞掉
  后续 `--save-to` / `--output-format`，导致图片落到 cwd 且强制 jpeg。
- **「退出码 0 但无图」一次性诊断**：`_run_arkcli` 改为返回 CompletedProcess，`_scan_arkcli_failure()`
  扫描 stdout 识别 Key 缺失 / 额度耗尽 / 模型未开通 / 内容审核 / 参数不支持，给出可读建议，避免反复重试。
- **绝对路径**：`--output-dir` 解析为绝对路径，规避相对路径在某些环境下的落盘偏差。

### 竖线衔接引导（用户反馈的拼接断裂根因）
- 新增模块常量 `VERTICAL_LINE_CONTINUITY`，注入**每一段**的生图提示词：
  贯穿全图的衔接带中段可竖直，但**距上下边缘约 10% 区域内必须收束为曲线/流体物（飘带、光晕、河流、
  云气、能量流等），严禁在上下边缘出现竖直柱子/树干/竖杆/硬直线等线性出口入口**——AI 无法保证相邻
  两段竖直线精确对齐，硬竖边必断裂。
- `references/03-continuity-rules.md` 新增「段间线状体衔接约束（避免竖直硬边）」专节。
- `references/09-arkcli-backend.md` 修正过时表述（`--sequential` 仅 pro/lite 适用，4.5/4.0 跳过），
  并重写 API Key 章节、故障排查表（含「安心体验」额度共享、`5.0 Pro 与 5.0 Lite 同族`、内容审核拦截提示）。

### 提速与配额保护
- **默认跳过已存在的段**（等价于 `--resume`，`--force` 可强制重跑）：重跑整批不再重复消耗已完成段的额度。
- **`--parallel N`（arkcli 专用）**：`>1` 时各段独立并行生成（不引用上一段成图）以缩短墙钟时间；
  会牺牲相邻段 image2image 连续性，仅建议追求速度或已有底图时开启。

## 2.2.3 - 修正「提示词字数 ↔ CLI 崩溃」的错误归因

- **删除 build_prompt 中误导性注释**：原注释称「prompt 过长易触发 CLI 解析异常」，
  此为误诊。方舟 `--model 未传` 等 CLI 解析异常与 prompt 长度**无关**，根因是
  `--api-key` 注入位置（原置于参数末尾）+ 环境变量 `\r` 污染导致参数错位。
  已在 `_generate_one_arkcli` 中将 api_key 紧跟 `--model` 注入并 `.strip()`（2.2.x 已修）。
- **明确两后端字数上限差异**：即梦官方 ≈800 字，火山方舟 Seedream 官方 ≈300 中文字
  （软性质量建议，非硬上限，超出不报错、长 prompt 实测可正常生成）；在
  `references/09-arkcli-backend.md` 第 11 节与故障排查表补充该差异及正确归因。
- **收紧 build_prompt 固定套话**以贴近官方软上限（约降 12%），但保留内容白名单与
  「文字逐字一致/零错字」两条关键质量约束不被裁剪。
- 提示词长度告警仅作为「可能丢细节」的质量提示，明确标注与 CLI 稳定性无关。

## 2.2.2 - 双后端选择规则与平台区分

- **明确两个后端分属不同平台**：即梦 CLI（即梦/剪映生态自有图片模型 + 即梦 credits）与
  火山 Ark CLI（方舟平台 Doubao Seedream 系列 + 方舟额度），模型命名、额度、登录方式互不相同，
  文档与示例已严格区分，避免逻辑混淆。
- **后端选择规则（强制）**：
  - 运行 `doctor.py` 读取安装状态；
  - 两者都未安装 → 先引导安装其一；
  - **只装了一个 → 默认就是那个平台**，无需询问；
  - **两个都装了 → 必须先向用户确认用哪个平台**，再显式指定 `--backend`；不得擅自默认。
- **脚本 `--backend auto`（新默认）**：仅装一个时自动选该后端；两个都装时主动报错拦截
  （提示二者平台差异），强制先选；都不装时报安装指引。把选择规则落到代码层，双重保险。
- **doctor.py 增强**：新增 `both_backends_installed` / `recommended_backend` 字段与对应
  文本提示，供智能体判断是否需要询问用户。
- 不引入任何个人 API Key / 接入点 id，可放心分享。

## 2.2.1 - 模型名支持中英文口语写法

- `--arkcli-model` 现支持中英文口语写法自动归一，例如「火山方舟 Seedream 图片模型 5.0 lite」
  /「seedream 5.0 pro」/「Seedream 4.5」均可被识别并解析为对应 `callable_model_id`；
  已是正确的友好名 / callable id / 接入点 id（ep-xxxx）仍原样保留；无法识别的内容原样透传由 `+gen` 报错。
- 不引入任何个人 API Key / 接入点 id，可放心分享。

## 2.2.0 - 兼容火山方舟全部 Seedream 图片模型

- **兼容四款图片模型**：`--arkcli-model` 现支持 `doubao-seedream-5-0-pro` / `doubao-seedream-5-0`
  (lite) / `doubao-seedream-4-5` / `doubao-seedream-4-0`，脚本自动解析为公开 `callable_model_id`
  （如 `doubao-seedream-4-5-251128`），并各自在方舟控制台开通后可用；
- **按模型自动选择输出格式**：`--output-format auto`（默认）下，pro/lite 用 `png`、4.5/4.0 用
  `jpeg`，避免向不支持 png 的模型传 `png` 触发报错；也可显式 `--output-format png|jpeg`；
- **强制单图（`--sequential disabled`）**：5.0 lite / 4.5 / 4.0 默认可能走组图，长海报需「一段一图」，
  脚本对所有模型强制关闭组图，确保拼接不破坏；
- **水印默认关闭**：新增 `--watermark` / `--no-watermark`（默认不加「AI 生成」水印，保持海报干净）；
- **提示词长度告警**：生图前检测中文字符数，超 300 字打印 `[警告]`，降低元素缺失风险；
- **新增 `--prompt-mode`**：`standard` / `fast` 优化模式（需配合 `--optimize-prompt`；`fast` 仅 5.0 pro 支持）；
- **`references/09-arkcli-backend.md` 重写**：新增模型能力对照表、按模型尺寸约束表（像素上下限）、
  参考图上限、组图行为、output_format 支持、提示词长度等；
- **`references/07-error-handling.md` 扩充**：新增 output_format 不支持、意外组图、提示词过长三类排查；
- 全文不出现任何个人 API Key / 接入点 id，仅用公开模型 id 与 `<占位符>`。

## 2.1.1 - 修复 Ark CLI 生图前置与模型 id 解析

- **修复「requires an endpoint id, not a plan model name」必现报错**：`generate_segments.py`
  新增 `_resolve_arkcli_model`，把友好名 / 展示名（如 `doubao-seedream-5-0-pro`）自动解析为
  可调用模型 id（如 `doubao-seedream-5-0-pro-260628`）；已为 `ep-xxxx` 或 callable id 则原样使用；
- **新增「模型须先在方舟控制台开通」前置步骤**（`references/09-arkcli-backend.md` 第 4 节），
  避免 `model_activation_required` 报错；并补充 `arkcli +deploy` 建推理接入点（`ep-xxxx`）流程；
- **修复默认尺寸过小被拒**：`--size` 默认值由 `1024x1792`（约 184 万像素，低于 Seedream-5.0
  下限）改为 `1440x2560`（约 368 万像素，已验证可用）；
- **新增 `--arkcli-endpoint` 参数**：可直接指定 `ep-xxxx` 接入点 id，优先级高于 `--arkcli-model`；
- **`generate_segments.py` 新增 `_enhance_arkcli_error`**：把常见 arkcli 报错（模型 id 写法 /
  未开通 / 尺寸）转化为可操作排查建议；
- **`references/07-error-handling.md` 扩充** Ark CLI 三类典型报错与处理；
- 全文不出现任何个人 API Key / 接入点 id，仅用公开模型 id 与 `<占位符>`。

## 2.1.0 - 双后端（即梦 CLI + 火山 Ark CLI）

- **新增火山引擎 Ark CLI 后端**：`generate_segments.py` 通过 `--backend arkcli` 调用
  `arkcli +gen`（Doubao-Seedream-5.0-pro / lite 等图片模型）生图；同步生成、`--input` 参考图、
  `--size` 自定义尺寸、`--save-to` 本地落盘，参考图上限 8 张；
- **双后端可切换**：`--backend dreamina|arkcli`（默认 dreamina）；两个后端共用同一套
  `poster_plan.json`、构图 / 文字白名单 / 连续性约束；
- **arkcli 自动探测**：依次尝试 `--arkcli-path` → 环境变量 `ARKCLI_BIN` → 系统 `PATH` →
  WorkBuddy 托管 Node 目录，无需手动加 PATH；
- **doctor.py 双后端检测**：`dreamina` 或 `arkcli` 任一可用即视为后端就绪；
- **新增 `references/09-arkcli-backend.md`**：Ark CLI 安装、跨设备 SSO 登录、API Key 配置、
  模型选择、`+gen` 参考图与尺寸、成本与故障排查；
- 拼接、质检、工具与测试保持引擎无关，原样保留；
- 技能重命名为 `continuous-long-poster-arkcli`。

## 2.0.0 - 即梦 CLI 精简版

- **移除原 OpenAI 兼容生图接口**：删除 `scripts/image_client.py`；
- **移除 API Key 配置体系**：删除 `scripts/config_manager.py`、`scripts/configure.py` 与 `config/` 目录（含旧版推荐服务商购买引导 `recommended_provider.json`）；
- **移除 OpenAI 接入文档**：删除 `references/06-api-setup-guide.md` 与 `config/schema.md`；
- **即梦成为唯一后端**：`scripts/generate_segments_dreamina.py` 反内联为 `scripts/generate_segments.py`（含 `build_prompt`），不再依赖 OpenAI 模块；
- `scripts/doctor.py` 改为检查 Python 依赖 + 即梦 CLI 是否可用，不再检查 API Key；
- `SKILL.md` / `README.md` 重写为即梦单后端流程，删除双后端选择与推荐入口购买引导；
- 依赖精简：`requests` 不再需要，仅保留 `Pillow` + `numpy`；
- 拼接（`stitch_long_poster.py`）、质检（`qc_report.py`）、工具（`utils.py`）与测试保持引擎无关，原样保留。

## 1.0.0 - 2026-07-21

- 首次发布 WorkBuddy 完整 Skill；
- 支持兼容 OpenAI Images API 的文字生图与图片编辑；
- 支持多段连续生成、断点续跑和单段重做；
- 支持逐对拼接计划；
- 支持直接、裁切、重叠、羽化和局部遮罩融合；
- 支持亮度/色彩匹配、接缝预览和质量报告；
- 加入 API 配置引导、推荐服务商占位配置和安全规范。
