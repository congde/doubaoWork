# 文件清单与验证结果

## 核心文件

- `SKILL.md`：WorkBuddy / OpenClaw 兼容的 Skill 主指令（四后端：OpenAI 兼容 API 默认 / OPC / 即梦 CLI / 火山 Ark CLI）。
- `README.md`：安装、配置、运行和安全说明。
- `requirements.txt`：Python 依赖（Pillow + numpy + requests；requests 仅 API 后端需要）。
- `LICENSE.txt`：可修改的商业授权模板。
- `CHANGELOG.md`：版本记录。

## 方法规则

- `references/01-core-method.md`
- `references/02-content-planning.md`
- `references/03-continuity-rules.md`
- `references/04-text-and-material-rules.md`
- `references/05-stitching-rules.md`
- `references/06-api-setup-guide.md`（openai / opc 后端用法必读）
- `references/07-error-handling.md`
- `references/08-dreamina-backend.md`（即梦 CLI 用法必读）
- `references/08-security-policy.md`
- `references/09-arkcli-backend.md`（火山 Ark CLI 用法必读）
- `references/10-textless-overlay.md`（无字底图 + 代码叠字模式必读）

## 可执行脚本

- `scripts/doctor.py`：检查 Python、依赖、API 配置与即梦/Ark CLI 安装状态（四后端检测）。
- `scripts/generate_segments.py`：四后端统一生图入口（`--backend openai / opc / dreamina / arkcli / auto`），按计划连续生成分段图，支持断点续跑和单段重做。
- `scripts/image_client.py`：OpenAI 兼容同步 Images API 客户端（openai 后端）。
- `scripts/opc_image_client.py`：OPC（OpenAI 兼容聚合 API）异步客户端（提交 → 轮询 → 下载；opc 后端）。
- `scripts/config_manager.py` / `scripts/configure.py`：API 配置读写（本地 ~/.workbuddy-long-poster/，Key 脱敏）。
- `scripts/overlay_text.py`：无字底图模式的代码精准叠字（PIL + 内置黑体）。
- `scripts/stitch_long_poster.py`：执行裁切、重叠、羽化、局部遮罩和色彩匹配。
- `scripts/qc_report.py`：生成接缝预览、联系表和质量报告。
- `scripts/run_pipeline.py`：辅助串联生成、拼接和质检。
- `scripts/utils.py`：通用工具（JSON 读写、文件名清理等）。

## 配置

- `config/schema.md`：API 配置字段说明。
- `config/settings.example.json`：配置示例（不含真实 Key）。
- `config/recommended_provider.json`：推荐配置入口（OPC（OpenAI 兼容聚合 API） <你的 OpenAI 兼容 API 服务商文档>，无购买链接）。

## 资源

- `assets/fonts/simhei.ttf`、`assets/fonts/NotoSansSC-VF.ttf`：overlay_text.py 代码叠字用字体。

## 示例与测试

- `examples/poster_plan.example.json`
- `examples/stitch_plan.example.json`
- `examples/task.example.md`
- `examples/project_structure.md`
- `tests/test_stitching.py`

## 已完成验证

- Python 全部脚本编译通过（py_compile）；
- SKILL.md frontmatter YAML 严格解析通过；
- 无旧第三方购买链接、无历史作者署名残留；
- 「衔接带方案头脑风暴」环节保留（SKILL.md 步骤 2 + 02/03 references）；
- 拼接、质检与测试与生图引擎无关，保持可用。

## 验证建议（使用者自查）

```bash
python scripts/doctor.py --json        # 四后端环境检查
python -m unittest discover -s tests -v
python scripts/generate_segments.py --plan examples/poster_plan.example.json \
  --output-dir /tmp/preview --dry-run   # 提示词预览（不调用任何后端）
```
