# 连续长海报自动生成与拼接 Skill（四后端统一版）

面向 WorkBuddy 的可执行 Skill：读取文章、PDF、聊天记录和视觉素材，调用 **OpenAI 兼容 API（默认）**、**OPC（OpenAI 兼容聚合 API）（<你的 API 服务地址>）**、**本地即梦（Dreamina）CLI** 或 **火山引擎 Ark CLI**（`arkcli +gen`，Doubao-Seedream 等）四选一生成多张上下连续的分段图片，再使用本地 Python 完成裁切、重叠、羽化、局部融合、质量检查和最终长图导出。

## 核心能力

- 内容与风格规划（含规划前「衔接带方案头脑风暴」决策环节）；
- 9:16 多段连续生成；
- 上一张成图作为下一张的视觉参考（image2image / 图片编辑）；
- 人物、Logo、品牌与排版一致性约束；
- 无字底图模式（`--textless`）+ 代码精准叠字（根治 AI 中文错字）；
- 逐对拼接方案；
- 自动裁切、重叠、羽化、局部遮罩和色彩匹配；
- 输出完整长海报、分段图、拼接计划和质量报告。

## 安装

1. 将本目录压缩为 ZIP，保证 `SKILL.md` 位于压缩包根目录。
2. 在 WorkBuddy 中进入“技能 → 添加技能 → 上传技能”。
3. 导入 ZIP 后启用本 Skill。

WorkBuddy 支持导入本地技能包，Skill 可以封装可执行脚本、文件操作和第三方 CLI 调用。本 Skill 会在用户授权的工作空间内创建项目文件。

## 运行要求

- Python 3.10+
- `Pillow`、`numpy`（全后端必需）；`requests`（仅 openai / opc API 后端需要）
- 任一可用生图后端（四选一）：
  - **OpenAI 兼容 API（默认后端）**：已配置的 Images API（GPT Image 2 等）；
  - **OPC（OpenAI 兼容聚合 API）**：`<你的 API base_url>`，可调用 gpt-image-2、即梦 5.0 Pro / Lite 等聚合模型；
  - **即梦 CLI**：本地已安装并登录的 `dreamina` CLI（来自 WorkBuddy 的 `dreamina-cli` 技能）；
  - **火山 Ark CLI**：本地已安装并登录的 `arkcli`（Doubao-Seedream 等），并配置 API Key。

安装依赖：

```bash
python -m pip install -r requirements.txt
```

## API 后端配置（openai / opc）

运行配置命令（Key 本地存储于 `~/.workbuddy-long-poster/config.json`，权限 600，不回显）：

```bash
python scripts/configure.py set --api-key "<KEY>" --base-url "<URL>" --model "<MODEL>"
```

也可用环境变量 `LONG_POSTER_API_KEY` / `LONG_POSTER_BASE_URL` / `LONG_POSTER_IMAGE_MODEL`。

用户需自行向所选 OpenAI 兼容 API 服务商申请 base_url / api_key / model（支持 gpt-image-2、即梦 5.0 Pro / Lite 等），然后：

```bash
python scripts/configure.py set \
  --api-key "<OPC_KEY>" \
  --base-url "<你的 API base_url>" \
  --model "gpt-image-2"
```

base_url 指向 `<你的 API 服务地址>` 时自动切换为 OPC 异步客户端（提交 → 轮询 → 下载）；也可显式
`--backend opc` 强制指定。详见 `references/06-api-setup-guide.md`。

## CLI 后端配置（dreamina / arkcli）

- **即梦**：`dreamina` CLI 来自 WorkBuddy 的 **`dreamina-cli`** 技能。启用后运行 `dreamina login` 完成 OAuth 授权，并用 `dreamina user_credit` 确认额度充足。
- **火山 Ark CLI**：运行 `npm i -g @volcengine/ark-cli`，再 `arkcli auth login volc-sso --no-browser` 跨设备授权并 `echo '<API_KEY>' | arkcli auth apikey` 写入 Key；并先到方舟控制台**开通**所用 Seedream 模型（兼容 5.0 pro / 5.0 lite / 4.5 / 4.0，不同模型分别开通）。详见 `references/09-arkcli-backend.md`。

## 后端选择

本 Skill 有四个生图后端，分属不同平台/生态，请勿混淆：

- **openai（OpenAI 兼容 API，默认）**：同步 Images API，消耗 API 额度；
- **opc（OPC（OpenAI 兼容聚合 API））**：异步接口，消耗 OPC 算力额度；
- **dreamina（即梦 CLI）**：即梦 / 剪映生态自有图片模型，消耗即梦 credits；
- **arkcli（火山 Ark CLI）**：火山引擎方舟平台 Doubao Seedream 系列，消耗方舟额度。

选择规则：用户明确指定 → 按指定；**API 已配置且未指定 → 默认 openai**（base_url 为 OPC 时自动切
opc）；API 未配置且**只装一个 CLI → 默认用那个**；**即梦与 Ark CLI 都装 → 先确认用户用哪个平台**再
显式指定 `--backend`。`generate_segments.py` 的 `--backend auto`（默认）遵循同一规则，并在需要用户
决策时主动报错拦截。

## 快速测试

检查环境（含 API 配置状态与四后端安装状态、推荐后端建议）：

```bash
python scripts/doctor.py
```

执行单元测试（拼接与质量检查部分，与生图引擎无关）：

```bash
python -m unittest discover -s tests -v
```

## 标准工作流

1. WorkBuddy 读取素材，先做「衔接带方案头脑风暴」，再创建 `poster_plan.json`；
2. `generate_segments.py` 调用所选后端（openai / opc / dreamina / arkcli）顺序生成分段图；
3. （可选）`--textless` 无字底图 + `overlay_text.py` 代码精准叠字；
4. WorkBuddy 查看分段图并创建 `stitch_plan.json`；
5. `stitch_long_poster.py` 执行最终拼接；
6. `qc_report.py` 创建接缝预览和质量报告。

示例文件位于 `examples/`。API 后端用法见 `references/06-api-setup-guide.md`，即梦后端用法见 `references/08-dreamina-backend.md`，火山 Ark CLI 后端用法见 `references/09-arkcli-backend.md`，无字底图模式见 `references/10-textless-overlay.md`。

## 重要限制

- AI 生图中的长中文文字可能出现错字。Skill 会要求逐张检查，但无法从技术上保证零错误；含大量中文文案时建议使用无字底图模式（`--textless`）。
- 只有后端支持参考图/图片编辑时，才能较稳定地延续上一张具体画面。
- 自动拼接代码能处理裁切、重叠、羽化和局部融合，但最优参数仍需要智能体基于实际成图判断。
- 生图会消耗所选后端的额度（API 费用 / 即梦 credits / 火山方舟额度），费用与额度政策由对应用户账号负责。

## 安全说明

- 不记录或回显任何密钥 / token；
- 不扫描工作空间外的文件；
- 不删除用户原始素材；
- 只向用户配置的 API 端点或本地 CLI 账号提交绘图提示词和明确指定的参考图片；
- 安装第三方 Skill 前建议进行代码审查。

## 版本

- 1.0.0：WorkBuddy 首个完整版本（OpenAI 兼容后端）。
- 1.2.0：新增即梦（Dreamina）CLI 后端。
- 2.0.0：精简为「即梦 CLI 单后端」版本。
- 2.1.0 ~ 2.3.0：新增火山 Ark CLI 后端、无字底图模式（`--textless` + `overlay_text.py`）、衔接带方案头脑风暴等。
- 3.0.0：**四后端统一版**——回植 OpenAI 兼容 API（默认后端）与 OPC（OpenAI 兼容聚合 API）异步后端，与即梦 CLI、火山 Ark CLI 并存统一入口（`--backend openai / opc / dreamina / arkcli / auto`）；移除旧推荐购买入口；用户需自备任意 OpenAI 兼容图片 API（自行申请 base_url / api_key / model）。
