# 配置字段说明

配置优先级：命令行参数 > 环境变量 > 用户配置文件 > 默认值。

| 字段 | 说明 |
|---|---|
| `api_key` | 图片 API 密钥。建议通过环境变量提供。 |
| `base_url` | API 根地址，例如 `https://api.openai.com/v1`。 |
| `model` | 图片模型名称，默认 `gpt-image-2`。 |
| `generation_path` | 文字生图路径，默认 `/images/generations`。 |
| `edit_path` | 图片编辑路径，默认 `/images/edits`。 |
| `size` | 默认输出尺寸。竖版通常用 `1024x1536`。 |
| `quality` | `low`、`medium`、`high`，以服务商支持为准。 |
| `timeout_seconds` | 单次请求超时。 |
| `max_retries` | 失败重试次数。 |
| `allow_text_only_fallback` | 编辑接口失败时，是否退化为纯文字重新生成。开启后连续性会下降。 |
| `multipart_image_field` | 编辑接口上传图片使用的字段名，默认 `image`。 |
| `extra_headers` | 服务商要求的额外请求头。不得在公开包里放密钥。 |
| `extra_body` | 服务商要求的额外请求参数。 |

环境变量：

```text
LONG_POSTER_API_KEY
LONG_POSTER_BASE_URL
LONG_POSTER_IMAGE_MODEL
LONG_POSTER_IMAGE_SIZE
LONG_POSTER_IMAGE_QUALITY
LONG_POSTER_CONFIG_PATH
```
