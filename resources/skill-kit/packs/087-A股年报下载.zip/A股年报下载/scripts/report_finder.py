#!/usr/bin/env python3
"""Query and optionally download A-share periodic report PDFs."""

from __future__ import annotations

import argparse
import html
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

CNINFO_QUERY_URL = "http://www.cninfo.com.cn/new/hisAnnouncement/query"
CNINFO_FULLTEXT_URL = "http://www.cninfo.com.cn/new/fulltextSearch/full"
CNINFO_PDF_BASE = "http://static.cninfo.com.cn/"
BSE_PERIODIC_URL = "https://testcyb.cs.com.cn/bjs/v1/periodic/{kind}/{page}.json"
DEFAULT_TIMEOUT = 30

REPORT_TYPES = {
    "annual": {
        "category": "category_ndbg_szsh;",
        "keywords": ["年度报告"],
        "exclude": ["摘要", "更正", "修订", "补充", "取消", "英文版"],
    },
    "half": {
        "category": "category_bndbg_szsh;",
        "keywords": ["半年度报告"],
        "exclude": ["摘要", "更正", "修订", "补充", "取消", "英文版"],
    },
    "q1": {
        "category": "category_yjdbg_szsh;",
        "keywords": ["第一季度报告"],
        "exclude": ["正文", "更正", "修订", "补充", "取消", "英文版"],
    },
    "q3": {
        "category": "category_sjdbg_szsh;",
        "keywords": ["第三季度报告"],
        "exclude": ["正文", "更正", "修订", "补充", "取消", "英文版"],
    },
}

BSE_KIND = {
    "annual": "0",
    "half": "1",
    "q1": "2",
    "q3": "3",
}

REPORT_ALIASES = {
    "年报": "annual",
    "年度报告": "annual",
    "annual": "annual",
    "中报": "half",
    "半年报": "half",
    "半年度报告": "half",
    "half": "half",
    "h1": "half",
    "一季报": "q1",
    "第一季度报告": "q1",
    "q1": "q1",
    "三季报": "q3",
    "第三季度报告": "q3",
    "q3": "q3",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="检索并下载 A 股定期报告 PDF")
    parser.add_argument("--code", help="股票代码，例如 600519、SH600519、600519.SH")
    parser.add_argument("--name", help="股票名称或公司简称，例如 贵州茅台、宁德时代")
    parser.add_argument("--year", required=True, type=int, help="报告年度，例如 2024")
    parser.add_argument("--report-type", default="annual", help="annual/half/q1/q3，也可写年报、半年报等")
    parser.add_argument("--download", action="store_true", help="下载命中的 PDF")
    parser.add_argument("--out-dir", default="reports", help="下载保存目录")
    parser.add_argument("--page-size", type=int, default=30, help="每页查询条数")
    return parser.parse_args()


def clean_code(raw: str) -> str:
    match = re.search(r"(\d{6})", raw)
    if not match:
        raise ValueError(f"无法识别股票代码：{raw}")
    return match.group(1)


def detect_market(code: str) -> dict[str, str]:
    if code.startswith(("600", "601", "603", "605")):
        return {"market": "沪市主板", "column": "sse", "plate": "sh"}
    if code.startswith(("688", "689")):
        return {"market": "科创板", "column": "sse", "plate": "shkcp"}
    if code.startswith(("000", "001", "002", "003")):
        return {"market": "深市主板", "column": "szse", "plate": "sz"}
    if code.startswith(("300", "301")):
        return {"market": "创业板", "column": "szse", "plate": "szcy"}
    if code.startswith(("430", "83", "87", "88", "920")):
        return {"market": "北交所相关代码", "column": "bse", "plate": "bse"}
    raise ValueError(f"暂不支持或无法判断市场：{code}")


def normalize_report_type(value: str) -> str:
    key = value.strip().lower()
    normalized = REPORT_ALIASES.get(key)
    if not normalized:
        raise ValueError(f"暂不支持的报告类型：{value}")
    return normalized


def disclosure_window(year: int, report_type: str) -> str:
    if report_type == "annual":
        return f"{year + 1}-01-01~{year + 1}-12-31"
    return f"{year}-01-01~{year + 1}-06-30"


def cninfo_stock_id(code: str, market: dict[str, str], org_id: str = "") -> str:
    if org_id:
        return f"{code},{org_id}"
    if market["column"] == "sse":
        return f"{code},gssh0{code}"
    return code


def request_json(url: str, data: dict[str, Any]) -> dict[str, Any]:
    encoded = urllib.parse.urlencode(data).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=encoded,
        headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Accept": "application/json, text/plain, */*",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": "http://www.cninfo.com.cn/new/commonUrl/pageOfSearch?url=disclosure/list/search",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    return json.loads(raw)


def request_fulltext(params: dict[str, Any]) -> dict[str, Any]:
    url = CNINFO_FULLTEXT_URL + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15",
            "Accept": "application/json, text/plain, */*",
            "Referer": "http://www.cninfo.com.cn/new/commonUrl?url=disclosure/list/search",
        },
    )
    with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    return json.loads(raw)


def strip_tags(text: str) -> str:
    text = re.sub(r"<[^>]+>", "", text or "")
    return html.unescape(text).strip()


def parse_time(value: Any) -> str:
    if value in (None, ""):
        return ""
    try:
        timestamp = int(value) / 1000
        return time.strftime("%Y-%m-%d", time.localtime(timestamp))
    except (TypeError, ValueError, OSError):
        return str(value)


def build_query(code: str, market: dict[str, str], report_type: str, year: int, page_size: int, org_id: str = "") -> dict[str, Any]:
    return {
        "pageNum": 1,
        "pageSize": page_size,
        "column": market["column"],
        "tabName": "fulltext",
        "plate": market["plate"],
        "stock": cninfo_stock_id(code, market, org_id),
        "searchkey": "",
        "secid": "",
        "category": REPORT_TYPES[report_type]["category"],
        "trade": "",
        "seDate": disclosure_window(year, report_type),
        "sortName": "",
        "sortType": "",
        "isHLtitle": "true",
    }


def build_name_query(name: str, report_type: str, year: int, page_size: int) -> dict[str, Any]:
    return {
        "pageNum": 1,
        "pageSize": page_size,
        "column": "",
        "tabName": "fulltext",
        "plate": "",
        "stock": "",
        "searchkey": name,
        "secid": "",
        "category": REPORT_TYPES[report_type]["category"],
        "trade": "",
        "seDate": disclosure_window(year, report_type),
        "sortName": "",
        "sortType": "",
        "isHLtitle": "true",
    }


def resolve_security_by_name(name: str, year: int, report_type: str) -> tuple[dict[str, Any] | None, list[dict[str, Any]], list[str]]:
    params = {
        "searchkey": name,
        "sdate": disclosure_window(year, report_type).split("~")[0],
        "edate": disclosure_window(year, report_type).split("~")[1],
        "isfulltext": "false",
        "sortName": "pubdate",
        "sortType": "desc",
        "pageNum": 1,
    }
    data = request_fulltext(params)
    items = data.get("announcements") or []
    candidates: dict[str, dict[str, Any]] = {}
    warnings: list[str] = []

    for item in items:
        code = str(item.get("secCode") or "")
        sec_name = strip_tags(item.get("secName") or item.get("tileSecName") or "")
        org_id = item.get("orgId") or ""
        if not re.fullmatch(r"\d{6}", code):
            continue
        try:
            market = detect_market(code)
        except ValueError:
            continue
        if name not in sec_name and sec_name not in name and name not in strip_tags(item.get("announcementTitle", "")):
            continue
        candidates[code] = {
            "code": code,
            "name": sec_name,
            "org_id": org_id,
            "market": market["market"],
        }

    ordered = list(candidates.values())
    exact = [item for item in ordered if item["name"] == name]
    if len(exact) == 1:
        return exact[0], ordered, warnings
    if len(ordered) == 1:
        return ordered[0], ordered, warnings
    if not ordered:
        warnings.append(f"没有按名称找到可识别的 A 股公司：{name}")
    else:
        warnings.append(f"名称匹配到多个候选，请确认股票代码或公司简称：{name}")
    return None, ordered, warnings


def request_bse_json(report_type: str, page: int) -> dict[str, Any]:
    url = BSE_PERIODIC_URL.format(kind=BSE_KIND[report_type], page=page)
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15",
            "Accept": "application/json, text/plain, */*",
            "Referer": "https://bse.cs.com.cn/",
        },
    )
    with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    return json.loads(raw)


def filter_records(items: list[dict[str, Any]], report_type: str, year: int) -> tuple[list[dict[str, Any]], list[str]]:
    rules = REPORT_TYPES[report_type]
    records: list[dict[str, Any]] = []
    warnings: list[str] = []

    for item in items:
        title = strip_tags(item.get("announcementTitle", ""))
        reason = ""
        if str(year) not in title:
            reason = "标题不含报告年度"
        elif not any(keyword in title for keyword in rules["keywords"]):
            reason = "标题不含报告类型关键词"
        elif any(word in title for word in rules["exclude"]):
            reason = "标题属于摘要、更正或补充类文件"
        elif not item.get("adjunctUrl"):
            reason = "公告缺少 PDF 路径"

        if reason:
            warnings.append(f"已过滤：{title or '无标题'}（{reason}）")
            continue

        url = urllib.parse.urljoin(CNINFO_PDF_BASE, item["adjunctUrl"])
        records.append(
            {
                "title": title,
                "code": item.get("secCode", ""),
                "name": strip_tags(item.get("secName", "")),
                "publish_date": parse_time(item.get("announcementTime")),
                "source": "巨潮资讯公告检索",
                "pdf_url": url,
            }
        )
    return records, warnings


def filter_bse_records(code: str, report_type: str, year: int, max_pages: int = 20) -> tuple[list[dict[str, Any]], list[str]]:
    rules = REPORT_TYPES[report_type]
    records: list[dict[str, Any]] = []
    warnings: list[str] = []

    for page in range(1, max_pages + 1):
        data = request_bse_json(report_type, page)
        items = (((data.get("data") or {}).get("data")) or [])
        if not items:
            break

        for item in items:
            title = strip_tags(item.get("f002v", ""))
            item_code = str(item.get("seccode", "")).zfill(6)
            if item_code != code:
                continue
            if str(year) not in title:
                warnings.append(f"已过滤：{title or '无标题'}（标题不含报告年度）")
                continue
            if not any(keyword in title for keyword in rules["keywords"]):
                warnings.append(f"已过滤：{title or '无标题'}（标题不含报告类型关键词）")
                continue
            if any(word in title for word in rules["exclude"]):
                warnings.append(f"已过滤：{title or '无标题'}（标题属于摘要、更正或补充类文件）")
                continue
            url = item.get("f003v") or ""
            if not url:
                warnings.append(f"已过滤：{title or '无标题'}（公告缺少 PDF 路径）")
                continue
            records.append(
                {
                    "title": title,
                    "code": item_code,
                    "name": item.get("secname", ""),
                    "publish_date": (item.get("f001d") or "")[:10],
                    "source": "北交所信息披露平台",
                    "pdf_url": url,
                }
            )
        if records:
            break

    if not records:
        warnings.append(f"北交所公开分页已扫描前 {max_pages} 页，未找到匹配报告。")
    return records, warnings


def safe_filename(text: str) -> str:
    text = re.sub(r"[\\/:*?\"<>|]+", "_", text)
    text = re.sub(r"\s+", "", text)
    return text[:120] or "report"


def download_pdf(url: str, out_dir: Path, filename: str) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / filename
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15",
            "Accept": "application/pdf,*/*",
            "Referer": "http://www.cninfo.com.cn/",
        },
    )
    with urllib.request.urlopen(req, timeout=120) as resp, tmp_path.open("wb") as fh:
        while True:
            chunk = resp.read(1024 * 64)
            if not chunk:
                break
            fh.write(chunk)

    with tmp_path.open("rb") as fh:
        header = fh.read(5)
    size = tmp_path.stat().st_size
    if not header.startswith(b"%PDF-"):
        tmp_path.unlink(missing_ok=True)
        raise ValueError("下载结果不是 PDF 文件")
    if size < 100 * 1024:
        warning = "文件小于 100KB，请人工确认是否完整"
    else:
        warning = ""
    tmp_path.replace(path)
    return {"path": str(path.resolve()), "size": size, "warning": warning}


def main() -> int:
    args = parse_args()
    result: dict[str, Any] = {
        "status": "failed",
        "query": {},
        "records": [],
        "downloaded_files": [],
        "warnings": [],
    }
    try:
        report_type = normalize_report_type(args.report_type)
        resolved_from_name = None
        candidates: list[dict[str, Any]] = []
        if args.code:
            code = clean_code(args.code)
            org_id = ""
        elif args.name:
            resolved_from_name, candidates, name_warnings = resolve_security_by_name(args.name, args.year, report_type)
            result["warnings"].extend(name_warnings)
            if not resolved_from_name and candidates:
                result["status"] = "need_confirm"
                result["candidates"] = candidates
                print(json.dumps(result, ensure_ascii=False, indent=2))
                return 0
            if resolved_from_name:
                code = resolved_from_name["code"]
                org_id = resolved_from_name.get("org_id", "")
            else:
                code = ""
                org_id = ""
        else:
            raise ValueError("请提供股票代码 --code 或股票名称 --name")

        market = detect_market(code) if code else {"market": "按名称检索", "column": "", "plate": ""}
        result["query"] = {
            "input_name": args.name or "",
            "code": code,
            "resolved_name": (resolved_from_name or {}).get("name", ""),
            "org_id": org_id,
            "year": args.year,
            "report_type": report_type,
            "market": market["market"],
            "disclosure_window": disclosure_window(args.year, report_type),
        }
        if market["column"] == "bse":
            records, warnings = filter_bse_records(code, report_type, args.year)
            result["records"] = records
            result["warnings"].extend(warnings[:20])
            result["status"] = "ok" if records else "not_found"
        else:
            if code:
                payload = build_query(code, market, report_type, args.year, args.page_size, org_id)
            else:
                payload = build_name_query(args.name, report_type, args.year, args.page_size)
            data = request_json(CNINFO_QUERY_URL, payload)
            items = data.get("announcements") or []
            if not items:
                result["status"] = "not_found"
                result["warnings"].append("公告列表没有返回结果，请确认股票代码、年份和披露状态。")
            else:
                records, warnings = filter_records(items, report_type, args.year)
                result["records"] = records
                result["warnings"].extend(warnings[:20])
                result["status"] = "ok" if records else "not_found"
                if records and not code:
                    first = records[0]
                    code = first.get("code", "")
                    result["query"]["code"] = code
                    result["query"]["resolved_name"] = first.get("name", "")
                    result["warnings"] = [
                        warning for warning in result["warnings"]
                        if not warning.startswith("没有按名称找到可识别的 A 股公司")
                    ]
                    try:
                        result["query"]["market"] = detect_market(code)["market"]
                    except ValueError:
                        result["query"]["market"] = "未识别"

        if args.download and result["records"]:
            out_dir = Path(args.out_dir)
            for record in result["records"]:
                file_code = record.get("code") or code or "unknown"
                filename = f"{file_code}_{args.year}_{safe_filename(record['title'])}.pdf"
                downloaded = download_pdf(record["pdf_url"], out_dir, filename)
                downloaded["title"] = record["title"]
                result["downloaded_files"].append(downloaded)
                if downloaded.get("warning"):
                    result["warnings"].append(f"{record['title']}：{downloaded['warning']}")

    except (ValueError, urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
        result["warnings"].append(str(exc))

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] in {"ok", "not_found"} else 1


if __name__ == "__main__":
    sys.exit(main())
