#!/usr/bin/env python3
"""Calculate Xiaohongshu paid-traffic unit economics with explicit inputs."""

from __future__ import annotations

import argparse
import json
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


CENT = Decimal("0.01")


def money(value: Decimal) -> str:
    return str(value.quantize(CENT, rounding=ROUND_HALF_UP))


def ratio(value: Decimal) -> str:
    return str(value.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP))


def nonnegative_decimal(raw: str, name: str) -> Decimal:
    try:
        value = Decimal(raw)
    except InvalidOperation as exc:
        raise argparse.ArgumentTypeError(f"{name} must be a number") from exc
    if value < 0:
        raise argparse.ArgumentTypeError(f"{name} must be non-negative")
    return value


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Calculate contribution margin, CAC limits, ROI targets, and estimated ad profit."
    )
    p.add_argument("--price", required=True, help="Actual paid average order value")
    p.add_argument("--platform-fee", default="0", help="Platform fee allocated per paid order")
    p.add_argument("--refund-allocation", default="0", help="Refund cost allocated per paid order")
    p.add_argument("--delivery-cost", default="0", help="Delivery or fulfillment cost per paid order")
    p.add_argument("--other-variable-cost", default="0", help="Other variable cost per paid order")
    p.add_argument("--desired-profit", default="0", help="Profit to retain per order after ads")
    p.add_argument("--spend", help="Campaign spend in the same observation window")
    p.add_argument("--paid-orders", type=int, help="Attributed paid orders in the same window")
    p.add_argument("--attributed-gmv", help="Attributed GMV in the same window")
    return p


def main() -> None:
    args = parser().parse_args()
    values = {
        "price": nonnegative_decimal(args.price, "price"),
        "platform_fee": nonnegative_decimal(args.platform_fee, "platform-fee"),
        "refund_allocation": nonnegative_decimal(args.refund_allocation, "refund-allocation"),
        "delivery_cost": nonnegative_decimal(args.delivery_cost, "delivery-cost"),
        "other_variable_cost": nonnegative_decimal(
            args.other_variable_cost, "other-variable-cost"
        ),
        "desired_profit": nonnegative_decimal(args.desired_profit, "desired-profit"),
    }
    if values["price"] <= 0:
        raise SystemExit("--price must be greater than zero")
    if args.paid_orders is not None and args.paid_orders < 0:
        raise SystemExit("--paid-orders must be non-negative")

    spend = nonnegative_decimal(args.spend, "spend") if args.spend is not None else None
    gmv = (
        nonnegative_decimal(args.attributed_gmv, "attributed-gmv")
        if args.attributed_gmv is not None
        else None
    )
    variable_cost = sum(
        (
            values["platform_fee"],
            values["refund_allocation"],
            values["delivery_cost"],
            values["other_variable_cost"],
        ),
        Decimal("0"),
    )
    contribution = values["price"] - variable_cost
    target_cac = contribution - values["desired_profit"]

    result: dict[str, object] = {
        "inputs": {
            "actual_paid_aov": money(values["price"]),
            "variable_cost_per_order": money(variable_cost),
            "desired_profit_per_order": money(values["desired_profit"]),
        },
        "unit_economics": {
            "contribution_before_ads_per_order": money(contribution),
            "break_even_cac": money(contribution),
            "target_cac": money(target_cac),
            "break_even_roi_gmv_over_spend": (
                ratio(values["price"] / contribution) if contribution > 0 else None
            ),
            "target_roi_gmv_over_spend": (
                ratio(values["price"] / target_cac) if target_cac > 0 else None
            ),
        },
        "warnings": [],
    }

    warnings = result["warnings"]
    assert isinstance(warnings, list)
    if contribution <= 0:
        warnings.append("Variable cost is greater than or equal to AOV; ads cannot break even.")
    if target_cac <= 0:
        warnings.append("Desired profit leaves no positive ad-cost allowance per order.")

    if spend is not None:
        campaign: dict[str, object] = {"spend": money(spend)}
        if args.paid_orders is not None:
            campaign["paid_orders"] = args.paid_orders
            campaign["actual_cac"] = (
                money(spend / Decimal(args.paid_orders)) if args.paid_orders > 0 else None
            )
            campaign["estimated_profit_after_ads"] = money(
                contribution * Decimal(args.paid_orders) - spend
            )
            campaign["maximum_spend_at_target_profit"] = money(
                target_cac * Decimal(args.paid_orders)
            )
            campaign["headroom_to_target_spend"] = money(
                target_cac * Decimal(args.paid_orders) - spend
            )
        if gmv is not None:
            campaign["attributed_gmv"] = money(gmv)
            campaign["actual_roi_gmv_over_spend"] = ratio(gmv / spend) if spend > 0 else None
        result["campaign"] = campaign
    elif args.paid_orders is not None or gmv is not None:
        warnings.append("Campaign metrics require --spend for CAC or ROI calculation.")

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
