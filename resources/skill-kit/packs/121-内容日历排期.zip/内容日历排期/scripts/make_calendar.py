#!/usr/bin/env python3
"""内容日历生成：栏目配置 → 带**真实日期**的周/月排期表（Markdown + CSV），含热点弹性位与库存提醒。"""
import argparse
import csv
import json
from datetime import date, timedelta
from pathlib import Path

CN_WD = ["一", "二", "三", "四", "五", "六", "日"]

DEMO = {
    "weeks": 4,
    "capacity_note": "每周 ~6h ｜ 周更 2 固定 + 1 弹性",
    "slots": [
        {"weekday": 1, "platform": "小红书", "column": "干货教程", "mode": "图文", "note": "固定栏目"},
        {"weekday": 3, "platform": "抖音", "column": "踩坑实录", "mode": "口播 60s", "note": "固定栏目"},
        {"weekday": 6, "platform": "全平台", "column": "互动问答", "mode": "低成本图文", "note": "评论区问题集中答"},
        {"weekday": 5, "platform": "（留白）", "column": "🔥热点位", "mode": "视热点定", "note": "弹性：无好热点则转发本周最佳"},
    ],
}


def next_week_monday(today=None):
    today = today or date.today()
    return today + timedelta(days=(7 - today.weekday()) % 7 or 7)


def build(config):
    start = next_week_monday()
    weeks = config.get("weeks", 4)
    rows = []
    for w in range(weeks):
        for slot in config["slots"]:
            d = start + timedelta(weeks=w, days=slot["weekday"] % 7)
            rows.append({
                "date": f"{d:%Y-%m-%d}", "week": w + 1, "weekday": f"周{CN_WD[d.weekday()]}",
                "platform": slot["platform"], "column": slot["column"], "mode": slot["mode"],
                "topic": slot.get("note", ""), "status": "⬜",
            })

    rows.sort(key=lambda r: r["date"])
    md = [f"# 内容日历（{start:%Y-%m-%d} 起 {weeks} 周）",
          f"产能基准：{config.get('capacity_note','')}",
          "",
          "| 日期 | 周 | 平台 | 栏目 | 形式 | 选题/备注 | 状态 |",
          "|---|---|---|---|---|---|---|"]
    md += [f"| {r['date']} | {r['weekday']} | {r['platform']} | {r['column']} | {r['mode']} | {r['topic']} | {r['status']} |" for r in rows]

    fixed = sum(1 for s in config["slots"] if "热点" not in s["column"])
    elastic = len(config["slots"]) - fixed
    md += ["",
           f"每周节奏：固定栏目 {fixed} 条 + 弹性位 {elastic} 条",
           "## 运营纪律",
           "- 保持 1~2 条成品库存，生病/忙崩时不空窗",
           "- 断更补偿预案：合集 repost + 一句真诚说明（不硬凑）",
           f"- 复盘节点：{start + timedelta(weeks=weeks):%Y-%m-%d}，看三个数——最好一条、最差一条、栏目平均"]
    return md, rows


def main():
    ap = argparse.ArgumentParser(description="内容日历生成（配置 JSON → MD + CSV）")
    ap.add_argument("input", nargs="?", help="配置 JSON")
    ap.add_argument("--out", help="输出前缀")
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()

    if args.demo:
        skill_root = Path(__file__).resolve().parent.parent
        exdir = skill_root / "examples"
        exdir.mkdir(parents=True, exist_ok=True)
        src = exdir / "calendar_demo.json"
        src.write_text(json.dumps(DEMO, ensure_ascii=False, indent=2), encoding="utf-8")
        args.input, args.out = str(src), str(exdir / "内容日历示例")
    elif not args.input:
        ap.error("请提供配置 JSON（字段见 examples/calendar_demo.json），或 --demo 演示")

    config = json.loads(Path(args.input).read_text(encoding="utf-8"))
    md, rows = build(config)
    prefix = args.out or "content_calendar"
    Path(f"{prefix}.md").write_text("\n".join(md), encoding="utf-8")
    with open(f"{prefix}.csv", "w", newline="", encoding="utf-8-sig") as f:
        wtr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wtr.writeheader()
        wtr.writerows(rows)
    print("\n".join(md[:14]))
    print("...")
    print(f"\n已生成：{prefix}.md / {prefix}.csv（CSV 可导入飞书/Notion 多维表格跟踪状态）")


if __name__ == "__main__":
    main()
