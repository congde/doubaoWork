#!/usr/bin/env python3
"""Collect Xiaohongshu comments from note links or keyword search results."""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

BASE_URL = "https://api.tikhub.io"
CONFIG_PATH = Path(__file__).resolve().parents[1] / "config" / "tikhub.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="采集小红书评论用于需求洞察")
    parser.add_argument("--note", action="append", default=[], help="笔记链接、分享文本或 note_id，可重复")
    parser.add_argument("--keyword", default="", help="关键词，先搜索笔记再采集评论")
    parser.add_argument("--notes", type=int, default=3, help="关键词模式下最多分析几条笔记")
    parser.add_argument("--limit", type=int, default=80, help="每条笔记最多采集一级评论数")
    parser.add_argument("--out", default="", help="保存 JSON 路径")
    return parser.parse_args()


def request_json(path: str, params: dict[str, Any], token: str) -> dict[str, Any]:
    url = BASE_URL + path + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0",
        },
    )
    with urllib.request.urlopen(req, timeout=45) as resp:
        return json.loads(resp.read().decode("utf-8", errors="replace"))


def load_api_key() -> str:
    token = os.environ.get("TIKHUB_API_KEY", "").strip()
    if token:
        return token
    if not CONFIG_PATH.exists():
        return ""
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ""
    value = str(data.get("api_key", "")).strip()
    if not value or "填在这里" in value or value.startswith("把你的"):
        return ""
    return value


def walk_values(obj: Any):
    if isinstance(obj, dict):
        yield obj
        for value in obj.values():
            yield from walk_values(value)
    elif isinstance(obj, list):
        for item in obj:
            yield from walk_values(item)


def first_value(obj: dict[str, Any], keys: list[str], default: Any = "") -> Any:
    for key in keys:
        if key in obj and obj[key] not in (None, ""):
            return obj[key]
    return default


def extract_note_id(text: str) -> str:
    match = re.search(r"/(?:explore|discovery/item)/([0-9a-fA-F]{20,32})", text)
    if match:
        return match.group(1)
    if re.fullmatch(r"[0-9a-fA-F]{20,32}", text.strip()):
        return text.strip()
    return ""


def extract_notes_from_search(payload: dict[str, Any], max_notes: int) -> list[dict[str, Any]]:
    notes: dict[str, dict[str, Any]] = {}
    for item in walk_values(payload):
        note_id = first_value(item, ["note_id", "noteId", "id"])
        title = first_value(item, ["title", "display_title", "displayTitle", "desc", "description"])
        if note_id and title:
            notes[str(note_id)] = {"note_id": str(note_id), "title": str(title)}
        if len(notes) >= max_notes:
            break
    return list(notes.values())


def extract_comments(payload: dict[str, Any], note_id: str) -> tuple[list[dict[str, Any]], str]:
    comments: dict[str, dict[str, Any]] = {}
    cursor = ""
    for item in walk_values(payload):
        if not cursor:
            cursor = str(first_value(item, ["cursor", "next_cursor", "nextCursor"], ""))
        comment_id = first_value(item, ["comment_id", "commentId", "id"])
        content = first_value(item, ["content", "text", "desc", "comment_content"])
        if not comment_id or not content:
            continue
        comments[str(comment_id)] = {
            "note_id": note_id,
            "comment_id": str(comment_id),
            "parent_comment_id": "",
            "level": 1,
            "content": str(content),
            "like_count": first_value(item, ["like_count", "likeCount", "liked_count", "likedCount"], 0),
            "reply_count": first_value(item, ["sub_comment_count", "reply_count", "replyCount"], 0),
        }
    return list(comments.values()), cursor


def apply_cursor_params(params: dict[str, Any], cursor: str) -> None:
    if not cursor:
        return
    try:
        cursor_data = json.loads(cursor)
    except json.JSONDecodeError:
        params["cursor"] = cursor
        return
    if not isinstance(cursor_data, dict):
        params["cursor"] = cursor
        return
    if cursor_data.get("cursor"):
        params["cursor"] = cursor_data["cursor"]
    if cursor_data.get("index") is not None:
        params["index"] = cursor_data["index"]
    if cursor_data.get("pageArea"):
        params["pageArea"] = cursor_data["pageArea"]


def collect_comments(note_ref: str, limit: int, token: str) -> dict[str, Any]:
    note_id = extract_note_id(note_ref)
    params = {"cursor": "", "index": 0, "pageArea": "UNFOLDED", "sort_strategy": "latest_v2"}
    if note_id:
        params["note_id"] = note_id
    else:
        params["share_text"] = note_ref
        note_id = note_ref

    comments: list[dict[str, Any]] = []
    seen_comment_ids: set[str] = set()
    cursor = ""
    warnings: list[str] = []
    while len(comments) < limit:
        if cursor:
            apply_cursor_params(params, cursor)
        try:
            payload = request_json("/api/v1/xiaohongshu/app_v2/get_note_comments", params, token)
        except urllib.error.HTTPError as exc:
            warnings.append(f"评论翻页中断：HTTP {exc.code} {exc.reason}")
            break
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
            warnings.append(f"评论翻页中断：{exc}")
            break
        page_comments, next_cursor = extract_comments(payload, note_id)
        if not page_comments:
            break
        for comment in page_comments:
            comment_id = comment.get("comment_id")
            if comment_id in seen_comment_ids:
                continue
            seen_comment_ids.add(str(comment_id))
            comments.append(comment)
        cursor = next_cursor
        if not cursor:
            break
        time.sleep(0.2)
    return {"note": note_ref, "note_id": note_id, "comments": comments[:limit], "warnings": warnings}


def main() -> int:
    args = parse_args()
    token = load_api_key()
    result: dict[str, Any] = {
        "status": "missing_api_key" if not token else "ok",
        "query": vars(args),
        "notes": [],
        "warnings": [],
    }
    if not token:
        result["warnings"].append("未检测到 TikHub 密钥，无法自动采集评论。请把密钥填到本技能目录的 config/tikhub.json 里的 api_key 字段，或设置环境变量 TIKHUB_API_KEY；暂时没有密钥时，可以粘贴评论文本后继续分析。")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    try:
        note_refs = list(args.note)
        if args.keyword:
            payload = request_json(
                "/api/v1/xiaohongshu/app_v2/search_notes",
                {
                    "keyword": args.keyword,
                    "page": 1,
                    "sort_type": "comment_descending",
                    "note_type": "不限",
                    "time_filter": "不限",
                    "source": "explore_feed",
                    "ai_mode": 0,
                },
                token,
            )
            found_notes = extract_notes_from_search(payload, args.notes)
            result["search_notes"] = found_notes
            note_refs.extend([n["note_id"] for n in found_notes])

        if not note_refs:
            result["status"] = "no_input"
            result["warnings"].append("请提供 --note 或 --keyword。")
        else:
            result["notes"] = [collect_comments(ref, args.limit, token) for ref in note_refs[: args.notes if args.keyword else None]]
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
        result["status"] = "failed"
        result["warnings"].append(str(exc))

    if args.out:
        Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] in {"ok", "missing_api_key", "no_input"} else 1


if __name__ == "__main__":
    sys.exit(main())
