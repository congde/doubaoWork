# -*- coding: utf-8 -*-
"""
书单视频生成脚本 —— 最终固化版（v27 经验沉淀）
====================================================
v1-v27 调试经验已全部沉淀，参数化版本，任何书籍都可复用。

使用方法：
    python make_video.py --book "书名" --author "作者"
    # 默认读取 templates/{书名}.json
    # 输出到 output/{书名}_{时间戳}/

核心经验（避坑指南）：
    1. ffmpeg ass filter 不接受带冒号的绝对路径（D:/... 会误解析为 WxH）
       → 用 cwd + 相对路径
    2. 全局时间戳导致分段不同步
       → 用 Whisper 对齐，每个片段生成独立 ASS（时间戳从 0）
    3. 字幕定位用 \pos() 精确控制，不用 Alignment+MarginV（Dialogue 行会覆盖样式）
    4. 多段字幕时 EN 槽强制用完整 seg["en"]，避免被 Whisper 检测的中文误填
    5. subprocess.run 在 Windows 下对 ffmpeg 返回异常 rc（4294967274）
       → 改用 Popen.communicate()
    6. print 含 Unicode 符号会触发 GBK 编码错误
       → 用 codecs.getwriter('utf-8') 重包装 stdout
"""
import asyncio, subprocess, json, time, os, random, sys, argparse, shutil
from pathlib import Path

# ===== 依赖自检（一次性） =====
def _check_deps():
    """检查关键依赖，缺失时给出安装提示"""
    missing = []
    for mod, pkg in [("whisper", "openai-whisper"), ("requests", "requests")]:
        try:
            __import__(mod)
        except ImportError:
            missing.append(pkg)
    if not shutil.which("ffmpeg"):
        missing.append("ffmpeg (系统 PATH)")
    if missing:
        skill_dir = Path(__file__).parent.parent
        print(f"缺少依赖: {', '.join(missing)}")
        print(f"运行安装脚本: python {skill_dir / 'scripts' / 'install.py'}")
        print(f"或手动: pip install {' '.join(m.replace(' (系统 PATH)', '') for m in missing)}")
        sys.exit(1)
_check_deps()

# Windows 下 stdout 编码修复
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

# ===== 默认路径（可通过 CLI 参数覆盖）=====
SKILL_DIR = Path(__file__).parent.parent.resolve()  # skill 根目录，自动计算
DEFAULT_SKILL_DIR = SKILL_DIR
DEFAULT_TEMPLATES_DIR = SKILL_DIR / "templates"
DEFAULT_OUTPUT_ROOT = Path.cwd() / "output"
DEFAULT_BGM = SKILL_DIR / "assets" / "bgm" / "bgm.mp3"
# fontconfig 配置文件路径（可选，跨平台兼容）
FONTCONFIG_PATH = SKILL_DIR / "fonts" / "fonts.conf"

W, H = 1080, 1920  # 竖屏 9:16


# ====================== 跨平台字体检测 ======================
def get_font_name():
    """返回 ASS 可用的中文字体名。优先级：系统字体 > 内置 fallback"""
    # 内置 fallback 字体（打包在 fonts/ 下）
    bundled_font = Path(__file__).parent.parent / "fonts" / "NotoSansCJKsc-Regular.ttf"
    if bundled_font.exists():
        return str(bundled_font.resolve())
    # 平台特定字体检测
    if sys.platform == 'win32':
        for name in ['Microsoft YaHei', 'SimHei', 'PingFang SC', 'Microsoft JhengHei']:
            test_font = Path(os.environ.get('WINDIR', 'C:\\Windows')) / 'Fonts' / f'{name}.ttf'
            if not test_font.exists():
                test_font = Path(os.environ.get('WINDIR', 'C:\\Windows')) / 'Fonts' / f'{name}.ttc'
            if test_font.exists():
                return name
    elif sys.platform == 'darwin':
        for name in ['PingFang SC', 'Heiti SC', 'STHeiti']:
            test_font = Path('/System/Library/Fonts') / f'{name}.ttc'
            if not test_font.exists():
                test_font = Path('/Library/Fonts') / f'{name}.ttf'
            if test_font.exists():
                return name
    else:  # Linux
        for name in ['Noto Sans CJK SC', 'WenQuanYi Micro Hei', 'Noto Sans SC']:
            # 用 fc-list 检测
            try:
                r = subprocess.run(['fc-list', '-q', name], capture_output=True, timeout=3)
                if r.returncode == 0:
                    return name
            except Exception:
                pass
        # 常见路径
        for path in ['/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
                     '/usr/share/fonts/noto-cjk/NotoSansCJK-Regular.ttc']:
            if Path(path).exists():
                return 'Noto Sans CJK SC'
    # 终极 fallback：返回 Arial（不会渲染中文但对 ASS 不报错）
    return 'Arial'


FONT_NAME = get_font_name()


# ====================== 工具函数 ======================
def escape_ass(t):
    """ASS 字符串转义"""
    return t.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")


def run_popen(cmd, cwd=None):
    """用 Popen 执行命令，避免 Windows 下 subprocess.run 的异常 rc"""
    r = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=cwd)
    out, _ = r.communicate()
    return r.returncode


# ===== MiniMax T2A 语音合成配置 =====
VOICE_CONFIG = {
    "model": "speech-2.8-hd",          # 语音模型
    "voice_id": "male-qn-qingse",       # 默认音色：青涩青年（书单男声）
    "speed": 1.0,                        # 语速 0.5-2.0
    "vol": 1.0,                          # 音量 0.1-2.0
    "pitch": 0,                          # 音调 -12 ~ 12
    "api_url": "https://api.minimaxi.com/v1/t2a_v2",
    "sample_rate": 32000,
    "bitrate": 128000,
    "format": "mp3",
    "channel": 1
}


def gen_voice_minimax(text, voice_file, api_key=None):
    """MiniMax T2A HTTP API 同步语音合成 — 返回 (ok, duration_seconds)"""
    import requests
    api_key = api_key or os.environ.get("MINIMAX_API_KEY", "")
    if not api_key:
        print(f"  [WARN] 无 MINIMAX_API_KEY")
        return False, 0
    try:
        payload = {
            "model": VOICE_CONFIG["model"],
            "text": text,
            "stream": False,
            "voice_setting": {
                "voice_id": VOICE_CONFIG["voice_id"],
                "speed": VOICE_CONFIG["speed"],
                "vol": VOICE_CONFIG["vol"],
                "pitch": VOICE_CONFIG["pitch"]
            },
            "audio_setting": {
                "sample_rate": VOICE_CONFIG["sample_rate"],
                "bitrate": VOICE_CONFIG["bitrate"],
                "format": VOICE_CONFIG["format"],
                "channel": VOICE_CONFIG["channel"]
            }
        }
        resp = requests.post(
            VOICE_CONFIG["api_url"],
            json=payload,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            timeout=30
        )
        data = resp.json()
        base = data.get("base_resp", {})
        if base.get("status_code") != 0:
            print(f"  [WARN] T2A error: {base.get('status_msg', 'unknown')}")
            return False, 0
        hex_audio = data["data"]["audio"]
        if not hex_audio:
            return False, 0
        import binascii
        audio_bytes = binascii.unhexlify(hex_audio)
        voice_file = Path(voice_file)
        voice_file.parent.mkdir(parents=True, exist_ok=True)
        with open(voice_file, "wb") as f:
            f.write(audio_bytes)
        duration = data.get("extra_info", {}).get("audio_length", 0) / 1000  # ms -> s
        return True, duration
    except Exception as e:
        print(f"  [WARN] MiniMax T2A 异常: {e}")
        return False, 0


def gen_silent_mp3(duration, voice_file):
    """生成静音 mp3 作为兜底"""
    run_popen(["ffmpeg", "-y", "-f", "lavfi", "-i",
               f"anullsrc=r=24000:cl=mono:d={duration}",
               "-acodec", "libmp3lame", "-q:a", "5", str(voice_file)],
              cwd=str(Path(voice_file).parent))


async def gen_voice_safe(text, voice_file, max_retry=2):
    """MiniMax T2A 语音合成，含重试 + 静音兜底。返回 (ok, duration)"""
    voice_file = Path(voice_file)
    for attempt in range(max_retry):
        ok, dur = gen_voice_minimax(text, str(voice_file))
        if ok and voice_file.exists() and voice_file.stat().st_size > 500:
            return True, dur
        if attempt < max_retry - 1:
            time.sleep(1.5 * (attempt + 1))
    print(f"  [WARN] T2A 全部失败，用静音兜底")
    gen_silent_mp3(3, str(voice_file))
    return False, 3.0


def get_duration(vf):
    """获取音频/视频时长"""
    r = subprocess.Popen(["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", str(vf)],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out, _ = r.communicate()
    try:
        return float(json.loads(out)["format"]["duration"])
    except:
        return 3.0


def fmt_time(t):
    """秒数 -> ASS 时间戳格式 (H:MM:SS.cc)"""
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    cs = int((t % 1) * 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


# ====================== ASS 构建（v27 最终布局）======================
def build_seg_ass(seg, ts_info, out_path):
    """
    字幕布局最终规格（v27）：
      - 书名：y=720 (屏幕 38%)
      - 作者：y=830 (屏幕 43%)
      - 中文：y=1340 (70%)
      - 英文：y=1390 (72.6%) — 紧贴中文下方 12px
    """
    duration = ts_info["duration"]
    segments_ts = ts_info["segments"]
    fade = min(0.3, duration * 0.2)
    book = escape_ass(seg.get("book", ""))
    author = escape_ass(seg.get("author", ""))
    cn = escape_ass(seg["cn"])
    en = escape_ass(seg.get("en", ""))

    lines = [
        "[Script Info]",
        "Title: 书单视频片段",
        "ScriptType: v4.00+",
        "WrapStyle: 0",
        f"PlayResX: {W}",
        f"PlayResY: {H}",
        "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        f"Style: Title,{FONT_NAME},100,&H00CEEB87,&H00FFFFFF,&H00000000,&H80000000,1,0,0,0,100,100,0,0,1,5,4,5,0,0,0,134",
        f"Style: Author,{FONT_NAME},48,&H0000A5FF,&H00FFFFFF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,4,3,5,0,0,0,134",
        f"Style: CN,{FONT_NAME},64,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,5,4,5,0,0,0,134",
        f"Style: EN,{FONT_NAME},40,&H00CCCCCC,&H00FFFFFF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,4,3,5,0,0,0,134",
        "",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]

    lines.append(f"Dialogue: 2,0:00:00.00,{fmt_time(duration)},Title,,0,0,0,,{{\\pos(540,720)}}{book}")
    if author:
        lines.append(f"Dialogue: 1,0:00:00.00,{fmt_time(duration)},Author,,0,0,0,,{{\\pos(540,830)}}作者：{author}")

    CN_Y = 1340
    EN_Y = 1390

    if len(segments_ts) == 1:
        lines.append(f"Dialogue: 0,0:00:00.00,{fmt_time(duration)},CN,,0,0,0,,{{\\pos(540,{CN_Y})\\fad({fade*1000:.0f},200)}}{cn}")
    else:
        for i, ts in enumerate(segments_ts):
            text = escape_ass(ts['text'])
            if i + 1 < len(segments_ts):
                end_ts = segments_ts[i + 1]['start'] + 0.2
            else:
                end_ts = duration
            lines.append(f"Dialogue: 0,{fmt_time(ts['start'])},{fmt_time(end_ts)},CN,,0,0,0,,{{\\pos(540,{CN_Y})\\fad({fade*1000:.0f},200)}}{text}")

    if en.strip():
        lines.append(f"Dialogue: 0,0:00:00.00,{fmt_time(duration)},EN,,0,0,0,,{{\\pos(540,{EN_Y})\\fad({fade*1000:.0f},200)}}{en}")

    with open(out_path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines))


# ====================== MiniMax 图片生成 ======================
def generate_image_minimax(prompt, save_path, api_key=None):
    """用 MiniMax image-01 生成单张图片"""
    import requests
    api_key = api_key or os.environ.get("MINIMAX_API_KEY", "")
    if not api_key:
        print(f"  [WARN] 无 MINIMAX_API_KEY，跳过图片生成")
        return False

    try:
        resp = requests.post(
            "https://api.minimax.chat/v1/image_generation",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={"model": "image-01", "prompt": prompt, "aspect_ratio": "9:16", "n": 1},
            timeout=60
        )
        data = resp.json()
        # MiniMax image-01 响应格式：data.image_urls: [url1, url2, ...]
        if "data" in data and "image_urls" in data["data"] and len(data["data"]["image_urls"]) > 0:
            url = data["data"]["image_urls"][0]
            if url:
                img_resp = requests.get(url, timeout=60)
                with open(save_path, "wb") as f:
                    f.write(img_resp.content)
                return True
        print(f"  [WARN] 图片生成失败: {resp.text[:200]}")
        return False
    except Exception as e:
        print(f"  [WARN] 图片生成异常: {e}")
        return False


# ====================== 主流程 ======================
async def run(book, author, template_path, work_dir, bgm_path):
    """主流程：图片 → 语音 → Whisper对齐 → ASS → 视频片段 → 合并 → BGM"""
    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print(f"《{book}》书单视频生成 (v27 最终版)")
    print(f"作者：{author}")
    print(f"工作目录：{work_dir}")
    print("=" * 60)

    os.chdir(work_dir)

    with open(template_path, "r", encoding="utf-8") as f:
        segments = json.load(f)
    for seg in segments:
        seg["book"] = f"《{book}》"
        seg["author"] = author

    voices_dir = work_dir / "voices"
    voices_dir.mkdir(exist_ok=True)
    ass_dir = work_dir / "ass"
    ass_dir.mkdir(exist_ok=True)

    print(f"\n[1/6] 图片生成 ({len(segments)} 张)...")
    bg_files = []
    for i, seg in enumerate(segments):
        bg_file = f"bg_{i:02d}.jpg"
        bg_abs = work_dir / bg_file
        bg_files.append(bg_file)
        if bg_abs.exists() and bg_abs.stat().st_size > 5000:
            print(f"  [{i+1}/{len(segments)}] 已有: {bg_file}")
            continue
        prompt = seg.get("prompt") or seg.get("cn", "")
        print(f"  [{i+1}/{len(segments)}] 生成: {prompt[:40]}...")
        ok = generate_image_minimax(prompt, str(bg_abs))
        if not ok:
            generate_image_minimax(seg["cn"], str(bg_abs))
        if (i + 1) % 5 == 0:
            time.sleep(2)

    print(f"\n[2/6] 语音生成...")
    timestamps, cur = [], 0.0
    voice_files = []
    for i, seg in enumerate(segments):
        vf = work_dir / f"seg_{i:02d}.mp3"
        voice_files.append(vf)
        if vf.exists() and vf.stat().st_size > 5000:
            dur = get_duration(vf)
            print(f"  [{i+1}/{len(segments)}] 已有({dur:.2f}s)")
        else:
            print(f"  [{i+1}/{len(segments)}] {seg['cn'][:20]}...", end=" ", flush=True)
            ok, api_dur = await gen_voice_safe(seg["cn"], str(vf))
            dur = api_dur if api_dur > 0 else get_duration(vf)
            print(f"[{'OK' if ok else '静音'}] {dur:.2f}s")
            if (i + 1) % 5 == 0 and i < len(segments) - 1:
                time.sleep(1.5)
        timestamps.append({"start": cur, "end": cur + dur, "duration": dur, "text": seg["cn"], "index": i})
        cur += dur

    total = timestamps[-1]["end"]
    print(f"  总时长: {total:.2f}s ({total/60:.1f}分钟)")

    print(f"\n[3/6] Whisper 时间戳对齐...")
    import whisper
    print("  加载 whisper tiny 模型...")
    model = whisper.load_model("tiny")

    seg_timestamps = []
    for i, seg in enumerate(segments):
        vf = voice_files[i]
        text = seg["cn"]
        print(f"  [{i+1}/{len(segments)}] {text[:25]}...", end=" ", flush=True)
        try:
            result = model.transcribe(str(vf), language="zh")
            word_segs = [{"start": s["start"], "end": s["end"], "text": s["text"].strip()}
                         for s in result["segments"]]
            print(f"-> {len(word_segs)}段")
        except Exception as e:
            print(f"FAIL: {e}")
            word_segs = [{"start": 0, "end": timestamps[i]["duration"], "text": text}]
        seg_timestamps.append({"duration": timestamps[i]["duration"], "segments": word_segs})

    print(f"\n[4/6] 生成 ASS 字幕...")
    for i, seg in enumerate(segments):
        build_seg_ass(seg, seg_timestamps[i], str(ass_dir / f"seg_{i}.ass"))
    print(f"  已生成 {len(segments)} 个 ASS 文件")

    print(f"\n[5/6] 生成视频片段...")
    random.seed(42)
    directions = [random.randint(0, 3)]
    for _ in range(1, len(segments)):
        d = random.randint(0, 3)
        while d == directions[-1]:
            d = random.randint(0, 3)
        directions.append(d)

    success_idx = []
    for i, seg in enumerate(segments):
        duration = timestamps[i]["duration"]
        out_rel = f"seg_{i}.mp4"
        bg_rel = bg_files[i]
        ass_rel = f"ass/seg_{i}.ass"

        d = directions[i]
        if d == 0:
            crop = "scale=1188:2112,crop=1080:1920:t*60:100"
        elif d == 1:
            crop = "scale=1188:2112,crop=1080:1920:108-t*60:100"
        elif d == 2:
            crop = "scale=1188:2112,crop=1080:1920:50:t*60"
        else:
            crop = "scale=1188:2112,crop=1080:1920:50:192-t*60"

        vf = f"{crop},ass={ass_rel}"
        run_popen([
            "ffmpeg", "-y", "-loop", "1", "-i", bg_rel, "-t", str(duration),
            "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-r", "30", "-preset", "fast",
            out_rel
        ], cwd=str(work_dir))

        out_abs = work_dir / out_rel
        if out_abs.exists() and out_abs.stat().st_size > 20000:
            success_idx.append(i)
        if (i + 1) % 7 == 0 or i == len(segments) - 1:
            print(f"  {i+1}/{len(segments)} ({len(success_idx)} 成功)")

    if not success_idx:
        print("[ERROR] 无可用片段")
        return None

    print(f"\n  合并 {len(success_idx)} 个片段...")
    with open(work_dir / "concat_videos.txt", "w", encoding="utf-8") as f:
        for i in success_idx:
            f.write(f"file 'seg_{i}.mp4'\n")
    run_popen(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", "concat_videos.txt",
               "-c", "copy", "merged.mp4"], cwd=str(work_dir))

    print(f"\n[6/6] 混合背景音乐...")
    with open(work_dir / "concat_voices.txt", "w", encoding="utf-8") as f:
        for i in success_idx:
            vf = voice_files[i]
            if vf.exists():
                f.write(f"file '{str(vf).replace(chr(92), '/')}'\n")
    run_popen(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", "concat_voices.txt",
               "-c", "copy", "voice_merged.mp3"], cwd=str(work_dir))

    run_popen(["ffmpeg", "-y", "-i", "merged.mp4", "-i", "voice_merged.mp3",
               "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "with_voice.mp4"],
              cwd=str(work_dir))

    final = work_dir / "final.mp4"
    bgm_path = Path(bgm_path)
    if not bgm_path.exists():
        # 尝试 skill 内置 BGM
        builtin_bgm = SKILL_DIR / "assets" / "bgm" / "bgm.mp3"
        if builtin_bgm.exists():
            bgm_path = builtin_bgm
            print(f"  使用内置 BGM: {bgm_path}")
    if bgm_path.exists():
        run_popen([
            "ffmpeg", "-y",
            "-i", "with_voice.mp4",
            "-i", str(bgm_path),
            "-filter_complex",
            "[1:a]volume=-20dB,aloop=loop=-1:size=2e+09[bgm];[0:a][bgm]amix=inputs=2:duration=first:dropout_transition=3[aout]",
            "-map", "0:v", "-map", "[aout]",
            "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
            str(final)
        ], cwd=str(work_dir))
    else:
        print("  [WARN] BGM 不存在，跳过 BGM 混合")
        shutil.copy("with_voice.mp4", str(final))

    if final.exists():
        size = final.stat().st_size / 1024 / 1024
        print(f"\n{'='*60}")
        print(f"OK 视频生成完成!")
        print(f"  书名:《{book}》")
        print(f"  作者:{author}")
        print(f"  时长:{total:.0f}秒 ({total/60:.1f}分钟)")
        print(f"  大小:{size:.1f}MB")
        print(f"  路径:{final}")
        print(f"{'='*60}")
        return str(final)
    else:
        print("\nFAILED")
        return None


def main():
    parser = argparse.ArgumentParser(description="书单视频生成（v27 最终版）")
    parser.add_argument("--book", required=True, help="书名")
    parser.add_argument("--author", required=True, help="作者")
    parser.add_argument("--template", help="模板 JSON 路径（默认 templates/{book}.json）")
    parser.add_argument("--workdir", help="工作目录（默认 output/{book}_{时间戳}）")
    parser.add_argument("--bgm", help="背景音乐路径")
    args = parser.parse_args()

    skill_dir = SKILL_DIR
    template = args.template or str(DEFAULT_TEMPLATES_DIR / f"{args.book}.json")
    if not Path(template).exists():
        print(f"[ERROR] 模板不存在: {template}")
        print(f"请先创建 {args.book}.json，格式参考 templates/human_weakness.json")
        sys.exit(1)

    if args.workdir:
        workdir = args.workdir
    else:
        ts = time.strftime("%Y%m%d_%H%M%S")
        workdir = str(DEFAULT_OUTPUT_ROOT / f"{args.book}_{ts}")

    bgm = args.bgm or str(DEFAULT_BGM)

    asyncio.run(run(args.book, args.author, template, workdir, bgm))


if __name__ == "__main__":
    main()