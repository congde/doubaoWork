# -*- coding: utf-8 -*-
"""书单号视频 · 一键安装脚本
拖入 QClaw 自动执行，或手动运行：python install.py"""
import subprocess, sys, os
from pathlib import Path

REQUIREMENTS = Path(__file__).parent / "requirements.txt"

def main():
    print("书单号视频 skill · 依赖安装")
    print("=" * 50)
    # 检查 pip
    try:
        subprocess.run([sys.executable, "-m", "pip", "--version"],
                       capture_output=True, check=True)
    except Exception:
        print("[ERROR] pip 不可用，请先安装 Python 3.8+")
        sys.exit(1)
    # 安装
    print(f"正在安装依赖（首次约需 2-5 分钟，torch ~500MB）...\n")
    cmd = [sys.executable, "-m", "pip", "install", "-r", str(REQUIREMENTS)]
    if os.environ.get("PIP_INDEX_URL") is None:
        # 国内用户加速
        cmd += ["-i", "https://pypi.tuna.tsinghua.edu.cn/simple"]
    r = subprocess.run(cmd)
    if r.returncode == 0:
        print("\n安装完成！试试：python make_video.py --book '人性的弱点' --author '戴尔·卡耐基'")
    else:
        print(f"\n安装失败 (exit {r.returncode})，请手动执行：")
        print(f"  pip install -r {REQUIREMENTS}")
        sys.exit(r.returncode)

if __name__ == "__main__":
    main()
