---
name: book-video-maker
description: |
  输入书名+作者，自动生成 1080P 竖屏书单短视频。
  AI 配图 + AI 配音 + 中英双语字幕 + Ken Burns 运镜。
  内置 4 本畅销书模板：《人性的弱点》《穷爸爸富爸爸》《谁动了我的奶酪》《自控力》。
  触发词：做书单视频 / 书单号 / 金句视频 / 读书视频 / 书名是XXX
---

# 书单号视频生成 skill

## 能力概述

输入书名+作者（或模板JSON），自动生成竖屏（1080×1920）书单视频，包含：
- 28 张 AI 生成背景图（MiniMax image-01）
- 28 句中文配音（edge-tts）
- 28 句中英对照字幕（Whisper 时间戳对齐）
- 背景音乐混合（BGM）
- Ken Burns 推拉运镜
- 视频自动合并输出

最终效果参考：`人性的弱点_20260722_*.mp4`（10MB左右，100-110秒）

## 使用方法

### 方式1：标准流程（推荐）

```bash
# 1. 创建模板 JSON（参考 templates/human_weakness.json）
# 模板格式：28 条金句 + 英文翻译 + 图片prompt
# 保存到：C:\Users\jianz\.qclaw\skills\书单号视频book-video-maker-skill-fixed\templates\XXX.json

# 2. 运行生成脚本
python make_video.py --book "XXX" --author "YYY"

# 可选参数：
#   --template  模板路径（默认 templates/{book}.json）
#   --workdir   输出目录（默认 output/{book}_{时间戳}）
#   --bgm       BGM 路径（默认 workspace-39c0dfe5 的朗读.MP3）
```

### 方式2：自定义模板路径

```bash
python make_video.py --book "原子习惯" --author "詹姆斯·克利尔" \
    --template "C:/mybooks/atomic_habits.json"
```

## 模板 JSON 格式

```json
[
  {
    "cn": "今天分享的是：《原子习惯》。",
    "en": "Today: Atomic Habits",
    "prompt": "A minimalist book cover with the title Atomic Habits on a wooden desk, soft natural light"
  },
  ...（共28条，前几行可加开场说明）...
]
```

**字段说明**：
- `cn`: 中文配音文案（必填，必用《》包裹书名）
- `en`: 英文翻译（必填，用于双语字幕）
- `prompt`: 图片生成 prompt（可选，默认用 cn 作为 prompt）

## 技术规范（v27 最终版）

| 参数 | 值 | 说明 |
|------|-----|------|
| 分辨率 | 1080×1920 | 竖屏 9:16 |
| 编码 | H.264 yuv420p | 兼容性最佳 |
| 帧率 | 30 fps | 流畅度 |
| 比特率 | - | preset=fast |
| 视频时长 | 100-110 秒 | 28 句金句 |
| 文件大小 | ~10MB | 默认参数 |

## 字幕布局规范（v27 经验沉淀）

**最终坐标**（1920 高度基准）：

| 元素 | y 坐标 | 字号 | 颜色 | 屏幕占比 |
|------|--------|------|------|---------|
| 书名《XXX》 | 720 | 100pt | 青色 &H00CEEB87 | 38% |
| 作者：XXX | 830 | 48pt | 橙色 &H0000A5FF | 43% |
| 中文字幕 | 1340 | 64pt | 白色 | 70% |
| 英文字幕 | 1390 | 40pt | 浅灰 &H00CCCCCC | 72.6% |

**字幕间距规则**：中英文字幕间距 12px（一点点空但不重叠），用户已确认此布局为最终版本。

## 核心经验（避坑指南 v1-v27）

### 🚨 6 大致命坑

1. **ffmpeg ass filter 不接受 `D:` 盘符冒号路径**
   - 现象：`Unable to parse option value as image size`，rc=4294967274
   - 解决：所有 ffmpeg 调用用 `cwd + 相对路径`（如 `ass=ass/seg_1.ass`）

2. **全局时间戳导致分段不同步**
   - 现象：第5秒还在显示第1句字幕
   - 解决：用 Whisper 对齐，每个片段生成独立 ASS（时间戳从 0 开始）

3. **subprocess.run 在 Windows 下 ffmpeg 返回异常 rc**
   - 现象：rc=4294967274（-22），文件实际成功
   - 解决：改用 `subprocess.Popen.communicate()`

4. **多段字幕时 EN 槽被中文误填**
   - 现象：英文字幕位置显示中文
   - 解决：多段时强制使用完整 `seg["en"]`，不切分到多段

5. **print 含 Unicode 触发 GBK 编码错误**
   - 现象：`UnicodeEncodeError: 'gbk' codec`
   - 解决：`codecs.getwriter('utf-8')` 重包装 stdout

6. **drawtext 中文显示方框**
   - 现象：所有中文字幕渲染成方框
   - 解决：放弃 drawtext，改用 ASS 方案（通过 `\pos()` 精确定位）

### ⚠️ 中等坑

- edge-tts 限速：分批生成 + 重试 + 静音备选
- 多段字幕时长偏短：用下一段开始+0.2s 作为当前段 END
- whisper 检测 end 时间偏短：单段时用 duration 而非 end

## 依赖清单

| 依赖 | 用途 | 安装 |
|------|------|------|
| Python 3.11+ | 运行环境 | 已预装 |
| edge-tts | 语音合成 | pip install edge-tts |
| openai-whisper | 时间戳对齐 | pip install openai-whisper |
| requests | HTTP 调用 | 已预装 |
| ffmpeg | 视频处理 | 系统 PATH |
| MiniMax API | 图片生成 | 环境变量 MINIMAX_API_KEY |
| 微软雅黑字体 | 中文字幕 | C:\Windows\Fonts\msyh.ttc |
| fontconfig | ffmpeg 字体加载 | C:\Windows\System32\fontconfig\fonts.conf |

## 输出路径规范

**默认输出目录**：
```
D:\qclaw\workspace-agent-7a378225\output\{book}_{YYYYMMDD_HHMMSS}\
├── bg_00.jpg ~ bg_27.jpg     # 28 张背景图
├── voices/seg_00.mp3 ~ seg_27.mp3   # 28 段语音
├── ass/seg_0.ass ~ seg_27.ass       # 28 个 ASS 字幕
├── seg_0.mp4 ~ seg_27.mp4           # 28 个视频片段
├── merged.mp4                       # 合并视频（无声）
├── with_voice.mp4                   # 加语音版
└── final.mp4                        # 最终版（含BGM）
```

**归档目录**（老赵的产品文档）：
```
D:\ObsidianVaults\龙虾一人公司\09.Agent产出\05.产品开发官\产品文档\{date}-书单视频《{book}》最终版.mp4
```

## 复用方式

老赵只需说："做书单视频，书名是XXX"，Agent 自动：
1. 提示创建/复用 `templates/{XXX}.json`
2. 运行 `python make_video.py --book "XXX" --author "YYY"`
3. 自动归档到产品文档目录

## 验证清单

每次生成后逐项检查：
- [ ] 图片全部生成（28 张）
- [ ] 语音全部生成（28 段）
- [ ] Whisper 对齐成功（无 FAIL）
- [ ] ASS 文件 28 个
- [ ] 视频片段 28/28 成功
- [ ] 中英字幕紧贴且无重叠（间距 12px）
- [ ] 中文字幕在屏幕 70% 位置
- [ ] 英文字幕在屏幕 72.6% 位置
- [ ] 最终视频无 BGM 卡顿
- [ ] 文件大小 ~10MB，时长 ~106秒

## 失败排查

| 现象 | 排查方向 |
|------|---------|
| ffmpeg rc=4294967274 | 检查路径是否含 `D:` 冒号，改用相对路径 |
| 字幕不同步 | 检查 Whisper 对齐输出，是否所有 seg 都有 start/end |
| 中文显示方框 | 检查 fontconfig 配置，确认 msyh.ttc 路径 |
| 图片生成失败 | 检查 MINIMAX_API_KEY 环境变量 |
| 视频片段生成 0 成功 | 检查 ass 文件是否存在，cwd 是否正确 |
| 输出视频无声音 | 检查 voice_merged.mp3 是否生成 |

---

_固化时间：2026-07-22 22:34_
_经验沉淀：v1-v27 共 27 次迭代_
_最终版本：v27_