# Next.js 全站 GA4 接入与生产验收

## 接入原则

- Google 提示“每个网页紧跟 `<head>` 添加一次”时，在 Next.js App Router 项目中不要把代码复制到多个 page 文件。
- 应在唯一的 `app/layout.tsx` Root Layout 接入一次，使所有路由继承，并避免重复 page_view。
- 先读取项目本地 `node_modules/next/dist/docs/` 的当前版本文档；当前版本若推荐 `@next/third-parties/google`，优先使用官方组件：

```tsx
import { GoogleAnalytics } from "@next/third-parties/google";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
      <GoogleAnalytics gaId="G-XXXXXXXXXX" />
    </html>
  );
}
```

- 如果项目已经使用 Google Tag Manager，应在 GTM 中配置 GA4，避免同时加载独立 GA4 组件。
- 不要为了“看起来贴近原始代码”忽略框架 lint 警告；手写 inline `gtag` 若被 Next.js 官方规则警告，应切换到当前版本推荐组件。

## 静态构建检查

对首页和至少两个子路由检查：

- Measurement ID 存在；
- `googletagmanager.com/gtag/js` 每页只有 1 个加载器；
- Measurement ID 通常出现 2 次属于正常：加载 URL 一次、`config` 初始化一次；
- 不存在第二套 GTM/GA 初始化；
- lint、类型检查、生产 build 全部通过。

## 生产浏览器验收

只看 HTML 不足以证明采集成功。真实浏览器中验证：

```js
({
  dataLayerReady: Array.isArray(window.dataLayer),
  dataLayerLength: window.dataLayer?.length ?? 0,
  gtagFunction: typeof window.gtag,
  gtagResources: performance.getEntriesByType("resource")
    .filter((r) => r.name.includes("googletagmanager.com/gtag/js"))
    .map((r) => r.name),
  collectRequests: performance.getEntriesByType("resource")
    .filter((r) => r.name.includes("google-analytics.com/g/collect")).length,
})
```

验收标准：

- `dataLayerReady === true`；
- `gtagFunction === "function"`；
- `gtagResources` 中只有目标 Measurement ID；
- 至少出现一次 `g/collect` 请求；
- 浏览器控制台没有相关 JS 错误；
- GA4 Realtime 可能延迟数分钟，不能因为后台暂时没显示就重复安装代码。

## 隐私与合规

若目标地区或业务需要 Cookie 同意：

- 在 consent 前设置 Google Consent Mode 默认状态；
- 根据用户选择更新 analytics storage；
- Privacy/Cookie 文案需披露分析用途；
- 不把开发、预览域名流量混入正式 GA4，必要时设置过滤器。