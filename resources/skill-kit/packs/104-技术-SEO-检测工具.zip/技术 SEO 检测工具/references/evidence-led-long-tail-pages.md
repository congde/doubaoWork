# Evidence-led long-tail SEO pages

Use this pattern when search data exposes a valuable query but the named integration, model, API, download, compliance status, or product capability is not publicly verified.

## Core rule

A query is evidence of **demand**, not evidence that the searched feature exists. Do not turn a GSC impression or trend spike into a fabricated tutorial, endpoint, download, partnership, benchmark, price, or compliance claim.

## Page-type decision

1. Verify the searched entity in first-party sources.
2. If the feature is verified, build the matching tutorial/comparison/tool page.
3. If it is not verified, build a dated **availability/status tracker** only when the query is relevant and the page can add real value.
4. If even the search intent is ambiguous, defer the page instead of producing thin content.

A good status page answers immediately:

- what is verified;
- what is not verified;
- when it was last checked;
- which first-party sources were checked;
- what evidence would change the status;
- what safe alternative the user can use now.

## Critical distinctions

- Using a provider's infrastructure does not prove that the provider publicly lists a product or endpoint under the site's marketing name.
- Generic API documentation does not prove a specific endpoint exists.
- Generic workflow nodes/loaders do not prove compatibility with an unverified model.
- A filename, screenshot, community post, or naming convention does not prove an official checkpoint or download.
- Natural-language camera direction is not a native trajectory/control API.
- Internal site Credits are not the provider's official public pricing.

## Page contract

Every indexable long-tail page should have:

- one unique intent and one H1;
- unique Title and Description;
- self-referencing canonical;
- visible short answer near the top;
- visible `Last checked` date for availability/status content;
- first-party sources and a stated update trigger;
- crawlable links to the parent conversion page and sibling resources;
- explicit independence/non-affiliation disclosure where third-party names appear;
- substantial unique content rather than a variant of the homepage;
- only schema that matches visible content (`WebPage`, `BreadcrumbList`, and `FAQPage` when FAQs are visible).

Keep the broad product/generator intent on the homepage when that experience already exists there. Do not create near-duplicate image/video landing pages merely because the navigation uses anchors.

## Claim-boundary worksheet

Before writing, record:

| Field | Required answer |
|---|---|
| Search query | Exact GSC/keyword evidence |
| Search intent | Tutorial, status, comparison, tool, or navigation |
| Verified facts | Claims backed by first-party sources or live product behavior |
| Unverified claims | Endpoint IDs, downloads, prices, parameters, partnerships, benchmarks, compliance, etc. |
| Safe alternative | Existing tool/workflow that genuinely works now |
| Update trigger | Exact first-party evidence needed to change status |

## Next.js static-export implementation note

For App Router projects using `output: "export"`, metadata routes may require an explicit static declaration. If `/sitemap.xml` fails build collection with a message that `dynamic = "force-static"` or `revalidate` is not configured, add:

```ts
export const dynamic = "force-static";
```

Then rebuild and verify the generated `out/sitemap.xml`. Follow the installed Next.js version's bundled docs first.

## Automated acceptance

Audit the generated production HTML, not only source JSX:

- Title `< 60` and Description `< 160` by project convention;
- exactly one intent-bearing H1;
- canonical equals the final trailing-slash/non-trailing-slash production URL;
- visible copy is substantial for the intent;
- project-required keyword-density guardrail passes without stuffing;
- JSON-LD parses and contains the expected types;
- FAQ schema questions equal visible FAQ questions in the same order;
- parent/sibling internal links exist in rendered HTML;
- sitemap contains every intended canonical URL;
- unsupported positive claims and guessed download/endpoint links are absent.

When writing claim-detection regexes, avoid flagging a quoted or explicitly negated sentence such as “X is available” inside an explanation of why that claim is unsupported. Prefer tests for unsafe positive constructions and actual guessed `href` values, then manually review the surrounding sentence.

## Release sequence

1. Build page matrix and claim boundaries.
2. Implement shared visual shell plus unique page bodies.
3. Add homepage and sibling internal links.
4. Add metadata, canonical, schema, sitemap.
5. Run tests, lint, production build, and generated-HTML SEO audit.
6. Push/deploy only after project confirmation rules are satisfied.
7. Re-run the audit against production HTML and verify status codes, canonical, sitemap, mobile layout, console, and links.
