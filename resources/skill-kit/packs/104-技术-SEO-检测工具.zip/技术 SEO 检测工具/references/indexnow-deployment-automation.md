# IndexNow 部署后自动通知

适用于 GitHub push 触发 Cloudflare Pages、Vercel 或类似异步生产部署的站点。目标不是“push 后立刻调用 API”，而是确认对应 commit 已在正式域名生效后再通知搜索引擎。

## 推荐架构

1. 生成 8–128 位 IndexNow Key。
2. 在站点根目录公开 `{key}.txt`，文件内容仅为 Key；上线后验证 `200 text/plain`。
3. 构建阶段生成 `deploy-meta.json`，至少包含当前生产 commit SHA。
4. GitHub Actions 在 push 后：
   - 恢复上一版生产 sitemap 基线；
   - 轮询正式域名的 `deploy-meta.json`，直到 commit 与 `${{ github.sha }}` 一致；
   - 获取新 sitemap；
   - 计算新增、更新、删除 URL；
   - POST `https://api.indexnow.org/indexnow`；
   - 成功后保存新 sitemap 作为下一次基线。
5. 快速连续 push 应取消旧 SHA 的等待任务，避免过期 workflow 阻塞最新部署。

## IndexNow 请求

```json
{
  "host": "example.com",
  "key": "[INDEXNOW_KEY]",
  "keyLocation": "https://example.com/[INDEXNOW_KEY].txt",
  "urlList": [
    "https://example.com/new-page/",
    "https://example.com/updated-page/",
    "https://example.com/deleted-page/"
  ]
}
```

- 单批最多 10,000 URL。
- 只提交正式 canonical host；禁止提交 Pages/Vercel 预览域名、API、后台、参数化重复页和 `noindex` 页面。
- 删除 URL 也要提交，同时应从 sitemap 移除并在生产返回 `404` 或 `410`。
- `200` 表示收到；首次 Key 验证可能返回 `202 Accepted`，也可视为已接受，但必须记录状态。
- 对网络错误、`429`、`500/502/503/504` 做有限指数退避；`429` 优先遵循 `Retry-After`。`400/403/422` 等确定性错误立即失败。

## sitemap 更新判定陷阱

不要默认 sitemap 的 `lastmod` 可靠。

- 若 `lastmod` 来自真实内容更新时间，可用 `URL + lastmod` 判断更新。
- 若 `lastmod` 被硬编码、每次构建统一写当前时间，或页面变化时不会同步更新，就会静默漏报或全站误报。
- 小型站（少量 canonical 页面）最稳妥的策略是：每次生产部署提交全部当前 URL，并额外提交从基线中发现的删除 URL。
- 大型站应使用可靠 `lastmod`、内容 hash、CMS `updated_at` 或 Git route mapping；不要无脑全量提交。
- Sitemap 为空时必须拒绝提交和拒绝覆盖基线，避免一次构建故障丢失历史快照。

## GitHub Actions 基线策略

可使用 `actions/cache`：

- cache key：当前 commit SHA；
- restore prefix：恢复最近一份 sitemap；
- 首次无基线：提交当前 sitemap 全量；
- IndexNow 成功后才保存新基线；
- IndexNow 失败时不要推进基线，使下一次部署仍能补交变化。

## 验收证据

上线后必须真实验证：

- `{key}.txt` → `200 text/plain`；
- `deploy-meta.json` → `200 application/json`，commit 等于生产提交；
- `sitemap.xml` → `200` 且非空；
- GitHub Action 已等待正确 commit；
- 日志显示提交 URL 数量、状态码和是否建立基线；
- Bing Webmaster Tools 后续可见 IndexNow URL，但不能把 API `200/202` 表述为“已收录”。

## 与 Cloudflare Crawler Hints 的关系

Crawler Hints 可作为低维护方案；精确 sitemap diff + IndexNow 更适合流水线审计。两者同时开启可能重复通知，通常择一即可。