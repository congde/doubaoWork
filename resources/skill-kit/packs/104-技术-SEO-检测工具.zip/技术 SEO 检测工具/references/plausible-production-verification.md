# Plausible 生产接入与验收

适用于 Next.js App Router、静态导出和自托管/代理域名的 Plausible Analytics。

## 接入原则

1. 只在唯一 Root Layout 接入一次，避免每页复制和客户端路由切换重复加载。
2. 当前 Next.js 版本优先遵循项目内 `node_modules/next/dist/docs`；常规做法是 `next/script`。
3. 外部脚本与初始化脚本都使用 `afterInteractive`（默认策略也可），初始化代码保留 Plausible 提供方原文语义。
4. 不根据脚本文件名猜测站点 ID、事件端点或代理规则；使用用户/后台提供的完整脚本 URL。

示例形态：

```tsx
import Script from "next/script";

<Script async src="https://analytics.example.com/js/site-script.js" strategy="afterInteractive" />
<Script id="plausible-init" strategy="afterInteractive">
  {`window.plausible=window.plausible||function(){(plausible.q=plausible.q||[]).push(arguments)};plausible.init=plausible.init||function(i){plausible.o=i||{}};plausible.init()`}
</Script>
```

## 验收顺序

1. **构建**：测试和 production build 必须通过。
2. **静态产物**：确认脚本 URL 与初始化标识进入产物，但不要以字符串计数判断实际 DOM 数量。Next.js RSC/Flight 数据可能重复序列化字符串；`afterInteractive` 脚本在原始 HTML 中也可能没有普通 `<script src>` 标签。
3. **真实生产域名**：带 cache-buster 打开正式域名，不只检查 Pages/Vercel 预览域名。
4. **DOM**：确认目标外部脚本在 hydration 后恰好一个。
5. **运行态**：确认 `typeof window.plausible === "function"`，初始化方法存在。
6. **网络**：在 Resource Timing 或 DevTools Network 中确认：
   - 脚本资源被请求；
   - 页面访问事件请求被发送；
   - 事件端点返回 2xx（Plausible 常见为 `202 Accepted`）。
7. **控制台**：没有与 Plausible 脚本、CSP、CORS 或事件上报有关的错误。与未登录 API 401、浏览器扩展等无关错误要分开报告。

## 推荐浏览器断言

```js
({
  scripts: [...document.querySelectorAll('script[src*="plausible"]')].map(s => s.src),
  plausibleType: typeof window.plausible,
  initType: typeof window.plausible?.init,
  resources: performance.getEntriesByType('resource')
    .filter(r => r.name.includes('plausible'))
    .map(r => ({ name: r.name, responseStatus: r.responseStatus || null }))
})
```

## 常见误判

- **只看源代码有脚本字符串**：不能证明浏览器执行或事件上报成功。
- **静态 HTML 中没有普通脚本标签就判失败**：`next/script` 的客户端注入需要以 hydration 后 DOM 为准。
- **把 RSC 字符串重复当成重复埋点**：以运行时 DOM 和网络请求次数为准。
- **只验证部署预览地址**：自定义域名可能有缓存、路由或安全规则差异，必须复验正式域名。
