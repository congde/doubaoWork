# Keyword-density and favicon verification

Use this reference when an SEO audit depends on a third-party density tool or when a deployed favicon appears unchanged.

## 1. Align keyword-density tokenization before editing copy

Different analyzers normalize punctuation and numbers differently. For example, a styled brand such as `WORD/3 RUN` may be counted as the two-token phrase `word3 run`, while a custom regex may separately report the exact text `WORD 3`. These are different metrics.

Workflow:

1. Record the analyzer's selected n-gram length, normalized keyword, count, total and density from its UI.
2. Reproduce the analyzer approximately against the rendered `<body>` text—not metadata, scripts or JSON-LD.
3. Normalize punctuation the same way the analyzer appears to do. Check numeric tokens and slash-joined brands explicitly.
4. Track separately:
   - target exact phrase density;
   - analyzer-normalized brand n-gram density;
   - core single-word count, density and rank among meaningful non-stopwords.
5. Change headings and body copy only in semantically useful places. Re-run the third-party tool after deployment; do not claim its result from a different in-house formula.

Recommended guardrails for this user's SEO work:

- target two-word main phrase: at least 1%, generally no more than 2%;
- domain/brand phrase is **not automatically a secondary keyword**: if the user explicitly excludes it, suppress the analyzer-normalized phrase to zero or the minimum required for truthful identity, and ensure it does not rank among primary/secondary n-grams;
- core single word: aim for the first meaningful-word frequency tier;
- never hit density by repetitive filler; distribute terms across title/H1/H2, explanatory copy, use cases and FAQ;
- if the selected analyzer filters standalone numbers, an exact phrase such as `WORD 3` may never appear in its “2 words” table even when the rendered body contains it correctly. Do not mutate the phrase to `WORD3`, `WORD/3`, or a spelled-out number just to satisfy that UI; verify the literal rendered phrase, Google-facing metadata, and analyzer limitation separately.

## 2. Keep semantic spacing and visual spacing aligned

When an exact target phrase is split across styled elements, `<span>WORD</span><b>3</b>` can remain semantically readable as `WORD 3` while negative letter-spacing or a tiny flex gap makes the logo look like `WORD3`. Verify both layers:

1. Inspect the rendered accessibility text and production HTML for the exact phrase.
2. Inspect the logo visually in a real browser at desktop and mobile sizes.
3. Use an explicit relative flex gap (for example, an `em` value) rather than relying on source whitespace between inline elements.
4. Re-run density checks after the CSS-only fix to prove the copy signal did not change.

## 3. Favicon verification must be visual at 16×16

A correct source hash does not prove the browser tab looks correct. Tiny marks, play triangles and high-contrast center shapes can dominate after downscaling.

Workflow:

1. Inspect all favicon sources and metadata conventions. In Next.js App Router, `src/app/favicon.ico` can emit an automatic first-priority icon and override a `public/favicon.ico` expectation.
2. Inspect generated HTML icon tags and their order.
3. If cache or convention precedence is uncertain, remove the automatic source and publish a unique versioned PNG path via metadata (`rel=icon` and `rel=shortcut icon`).
4. Generate real 16×16 and 32×32 images, then enlarge them with nearest-neighbor solely for visual inspection.
5. Confirm the intended letters/mark remain recognizable. If a bright overlay overwhelms the mark, make a favicon-specific simplification while preserving brand identity.
6. Build, deploy, fetch the effective icon URL, compare source/online checksum and verify HTTP 200 + correct content type.
7. Re-read live HTML and ensure old automatic/cache-prone icon URLs are absent.

## 4. New GSC property handling

- Domain-property verification through a DNS provider can be completed using the provider's one-time authorization flow.
- After verification, submit the sitemap and inspect the homepage with URL Inspection.
- A newly created property can briefly show `Couldn't fetch` even when the sitemap returns 200 and parses correctly. Verify default UA and Googlebot UA, robots declaration, XML parsing and live URL test before changing production.
- If the live URL test succeeds, request indexing once. Repeated requests do not improve queue priority.
- Schedule a later read-only recheck rather than repeatedly resubmitting.