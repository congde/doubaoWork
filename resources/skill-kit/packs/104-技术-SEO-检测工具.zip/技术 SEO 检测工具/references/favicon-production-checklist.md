# Favicon production verification

Use this checklist when a deployed site keeps showing an old/default tab icon after a favicon change.

## 1. Identify the effective source, not just `public/favicon.ico`

- Inspect generated HTML and list every `<link rel="icon">`, `<link rel="shortcut icon">`, and `<link rel="apple-touch-icon">`.
- In Next.js App Router, file conventions such as `src/app/favicon.ico`, `src/app/icon.*`, or `src/app/apple-icon.*` can be emitted ahead of metadata configured in `layout.tsx` and override assets under `public/`.
- Search the project for every icon-like file before editing. Do not assume the file under `public/` is authoritative.

## 2. Verify visual identity at real favicon sizes

A 512px preview is insufficient. Always render the candidate at 16×16 and 32×32, then enlarge those exact rasterized results with nearest-neighbor for inspection.

Watch for:

- bright central details dominating after downsampling;
- letters or brand marks disappearing;
- a video/play overlay embedded in a thumbnail being mistaken for part of the desired logo;
- low-resolution chat thumbnails being used instead of the original asset.

If needed, make a favicon-specific derivative that preserves the brand mark while simplifying tiny details. Show the derivative to the user when the source identity is ambiguous.

## 3. Force a genuinely new URL when cache is sticky

Replacing bytes at `/favicon.ico` may not refresh Chrome's origin-level favicon cache. Prefer a new semantic/versioned path, for example:

```html
<link rel="shortcut icon" href="/brand-favicon-v3.png" type="image/png">
<link rel="icon" href="/brand-favicon-v3.png" type="image/png" sizes="512x512">
```

For Next.js, remove an unwanted `src/app/favicon.ico` convention file if it keeps emitting the old `/favicon.ico?...` link. Confirm the generated HTML no longer contains that route.

## 4. Build and deployment verification

After changing the favicon:

1. Run lint and production build.
2. Inspect the built HTML icon tags.
3. Assert the old icon path is absent and the new unique path is present.
4. Verify the new asset exists in the output directory.
5. Deploy.
6. Fetch the live HTML with a cache-busting query.
7. Fetch the effective icon URL and check status and `Content-Type`.
8. Compare local and live SHA256 values.
9. Open the live icon URL directly and visually confirm the expected brand mark.

Do not tell the user it is merely browser cache until the effective HTML source, live asset bytes, and 16×16 visual result have all been checked.
