# 首页 SEO-Copy 验收口径

用于英文营销首页、品牌词首页和单页 MVP 的可复用检查。数值是护栏，不是机械排名公式。

## 1. 元数据

- Title：默认 `< 60` 字符；主词靠前，页面类型/核心价值清楚，品牌通常放末尾。
- Description：默认 `< 160` 字符；建议留少量截断余量，同时包含用户任务、差异点和自然行动暗示。
- Canonical：绝对 HTTPS URL，与 sitemap 主机一致。
- OG/Twitter：不仅检查标签，还要请求图片 URL，确认 `200` 且 `Content-Type: image/*`。
- favicon：提供 ICO、常用 PNG 尺寸和 Apple Touch Icon；构建后确认文件进入产物并出现在 HTML link 中。

## 2. 正文与关键词

- 1000+ 英文词适合信息充足的营销首页或内容页，不适合登录、工具、状态、结账等任务型页面强行凑字数。
- 精确词密度只做异常检测。1000 词 × 2% 等于约 20 次精确重复，常会显得机械。
- 优先用主实体、功能词、用户任务、输入输出、场景、受众、限制、FAQ 等形成语义覆盖。
- 对新品牌词首页，可先以约 0.8%–1.3% 精确短语作为自然度检查区间，再人工通读；这不是跨项目硬规则。
- 一个 H1 承载主搜索意图；创意口号可以保留，但不能让用户和爬虫看不出页面是什么。

## 3. AIDA 与免责声明

- Attention：首屏用主意图、强结果画面和清晰 CTA。
- Interest：解释能力、工作流、输入输出和差异。
- Desire：加入真实使用场景、收益、角色和结果想象，不只罗列功能。
- Action：主 CTA、次 CTA、登录/试用/候补等路径一致。
- 免责声明采用“集中声明、避免打断转化”：首屏不反复劝退；素材标注、FAQ、页脚和 Schema 承担必要边界。
- 必守底线：不冒充官方，不虚构已开放能力、价格、用户量、评分或实测结果。

## 4. Schema

常见组合：`WebSite` + `WebPage` + `SoftwareApplication`/`Product`（按真实页面类型）+ `FAQPage`。

- FAQ Schema 必须与可见 FAQ 一致。
- 不添加不可证实的 AggregateRating、Review、Offer。
- 独立站与上游官方产品要用真实实体关系表达，不能混成同一主体。

## 5. 技术统一

- 首页、robots、sitemap 返回 200。
- HTTP → HTTPS 301。
- www 与裸域只能有一个规范主机返回 200；另一主机 301，并保留 path/query。
- 若是 Cloudflare Pages Functions，可用根级 `functions/_middleware.js` 在请求进入静态资源/函数前统一主机；本地用 Host header 验证，再到生产域名复验。
- OAuth、API 等既有 Functions 必须在新增 middleware 后重新编译与做冒烟测试。

## 6. 双阶段验证

### 本地

1. lint / typecheck / build。
2. 从静态产物 HTML 统计：title、description、可见词数、精确短语次数、H1、JSON-LD 类型、FAQ 数量。
3. 确认 OG、favicon 文件进入构建产物。
4. 编译 Pages Functions；若新增主机重定向，用本地 Host header 检查状态码和 Location。

### 生产

1. 加 cache-busting 参数读取生产 HTML，重复统计。
2. 请求 OG、favicon、robots、sitemap，记录状态码与 Content-Type。
3. 验证 canonical 主机、www/裸域 301、路径与 query 保留。
4. 冒烟测试登录/API 重定向，确认 SEO middleware 没有破坏动态能力。
5. 浏览器检查 H1、内容区块和控制台错误。
