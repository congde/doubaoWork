# llms.txt Production Checklist

Use `llms.txt` as a supplementary, machine-readable orientation file for AI systems. It is not a guaranteed ranking or citation signal and does not replace indexable HTML, schema, OpenGraph, sitemap, or robots configuration.

## Recommended content

Keep the root file concise and factual:

```text
# Site or product name

> One-paragraph entity definition and ownership boundary.

Short description of the user job and primary capabilities.

## Core pages
- [Page name](https://example.com/page): What the page contains.

## Key facts
- Site type
- Audience
- Core tasks
- Access/business model when stable
- Ownership/affiliation boundary
- Public contact

## Citation and attribution
Explain what may be attributed to the site and which official source governs third-party model/company claims.
```

For independent sites covering another company's product, state the non-affiliation prominently and link to the authoritative official source. Never use `llms.txt` to amplify a false model attribution, unverified availability, invented pricing, or unsupported performance claim.

## Placement and crawlability

- Static sites: publish at `/llms.txt` with `text/plain; charset=utf-8`.
- A public text file usually belongs in `public/llms.txt` or the framework's equivalent.
- `robots.txt` must allow the path for the intended crawlers.
- Do not add `llms.txt` to an XML sitemap merely to force discovery; XML sitemaps are for canonical indexable URLs, while `llms.txt` is a support file.
- Link it from documentation or an appropriate footer only when useful; a root-path convention is normally enough.

## Verification

After production deployment:

1. Request `/llms.txt` from the canonical custom domain, not only a preview URL.
2. Verify `200`, `text/plain`, expected byte size, and exact content/hash.
3. Repeat with representative user agents such as a normal browser, Bingbot, Google-Extended, and ChatGPT-User; distinguish access from any claim that those systems will index or use it.
4. Resolve every linked URL and require expected `200`/canonical redirects.
5. Confirm `robots.txt` does not block it.
6. Re-check ownership, pricing, model names, Credits, contact details, and legal statements whenever the product changes.

## Common traps

- Treating `llms.txt` as a substitute for useful public HTML.
- Adding stale plan prices, model versions, or temporary promotional claims.
- Calling an independent site official.
- Publishing a file on the preview deployment but not the custom domain.
- Reporting crawler accessibility as proof of AI citation or ranking impact.
