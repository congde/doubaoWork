---
name: technical-seo-release-audit
title: SEO 上线与收录配置
description: 上线前后完成 SEO/GEO/AEO 复核：页面矩阵、indexability、schema、GSC、sitemap、AI 可引用结构。
version: 2.5.1
owner: Website Launch Toolkit
category: 做站全流程
stage: 10-seo
updated: 2026-08-11
student_level: beginner
source: internal-site-building-flow-publicized
---

# SEO 上线与收录配置

上线前后完成 SEO/GEO/AEO 复核：页面矩阵、indexability、schema、GSC、sitemap、AI 可引用结构。

专项参考：需要发布 AI 抓取辅助文件时，按 `references/llms-txt-production-checklist.md` 创建和验收 `/llms.txt`；保持实体、所有权和模型归属准确，不把“可抓取”夸大成“必然被 AI 引用”。

当 GSC/趋势出现有需求、但目标模型、集成、API、下载或能力尚未被一手来源证实时，按 `references/evidence-led-long-tail-pages.md` 决定做真实教程、日期化状态追踪页或暂缓；严禁把搜索需求写成产品存在的证据。

> 这是内部做站、上线、复盘流水线的脱敏用户版：保留阶段顺序、判断标准、质量闸门、交接格式和返修闭环；移除私有路径、账号、密钥、内部群聊和生产环境细节。

## 流水线位置

- 当前阶段：`10-seo`
- 角色：上线前后完成 SEO/GEO/AEO 复核：页面矩阵、indexability、schema、GSC、sitemap、AI 可引用结构。
- 上游：PRD、前端部署、文案、合规、页面矩阵。
- 下游：QA、上线运营、数据复盘。

## 什么时候使用

- 站点准备上线，需要 SEO 复核
- 要检查 sitemap/robots/canonical/schema
- 要提交 GSC 和建立收录监控
- QA 后要做 SEO recheck

## 输入契约

开始前尽量准备：

- 线上 URL
- 页面矩阵
- 目标关键词
- sitemap/robots
- GSC/Cloudflare 权限（没有就标 BLOCKED）

缺信息时按这个规则处理：

- 影响结论、上线安全、生产数据或真实部署：输出 `[BLOCKED]`，列出缺失项和获取方式。
- 不影响当前阶段 v0 推进：标 `[待确认]`，继续产出可复核草案。
- 没有证据的数据、价格、趋势、法律结论、部署结果：不要编造。
- 密钥、Cookie、Token、支付后台、生产数据库、私有路径：只写变量名或 `[REDACTED]`。

## 开始前检查 / Preflight

先检查账号、Token、浏览器登录态。缺关键权限时要阻断提醒用户，不要假装完成。

### 需要准备
- 新手难度：high
- 账号/后台：
- Google Search Console
- Bing Webmaster
- GA4/Clarity
- Ahrefs/SEO Audit（推荐）
- 环境变量 / Token：
- 无硬性要求；按项目资料推进。
- 浏览器登录态：
- GSC 登录态
- Bing Webmaster 登录态
- Cloudflare Dashboard 登录态

### 缺失处理
- 缺 GSC/Bing 登录态不能提交/验证收录：BLOCKED
- 缺 Ahrefs 权限写 missing_ahrefs_access，不得伪造 Audit

### 可以降级继续
- 可先检查 sitemap/robots/schema/canonical

### 安全索要话术
```text
[BLOCKED: SETUP_REQUIRED]

当前阶段缺少必要账号、Token 或浏览器登录态。
请不要把完整 token、密码、验证码、Cookie 直接发到聊天里。

推荐处理方式：
1. Token / API Key：写入本机 .env 或对应平台的 Secrets，只回复“已配置”。
2. 浏览器登录态：在当前可见浏览器完成登录并保持页面打开，只回复“已登录”。
3. 如果你不确定在哪里配置，把平台名称告诉 AI，让 AI 给你逐步指引。
```

## 一键启动 Prompt

```text
你现在执行 Website Launch Toolkit 做站流水线的「SEO 上线与收录配置」阶段。

项目：[项目名称]
当前阶段：10-seo
目标市场：[默认 US / English，可修改]
上游输入：[粘贴调研报告 / PRD / 定价 / 合规 / 文案 / 设计 / 代码 / 线上 URL / 数据截图]
限制条件：[时间、预算、技术栈、不能做什么]

请严格按这个 Skill 执行：
1. 先执行“开始前检查 / Preflight”和“输入契约”，缺关键账号、Token、浏览器登录态或关键资料就输出 [BLOCKED: SETUP_REQUIRED] / [BLOCKED]，不要猜。
2. 如果可以推进，按“阶段流程”逐步产出。
3. 每个重要判断都写依据；没有依据就标 [待确认]。
4. 输出“交付物 + 验收清单自检 + 下游交接摘要”。
5. 涉及公开发布、生产部署、支付、真实用户数据时，先列确认项，不要擅自执行。
6. 最后一行只能是：[DONE] / [BLOCKED] / [NEEDS_REVIEW]。
```

## 阶段流程

### 1. 页面矩阵对账
每个 indexable 页面有主词、H1、title、description、canonical、内链、schema、唯一价值。

- 搜索词只证明需求，不证明被搜索的产品/模型/集成/API/下载/合规状态真实存在。
- 先用一手来源核验：已证实才做教程/对比/工具页；未证实但意图明确且有信息价值时，做带 `Last checked`、证据来源、状态变更条件和安全替代方案的独立状态页；意图本身不清楚就暂缓。
- 如果首页已有真实生成器/核心体验，广义产品词继续由首页承接；不要因为导航使用锚点，就复制近似 Image/Video 内页制造关键词内耗。
- 新增长尾内页必须有可抓取、可被真实用户发现的内部入口。“首页不要大改”不等于“首页不得出现链接”：对公开资源页默认审计完整发现矩阵——桌面 Header、移动 Header、Footer、内页兄弟互链、返回核心任务 CTA、sitemap。2–5 个长标题可收进现有风格的 `Guides` / `Resources` 下拉，Footer 作为稳定兜底；不能只因为 Footer 有链接就宣布 Header 导航完成。只有用户明确要求“首页零改动”时才仅依赖 sitemap、内页互链和回链；若用户随后反馈“看不到跳转链接 / 正常改动就好”，以后者为当前范围真源，并同步修改原先禁止首页 slug 的回归测试。
- “本站使用某供应商基础设施”与“供应商公开发布了同名 endpoint/模型”必须分开表述，内部 Credits 也不能冒充供应商公开价格。

### 2. Indexability
noindex 页面不进 sitemap；placeholder/prototype/pending data 不得索引。

### 3. SERP 竞争力
对照 Top 3：首屏价值、工具/数据/答案、FAQ、short answer、AI 可引用块。

对于品牌词/产品词首页，必须分开统计精确短语与核心单词：双词主关键词按本项目约定自然达到约 1% 以上，核心单词在剔除停用词后的有效词频中尽量靠前；同时检查主题语义词，不能靠机械重复主词达标。详细测量口径、AIDA、favicon 和 GSC 闭环见 `references/homepage-keyword-seo-and-indexing.md`。

### 4. 技术 SEO
robots、sitemap、canonical、HTTPS 301、status code、OG、schema、性能基础检查。

- Next.js App Router 的全站 GA4 应在唯一 Root Layout 中接入一次，不要逐页复制造成重复采集；优先遵循项目当前 Next.js 版本文档并使用官方 Google Analytics 组件。
- Next.js App Router 使用 `output: "export"` 时，metadata route（特别是 `sitemap.ts`）若在 build 阶段提示未配置静态行为，应按当前安装版本文档显式添加 `export const dynamic = "force-static"` 或合适的 `revalidate`，然后检查真正生成的 `out/sitemap.xml`，不要只看源码。
- 长尾页 SEO 自动审计应读取生产构建 HTML：验证 Title/Description、唯一 H1、canonical、词数/项目约定密度、JSON-LD、可见 FAQ 与 FAQ schema 顺序一致、父子/兄弟内链和 sitemap。统计可见 FAQ 时必须限定在显式 FAQ 容器或 ID 中，不能扫描全页所有 `<details>`；Header 的 Guides/Resources 原生 disclosure 不是 FAQ，否则新增导航会制造假失败。声明检测正则不能把“引用一个错误说法并明确否定它”误判成正面宣传；优先检查不受支持的肯定句和真实猜测链接，再人工读上下文。
- GA4 生产验收不能只搜索 HTML：必须在真实浏览器确认 `dataLayer`、`window.gtag`、目标 `gtag.js` 资源和至少一次 `google-analytics.com/g/collect` 请求，且控制台无相关错误。详见 `references/nextjs-ga4-production-verification.md`。
- Plausible（含自托管/代理域名）同样必须在唯一 Root Layout 接入并做运行态验收：真实生产域名 hydration 后脚本只加载一次、`window.plausible` 可用、事件端点返回 2xx（常见 `202`）、控制台无相关错误。不要拿 RSC/Flight 字符串计数冒充 DOM 数量，也不要只验预览域名。详见 `references/plausible-production-verification.md`。
- Bing URL Inspection 的 `Markup types found` 列表中，JSON-LD/OpenGraph 左侧圆圈 `i` 是信息/详情入口，不是失败状态；类型被列出本身说明 Bing 已发现。不要为了追不存在的绿色对勾重复注入 markup，仍应独立用 Bingbot UA 验证原始 HTML、JSON 可解析性、OG 必需字段与 OG 图片 `200 image/*`。

- Favicon 不能只验证文件存在和哈希；必须检查框架文件约定的优先级、线上 HTML 的有效 icon URL，并用真实 16×16 / 32×32 像素预览确认品牌仍可辨认。
- 第三方关键词密度工具必须先对齐其分词口径。数字、斜杠和品牌词可能被归一化为不同 n-gram；不得拿自定义正则的结果冒充第三方工具结果。
- 详细排查流程见 `references/keyword-density-and-favicon-verification.md`。

### 5. GSC/提交
验证站点、提交 sitemap、记录首次抓取风险；无权限就输出待办而非假完成。

- 新域名资源验证后，优先用 URL Inspection 做实时测试并只请求一次索引。
- 新资源的 sitemap 短时显示“无法抓取”时，先验证普通 UA、Googlebot UA、robots、XML 解析和实时网址测试；证据都正常则延后复查，不要反复提交或盲改生产配置。
- Bing/Yandex 等支持 IndexNow 的搜索引擎，优先在**生产部署成功后**自动通知，而不是 push 后立即通知：用部署 commit marker 确认正式域名已服务当前 SHA，再比较 sitemap 基线并提交新增、更新、删除 URL。
- 不得盲信静态 `lastmod`：小型站可在每次生产部署提交全部当前 canonical URL 并补交删除 URL；大型站应使用真实更新时间、内容 hash、CMS `updated_at` 或 route mapping。IndexNow `200/202` 只代表请求被接收，不等于已收录。
- 完整实现、重试、缓存基线和验收证据见 `references/indexnow-deployment-automation.md`。

### 6. GEO/AEO
补清晰定义、步骤、数据表、Q&A、引用友好段落。

- 需要面向 AI 爬虫补充站点说明时，可发布根级 `/llms.txt`：实体定义、核心页面、可证实事实、归属边界、引用口径和 canonical URL。它不替代 robots/sitemap/schema，也不保证排名或被引用；不要放进 XML sitemap。生产验收要覆盖 `200 text/plain`、链接可访问、robots 允许，以及普通 UA、Bingbot、Google-Extended、ChatGPT-User 均可获得同一正文。详见 `references/llms-txt-production-checklist.md`。

### 7. 交接
给 QA/运营：可索引清单、阻塞页、提交状态、首周监控项。


## 2026-06 最新做站实践升级

本版按 Website Launch Toolkit 内部最新做站流水线同步，用户版默认采用“自动工厂”而不是手工接力：

- **Kanban / 项目控制板是唯一事实源**：正式做站任务、返修、复验、上线和复盘都要落到任务板或等价 `project-control.md`，聊天只做进度可见性和人工确认。
- **用户只提交 Project Launch Card**：关键词、域名、目标市场、项目类型、约束、账号准备状态；总控自动拆 DAG、派工、验收、返修和汇报。
- **Cloudflare-first 技术栈**：静态内容优先 Pages；动态能力、会员、支付、AI API、上传、后台和数据写入默认 Workers + D1/R2/Queues/Secrets。
- **硬闸门不能跳过**：新词/机会 → PRD/Route Contract → 定价/合规 → SEO-Copy Freeze → 视觉真源 → Data Contract → 实现 → PM/SEO/合规复核 → QA → Release Owner Review → Launch → Data Review。
- **上线前必须有真实证据**：生产 URL、commit/push/deploy、移动端截图、控制台/网络检查、sitemap/robots/canonical/schema、GA4/Clarity/Bing/GSC 或等价数据链路。
- **公开动作先确认**：付款、真实预算、生产 DNS/域名绑定、外部发帖/投稿/目录提交、邮件/社媒公开发布，必须等用户确认；低风险内部修复可以直接推进。
- **复盘反哺 Skills**：P0/P1、卡点、平台限制、转化数据、外链效果和 Kill/Iterate/Scale 决策，要回写阶段手册或项目复盘，不让同类问题重复踩坑。

### 本阶段新增重点
- SEO/GEO/AEO 同时做：indexability、schema、FAQ、内部链接、AI 可引用结构、站点实体和页面矩阵完整性。
- 上线前打开 Cloudflare Crawler Hints；补 GSC、Bing Webmaster/IndexNow、GA4、Clarity，并记录验证证据。
- 外链是排名核心变量：冷启动不只是发渠道，要建立外链资产表、提交/收录/rel/索引状态和效果归因。

## 交付物

- SEO 复核报告
- 页面 index/noindex 清单
- GSC/sitemap 状态
- schema/metadata 检查
- AI 可引用优化建议

## 验收清单 / 质量门槛

- [ ] sitemap 只含可索引真实页面
- [ ] 核心页有唯一 H1/title/meta/canonical
- [ ] GSC 状态真实
- [ ] 生产 HTTP → HTTPS 301 已验证；www/裸域只能保留一个 200，另一主机应 301 且保留路径与查询参数
- [ ] 没有薄页污染初始抓取
- [ ] Title 默认控制在 60 字符以内，Description 默认控制在 160 字符以内；同时检查 SERP 可读性，不能只为卡长度删掉搜索意图
- [ ] 内容页/营销首页在有足够信息价值时可把 1000+ 英文词作为目标，但登录页、工具页、状态页不机械凑字数
- [ ] 精确关键词密度是诊断护栏，不是排名配方：通常优先自然语义覆盖；若项目要求约 2%，先核算 1000 词会产生约 20 次精确重复的堆砌风险，再改用更自然的精确词范围与实体/同义语义覆盖
- [ ] H1 明确承载页面主意图；创意口号可保留为同一 H1 的视觉层级或邻近副标题
- [ ] OG/Twitter 图片必须请求到 `200 image/*`，不能只检查 meta 标签存在；favicon、Apple Touch Icon 同样要验证真实文件和 HTML link
- [ ] JSON-LD 可解析，FAQPage 与可见 FAQ 逐项一致，不虚构 rating、review、price、availability
- [ ] 本地 build/lint 通过后，再对生产 HTML重新统计 title、description、词数、精确短语次数、H1、Schema 和社交图片；不能用本地结果代替上线验收

详细的首页 SEO-Copy 验收口径与自动化探针见 `references/homepage-seo-copy-acceptance.md`。

## 下游交接格式

```markdown
# SEO 上线与收录配置交接摘要

## 当前结论
- 状态：[DONE] / [BLOCKED] / [NEEDS_REVIEW]
- 一句话结论：

## 关键输入
- 项目：
- 当前阶段：10-seo
- 上游资料：

## 本阶段交付物
- 文件/内容：
- 核心判断：
- 已确认项：
- 待确认项：

## 质量门槛自检
- 通过项：
- 未通过项：

## 风险
- P0：
- P1：
- P2：

## 给下游的最小必要信息
- 下一阶段：QA、上线运营、数据复盘。
- 必须读取：
- 不能假设：
- 建议启动 Prompt：
```

## 用户怎么用

优先用自然语言，不要求会脚本：

1. 打开 `SKILL.md`。
2. 复制“一键启动 Prompt”。
3. 把你的项目资料填进方括号。
4. 发给 Hermes、OpenClaw、Claude、ChatGPT、Gemini、Cursor 等 AI 工具。
5. 让 AI 按“交付物”和“验收清单”输出，再把交接摘要交给下一阶段。

如果你使用 Website Launch Toolkit 一键安装包，安装后在新会话里直接说：

```text
请加载 Website Launch Toolkit Skill：technical-seo-release-audit，按我的项目资料执行。
```

## 常见坑

- 正文写 noindex 但 HTML 没设置
- login/admin/app 进 sitemap
- 只生成 sitemap 不提交 GSC
- 上线后才发现 canonical 指错域名
- 用自定义脚本算出“关键词密度达标”，却没有复现用户指定工具的数字/斜杠分词规则；或把用户明确排除的域名/品牌短语误当成必须达到密度的次关键词
- 只验证 favicon 文件已上传，没有检查框架自动 favicon 的优先级，也没有看 16×16 标签页效果
- GSC 新资源刚提交 sitemap 就显示“无法抓取”时立刻反复提交；应先做 Googlebot UA、XML、robots 和实时网址测试，再延后复查
- 看见 GSC impression 或 Trends 飙升就直接写“官方教程”、猜 endpoint、checkpoint、VRAM、价格或合作关系；搜索需求不是产品存在证据，应先决定真实教程、状态追踪页或暂缓
- 用过宽的正则扫描虚假声明，结果把页面中明确否定的引述也判失败；检测要聚焦不受支持的肯定句和实际链接，并保留人工上下文复核

## 标准包内容

- `SKILL.md`：阶段入口、输入契约、一键启动 Prompt、流程与验收清单。
- `references/evidence-led-long-tail-pages.md`：未证实模型/集成/API/下载类关键词的页面决策、声明边界、Next.js 静态导出与生成 HTML 验收。

## 更新记录

### 2.5.1 — 2026-08-11
- 将长尾内页内部发现从“优先 Footer”升级为完整矩阵：桌面 Header、移动 Header、Footer、兄弟互链、核心 CTA 和 sitemap 一次性审计；Footer 不再替代 Header 完成度。
- 明确“不要大改”不等于“首页零改”，后续用户要求可见跳转时必须更新范围合同与回归测试。
- 修正 FAQ 自动审计口径：只统计显式 FAQ 容器内的 disclosure，避免把 Header Guides `<details>` 误判为 FAQ。

### 2.5.0 — 2026-08-10
- 新增证据驱动长尾页决策：搜索需求不等于功能存在；在真实教程、日期化状态追踪页和暂缓之间做选择。
- 补充供应商基础设施与公开同名 endpoint、内部 Credits 与供应商价格、自然语言提示与原生控制的声明边界。
- 新增 Next.js `output: "export"` 下 sitemap metadata route 静态声明和生成 HTML SEO 自动验收方法。
- 新增参考文件：`references/evidence-led-long-tail-pages.md`。

### 2.4.0 — 2026-07-26
- 新增生产部署感知的 IndexNow 自动化：commit marker、sitemap 基线、首次全量、删除 URL、静态 `lastmod` 漏报防护、`429/5xx` 重试与 `200/202` 验收口径。
- 新增 Next.js App Router 全站 GA4 标准接入和真实浏览器验收：Root Layout 单例、官方组件、`dataLayer`、`gtag.js` 与 `g/collect` 网络证据。
- 新增参考文件：`references/indexnow-deployment-automation.md`、`references/nextjs-ga4-production-verification.md`。

### 2.3.0 — 2026-06-05
- 全量同步 Website Launch Toolkit 内部最新做站实践：Kanban/project-control 事实源、Project Launch Card、Cloudflare-first、硬闸门、Release Owner Review、真实上线证据与复盘回写。
- 补充本阶段新版验收重点，覆盖 SEO-Copy Freeze、Route/Data Contract、Visual Style Rationale、GA4/Clarity/Bing/GSC、Crawler Hints、外链 ledger、Kill/Iterate/Scale 等新门槛中与本阶段相关的部分。


### 2.2.0 — 2026-05-26
- 新增 Preflight：账号、Token、浏览器登录态、缺失阻断和安全索要话术。
- 更新一键启动 Prompt，要求先检查环境再执行，避免新手在无权限状态下误判 DONE。

### 2.1.0 — 2026-05-23
- 基于最新内部一键做站与数据复盘流水线重写用户版。
- 补齐新词硬闸、SEO-Copy Freeze、Route/Data Contract、PM Gate、QA_GO、Crawler Hints、上线后复盘等关键闸门。
- 保持 Prompt-first 使用方式，脚本仅作为可选辅助。

### 1.2.1 — 2026-05-18
- 标准包结构版本，包含使用说明、模板和辅助脚本。
