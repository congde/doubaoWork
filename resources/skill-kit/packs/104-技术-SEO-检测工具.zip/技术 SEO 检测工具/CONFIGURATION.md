# 配置与依赖

- 输入：生产 URL、目标页面、关键词、预期 canonical/schema、站点地图和分析平台。
- API：核心静态检查无付费 API；GSC/Bing/IndexNow 通常免费；Ahrefs/Plausible 可选且可能收费。
- 没有账号权限时降级为静态技术 SEO 检查，不宣称已完成平台提交。
- 所有域名、Site ID、Measurement ID、IndexNow Key 和凭据由用户配置。
