#!/usr/bin/env python3
"""Fetch a public page and report basic technical SEO signals."""
import argparse, json, re
from html.parser import HTMLParser
from urllib.request import Request, urlopen
from urllib.parse import urljoin

class Parser(HTMLParser):
    def __init__(self):
        super().__init__(); self.title=""; self.h1=[]; self.canonical=""; self._tag=None
    def handle_starttag(self,tag,attrs):
        d=dict(attrs); self._tag=tag
        if tag=="link" and "canonical" in d.get("rel","").lower(): self.canonical=d.get("href","")
    def handle_endtag(self,tag):
        if self._tag==tag: self._tag=None
    def handle_data(self,data):
        s=data.strip()
        if self._tag=="title" and s: self.title+=s
        if self._tag=="h1" and s: self.h1.append(s)

def fetch(url):
    req=Request(url,headers={"User-Agent":"technical-seo-release-audit/1.0"})
    with urlopen(req,timeout=20) as r: return r.status,r.headers.get("content-type",""),r.read(2_000_000).decode("utf-8","replace")

def main():
    p=argparse.ArgumentParser(description="Check title, H1, canonical, robots and sitemap")
    p.add_argument("url"); args=p.parse_args()
    status,ctype,html=fetch(args.url)
    parser=Parser(); parser.feed(html)
    origin=re.match(r"https?://[^/]+",args.url)
    base=origin.group(0) if origin else args.url
    result={"url":args.url,"status":status,"content_type":ctype,"title":parser.title,"h1":parser.h1,"canonical":urljoin(args.url,parser.canonical) if parser.canonical else None}
    for name,path in {"robots":"/robots.txt","sitemap":"/sitemap.xml"}.items():
        try: result[name+"_status"]=fetch(urljoin(base,path))[0]
        except Exception: result[name+"_status"]=None
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if status!=200 or not parser.title or not parser.h1: raise SystemExit(1)

if __name__ == "__main__": main()
