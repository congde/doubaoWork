# 配置与依赖

- 必填：`AI_NEWS_API_BASE`。
- 可选：`AI_NEWS_API_KEY`、`AI_NEWS_USER_AGENT`。
- 命令：`curl`；可选 `jq`。
- API 是否收费、限流和保留查询记录取决于服务运营方，调用前披露。
- 不使用伪装浏览器 UA 绕过服务端限制。
