---
name: ai-news-digest-api-client
description: 通过可配置的 AI 资讯 REST API 查询今日热点、日报、指定日期归档、分类动态和关键词结果，并整理成带原文链接的中文简报。适用于“今天 AI 圈有什么”“AI 日报”“最近模型/产品/论文发布”等时效性问题。
---

# AI 资讯 API 简报

从用户配置的资讯 API 获取实时数据，不使用模型训练记忆冒充今日新闻。

## 配置

```bash
export AI_NEWS_API_BASE="https://news-api.example.com"
# 仅当服务端要求鉴权时设置：
export AI_NEWS_API_KEY=""
# 可选；默认使用明确标识 Skill 的客户端 UA，不伪装浏览器：
export AI_NEWS_USER_AGENT="ai-news-digest-skill/1.0"
```

- `AI_NEWS_API_BASE` 必填，不在公开 Skill 中写死私有服务域名。
- `AI_NEWS_API_KEY` 可选，只从环境变量或 Secret Store 读取。
- 若 API 不需要鉴权，保持 `AI_NEWS_API_KEY` 为空。
- 服务端若封禁标准客户端 UA，应由服务运营方提供正式白名单，不通过伪装浏览器绕过。

## 兼容 API 合同

默认支持：

| 端点 | 用途 |
|---|---|
| `GET /api/public/items` | 查询滚动资讯流 |
| `GET /api/public/daily` | 最新日报 |
| `GET /api/public/daily/{YYYY-MM-DD}` | 指定日期日报 |
| `GET /api/public/dailies?take=N` | 日报归档 |

`items` 可选参数：

```text
mode=selected|all
category=ai-models|ai-products|industry|paper|tip
since=<ISO-8601>
q=<keyword>
take=1..100
cursor=<opaque token>
```

如果服务端合同不同，应在安装时通过适配器映射，不修改 Skill 中的业务判断。

## 请求方法

```bash
BASE="${AI_NEWS_API_BASE%/}"
UA="${AI_NEWS_USER_AGENT:-ai-news-digest-skill/1.0}"

headers=(-H "User-Agent: $UA" -H "Accept: application/json")
if [ -n "${AI_NEWS_API_KEY:-}" ]; then
  headers+=(-H "Authorization: Bearer ${AI_NEWS_API_KEY}")
fi
curl -fsS "${headers[@]}" "$BASE/api/public/items?mode=selected&take=50"
```

日志中不得输出 `Authorization` 请求头或 API Key。

## 路由规则

1. 用户问“今天/最近/过去 N 小时发生了什么”：查询 `items`，默认 `mode=selected` 并带 `since`。
2. 用户明确说“日报”：查询 `daily`。
3. 用户明确说“全部/完整/全量”：才使用 `mode=all`。
4. 用户问模型、产品、行业、论文或技巧：增加 `category`。
5. 用户指定公司、产品或主题：使用服务端 `q` 搜索。
6. 查询历史日期：使用 `daily/{date}`；不要用滚动资讯流假装历史归档。

## 时间窗

生成 UTC ISO-8601 时间：

```bash
# 最近 24 小时，兼容 GNU/BSD date
since=$(date -u -d '24 hours ago' +%Y-%m-%dT%H:%M:%SZ 2>/dev/null \
  || date -u -v-24H +%Y-%m-%dT%H:%M:%SZ)
```

输出时转换为用户时区。没有确定用户时区时，明确标注所用时区。

## 数据处理

每条结果至少保留：

```json
{
  "title": "中文标题",
  "url": "https://source.example/article",
  "source": "来源名称",
  "publishedAt": "ISO-8601",
  "summary": "可空",
  "category": "可空"
}
```

规则：

- `url` 必须保留，方便回到原文核验。
- API 摘要只能作为摘要，不当作原文引语。
- 涉及重大版本、价格、政策或争议信息时，打开原始来源复核。
- 去重优先使用规范化 URL；其次使用标题和来源组合。
- 游标是黑盒，只能原样回传，不能解析或自行递增。
- API 返回空数据时如实说明，不编造热点补位。

## 输出格式

```markdown
## AI 动态简报

时间窗：<开始> 至 <结束>（<时区>）
共 <N> 条，按发布时间倒序。

### 模型发布
1. **<标题>** — <来源>
   <50–100 字摘要>
   <原文链接>

### 产品发布
2. ...

### 行业动态
3. ...

### 论文研究
4. ...
```

只有一个分类时使用扁平编号列表。最终用户输出不展示端点、raw 参数、游标、限流或缓存细节。

## 错误处理

- `401/403`：检查 API Key、权限和服务端白名单，不尝试绕过。
- `404`：日报可能尚未生成；查询最近归档并说明日期。
- `429`：按 `Retry-After` 退避，禁止并发猛拉。
- `5xx`：有限重试后说明数据源不可用，不改用训练记忆伪造今日资讯。
- 返回结构变化：停止格式化并报告合同不兼容。

## 费用与隐私

- Skill 本身免费；API 服务是否收费由 `AI_NEWS_API_BASE` 的运营方决定。
- 调用前应披露数据服务提供方、价格、限流、隐私政策和数据保留方式。
- 搜索关键词可能会发送给第三方 API；涉及私密项目名时先征得用户同意。
- 不在包内保存 API Key、请求日志、用户查询历史或返回数据缓存。
