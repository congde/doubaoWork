#!/usr/bin/env python3
"""
Novel Organizer - 章节管理与一致性追踪工具

Usage:
    python novel_organizer.py --init <project-name>
    python novel_organizer.py --add-chapter <project-dir> --title "Chapter Title"
    python novel_organizer.py --list <project-dir>
    python novel_organizer.py --check <project-dir>
    python novel_organizer.py --export <project-dir> --output <output-file>
    python novel_organizer.py --summary <project-dir> --chapter <number>

Examples:
    python novel_organizer.py --init my-novel
    python novel_organizer.py --add-chapter my-novel --title "第一章 觉醒"
    python novel_organizer.py --list my-novel
    python novel_organizer.py --check my-novel
    python novel_organizer.py --export my-novel --output novel.md
    python novel_organizer.py --summary my-novel --chapter 3
"""

import sys
import os
import re
import json
import argparse
from pathlib import Path
from datetime import datetime


# ============================================================
# 项目初始化
# ============================================================

def init_project(project_name, base_dir="."):
    """初始化小说项目目录结构"""
    project_path = Path(base_dir).resolve() / project_name

    if project_path.exists():
        print(f"  Error: Project directory already exists: {project_path}")
        return None

    directories = [
        "chapters",       # 章节文件
        "settings",       # 设定文件（世界观、角色卡）
        "outlines",       # 大纲文件
        "notes",          # 伏笔与一致性追踪
    ]

    for d in directories:
        (project_path / d).mkdir(parents=True, exist_ok=True)

    # 创建初始设定文件
    meta = {
        "title": project_name,
        "created": datetime.now().isoformat(),
        "chapters": [],
        "characters": [],
        "foreshadowing": [],   # 伏笔列表
        "timeline": [],        # 时间线事件
    }

    meta_path = project_path / "meta.json"
    meta_path.write_text(
        json.dumps(meta, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    # 创建设定文件模板
    world_setting = project_path / "settings" / "world_setting.md"
    world_setting.write_text(
        "# 世界观设定\n\n"
        "## 时代背景\n\n## 地理环境\n\n"
        "## 社会结构\n\n## 体系设定\n\n## 核心冲突\n",
        encoding="utf-8"
    )

    character_template = project_path / "settings" / "character_template.md"
    character_template.write_text(
        "# 角色卡模板\n\n"
        "角色名：\n身份/职业：\n年龄：\n"
        "外貌特征：\n性格关键词：\n说话风格：\n"
        "核心动机：\n内在冲突：\n成长弧线：\n"
        "背景故事：\n特殊能力/技能：\n弱点/缺陷：\n关系网络：\n",
        encoding="utf-8"
    )

    # 创建大纲模板
    outline_template = project_path / "outlines" / "outline_template.md"
    outline_template.write_text(
        "# 小说大纲模板\n\n"
        "## 全书大纲\n\n### 第一幕（25%）\n### 第二幕（50%）\n### 第三幕（25%）\n\n"
        "## 分卷大纲\n\n### 第一卷\n- 卷名：\n- 核心冲突：\n- 主要事件：\n"
        "- 涉及角色：\n- 伏笔：\n\n"
        "## 章节细纲\n\n### 第1章\n- 场景列表：\n- 核心事件：\n- 章末钩子：\n",
        encoding="utf-8"
    )

    # 创建伏笔追踪文件
    foreshadow = project_path / "notes" / "foreshadowing.md"
    foreshadow.write_text(
        "# 伏笔追踪表\n\n"
        "| 编号 | 伏笔内容 | 埋设章节 | 回收章节 | 状态 |\n"
        "|------|----------|----------|----------|------|\n"
        "| F001 |          |          |          | 未回收 |\n",
        encoding="utf-8"
    )

    consistency = project_path / "notes" / "consistency.md"
    consistency.write_text(
        "# 一致性检查记录\n\n"
        "## 角色状态表\n\n"
        "| 角色 | 当前位置 | 状态 | 已知信息 | 更新章节 |\n"
        "|------|----------|------|----------|----------|\n\n"
        "## 时间线\n\n"
        "| 章节 | 时间点 | 事件 |\n"
        "|------|--------|------|\n",
        encoding="utf-8"
    )

    print(f"  Project '{project_name}' initialized at: {project_path}")
    print(f"  Directory structure created:")
    print(f"    {project_name}/")
    print(f"      meta.json           (project metadata)")
    print(f"      chapters/           (chapter files)")
    print(f"      settings/           (world & character settings)")
    print(f"      outlines/           (plot outlines)")
    print(f"      notes/              (foreshadowing & consistency)")
    return project_path


# ============================================================
# 添加章节
# ============================================================

def add_chapter(project_dir, title, content=None):
    """添加新章节"""
    project_path = Path(project_dir).resolve()
    meta = _load_meta(project_path)

    chapter_num = len(meta["chapters"]) + 1
    chapter_filename = f"chapter_{chapter_num:03d}.md"

    chapter_path = project_path / "chapters" / chapter_filename

    # 章节内容
    if content:
        chapter_text = content
    else:
        chapter_text = f"# {title}\n\n[章节内容待写入]\n"

    chapter_path.write_text(chapter_text, encoding="utf-8")

    # 更新 meta
    chapter_entry = {
        "number": chapter_num,
        "title": title,
        "filename": chapter_filename,
        "word_count": len(chapter_text),
        "created": datetime.now().isoformat(),
    }
    meta["chapters"].append(chapter_entry)
    _save_meta(project_path, meta)

    print(f"  Added chapter {chapter_num}: {title}")
    print(f"    File: {chapter_path}")
    print(f"    Word count: {chapter_entry['word_count']} chars")
    return chapter_path


# ============================================================
# 列出章节
# ============================================================

def list_chapters(project_dir):
    """列出所有章节"""
    project_path = Path(project_dir).resolve()
    meta = _load_meta(project_path)

    if not meta["chapters"]:
        print("  No chapters found.")
        return

    print(f"\n  Novel: {meta['title']}")
    print(f"  Total chapters: {len(meta['chapters'])}")
    print(f"  Total words: {sum(c['word_count'] for c in meta['chapters'])}")
    print(f"  {'─' * 60}")

    for ch in meta["chapters"]:
        print(f"  Ch.{ch['number']:03d} | {ch['title']:<30s} | {ch['word_count']:>6d} chars")

    print(f"  {'─' * 60}")


# ============================================================
# 一致性检查
# ============================================================

def check_consistency(project_dir):
    """检查项目一致性"""
    project_path = Path(project_dir).resolve()
    meta = _load_meta(project_path)

    issues = []
    warnings = []

    # 1. 检查章节文件是否存在
    for ch in meta["chapters"]:
        ch_path = project_path / "chapters" / ch["filename"]
        if not ch_path.exists():
            issues.append(f"  Chapter {ch['number']} file missing: {ch['filename']}")

    # 2. 检查角色名一致性
    char_names = [c.get("name", "") for c in meta.get("characters", []) if c.get("name")]
    char_alias_map = {}
    for c in meta.get("characters", []):
        name = c.get("name", "")
        aliases = c.get("aliases", [])
        for alias in aliases:
            char_alias_map[alias] = name

    # 扫描章节中的角色提及
    name_occurrences = {name: 0 for name in char_names}
    for ch in meta["chapters"]:
        ch_path = project_path / "chapters" / ch["filename"]
        if ch_path.exists():
            text = ch_path.read_text(encoding="utf-8")
            for name in char_names:
                name_occurrences[name] += text.count(name)

    # 3. 检查伏笔回收状态
    foreshadow_path = project_path / "notes" / "foreshadowing.md"
    if foreshadow_path.exists():
        foreshadow_text = foreshadow_path.read_text(encoding="utf-8")
        unrecovered = len(re.findall(r'\|.*未回收.*\|', foreshadow_text))
        recovered = len(re.findall(r'\|.*已回收.*\|', foreshadow_text))
        total = unrecovered + recovered
        if total > 0:
            print(f"  Foreshadowing: {recovered}/{total} recovered, {unrecovered} pending")
            if unrecovered > 0 and len(meta["chapters"]) > 10:
                warnings.append(f"  {unrecovered} unrecovered foreshadowing items - check if they should be resolved")

    # 4. 检查章节连续性
    chapter_numbers = [c["number"] for c in meta["chapters"]]
    expected = list(range(1, len(chapter_numbers) + 1))
    if chapter_numbers != expected:
        issues.append(f"  Chapter numbering gap: expected {expected}, got {chapter_numbers}")

    # 5. 检查角色提及情况
    for name, count in name_occurrences.items():
        if count == 0 and len(meta["chapters"]) > 3:
            warnings.append(f"  Character '{name}' has 0 mentions across all chapters")

    # 输出结果
    print(f"\n  Consistency Check Report")
    print(f"  {'─' * 60}")

    if name_occurrences:
        print(f"\n  Character mentions:")
        for name, count in name_occurrences.items():
            status = "  OK" if count > 0 else "  !!"
            print(f"    {status} {name}: {count} mentions")

    if issues:
        print(f"\n  Issues found ({len(issues)}):")
        for issue in issues:
            print(f"    {issue}")
    else:
        print(f"\n  No critical issues found.")

    if warnings:
        print(f"\n  Warnings ({len(warnings)}):")
        for w in warnings:
            print(f"    {w}")

    print(f"  {'─' * 60}")
    return len(issues) == 0


# ============================================================
# 导出
# ============================================================

def export_novel(project_dir, output_file, fmt="md"):
    """导出完整小说"""
    project_path = Path(project_dir).resolve()
    meta = _load_meta(project_path)

    if not meta["chapters"]:
        print("  No chapters to export.")
        return None

    output_path = Path(output_file).resolve()

    parts = []
    parts.append(f"# {meta['title']}\n")
    parts.append(f"> 共 {len(meta['chapters'])} 章\n")
    parts.append(f"> 导出时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
    parts.append("\n---\n\n")

    # 目录
    parts.append("## 目录\n\n")
    for ch in meta["chapters"]:
        parts.append(f"- 第{ch['number']}章 {ch['title']}\n")
    parts.append("\n---\n\n")

    # 正文章节
    for ch in meta["chapters"]:
        ch_path = project_path / "chapters" / ch["filename"]
        if ch_path.exists():
            content = ch_path.read_text(encoding="utf-8")
            parts.append(content)
            parts.append("\n\n---\n\n")
        else:
            parts.append(f"## 第{ch['number']}章 {ch['title']}\n\n[章节文件缺失]\n\n---\n\n")

    full_text = "".join(parts)

    if fmt == "txt":
        # 去掉 Markdown 标记
        full_text = re.sub(r'^#+\s*', '', full_text, flags=re.MULTILINE)
        full_text = re.sub(r'\*{1,2}([^*]+)\*{1,2}', r'\1', full_text)
        full_text = re.sub(r'---', '', full_text)
        output_path = output_path.with_suffix(".txt")

    output_path.write_text(full_text, encoding="utf-8")

    total_words = sum(c['word_count'] for c in meta['chapters'])
    print(f"  Exported novel: {output_path}")
    print(f"  Chapters: {len(meta['chapters'])}")
    print(f"  Total words: {total_words}")
    return output_path


# ============================================================
# 章节摘要
# ============================================================

def generate_summary(project_dir, chapter_num):
    """生成指定章节的摘要"""
    project_path = Path(project_dir).resolve()
    meta = _load_meta(project_path)

    chapter = None
    for ch in meta["chapters"]:
        if ch["number"] == chapter_num:
            chapter = ch
            break

    if not chapter:
        print(f"  Chapter {chapter_num} not found.")
        return None

    ch_path = project_path / "chapters" / chapter["filename"]
    if not ch_path.exists():
        print(f"  Chapter file missing: {chapter['filename']}")
        return None

    text = ch_path.read_text(encoding="utf-8")

    # 简单提取摘要：取前200字 + 关键句子
    # 去掉标题行
    lines = [l for l in text.split("\n") if not l.startswith("#")]
    content = " ".join(lines).strip()

    # 按句分割
    sentences = re.split(r'[。！？.!?]', content)
    sentences = [s.strip() for s in sentences if s.strip()]

    # 摘要 = 前3句 + 最后1句
    if len(sentences) <= 4:
        summary = "。".join(sentences) + "。"
    else:
        summary = "。".join(sentences[:3]) + "。" + sentences[-1] + "。"

    # 提取角色名
    char_names = [c.get("name", "") for c in meta.get("characters", []) if c.get("name")]
    mentioned_chars = []
    for name in char_names:
        if name in text:
            mentioned_chars.append(name)

    print(f"  Chapter {chapter_num}: {chapter['title']}")
    print(f"  Word count: {len(content)}")
    print(f"  Characters mentioned: {', '.join(mentioned_chars) if mentioned_chars else 'None'}")
    print(f"  Summary: {summary[:300]}...")

    return {
        "chapter": chapter_num,
        "title": chapter["title"],
        "word_count": len(content),
        "summary": summary,
        "characters": mentioned_chars,
    }


# ============================================================
# 辅助函数
# ============================================================

def _load_meta(project_path):
    """加载项目元数据"""
    meta_path = Path(project_path) / "meta.json"
    if not meta_path.exists():
        print(f"  Error: Not a novel project (meta.json not found): {project_path}")
        sys.exit(1)
    return json.loads(meta_path.read_text(encoding="utf-8"))


def _save_meta(project_path, meta):
    """保存项目元数据"""
    meta_path = Path(project_path) / "meta.json"
    meta_path.write_text(
        json.dumps(meta, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )


# ============================================================
# 主入口
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Novel Organizer - 章节管理与一致性追踪工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python novel_organizer.py --init my-novel
  python novel_organizer.py --add-chapter my-novel --title "第一章 觉醒"
  python novel_organizer.py --list my-novel
  python novel_organizer.py --check my-novel
  python novel_organizer.py --export my-novel --output novel.md
  python novel_organizer.py --summary my-novel --chapter 3
        """
    )

    parser.add_argument("--init", metavar="PROJECT_NAME", help="Initialize a new novel project")
    parser.add_argument("--add-chapter", metavar="PROJECT_DIR", help="Add a new chapter to project")
    parser.add_argument("--list", metavar="PROJECT_DIR", help="List all chapters")
    parser.add_argument("--check", metavar="PROJECT_DIR", help="Run consistency check")
    parser.add_argument("--export", metavar="PROJECT_DIR", help="Export novel to file")
    parser.add_argument("--summary", metavar="PROJECT_DIR", help="Generate chapter summary")
    parser.add_argument("--title", default="新章节", help="Chapter title (for --add-chapter)")
    parser.add_argument("--output", default="novel_export.md", help="Output file path (for --export)")
    parser.add_argument("--format", default="md", choices=["md", "txt"], help="Export format")
    parser.add_argument("--chapter", type=int, default=1, help="Chapter number (for --summary)")

    args = parser.parse_args()

    if args.init:
        init_project(args.init)
    elif args.add_chapter:
        add_chapter(args.add_chapter, args.title)
    elif args.list:
        list_chapters(args.list)
    elif args.check:
        check_consistency(args.check)
    elif args.export:
        export_novel(args.export, args.output, args.format)
    elif args.summary:
        generate_summary(args.summary, args.chapter)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
