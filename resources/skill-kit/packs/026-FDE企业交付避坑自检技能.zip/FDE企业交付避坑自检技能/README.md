# 技能命名说明（给其他智能体）

目标系统（部分强制小写命名的 agent 框架）要求 `SKILL.md` 的 `name` 字段**只能包含小写字母、数字、连字符**（`a-z 0-9 -`）。

- 原始中文名：`AI时代企业交付避坑自检`
- 本包合规 slug：`ai-delivery-pitfall-check`

已做处理：
1. 文件夹名已改为 `ai-delivery-pitfall-check`；
2. SKILL.md 第 2 行 `name:` 已同步改为 `ai-delivery-pitfall-check`；
3. 文件夹名与 `name` 保持一致，解压后整体放入 skills 目录（如 `~/.workbuddy/skills/`）即可被识别。

如你的系统不限制命名，可忽略本说明，直接按原中文名使用。
