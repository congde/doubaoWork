#!/usr/bin/env python3
"""
中文出版书稿格式检查与修复工具

功能：
  1. 审查模式（--mode audit）：扫描 docx，输出按章节、按优先级的问题报告
  2. 修复模式（--mode fix）：精准修改指定章节，不波及其他内容

用法：
  python fix_docx_format.py audit <unpacked_dir>              # 审查全部章节
  python fix_docx_format.py audit <unpacked_dir> --ch 1,7,10  # 审查指定章节
  python fix_docx_format.py fix <unpacked_dir>                 # 修复全部需修改章节
  python fix_docx_format.py fix <unpacked_dir> --ch 1,7,10    # 仅修复指定章节
  python fix_docx_format.py fix <unpacked_dir> --dry-run      # 预览修改不实际写入

注意：本脚本操作的是解包后的 docx 目录（用 pack.py 解包后的目录），
     修复完成后需用 pack.py 重新打包为 .docx 文件。

依赖：lxml
"""

import argparse
import re
import sys
from pathlib import Path
from lxml import etree

NSMAP = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
W_NS = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'


# ─── 工具函数 ────────────────────────────────────────────────

def get_para_text(para):
    """获取段落纯文本"""
    return ''.join(t.text or '' for t in para.findall('.//w:t', NSMAP))


def get_para_style(para):
    """获取段落样式值"""
    pPr = para.find('w:pPr', NSMAP)
    if pPr is not None:
        pStyle = pPr.find('w:pStyle', NSMAP)
        if pStyle is not None:
            return pStyle.get(f'{W_NS}val', '')
    return ''


def is_heading(style_val):
    """判断是否为标题样式"""
    return style_val in ('2', '3', '4', '5', '36', '37', '38', '39')


def find_chapter_ranges(paras):
    """自动识别章节标题段落，返回 {章节名: (起始段落索引, 结束段落索引)}"""
    chapters = {}
    ch_pattern = re.compile(r'^(第\d+章)\s')
    
    heading_indices = []
    for i, para in enumerate(paras):
        text = get_para_text(para).strip()
        style = get_para_style(para)
        if ch_pattern.match(text) and is_heading(style):
            heading_indices.append((i, ch_pattern.match(text).group(1)))
    
    for idx, (para_idx, ch_name) in enumerate(heading_indices):
        end_idx = heading_indices[idx + 1][0] - 1 if idx + 1 < len(heading_indices) else len(paras) - 1
        chapters[ch_name] = (para_idx, end_idx)
    
    return chapters


# ─── 检查函数 ────────────────────────────────────────────────

def check_smart_quotes(para, para_idx):
    """检查中文双引号滥用（P0级）"""
    issues = []
    text = get_para_text(para)
    
    # 跳过空段落
    if not text.strip():
        return issues
    
    # 检查 \u201c \u201d
    left_count = text.count('\u201c')
    right_count = text.count('\u201d')
    
    if left_count > 0 or right_count > 0:
        # 提取引号内容
        quoted_contents = re.findall(r'[\u201c]([^\u201d]{1,80})[\u201d]', text)
        
        # 判断是否为合理使用（代码指令等）
        reasonable = []
        unreasonable = []
        for content in quoted_contents:
            # 代码指令特征：以动词开头，像对话
            if re.match(r'^(请|帮我|整理|生成|分析|写|制作|创建)', content):
                reasonable.append(content)
            else:
                unreasonable.append(content)
        
        if unreasonable:
            issues.append({
                'level': 'P0',
                'type': 'smart_quotes',
                'para_idx': para_idx,
                'count': len(unreasonable),
                'contents': unreasonable,
                'preview': text[:80]
            })
    
    return issues


def check_numbering(para, para_idx):
    """检查正文编号格式（P0级）"""
    issues = []
    text = get_para_text(para).strip()
    style = get_para_style(para)
    
    if not text or is_heading(style):
        return issues
    
    # 检查正文中的 (1) 或 （1）——无论是否在行首都算问题
    if re.search(r'[\(（]\d+[）\)]', text):
        issues.append({
            'level': 'P0',
            'type': 'numbering_paren',
            'para_idx': para_idx,
            'preview': text[:80]
        })
    
    # 检查正文中的 1. 2. 3. 格式（行首列举）
    if re.match(r'\d+\.\s', text):
        issues.append({
            'level': 'P0',
            'type': 'numbering_dot',
            'para_idx': para_idx,
            'preview': text[:80]
        })
    
    return issues


# ─── 修复函数 ────────────────────────────────────────────────

def fix_smart_quotes_in_text(text, is_code_context=False):
    """修复文本中的中文双引号
    
    策略：
    - 代码指令内容保留引号
    - 术语/概念名直接去掉引号
    - 短语引用改写为无引号形式
    
    返回 (修改后文本, 是否有修改)
    """
    if '\u201c' not in text and '\u201d' not in text:
        return text, False
    
    original = text
    
    # 提取所有引号对
    # 逐对处理
    result = []
    i = 0
    modified = False
    
    while i < len(text):
        if text[i] == '\u201c':
            # 找到对应的右引号
            end = text.find('\u201d', i + 1)
            if end == -1:
                result.append(text[i:])
                break
            
            content = text[i+1:end]
            
            # 判断是否保留
            # 1. 代码指令（以动词开头）→ 保留引号
            if re.match(r'^(请|帮我|整理|生成|分析|写|制作|创建|启动|运行|执行)', content):
                result.append('\u201c')
                result.append(content)
                result.append('\u201d')
            else:
                # 去掉引号，直接保留内容
                result.append(content)
                modified = True
            
            i = end + 1
        else:
            result.append(text[i])
            i += 1
    
    return ''.join(result), modified


def fix_numbering_in_text(text, style_val):
    """修复编号格式
    
    标题中 (1) 保持不变
    正文中 (1)/（1）→ 1），1. → 1）
    """
    if is_heading(style_val):
        return text, False
    
    original = text
    modified = False
    
    # (1) → 1）(全文匹配，不仅行首)
    new_text = re.sub(r'\((\d+)\)', r'\1）', text)
    # （1）→ 1）(全文匹配)
    new_text = re.sub(r'（(\d+)）', r'\1）', new_text)
    # 1. → 1）(行首数字+句号)
    new_text = re.sub(r'^(\d+)\.\s', r'\1）', new_text)
    
    if new_text != original:
        modified = True
    
    return new_text, modified


def apply_fix_to_para(para, fix_quotes=True, fix_numbering=True):
    """对一个段落应用所有修复，返回是否有修改"""
    style_val = get_para_style(para)
    any_modified = False
    
    for run in para.findall('w:r', NSMAP):
        t_elem = run.find('w:t', NSMAP)
        if t_elem is None or t_elem.text is None:
            continue
        
        text = t_elem.text
        modified = False
        
        if fix_quotes:
            text, q_mod = fix_smart_quotes_in_text(text)
            modified = modified or q_mod
        
        if fix_numbering:
            text, n_mod = fix_numbering_in_text(text, style_val)
            modified = modified or n_mod
        
        if modified:
            t_elem.text = text
            # 保留空格属性
            if t_elem.get(f'{W_NS}space') is None and text and (text[0] == ' ' or text[-1] == ' '):
                t_elem.set(f'{W_NS}space', 'preserve')
            any_modified = True
    
    return any_modified


# ─── 主逻辑 ──────────────────────────────────────────────────

def audit(unpacked_dir, chapter_filter=None):
    """审查模式：扫描并输出问题报告"""
    doc_path = Path(unpacked_dir) / 'word' / 'document.xml'
    tree = etree.parse(str(doc_path))
    body = tree.find('w:body', NSMAP)
    paras = body.findall('.//w:p', NSMAP)
    
    chapters = find_chapter_ranges(paras)
    
    if chapter_filter:
        ch_nums = set(chapter_filter)
        chapters = {k: v for k, v in chapters.items() 
                    if any(re.search(rf'{n}', k) for n in ch_nums)}
    
    total_issues = {'P0': 0, 'P1': 0, 'P2': 0}
    
    print("=" * 60)
    print("📋 中文出版书稿格式审查报告")
    print("=" * 60)
    
    for ch_name, (start, end) in sorted(chapters.items(), key=lambda x: x[1][0]):
        ch_issues = []
        
        for i in range(start, end + 1):
            para = paras[i]
            ch_issues.extend(check_smart_quotes(para, i))
            ch_issues.extend(check_numbering(para, i))
        
        # 统计
        p0_count = sum(1 for iss in ch_issues if iss['level'] == 'P0')
        quote_count = sum(iss.get('count', 1) for iss in ch_issues if iss['type'] == 'smart_quotes')
        number_count = sum(1 for iss in ch_issues if iss['type'] in ('numbering_paren', 'numbering_dot'))
        
        total_issues['P0'] += p0_count
        
        if p0_count > 0:
            severity = '🔴' if quote_count > 10 or number_count > 5 else '🟠'
            print(f"\n{severity} {ch_name} (段落 {start}-{end})")
            print(f"   双引号问题：{quote_count} 处")
            print(f"   编号格式问题：{number_count} 处")
            
            # 显示前3个样本
            for iss in ch_issues[:3]:
                print(f"   → 段落{iss['para_idx']}: {iss['preview'][:60]}...")
            if len(ch_issues) > 3:
                print(f"   ... 还有 {len(ch_issues)-3} 处问题")
        else:
            print(f"✅ {ch_name} (段落 {start}-{end}) — 未发现P0问题")
    
    print("\n" + "=" * 60)
    print(f"审查完成：共发现 P0 问题 {total_issues['P0']} 处")
    print("=" * 60)


def fix(unpacked_dir, chapter_filter=None, dry_run=False):
    """修复模式：精准修改指定章节"""
    doc_path = Path(unpacked_dir) / 'word' / 'document.xml'
    tree = etree.parse(str(doc_path))
    body = tree.find('w:body', NSMAP)
    paras = body.findall('.//w:p', NSMAP)
    
    chapters = find_chapter_ranges(paras)
    
    if chapter_filter:
        ch_nums = set(chapter_filter)
        chapters = {k: v for k, v in chapters.items() 
                    if any(re.search(rf'{n}', k) for n in ch_nums)}
    
    total_fixes = 0
    ch_fixes = {}
    
    for ch_name, (start, end) in sorted(chapters.items(), key=lambda x: x[1][0]):
        ch_fix_count = 0
        
        for i in range(start, end + 1):
            para = paras[i]
            if apply_fix_to_para(para):
                ch_fix_count += 1
        
        ch_fixes[ch_name] = ch_fix_count
        total_fixes += ch_fix_count
    
    if not dry_run and total_fixes > 0:
        # 备份原文件
        backup_path = str(doc_path) + '.bak'
        import shutil
        if not Path(backup_path).exists():
            shutil.copy2(str(doc_path), backup_path)
            print(f"📦 已备份至 {backup_path}")
        
        # 写入修改
        tree.write(str(doc_path), xml_declaration=True, encoding='UTF-8', standalone=True)
        print(f"✅ 已写入修改")
    
    # 输出报告
    print("\n" + "=" * 60)
    print("🔧 修复报告")
    print("=" * 60)
    
    for ch_name, count in sorted(ch_fixes.items()):
        status = '✅ 已修复' if count > 0 else '⏭️ 无需修改'
        print(f"  {ch_name}: {count} 个段落 {status}")
    
    action = "(预览)" if dry_run else "(已执行)"
    print(f"\n共修复 {total_fixes} 个段落 {action}")
    print("=" * 60)


def main():
    parser = argparse.ArgumentParser(description='中文出版书稿格式检查与修复工具')
    parser.add_argument('mode', choices=['audit', 'fix'], help='运行模式：audit=审查, fix=修复')
    parser.add_argument('unpacked_dir', help='解包后的docx目录路径')
    parser.add_argument('--ch', help='指定章节号，逗号分隔，如 1,7,10')
    parser.add_argument('--dry-run', action='store_true', help='预览修改不实际写入')
    
    args = parser.parse_args()
    
    chapter_filter = [c.strip() for c in args.ch.split(',')] if args.ch else None
    
    if args.mode == 'audit':
        audit(args.unpacked_dir, chapter_filter)
    else:
        fix(args.unpacked_dir, chapter_filter, args.dry_run)


if __name__ == '__main__':
    main()
