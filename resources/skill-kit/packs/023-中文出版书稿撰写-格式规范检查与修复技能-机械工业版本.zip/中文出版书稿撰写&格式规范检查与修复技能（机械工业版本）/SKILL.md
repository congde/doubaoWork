---
name: chinese-manuscript-format
description: 中文出版书稿格式规范检查与修复技能。当用户需要对中文书稿（.docx）进行出版格式审查、消除AI写作痕迹、修正编号格式、或按出版社反馈修改稿件时使用此技能。典型触发场景：出版社退修稿件、书稿格式规范化、AI味检测与消除、编号格式统一。
agent_created: true
---

# 中文出版书稿格式规范

## 概述

本技能提供中文出版书稿的格式审查和修复能力，重点解决两个核心问题：
1. **AI味消除**：检测并修复出版社判定为AI写作标志的格式问题
2. **出版规范对齐**：统一编号格式、图注表注位置等出版体例

## 工作流程

### 第一步：确定需求

识别用户的操作类型：
- **审查**：用户说"检查格式""看看有没有问题""出版社反馈了"→ 运行审查模式
- **修复**：用户说"帮我改""修复一下""按出版社要求修改"→ 先审查再修复
- **咨询**：用户问"出版格式有什么要求""双引号能不能用"→ 加载 `references/ai-signatures.md` 解答

### 第二步：审查（必做）

对 docx 文件执行格式审查，使用 `scripts/fix_docx_format.py`：

```bash
# 1. 解包 docx（用 docx 技能的 unpack 脚本）
python3 <docx_skill_path>/scripts/office/unpack.py input.docx /tmp/unpacked/

# 2. 审查全部章节
python3 <skill_path>/scripts/fix_docx_format.py audit /tmp/unpacked/

# 3. 审查指定章节
python3 <skill_path>/scripts/fix_docx_format.py audit /tmp/unpacked/ --ch 1,7,10
```

审查输出包含：
- 🔴 P0：必须修改（出版社明确点名的AI味问题）
- 🟠 P1：需要确认（样式规范，如底纹、截图底色）
- 🟡 P2：建议优化（内容层面的AI痕迹）

### 第三步：修复 P0 问题

P0 问题（中文双引号、编号格式）可自动修复：

```bash
# 预览修改（不实际写入）
python3 <skill_path>/scripts/fix_docx_format.py fix /tmp/unpacked/ --dry-run

# 实际修复全部章节
python3 <skill_path>/scripts/fix_docx_format.py fix /tmp/unpacked/

# 仅修复指定章节
python3 <skill_path>/scripts/fix_docx_format.py fix /tmp/unpacked/ --ch 1,10
```

修复完成后打包回 docx：
```bash
python3 <docx_skill_path>/scripts/office/pack.py /tmp/unpacked/ output.docx --original input.docx
```

### 第四步：处理 P1/P2 问题

P1 和 P2 问题无法自动修复，需要生成修改建议清单供人工处理：

| P1 问题 | 操作方式 |
|---------|---------|
| 提示词底纹 | 在 Word 中选中代码块 → 设置灰色底纹 |
| 截图底色 | 截图工具切换为白底/浅灰底 → 重新插入 |
| 图注位置 | 图注移至图片下方 |
| 表注位置 | 表注移至表格上方 |
| 长图分页 | 拆分长图 → 第二部分标注"（续）" |

## 核心规范速查

加载 `references/ai-signatures.md` 查看完整规范。以下为最常引用的要点：

### 中文双引号规则

| 场景 | 处理方式 |
|------|---------|
| 术语/概念名 | 直接去掉引号，融入句子 |
| 产品功能名 | 改用书名号《》或去掉引号 |
| 代码指令内容 | **保留引号**（如 `"请帮我整理数据"`） |
| 真实对话引用 | 保留引号 |

### 编号格式规则

| 场景 | 正确格式 | 错误格式 |
|------|---------|---------|
| 章节标题 | (1) 或（1） | — |
| 正文知识点 | 1）2）3） | (1) （1）1. |

### 修复精准性原则

修改大型 docx 文件时，必须确保：
1. **章节隔离**：仅修改指定章节的段落，不波及其他章节
2. **备份优先**：修改前自动备份 document.xml
3. **验证修改**：修复后统计每个章节的引号变化量，确认非目标章节无变化

## 资源文件

- `scripts/fix_docx_format.py`：核心修复脚本，支持 audit/fix 两种模式
- `references/ai-signatures.md`：完整的 AI 味特征库和修复方案
- `references/numbering-rules.md`：编号格式规范详情和正则表达式
