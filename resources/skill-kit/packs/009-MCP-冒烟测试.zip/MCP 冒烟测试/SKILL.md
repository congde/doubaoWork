---
name: mcp-stdio-smoke-test
description: "Smoke-test a stdio MCP server end-to-end when it is configured in ~/.workbuddy/mcp.json but not yet Trusted in the UI (so no mcp__ tools are available in the session). This skill should be used when a user asks 'test whether the MCP works / 测试下 MCP 是否可用 / 验证 MCP 能不能用' for a server that was just added but has no connected tools, or to debug a misbehaving MCP before trusting it."
agent_created: true
---

# MCP stdio 冒烟测试

## 用途

当某个 MCP 服务器已写入 `~/.workbuddy/mcp.json`，但**尚未在 UI 里 Trust**，
当前 WorkBuddy 会话里没有 `mcp__SERVER__*` 工具时，直接用 `mcp` Python SDK
把服务器作为子进程拉起来，走 stdio 协议做端到端验证：

`initialize` → `tools/list` → （可选）`tools/call`

这样无需先 Trust / 重载会话，就能证明「服务器本身能不能用、工具能不能返回数据」。

## 何时用

- 用户说「测试下 MCP 是否可用 / 验证 MCP 能不能用」且当前会话无该 MCP 工具。
- 接入新 MCP 后想先确认它能启动、列工具、返回真实数据，再决定是否 Trust。
- MCP 在 UI 里连接报错，需要判断是服务器问题还是 WorkBuddy 信任/配置问题。

## 前置条件

- 运行 MCP 所用的 Python 环境里装了 `mcp` SDK（含 `mcp.client.stdio` /
  `mcp.client.session`）。WorkBuddy 的 MCP 服务器一般用其自带 venv 的 python。
- 服务器脚本本身可独立运行（stdio 模式）。多数 `mcp.json` 里的 `command`+`args`
  就是 stdio 入口；若服务器默认走 HTTP，本方法不适用（需看其 `--transport` 参数）。
- macOS 没有 GNU `timeout` 命令，不要用 `timeout` 包裹；改用脚本自带超时或
  直接运行（SDK 自带连接超时）。

## 步骤

### 1. 确认 mcp SDK 可用

```bash
VENV/bin/python -c "import mcp; from mcp.client.stdio import stdio_client; from mcp.client.session import ClientSession; print('ok')"
```

### 2. 列工具（最轻量验证，证明服务器能启动并响应）

```bash
VENV/bin/python SKILL_DIR/scripts/smoke_test_mcp.py \
    --command VENV/bin/python \
    --args SERVER_PATH/server.py \
    --list-only
```

若 `initialize OK` 且打印出 `tools/list (N)` 及工具列表，说明服务器健康。

### 3. 实调一个工具（验证能返回真实数据）

从 `tools/list` 输出里挑一个无副作用的只读工具（如 `data_status` /
`alarm_stats` / `health`），用 `--call` + `--params`(JSON) 调用：

```bash
VENV/bin/python SKILL_DIR/scripts/smoke_test_mcp.py \
    --command VENV/bin/python \
    --args SERVER_PATH/server.py \
    --env KEY=VAL \
    --call alarm_stats --params '{"group_by":"outdoor_model","top":5}'
```

服务器自身的参数校验错误（如非法 enum 值）会被正确返回——这本身也证明
MCP 的输入校验链路工作正常，不等于测试失败。按报错提示修正 `--params` 即可。

### 4. 解读结果

- `initialize OK` + 工具列表 → 传输层与服务可用。
- 工具返回真实数据行 → 后端（DB/API）连通且逻辑正确。
- 若 `initialize` 阶段就报错 → 服务器脚本、依赖（如私有模块 `ecoer_privacy`）
  或连接串（`ECOER_PG_DSN` 等 env）有问题，先看 stderr。
- 若 `call_tool` 报 `Unknown tool` → 工具名记错了，以 `tools/list` 为准。
- 若 `call_tool` 报 pydantic `literal_error` → 参数取值不在枚举内，按工具
  schema 修正（例如按「机型」聚合时维度名是 `outdoor_model`/`indoor_model`，
  不是 `model`）。

## 注意事项

- 这是**独立验证手段**，不等同于在 WorkBuddy UI 里 Trust 后获得的原生
  `mcp__*` 工具。验证通过后，仍需提示用户在连接器管理页右上角「自定义连接器」
  里 Trust 该服务器，才能在对话中直接以工具形式调用。
- 只读地调用工具；不要借冒烟测试触发写操作或 `admin_unlock` 等敏感工具，
  除非用户明确要求。
- 测试连接串/口令等敏感信息来自用户提供的 `mcp.json`，不要写死进脚本或日志。
- `info.serverInfo` 在 SDK 里属性名是 `server_info`（带下划线），脚本已修正；
  自行写客户端时注意，否则会 AttributeError。
