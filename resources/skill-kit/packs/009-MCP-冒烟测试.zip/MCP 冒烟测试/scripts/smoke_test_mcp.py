#!/usr/bin/env python3
"""MCP stdio 冒烟测试客户端。

用途：当某个 MCP 服务器已写进 ~/.workbuddy/mcp.json 但尚未在 UI 里 Trust、
当前会话没有 mcp__xxx__* 工具时，直接用 mcp Python SDK 把服务器拉起来，
走 stdio 协议做端到端验证：initialize -> list_tools -> (可选) call_tool。

这能证明「服务器本身可用」，无需先 Trust / 重载会话。

用法：
  python smoke_test_mcp.py --command /path/venv/bin/python --args server.py \
      [--env KEY=VAL ...] [--call <tool> --params '{"k":"v"}']

示例（ecoer MCP）：
  python smoke_test_mcp.py \
      --command /Users/mac/Claude/Console/.venv/bin/python \
      --args /Users/mac/Claude/Console/ecoer_mcp.py \
      --env ECOER_PG_DSN=dbname=ecoer host=localhost \
      --call alarm_stats --params '{"group_by":"outdoor_model","top":5}'
"""
import argparse, asyncio, json, sys

from mcp.client.stdio import stdio_client, StdioServerParameters
from mcp.client.session import ClientSession


async def run(command, args, envs, call, params, list_only):
    params_obj = StdioServerParameters(command=command, args=args, env=envs or None)
    async with stdio_client(params_obj) as (r, w):
        async with ClientSession(r, w) as s:
            info = await s.initialize()
            print("=== initialize OK ===")
            print("server:", info.server_info.name, info.server_info.version)
            print("protocol:", info.protocol_version)

            tools = await s.list_tools()
            print(f"\n=== tools/list ({len(tools.tools)}) ===")
            for t in tools.tools:
                print(" -", t.name, "::", (t.description or "").split("\n")[0][:70])

            if list_only:
                print("\n=== LIST ONLY OK ===")
                return

            if not call:
                print("\n(未指定 --call，跳过调用。加 --call <tool> --params '{...}' 实调一个工具)")
                print("=== OK ===")
                return

            print(f"\n=== call: {call} ===")
            res = await s.call_tool(call, params or {})
            for c in res.content:
                txt = getattr(c, "text", None)
                if txt is not None:
                    print(txt[:3000])
            print("\n=== CALL OK ===")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--command", required=True, help="服务器可执行文件，如 venv 里的 python")
    ap.add_argument("--args", required=True, help="服务器脚本路径（单个参数即可）")
    ap.add_argument("--env", action="append", help="环境变量 KEY=VAL，可多次")
    ap.add_argument("--call", help="要调用的工具名（从 tools/list 里取）")
    ap.add_argument("--params", help="调用参数 JSON 字符串")
    ap.add_argument("--list-only", action="store_true", help="只列工具不调用")
    a = ap.parse_args()

    envs = {}
    for e in a.env or []:
        k, _, v = e.partition("=")
        envs[k] = v

    params = None
    if a.params:
        try:
            params = json.loads(a.params)
        except json.JSONDecodeError as ex:
            print("PARAMS JSON 解析失败:", ex); sys.exit(2)

    try:
        asyncio.run(run(a.command, [a.args], envs, a.call, params, a.list_only))
    except Exception as ex:
        print("\n!!! MCP 测试失败 !!!")
        print(type(ex).__name__, str(ex)[:2000])
        sys.exit(1)


if __name__ == "__main__":
    main()
