---
name: chat-daily-digest
description: 聊天记录按天整理成固定格式的 HTML 日报。输入聊天工具导出的 HTML/TXT/PDF，输出「总体看板（主题数、发言数、同比昨天、最积极 TOP5、最热主题 TOP5、关键提示、注意事项）+ 大类→发言人→要点」的结构化日报，自动过滤寒暄、屏蔽政治宗教话题、负面信息折叠不主动展示。当用户说「整理群聊」「群聊日报」「今天群里聊了什么」「爬楼」「群聊归档」「按天整理聊天记录」时触发。
agent_created: true
---

# 群聊日报（chat-daily-digest）

## 用途

把聊天记录导出文件（各类聊天工具 PC 端导出的 HTML / TXT / PDF 均可），按「一天一份」的粒度，蒸馏成**格式完全一致**的 HTML 日报。
核心价值是**跨天可比**：固定的看板指标、固定的分类体系、固定的 HTML 模板，
让"今天和昨天比活跃度降了多少""这个主题讨论了几天"变得可查。

与 `chat-html-distill` 的区别：那个做**一次性深度提纯**（话题地图 + 可信度分级 + 未决清单），
本技能做**每日流水线**（看板 + 同比 + 分类归档 + 模板化 HTML）。

## 隐私与合规（硬约束）

- **全程本地处理**：所有解析、统计、渲染都在本机脚本内完成，不联网、不上传任何聊天内容。
- **自动脱敏**：`config.json` 的 `privacy_patterns` 会命中手机号、身份证号、邮箱并做掩码处理。
- **不复现原文**：`cautions` 提示里禁止复现号码/身份证原文，只写掩码（如 `1********46`）+ 原文 id。
- **敏感话题**：政治、宗教等类目按 `config.json` 的 `sensitive` 表屏蔽并计数；负面信息折叠，不主动展示。
- **使用者责任**：日报内容仍是群聊原文的集合，分享前请自行确认已获得相关成员的同意。

## 执行流水线

```
S1 解析 → S2 语义整理（LLM）→ S2.5 溯源回填（脚本）→ S3 渲染 → S4 交付
```

### S1 解析：源文件 → 结构化消息流

```bash
python scripts/extract_chat.py "<导出文件>" --group "群聊名称" [--date YYYY-MM-DD] [--all-days]
```

- 支持 `.html` / `.htm`（聊天工具导出的网页格式）、`.txt` / `.md`、`.pdf`（需 `pip install pypdf`）。
- `--date` 是还原「今天/昨天」这类相对时间标签的锚点，缺省取今天。**导出的文件不是当天整理时，务必显式指定。**
- 默认只导出锚点日期当天；加 `--all-days` 导出文件中所有日期（批量补历史时用）。
- 产出落在 `<output_base>/<群名>/data/`：
  - `<date>_messages.jsonl` — 消息流，每行 `{id,date,time,speaker,text,type,sensitive}`
  - `<date>_clean.txt` — `[HH:MM] 昵称：正文`，供 LLM 读取的干净文本
  - `<date>_stats.json` — 确定性统计（总量、有效量、寒暄过滤数、发言人排行、敏感候选）

**已知限制**：图片/语音/视频内容不可读，只记为占位符；撤回消息不可考；自定义表情会丢失。

**引用消息的 DOM 语义（重要，曾导致 28% 消息正文丢失）**：

导出文件的引用消息结构里，`msg-refer-content` 是**发送者自己的正文**，
被引用原话在 `msg-refer-detail` 下的 `msg-refer-user`（回复对象）与 `msg-refer-text`（被引原文）。
早期的实现把 `msg-refer-content` 当成"被引用内容"提取后丢弃，导致 763/3301 条引用消息正文变空、
回退成"发言人名字+空"的垃圾。现脚本已修正：

- `MAIN_BODY_RE` 同时匹配 `msg-text-content` / `msg-share-body` / `msg-refer-content`
- 先用 `REFER_USER_RE` 取出回复对象（渲染成 `[回复 XXX] ` 前缀），再把 `msg-refer-user` 与 `msg-refer-text` 从片段中剔除，避免被引原文重复计入
- `FALLBACK_CLASS` 补齐 `msg-is-shipinhao` / `sharerecord` / `sharelocation` / `shareuser` / `shareweapp` 等类型

解析完**必须自查**：若 `clean.txt` 里大量消息是"昵称：昵称"或正文以发言人自己的名字开头，
说明正文提取失败，先修 `extract_chat.py` 再往下走，否则后面全是垃圾进垃圾出。
可用这条命令抽查正文以发言人名字开头的比例（`suspect` 应接近 0）：

```bash
python scripts/extract_chat.py "<导出文件>" --group "群名" --all-days --date YYYY-MM-DD 2>&1 | grep suspect
```

### S2 语义整理：读 clean.txt → 写 digest.json

这一步是本技能唯一的智力活，必须由模型完成。

1. 读 `<output_base>/<群名>/data/<date>_clean.txt`。
2. 若消息数 **> 600 条**，按时间顺序切成 2–4 段并行处理，最后合并（同一主题跨段合并，同一人同一大类的要点合并）。
3. 读 `references/taxonomy.md`（分类与主题切分规则）与 `references/moderation.md`（屏蔽与负面处理）。
4. 按 `references/schema.md` 的契约，写出 `<output_base>/<群名>/data/<date>_digest.json`。

**四条不可违反的约束**：

1. **严禁脑补** —— 每条要点必须有 `evidence`（`_messages.jsonl` 里的消息 `id`）。数字、日期、金额、人名、型号 100% 保留原文。推断出来的角色必须写 `[推断]`。
2. **不输出统计数字** —— 主题数、发言数、排行、同比全由脚本算，写了也无效。
3. **政治/宗教/不当内容零摘录** —— 只写进 `blocked` 的 `count` 与 `detail`，任何字段都不得出现原文片段。
4. **负面信息进 `negative`，不进正文** —— 客观陈述不复述原话，渲染后默认折叠。

**归类优先级**（详见 taxonomy.md）：决策 > 任务 > 风险 > 问题 > 资源 > 反馈 > 信息 > 闲聊。
固定八大类套不进去时，用 `x1`/`x2` 自定义 id 并在 `custom_categories` 里命名。

**`evidence` 的正确写法 —— 写 `evidence_text`，不要手写 id**：

`clean.txt` 里一条消息可能跨多行（长文、分点、转发），**行号 ≠ 消息 id**，
照着行号填 `evidence` 必然错位。正确做法是 S2 只写 `evidence_text`（原文片段数组），
由 S2.5 的脚本反查成 id：

```json
{"time": "14:09", "topic": "t3", "point": "整理发布汕头学生卡资费清单",
 "evidence_text": ["汕头市学生专属流量套餐（2026最新，三大运营商校园/学子卡）"]}
```

片段选取规则：
- 必须是**单条消息内**的连续子串（跨消息要拆成多个片段），20–30 字最稳
- 用消息中段的实词，别用开头（开头常带 `[回复 XXX]` 前缀）或纯表情
- 同一条要点引用多条消息时按**时间顺序**排列，脚本用游标匹配，乱序会退化成全局搜索（仍能命中，但可能张冠李戴）

### S2.5 溯源回填：evidence_text → evidence

```bash
python scripts/resolve_evidence.py --group "群聊名称" --date YYYY-MM-DD [--dry-run]
```

用「顺序游标 + 全文兜底」的子串匹配，把 `evidence_text` 解析成 `_messages.jsonl` 的 `id` 写回 `digest.json`。
输出会报告未匹配的片段，**出现 `[warn]` 必须修正后再渲染**（通常是片段跨了两条消息，拆开即可）。
`--dry-run` 只报告不写入。

### S3 渲染：数据 → HTML

```bash
python scripts/render_digest.py --group "群聊名称" --date YYYY-MM-DD
```

自动读取当天的 `stats.json` + `digest.json`，以及昨天的同名文件算同比，套用 `assets/template.html` 输出：

```
<output_base>/<群名>/html/<date>_<群名>_群聊日报.html
```

看板指标全部由脚本计算，不采信 LLM 给的任何数字：
主题数、按 `evidence` 聚合出的最热主题 TOP5、`stats.json` 的发言数/发言人数/TOP5 发言人、与昨天的增减与百分比。

### S4 交付

把生成的 HTML 文件路径告诉用户，由用户自行打开。
技能本身不得自动调用任何界面展示或文件预览能力。

## 输出目录结构

```
<output_base>/                      默认 %USERPROFILE%/Documents/群聊整理，改 config.json 的 output_base
└── <群名>/
    ├── html/2026-08-30_<群名>_群聊日报.html
    └── data/
        ├── 2026-08-30_messages.jsonl
        ├── 2026-08-30_clean.txt
        ├── 2026-08-30_stats.json
        ├── 2026-08-30_digest.json
        └── 2026-08-29_*.json        昨天的文件，用于算同比
```

`data/` 必须保留 —— 同比依赖昨天的 `stats.json` 与 `digest.json`，删了就退化成"无昨日数据"。

## 参数调整

改 `config.json` 即可，无需动脚本：

| 字段 | 作用 |
|---|---|
| `output_base` | 输出根目录 |
| `categories` | 固定大类（id / name / hint），**改 name 不影响 id，历史日报仍可比** |
| `chitchat_exact` / `chitchat_regex` / `min_length` | 寒暄去噪规则 |
| `sensitive` | 政治 / 宗教 / 其他不当的关键词表 |
| `negative_signals` | 负面信号词，辅助识别 |
| `top_n` | 排行 TOP N，默认 5 |

发现误伤（如业务群里正常的"政府补贴申报"被标敏感）→ 从 `sensitive` 里删词或细化。

## 常见问题

| 现象 | 排查 |
|---|---|
| 解析出 0 条消息 | 用 `--date` 指定锚点日期；或导出格式非标准，需给 `TXT_PATTERNS` 加正则 |
| 时间全是空的 | 源文件没带时间分隔标记，只能靠 `--date` 兜底 |
| 同比显示"无昨日数据" | 检查 `data/` 下是否有昨天的 `stats.json` 与 `digest.json`，两者缺一不可 |
| PDF 报缺库 | `python -m pip install pypdf` |
| 正文里发言人名字重复 | HTML 解析踩了 `msg-content` 外层容器的坑，已在脚本里白名单化处理；若导出工具改了 DOM 结构，需同步修 `TEXT_BODY_RE` |
| JSON 报 `Expecting ',' delimiter` | 字符串值里嵌了 ASCII 双引号。**写 digest.json 时一律用中文引号「」，不要用 `\"` 转义**（转义在多次读写后极易再次破损） |
| `resolve_evidence.py` 报片段未匹配 | 片段跨了两条消息 —— 拆成两个片段；或片段含表情占位符被清洗掉了 —— 换消息中段的实词 |
| 同一大类下同一人要拆多个 section | 渲染器按 section 遍历，允许 person 重名；若担心混淆可在 person 尾部加空格区分（`resolve_evidence.py` 不会 trim，改名前先确认） |
| 敏感候选其实是正常内容（误伤） | 人工复核后**照常收录进正文**，并在 `cautions` 里写明「脚本标记 N 条经复核为误伤，原因为 X」。屏蔽数只统计复核后确认的条数 |
| 需要在 `cautions` 里提示隐私信息 | **不要在提示里复现原文号码/身份证**，写成掩码（`1********46`）+ 原文 id，否则提示本身就成了泄露源 |

## 参考文件

- `references/schema.md` — digest.json 数据契约（S2 必读）
- `references/taxonomy.md` — 分类体系、主题切分、要点写法（S2 必读）
- `references/moderation.md` — 屏蔽、去噪、负面信息处理规则
