# digest.json 数据契约（LLM 唯一必须产出的文件）

`scripts/render_digest.py` 严格按本契约读取。**任何字段缺失或类型不符都会导致渲染出错或内容丢失。**

## 硬性规则（最重要）

1. **不得输出任何统计数字**。主题数、发言数、发言人数、TOP 排行、同比变化全部由 `render_digest.py` 从 `stats.json` 与 `evidence` 数组算出。写了也会被忽略。
2. **每条要点必须带溯源**。推荐写 `evidence_text`（原文片段数组），由 `resolve_evidence.py` 反查成 `evidence`（`_messages.jsonl` 里的 `id` 数组，至少 1 个）；直接写 `evidence` 也可以，但**不要照 clean.txt 的行号填**——一条消息可能跨多行，行号 ≠ id。无溯源的要点无法核查，视为脑补，禁止写入。
3. **`category` 只能取 config.json 里已定义的 `id`**；确需新增时，id 用 `x1`/`x2`…，并同时在 `custom_categories` 里给出 `name`。
4. **`topic` 必须是 `topics` 数组中已声明的 id**，不得凭空引用。
5. 只在正文中写"结论与价值"，**不写"张三说了很多""大家讨论了"这类空话**。

## 完整结构

```jsonc
{
  "group": "产品研发群",
  "date": "2026-08-30",
  "source_file": "E:/导出/产品研发群.html",

  "topics": [
    {
      "id": "t1",
      "name": "V2.3 版本发布节奏",      // ≤12 字，名词短语
      "desc": "是否延期到下周三的决策讨论",  // ≤40 字，一眼看懂在争什么
      "status": "open"                 // open 进行中 / closed 已闭环 / pending 待跟进
    }
  ],

  "sections": [                        // 大类 → 人 → 要点
    {
      "category": "decision",          // config 里的固定 id
      "category_name": "决策与结论",    // 省略时脚本取 config 里的默认名
      "person": "张三",                 // 群昵称，与 jsonl 中 speaker 完全一致
      "role": "项目负责人",              // 可省略；凡是推断出来的，必须写 "[推断] 项目负责人"
      "entries": [
        {
          "time": "09:12",             // 与 jsonl 中该消息的 time 一致
          "topic": "t1",               // 关联主题 id
          "point": "确认 V2.3 延期到下周三，先发灰度包",   // 提炼后的价值点，一条一个意思
          "quote": "那就下周三，我先出灰度",                // 可选，关键原话原文照录
          "evidence_text": ["那就下周三，我先出灰度", "灰度包只放 A 组"],  // 推荐：原文片段，由脚本反查 id
          "evidence": [12, 13]         // 由 resolve_evidence.py 回填；手写亦可，但勿用行号
        }
      ]
    }
  ],

  "key_notes": [                       // 3-6 条，今天最该知道的事
    "V2.3 延期至 9 月 6 日，灰度包先行"
  ],

  "cautions": [                        // 2-5 条，风险 / 待办 / 需跟进
    "李四承诺的压测报告还没交付，卡住发布评审"
  ],

  "negative": [                        // 负面信息，渲染后默认折叠，不主动展示
    {
      "title": "对排期调整的抱怨",
      "summary": "王五认为临时改期影响下游排产，情绪较强烈",   // 客观陈述，不复述煽动性原文
      "severity": "mid",               // high / mid / low
      "evidence": [48, 51]
    }
  ],

  "blocked": {                         // 政治 / 宗教 / 不当内容
    "count": 2,
    "detail": { "政治": 1, "宗教": 1 },
    "note": "两条涉及敏感话题，已按规则屏蔽，不计入正文"   // 只给类别与条数，禁止摘录内容
  },

  "custom_categories": [               // 仅当 sections 用到 x1/x2 时才填
    { "id": "x1", "name": "客户现场反馈" }
  ]
}
```

## 字段速查

| 字段 | 必填 | 说明 |
|---|---|---|
| `group` / `date` | ✅ | 与 `--group` / `--date` 一致，不一致以命令行参数为准 |
| `topics` | ✅ | 可为空数组（当天无实质讨论时） |
| `sections` | ✅ | 可为空数组 |
| `sections[].entries[].evidence_text` | ✅ | **推荐写法**：原文片段数组，交 `resolve_evidence.py` 回填 id。片段须是单条消息内的连续子串，多条按时间顺序排列 |
| `sections[].entries[].evidence` | ✅ | **至少 1 个 id**（手写或由脚本回填），这是反脑补的核心约束 |
| `negative[].evidence_text` | ✅ | 同上的推荐写法 |
| `key_notes` / `cautions` | ✅ | 可以是元素为字符串的数组，也支持 `{"text": "..."}` |
| `negative` | ✅ | 无则 `[]` |
| `blocked` | ✅ | 无则 `{"count": 0, "detail": {}}` |
| `custom_categories` | ⬜ | 仅使用自定义分类时需要 |

## 最小可用示例（当天几乎没内容）

```json
{
  "group": "产品研发群",
  "date": "2026-08-30",
  "topics": [],
  "sections": [],
  "key_notes": ["全天无实质性讨论"],
  "cautions": [],
  "negative": [],
  "blocked": { "count": 0, "detail": {} }
}
```
