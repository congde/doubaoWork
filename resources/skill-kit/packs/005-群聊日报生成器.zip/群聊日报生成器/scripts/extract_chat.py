#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extract_chat.py — 把聊天记录导出（HTML / TXT / PDF）解析为结构化消息流。

产出（写入 <output_base>/<群名>/data/）：
  <date>_messages.jsonl  每行一条消息：{id,date,time,speaker,text,type,sensitive}
  <date>_clean.txt       LLM 易读的分天文本：HH:MM 昵称：正文
  <date>_stats.json      确定性统计：总量/有效/寒暄/屏蔽候选/发言人排行/按小时分布

设计原则：脚本只做「确定性」的事（解析、去噪、计数），
语义层（主题识别、归类、价值提炼）交给 LLM，禁止脚本脑补。

用法：
  python scripts/extract_chat.py <输入文件> --group "群聊名称" [--date YYYY-MM-DD]
                                 [--outdir <base>] [--config <config.json>] [--all-days]
"""

import argparse
import html as ihtml
import json
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

# Windows 中文控制台默认 GBK(936)：UTF-8 字节流会显示成乱码。
# 因此跟随 PYTHONIOENCODING 环境变量（.bat 中已设为 gbk），
# 并用 errors="replace" 兜底，避免 emoji 触发 UnicodeEncodeError 中断整个流程。
try:
    sys.stdout.reconfigure(
        encoding=os.environ.get("PYTHONIOENCODING") or "utf-8",
        errors="replace",
    )
except Exception:
    pass

HERE = Path(__file__).resolve().parent
SKILL_DIR = HERE.parent
DEFAULT_CONFIG = SKILL_DIR / "config.json"

MEDIA_PLACEHOLDERS = {
    "[图片]", "[表情]", "[动画表情]", "[语音]", "[视频]", "[文件]",
    "[聊天记录]", "[链接]", "[位置]", "[名片]", "[撤回消息]", "[系统消息]",
}

SYSTEM_SPEAKER = "[系统]"

# ----------------------------- 通用工具 -----------------------------

def load_config(path: Path) -> dict:
    cfg = json.loads(DEFAULT_CONFIG.read_text(encoding="utf-8")) if DEFAULT_CONFIG.exists() else {}
    if path and Path(path).exists():
        cfg.update(json.loads(Path(path).read_text(encoding="utf-8")))
    return cfg


def strip_tags(s: str) -> str:
    s = re.sub(r"<br\s*/?>", "\n", s, flags=re.I)
    s = re.sub(r"</?(?:p|div|span|section)[^>]*>", "\n", s, flags=re.I)
    s = re.sub(r"<[^>]+>", "", s)
    s = ihtml.unescape(s)
    s = re.sub(r"[ \t\u00a0]+", " ", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def norm_date_token(tok: str, anchor: str, cur: str):
    """把日期 token 规范成 YYYY-MM-DD；无法识别返回 None。"""
    if not tok:
        return None
    tok = tok.strip()
    m = re.match(r"^(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})日?$", tok)
    if m:
        return f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    a = datetime.strptime(anchor, "%Y-%m-%d")
    if tok in ("今天", "今日"):
        return a.strftime("%Y-%m-%d")
    if tok in ("昨天", "昨日"):
        return (a - timedelta(days=1)).strftime("%Y-%m-%d")
    if tok in ("前天",):
        return (a - timedelta(days=2)).strftime("%Y-%m-%d")
    if re.fullmatch(r"(星期|周)[一二三四五六日天]", tok):
        return None
    return None


def norm_time_token(tok: str) -> str:
    m = re.search(r"(\d{1,2}):(\d{2})(?::(\d{2}))?", tok or "")
    if not m:
        return ""
    if m.group(3):
        return f"{int(m.group(1)):02d}:{m.group(2)}:{m.group(3)}"
    return f"{int(m.group(1)):02d}:{m.group(2)}"


# ----------------------------- HTML 解析 -----------------------------

GROUP_TIME_RE = re.compile(r'class="msg-grouptime"[^>]*>(.*?)</div>', re.S)
USER_NAME_RE = re.compile(r'<div class="user-name"[^>]*>(.*?)</div>', re.S)
MAIN_BODY_RE = re.compile(
    r'<div class="(?:msg-text-content|msg-share-body|msg-refer-content)"[^>]*>(.*?)</div>', re.S
)
# 坑4：msg-refer-content 是「发送者自己的正文」，不是被引用的内容。
#      被引用的原文在 msg-refer-detail > msg-refer-info > msg-refer-user / msg-refer-text。
#      早期版本把 refer-content 当引用丢掉，导致 23% 的消息正文被替换成重复垃圾，已修正。
REFER_USER_RE = re.compile(r'<span class="msg-refer-user"[^>]*>(.*?)</span>', re.S)
REFER_TEXT_RE = re.compile(r'<span class="msg-refer-text"[^>]*>(.*?)</span>', re.S)
EMOJI_RE = re.compile(r'<span title="([^"]*)" class="wx-emoji"[^>]*>.*?</span>', re.S)
IMG_TITLE_RE = re.compile(r'<img[^>]*title="([^"]*)"[^>]*>')

FALLBACK_CLASS = [
    ("msg-is-revoke", "[撤回消息]"),
    ("msg-is-image", "[图片]"),
    ("msg-is-sticker", "[表情]"),
    ("msg-is-emoji", "[表情]"),
    ("msg-is-voice", "[语音]"),
    ("msg-is-video", "[视频]"),
    ("msg-is-shipinhao", "[视频号]"),
    ("msg-is-file", "[文件]"),
    ("msg-is-chatrecord", "[聊天记录]"),
    ("msg-is-sharerecord", "[聊天记录]"),
    ("msg-is-location", "[位置]"),
    ("msg-is-sharelocation", "[位置]"),
    ("msg-is-card", "[名片]"),
    ("msg-is-shareuser", "[名片]"),
    ("msg-is-shareweapp", "[小程序]"),
]


def parse_html(path: Path, anchor: str):
    raw = path.read_text(encoding="utf-8", errors="ignore")

    # 坑1：必须先跳过 <style> 块，否则样式里的 .msg-item 选择器会被当成消息
    styles = list(re.finditer(r"</style>", raw, flags=re.I))
    body = raw[styles[-1].end():] if styles else raw

    # class="msg-item" 后面可能紧跟引号（无附加 class）或空格（msg-is-sender 等），两种都要匹配
    chunks = re.split(r'(?=<div class="msg-item["\s])', body)
    msgs, cur_date, cur_time = [], None, ""

    for ch in chunks:
        if '<div class="msg-item' not in ch:
            continue

        # 时间分隔标记
        if "msg-is-grouptime" in ch:
            gt = GROUP_TIME_RE.search(ch)
            label = strip_tags(gt.group(1)) if gt else ""
            tmatch = re.search(r"\d{1,2}:\d{2}", label)
            dtok = label[: tmatch.start()].strip() if tmatch else label.strip()
            d = norm_date_token(dtok, anchor, cur_date)
            if d:
                cur_date = d
            if tmatch:
                cur_time = norm_time_token(tmatch.group(0))
            continue

        # 系统消息
        if "msg-is-system" in ch:
            txt = strip_tags(ch)
            txt = re.sub(r"\s+", " ", txt)
            if txt:
                msgs.append({"date": cur_date or anchor, "time": cur_time,
                             "speaker": SYSTEM_SPEAKER, "text": txt, "type": "system"})
            continue

        # 发言人
        nm = USER_NAME_RE.search(ch)
        speaker = strip_tags(nm.group(1)) if nm else ""
        speaker = re.sub(r"\s+", " ", speaker).strip() or "未知"

        # 坑2：正则 msg-[a-z-]*content 会误匹配外层 msg-content 容器，
        #      必须白名单化，否则发言人名字会在正文里重复出现。
        # 坑3：引用块可能嵌在正文 div 内部，必须先摘出来再解析正文，否则内容重复。
        # 引用回复：取「被引用人」做归属标注；被引用的原文大多数已在正文出现过，不再重复保留
        reply_to = ""
        um = REFER_USER_RE.search(ch)
        if um:
            reply_to = strip_tags(um.group(1)).strip().rstrip(":：").strip()
        ch = REFER_USER_RE.sub("", ch)
        ch = REFER_TEXT_RE.sub("", ch)

        bodies = MAIN_BODY_RE.findall(ch)
        text = ""
        if bodies:
            parts = []
            for b in bodies:
                b = EMOJI_RE.sub(r"\1", b)
                b = IMG_TITLE_RE.sub(r"\1", b)
                t = strip_tags(b)
                if t:
                    parts.append(t)
            text = "\n".join(parts)
            if text and reply_to:
                text = f"[回复 {reply_to}] {text}"
        else:
            for cls, placeholder in FALLBACK_CLASS:
                if cls in ch:
                    text = placeholder
                    break
            if not text:
                t = strip_tags(ch)
                text = t if t and t != speaker else ""

        if not text:
            continue
        msgs.append({"date": cur_date or anchor, "time": cur_time,
                     "speaker": speaker, "text": text, "type": "user"})
    return msgs


# ----------------------------- TXT / PDF 解析 -----------------------------

TXT_PATTERNS = [
    # 2026-08-30 12:21:33 张三: 内容   |  [2026-08-30 12:21:33] 张三: 内容
    re.compile(
        r"^\[?\s*(?P<d>\d{4}[-/年.]\d{1,2}[-/月.]\d{1,2})日?[ T]?"
        r"(?P<t>\d{1,2}:\d{2}(?::\d{2})?)?\s*\]?\s+(?P<n>[^\s:：]{1,30})[:：]\s?(?P<m>.*)$", re.S),
    # 2026-08-30 12:21 张三   （无冒号）
    re.compile(
        r"^\[?\s*(?P<d>\d{4}[-/年.]\d{1,2}[-/月.]\d{1,2})日?[ T]?"
        r"(?P<t>\d{1,2}:\d{2}(?::\d{2})?)?\s*\]?\s+(?P<n>[^\s]{1,30})$", re.S),
    # 张三 2026年8月25日 12:21   （聊天记录 txt 导出常见）
    re.compile(
        r"^(?P<n>.{1,30}?)\s+(?P<d>\d{4}年\d{1,2}月\d{1,2}日)\s*"
        r"(?P<t>\d{1,2}:\d{2}(?::\d{2})?)?$", re.S),
]
SEP_DATE_RE = re.compile(r"^\s*-{2,}\s*(\d{4}[-/年.]\d{1,2}[-/月.]\d{1,2})日?\s*-{2,}\s*$")


def parse_txt(text: str, anchor: str):
    msgs, cur_date, cur = [], anchor, None
    for line in text.splitlines():
        if not line.strip():
            continue
        sep = SEP_DATE_RE.match(line)
        if sep:
            d = norm_date_token(sep.group(1), anchor, cur_date)
            if d:
                cur_date = d
            continue

        hit = None
        for pat in TXT_PATTERNS:
            hit = pat.match(line)
            if hit:
                break
        if hit:
            d = norm_date_token(hit.group("d"), anchor, cur_date)
            if d:
                cur_date = d
            tm = norm_time_token(hit.group("t") or "")
            name = hit.group("n").strip()
            body = (hit.groupdict().get("m") or "").strip()
            cur = {"date": cur_date, "time": tm, "speaker": name, "text": body, "type": "user"}
            if body:
                msgs.append(cur)
            elif cur not in msgs:
                msgs.append(cur)
        elif cur is not None:
            cur["text"] = (cur["text"] + "\n" + line.strip()).strip()
        else:
            msgs.append({"date": cur_date, "time": "", "speaker": "未知",
                         "text": line.strip(), "type": "user"})
    return [m for m in msgs if m.get("text")]


def pdf_to_text(path: Path) -> str:
    for mod in ("pypdf", "PyPDF2"):
        try:
            reader_cls = __import__(mod, fromlist=["PdfReader"]).PdfReader
            reader = reader_cls(str(path))
            return "\n".join((p.extract_text() or "") for p in reader.pages)
        except ImportError:
            continue
        except Exception:
            continue
    raise SystemExit(
        "缺少 PDF 解析库。请先安装：\n"
        "  python -m pip install pypdf\n"
        "或改用 HTML / TXT 导出。"
    )


# ----------------------------- 去噪 / 敏感扫描 -----------------------------

def is_chitchat(text: str, cfg: dict) -> bool:
    t = (text or "").strip()
    if not t:
        return True
    if t in MEDIA_PLACEHOLDERS:
        return True
    body = re.sub(r"\s", "", t)
    if not body:
        return True
    if body in set(cfg.get("keep_short", [])):
        return False
    if len(body) < int(cfg.get("min_length", 4)):
        return True
    core = re.sub(r"[\s\W_]", "", t).lower()
    exact = {re.sub(r"[\s\W_]", "", x).lower() for x in cfg.get("chitchat_exact", [])}
    if core in exact:
        return True
    for pat in cfg.get("chitchat_regex", []):
        try:
            if re.search(pat, t):
                return True
        except re.error:
            continue
    return False


def sensitive_hits(text: str, cfg: dict):
    hits = []
    for cat, words in (cfg.get("sensitive") or {}).items():
        for w in words:
            if w and w in text:
                hits.append(cat)
                break
    return sorted(set(hits))


# ----------------------------- 主流程 -----------------------------

def main():
    ap = argparse.ArgumentParser(description="聊天记录导出解析为结构化消息流")
    ap.add_argument("input", help="聊天工具导出的 .html / .txt / .md / .pdf 文件")
    ap.add_argument("--group", required=True, help="群聊名称（用于输出目录与标题）")
    ap.add_argument("--date", default=None, help="锚点日期 YYYY-MM-DD，用于还原「今天/昨天」")
    ap.add_argument("--outdir", default=None, help="输出根目录，默认取 config.output_base")
    ap.add_argument("--config", default=None, help="自定义配置文件路径")
    ap.add_argument("--all-days", action="store_true",
                    help="导出文件中所有日期（默认只导出锚点日期当天）")
    args = ap.parse_args()

    cfg = load_config(Path(args.config) if args.config else None)
    src = Path(args.input).expanduser()
    if not src.exists():
        raise SystemExit(f"输入文件不存在：{src}")

    anchor = args.date or datetime.now().strftime("%Y-%m-%d")
    ext = src.suffix.lower()

    if ext in (".html", ".htm"):
        msgs = parse_html(src, anchor)
    elif ext == ".pdf":
        msgs = parse_txt(pdf_to_text(src), anchor)
    else:
        msgs = parse_txt(src.read_text(encoding="utf-8", errors="ignore"), anchor)

    # 补齐日期 / 编号
    cur = anchor
    for i, m in enumerate(msgs, 1):
        if not m.get("date"):
            m["date"] = cur
        cur = m["date"]
        m["id"] = i

    # 去噪 + 敏感标记
    chitchat = 0
    sensitive_candidates = []
    kept = []
    for m in msgs:
        hits = sensitive_hits(m["text"], cfg)
        if hits:
            m["sensitive"] = hits
            sensitive_candidates.append({"id": m["id"], "time": m.get("time", ""),
                                         "speaker": m["speaker"], "reason": hits})
        if m["type"] == "system":
            kept.append(m)
            continue
        if is_chitchat(m["text"], cfg):
            chitchat += 1
            continue
        kept.append(m)

    # 按天分组
    by_day = defaultdict(list)
    for m in kept:
        by_day[m["date"]].append(m)

    if not by_day:
        raise SystemExit("未解析到任何消息。请检查文件格式，或用 --date 指定锚点日期后重试。")

    days = sorted(by_day)
    if not args.all_days and anchor in by_day:
        days = [anchor]
    elif not args.all_days:
        days = [days[-1]]

    base = Path(args.outdir or cfg.get("output_base", "./群聊整理")).expanduser()
    group_dir = base / args.group
    data_dir = group_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)

    written = []
    for day in days:
        day_msgs = by_day[day]
        jsonl = data_dir / f"{day}_messages.jsonl"
        clean = data_dir / f"{day}_clean.txt"
        stats_p = data_dir / f"{day}_stats.json"

        with jsonl.open("w", encoding="utf-8") as f:
            for m in day_msgs:
                f.write(json.dumps(m, ensure_ascii=False) + "\n")

        with clean.open("w", encoding="utf-8") as f:
            f.write(f"# 群聊：{args.group}   日期：{day}\n")
            f.write(f"# 共 {len(day_msgs)} 条有效消息（已过滤纯寒暄与媒体占位）\n")
            f.write("# 时间说明：导出文件只在时间分隔标记处给出时间，标记区间内的消息沿用该时间，"
                    "实际发生时间在该时刻之后数分钟内。\n\n")
            for m in day_msgs:
                f.write(f"[{m.get('time','')}] {m['speaker']}：{m['text']}\n")

        speakers = Counter(m["speaker"] for m in day_msgs if m["type"] == "user")
        hours = Counter((m.get("time") or "?").split(":")[0] for m in day_msgs)
        s_cand = [c for c in sensitive_candidates
                  if any(m["id"] == c["id"] for m in day_msgs)]

        stats = {
            "date": day,
            "group": args.group,
            "source_file": str(src),
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "raw_messages": len(msgs),
            "valid_messages": len(day_msgs),
            "chitchat_removed": chitchat if len(days) == 1 else None,
            "speaker_count": len(speakers),
            "speakers": dict(speakers.most_common()),
            "by_hour": dict(sorted(hours.items())),
            "sensitive_candidates": s_cand,
            "sensitive_count": len(s_cand),
        }
        stats_p.write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
        written.append((day, len(day_msgs), jsonl, stats_p))

    print("解析完成：")
    for day, n, j, s in written:
        print(f"  {day}  有效消息 {n} 条")
        print(f"    jsonl -> {j}")
        print(f"    stats -> {s}")
    print(f"  寒暄/无意义消息已过滤：{chitchat} 条；敏感候选：{len(sensitive_candidates)} 条（待 LLM 复核）")


if __name__ == "__main__":
    main()
