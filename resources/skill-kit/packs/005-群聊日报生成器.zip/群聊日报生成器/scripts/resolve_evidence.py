#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
resolve_evidence.py — 把 digest 里的「原文片段」解析成 jsonl 里的消息 id。

为什么需要这一步：
  clean.txt 里一条消息可能跨多行（长文、分点论述），所以「行号 → id」的映射不成立。
  人工按行号推算 evidence 极易错位。改为让 LLM 只提供**原文片段**，由脚本精确反查 id，
  既保证 evidence 100% 可溯源，又符合 schema「不采信 LLM 给的数字」的原则。

用法：
  python scripts/resolve_evidence.py --group "群聊名称" --date YYYY-MM-DD [--dry-run]

行为：
  - 读取 data/<date>_messages.jsonl 与 data/<date>_digest.json
  - 遍历 sections[].entries[] 与 negative[]，把 evidence_text[] 按原文片段顺序解析为 evidence[]
  - 片段采用「顺序游标」匹配：同一条目内的多个片段按时间先后依次向后查找，避免同文本重复时错位
  - 片段找不到时打印告警并把该片段计入 unresolved，不静默丢弃
  - 默认原地写回 digest.json（覆盖 evidence 字段），--dry-run 只报告不写入
"""

import argparse
import json
import os
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(
        encoding=os.environ.get("PYTHONIOENCODING") or "utf-8", errors="replace"
    )
except Exception:
    pass

HERE = Path(__file__).resolve().parent
SKILL_DIR = HERE.parent


def load_messages(jsonl: Path):
    msgs = []
    with jsonl.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                msgs.append(json.loads(line))
    return msgs


def resolve(digest: dict, msgs: list):
    """把 evidence_text[] 解析成 evidence[]。返回 (unresolved_list)。"""
    unresolved = []

    def resolve_one(entry: dict, where: str):
        frags = entry.pop("evidence_text", None)
        if frags is None:
            if not entry.get("evidence"):
                unresolved.append((where, "<无 evidence / evidence_text>", ""))
            return
        ids = []
        cursor = 0
        for frag in frags:
            frag = (frag or "").strip()
            if not frag:
                continue
            hit = None
            for i in range(cursor, len(msgs)):
                if frag in msgs[i]["text"]:
                    hit = msgs[i]["id"]
                    cursor = i + 1
                    break
            if hit is None:  # 回退：允许片段出现在游标之前（例如同一条目内乱序引用）
                for i in range(0, len(msgs)):
                    if frag in msgs[i]["text"]:
                        hit = msgs[i]["id"]
                        break
            if hit is None:
                unresolved.append((where, frag, ""))
            else:
                ids.append(hit)
        existing = entry.get("evidence") or []
        merged = sorted(set(existing) | set(ids))
        entry["evidence"] = merged

    for si, s in enumerate(digest.get("sections") or []):
        person = s.get("person", "?")
        for ei, e in enumerate(s.get("entries") or []):
            resolve_one(e, f"sections[{si}].{person}.entries[{ei}]")

    for ni, n in enumerate(digest.get("negative") or []):
        resolve_one(n, f"negative[{ni}]")

    return unresolved


def main():
    ap = argparse.ArgumentParser(description="把 digest 的原文片段解析为消息 id")
    ap.add_argument("--group", required=True)
    ap.add_argument("--date", required=True)
    ap.add_argument("--base", default=None, help="输出根目录，默认取 config.output_base")
    ap.add_argument("--digest", default=None, help="digest.json 路径（默认自动查找）")
    ap.add_argument("--dry-run", action="store_true", help="只报告，不写回文件")
    args = ap.parse_args()

    cfg = {}
    cfg_p = SKILL_DIR / "config.json"
    if cfg_p.exists():
        cfg = json.loads(cfg_p.read_text(encoding="utf-8"))

    base = Path(args.base or cfg.get("output_base", "./群聊整理")).expanduser()
    data_dir = base / args.group / "data"
    digest_p = Path(args.digest) if args.digest else data_dir / f"{args.date}_digest.json"
    jsonl_p = data_dir / f"{args.date}_messages.jsonl"

    if not digest_p.exists():
        raise SystemExit(f"缺少 digest.json：{digest_p}")
    if not jsonl_p.exists():
        raise SystemExit(f"缺少 messages.jsonl：{jsonl_p}")

    digest = json.loads(digest_p.read_text(encoding="utf-8"))
    msgs = load_messages(jsonl_p)

    unresolved = resolve(digest, msgs)

    total = 0
    empty = 0
    for s in digest.get("sections") or []:
        for e in s.get("entries") or []:
            total += 1
            if not e.get("evidence"):
                empty += 1

    print(f"解析对象：{digest_p.name}（消息库 {len(msgs)} 条）")
    print(f"  要点总数 {total} 条，其中无 evidence 的 {empty} 条")
    if unresolved:
        print(f"  [warn] 有 {len(unresolved)} 个原文片段未能匹配，请核对：")
        for where, frag, _ in unresolved:
            print(f"    - {where}: {frag[:60]}")
    else:
        print("  全部原文片段匹配成功")

    if not args.dry_run:
        with digest_p.open("w", encoding="utf-8", newline="\n") as f:
            json.dump(digest, f, ensure_ascii=False, indent=2)
        print(f"  已写回：{digest_p}")


if __name__ == "__main__":
    main()
