#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
render_digest.py — 把 LLM 产出的 digest.json + 脚本产出的 stats.json 渲染成日报 HTML。

职责边界：
  - 本脚本只做「确定性渲染与统计」，不做任何语义判断。
  - 主题数、发言数、发言人数、TOP 排行、同比变化 —— 全部由脚本从数据算出，
    不接受 LLM 直接给数字（防脑补）。

用法：
  python scripts/render_digest.py --group "群聊名称" --date YYYY-MM-DD
                                  [--base <输出根目录>] [--digest <digest.json>]
                                  [--template <template.html>] [--config <config.json>]
输出：
  <base>/<群名>/html/<date>_<群名>_群聊日报.html
"""

import argparse
import html as ihtml
import json
import os
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

# 同 extract_chat.py：跟随 PYTHONIOENCODING（.bat 中设为 gbk），
# 保证 Windows 中文控制台下中文路径与提示不乱码、emoji 不中断流程。
try:
    sys.stdout.reconfigure(
        encoding=os.environ.get("PYTHONIOENCODING") or "utf-8",
        errors="replace",
    )
except Exception:
    pass

HERE = Path(__file__).resolve().parent
SKILL_DIR = HERE.parent
DEFAULT_CONFIG = SKILL_DIR / "config.json"
DEFAULT_TEMPLATE = SKILL_DIR / "assets" / "template.html"

WEEKDAYS = ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"]
SEV_LABEL = {"high": "高", "mid": "中", "low": "低"}


# ----------------------------- 工具 -----------------------------

def esc(s) -> str:
    return ihtml.escape("" if s is None else str(s), quote=False)


def load_json(p: Path, default=None):
    if not p or not Path(p).exists():
        return default
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[warn] 无法解析 {p}：{e}")
        return default


def load_config(path):
    cfg = json.loads(DEFAULT_CONFIG.read_text(encoding="utf-8")) if DEFAULT_CONFIG.exists() else {}
    if path and Path(path).exists():
        cfg.update(json.loads(Path(path).read_text(encoding="utf-8")))
    return cfg


def weekday_of(date_str: str) -> str:
    try:
        return WEEKDAYS[datetime.strptime(date_str, "%Y-%m-%d").weekday()]
    except Exception:
        return ""


def delta_html(cur, prev, unit="", pct=True):
    """生成同比变化 HTML（上升绿 / 下降橙 / 持平灰）。"""
    if prev is None:
        return '<span class="flat">— 昨日无数据</span>'
    d = cur - prev
    if prev == 0:
        return '<span class="flat">— 昨日为 0，无可比值</span>' if d == 0 else \
            f'<span class="up">↑ 昨日为 0</span>'
    if d == 0:
        return '<span class="flat">— 与昨日持平</span>'
    arrow = "↑" if d > 0 else "↓"
    cls = "up" if d > 0 else "down"
    pct_txt = f"（{abs(d) / prev * 100:.0f}%）" if pct else ""
    return f'<span class="{cls}">{arrow} {abs(d)}{unit} {pct_txt}</span>'


# ----------------------------- 片段构造 -----------------------------

def build_kpi_cards(cur: dict, prev: dict) -> str:
    items = [
        ("今日主题数", cur["topics"], prev["topics"] if prev else None, "个"),
        ("有效发言数", cur["messages"], prev["messages"] if prev else None, "条"),
        ("发言人数", cur["speakers"], prev["speakers"] if prev else None, "人"),
        ("已屏蔽条数", cur["blocked"], prev["blocked"] if prev else None, "条"),
    ]
    out = []
    for label, c, p, unit in items:
        out.append(
            f'<div class="kpi"><div class="label">{esc(label)}</div>'
            f'<div class="value">{c}<span style="font-size:14px;font-weight:400;color:#8b939c;"> {unit}</span></div>'
            f'<div class="delta">较昨日 {delta_html(c, p, unit)}</div></div>'
        )
    return "".join(out)


def build_speaker_rows(stats: dict, top_n: int) -> str:
    speakers = [(k, v) for k, v in (stats.get("speakers") or {}).items() if k]
    if not speakers:
        return '<div class="empty">今日无有效发言记录。</div>'
    speakers.sort(key=lambda x: -x[1])
    top = speakers[:top_n]
    mx = max(v for _, v in top) or 1
    rows = []
    for i, (name, cnt) in enumerate(top, 1):
        w = int(cnt / mx * 100)
        rows.append(
            f'<li><span class="no">{i}</span><span class="name">{esc(name)}</span>'
            f'<span class="bar"><i style="width:{w}%"></i></span>'
            f'<span class="num">{cnt} 条</span></li>'
        )
    return f'<ol class="rank">{"".join(rows)}</ol>'


def build_topic_rows(heat: list, top_n: int) -> str:
    if not heat:
        return '<div class="empty">今日未识别出明确主题。</div>'
    mx = max(h["msgs"] for h in heat) or 1
    rows = []
    for i, h in enumerate(heat[:top_n], 1):
        status = {"open": "进行中", "closed": "已闭环", "pending": "待跟进"}.get(h.get("status"), "")
        desc = h.get("desc") or ""
        rows.append(
            f'<div class="topic-row"><span class="no" style="flex:0 0 20px;height:20px;line-height:20px;'
            f'text-align:center;border-radius:6px;font-size:11px;font-weight:700;'
            f'background:#eaf1ff;color:#2f6fed;">{i}</span>'
            f'<div style="flex:1;min-width:0;">'
            f'<div class="t-name">{esc(h["name"])}</div>'
            f'<div class="t-desc">{esc(desc)}</div>'
            f'<div class="bar" style="height:6px;background:#eef0f3;border-radius:999px;margin-top:6px;overflow:hidden;">'
            f'<i style="display:block;height:100%;width:{int(h["msgs"] / mx * 100)}%;'
            f'background:linear-gradient(90deg,#2f6fed,#7aa7ff);"></i></div>'
            f'</div>'
            f'<span class="t-meta">{h["msgs"]} 条 · {h["persons"]} 人{(" · " + status) if status else ""}</span></div>'
        )
    return "".join(rows)


def build_notes(items, cls, icon) -> str:
    if not items:
        return '<div class="empty">今日无特别需要提示的内容。</div>'
    out = []
    for it in items:
        txt = it if isinstance(it, str) else (it.get("text") or it.get("point") or "")
        out.append(f'<div class="note {cls}"><span class="ico">{icon}</span><p>{esc(txt)}</p></div>')
    return "".join(out)


def build_sections(sections: list, cat_meta: dict, topic_names: dict) -> str:
    if not sections:
        return '<div class="empty">今日无实质性讨论内容（全部为寒暄或已被过滤）。</div>'

    grouped = defaultdict(list)
    order = []
    for s in sections:
        cid = s.get("category") or "other"
        if cid not in grouped:
            order.append(cid)
        grouped[cid].append(s)

    # 固定分类顺序优先，自适应分类排在后面
    fixed = [c["id"] for c in cat_meta]
    order.sort(key=lambda c: (fixed.index(c) if c in fixed else 99, c))
    # 闲聊类排最后
    if "chitchat" in order:
        order.remove("chitchat")
        order.append("chitchat")

    htmls = []
    for cid in order:
        secs = grouped[cid]
        name = next((s.get("category_name") for s in secs if s.get("category_name")), None)
        if not name:
            name = next((c["name"] for c in cat_meta if c["id"] == cid), cid)
        total = sum(len(s.get("entries") or []) for s in secs)
        if cid == "chitchat":
            block = (
                f'<details class="collapse"><summary>{esc(name)}（{total} 条，无实质内容，默认折叠）</summary>'
                f'<div class="body">{_render_persons(secs, topic_names)}</div></details>'
            )
            htmls.append(block)
            continue
        htmls.append(
            f'<div class="cat"><div class="cat-head"><span class="cname">{esc(name)}</span>'
            f'<span class="ccount">{total} 条要点 · {len(secs)} 人</span></div>'
            f'{_render_persons(secs, topic_names)}</div>'
        )
    return "".join(htmls)


def _render_persons(secs: list, topic_names: dict) -> str:
    secs = sorted(secs, key=lambda s: -len(s.get("entries") or []))
    out = []
    for s in secs:
        person = s.get("person") or "未知"
        role = s.get("role") or ""
        initial = esc(person[:1]) if person else "?"
        lis = []
        for e in (s.get("entries") or []):
            tm = esc(e.get("time") or "")
            tid = e.get("topic")
            tag = f'<span class="tag">{esc(topic_names.get(tid, tid))}</span>' if tid else ""
            quote = e.get("quote")
            q = f'<span class="quote">原文：{esc(quote)}</span>' if quote else ""
            lis.append(
                f'<li>{tag}<span class="tm">{tm}</span>{esc(e.get("point", ""))}{q}</li>'
            )
        out.append(
            f'<div class="person"><div class="person-head">'
            f'<span class="avatar">{initial}</span><span>{esc(person)}</span>'
            f'<span class="role">{esc(role)}</span>'
            f'<span class="pcount">{len(lis)} 条</span></div>'
            f'<ul class="points">{"".join(lis)}</ul></div>'
        )
    return "".join(out)


def build_negative(negative: list, topic_names: dict) -> str:
    if not negative:
        return '<div class="empty">今日未发现需要单独记录的负面信息。</div>'
    out = []
    for n in negative:
        sev = (n.get("severity") or "low").lower()
        sev_label = SEV_LABEL.get(sev, "低")
        ev = n.get("evidence") or []
        ev_txt = f'<div style="margin-top:6px;color:#8b939c;font-size:12px;">关联消息：{esc(", ".join(str(x) for x in ev))}</div>' if ev else ""
        out.append(
            f'<details class="collapse"><summary>'
            f'<span class="sev {sev}">{sev_label}</span> {esc(n.get("title") or "负面信息")}</summary>'
            f'<div class="body">{esc(n.get("summary", ""))}{ev_txt}</div></details>'
        )
    return "".join(out)


def build_governance(blocked: dict, stats: dict, cfg: dict) -> str:
    lines = []
    b = blocked or {}
    cnt = b.get("count", 0)
    detail = b.get("detail") or {}
    lines.append(f'<div class="note warn"><span class="ico">🛡️</span><p>'
                 f'<b>敏感话题屏蔽：{cnt} 条</b>'
                 f'{("（" + "、".join(f"{esc(k)} {v} 条" for k, v in detail.items()) + "）") if detail else ""}'
                 f'。按预设规则，政治 / 宗教 / 不当内容不进入正文，仅保留计数。</p></div>')
    chit = stats.get("chitchat_removed")
    if chit is not None:
        lines.append(f'<div class="note"><span class="ico">🧹</span><p>'
                     f'寒暄与无实质内容过滤：<b>{chit}</b> 条（含「收到/好的/谢谢」、纯表情、纯图片语音占位）。</p></div>')
    cand = stats.get("sensitive_count", 0)
    lines.append(f'<div class="note"><span class="ico">🔎</span><p>'
                 f'关键词初筛敏感候选：<b>{cand}</b> 条，已交由模型复核后定级。</p></div>')
    lines.append('<div class="note"><span class="ico">📌</span><p>'
                 '所有数字由脚本从原始消息统计得出；主题、归类与价值提炼由模型完成，推断内容已显式标注。</p></div>')
    return "".join(lines)


# ----------------------------- 主流程 -----------------------------

def main():
    ap = argparse.ArgumentParser(description="渲染群聊日报 HTML")
    ap.add_argument("--group", required=True, help="群聊名称")
    ap.add_argument("--date", required=True, help="日期 YYYY-MM-DD")
    ap.add_argument("--base", default=None, help="输出根目录，默认取 config.output_base")
    ap.add_argument("--digest", default=None, help="digest.json 路径（默认自动查找）")
    ap.add_argument("--template", default=None, help="HTML 模板路径")
    ap.add_argument("--config", default=None, help="自定义配置")
    args = ap.parse_args()

    cfg = load_config(Path(args.config) if args.config else None)
    base = Path(args.base or cfg.get("output_base", "./群聊整理")).expanduser()
    group_dir = base / args.group
    data_dir = group_dir / "data"
    html_dir = group_dir / "html"
    html_dir.mkdir(parents=True, exist_ok=True)

    digest_p = Path(args.digest) if args.digest else data_dir / f"{args.date}_digest.json"
    stats_p = data_dir / f"{args.date}_stats.json"
    digest = load_json(digest_p, None)
    stats = load_json(stats_p, None)
    if digest is None:
        raise SystemExit(f"缺少语义整理结果：{digest_p}\n请由 LLM 按 references/schema.md 生成 digest.json 后再渲染。")
    if stats is None:
        raise SystemExit(f"缺少统计文件：{stats_p}\n请先运行 scripts/extract_chat.py。")

    y = (datetime.strptime(args.date, "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m-%d")
    prev_stats = load_json(data_dir / f"{y}_stats.json", None)
    prev_digest = load_json(data_dir / f"{y}_digest.json", None)

    # ---- 主题热度：由脚本按 evidence 统计，不采信 LLM 给的数字 ----
    topics = digest.get("topics") or []
    topic_names = {t.get("id"): (t.get("name") or t.get("id")) for t in topics}
    topic_meta = {t.get("id"): t for t in topics}

    heat_map, person_map = defaultdict(set), defaultdict(set)
    for s in digest.get("sections") or []:
        for e in s.get("entries") or []:
            tid = e.get("topic")
            for mid in (e.get("evidence") or []):
                if tid:
                    heat_map[tid].add(mid)
            if tid:
                person_map[tid].add(s.get("person") or "未知")
    heat = []
    for tid, ids in heat_map.items():
        heat.append({
            "id": tid,
            "name": topic_names.get(tid, tid),
            "desc": (topic_meta.get(tid) or {}).get("desc", ""),
            "status": (topic_meta.get(tid) or {}).get("status", ""),
            "msgs": len(ids),
            "persons": len(person_map.get(tid, ())),
        })
    heat.sort(key=lambda h: (-(h["msgs"] + h["persons"] * 2), -h["msgs"]))
    # 未挂载到任何主题的主题也需出现（0 条则沉底）
    seen = {h["id"] for h in heat}
    for t in topics:
        if t.get("id") not in seen:
            heat.append({"id": t.get("id"), "name": t.get("name"), "desc": t.get("desc", ""),
                         "status": t.get("status", ""), "msgs": 0, "persons": 0})

    cur = {
        "topics": len(topics),
        "messages": int(stats.get("valid_messages", 0)),
        "speakers": int(stats.get("speaker_count", 0)),
        "blocked": int((digest.get("blocked") or {}).get("count", 0)),
    }
    prev = None
    if prev_stats and prev_digest:
        prev = {
            "topics": len(prev_digest.get("topics") or []),
            "messages": int(prev_stats.get("valid_messages", 0)),
            "speakers": int(prev_stats.get("speaker_count", 0)),
            "blocked": int((prev_digest.get("blocked") or {}).get("count", 0)),
        }

    top_n = int(cfg.get("top_n", 5))
    cat_meta = cfg.get("categories", [])

    tpl_path = Path(args.template) if args.template else DEFAULT_TEMPLATE
    tpl = tpl_path.read_text(encoding="utf-8")

    mapping = {
        "{{DOC_TITLE}}": f"{args.date} · {args.group} · 群聊日报",
        "{{GROUP_NAME}}": esc(args.group),
        "{{DATE}}": esc(args.date),
        "{{WEEKDAY}}": weekday_of(args.date),
        "{{SPEAKER_COUNT}}": str(cur["speakers"]),
        "{{VALID_MESSAGES}}": str(cur["messages"]),
        "{{TOPIC_COUNT}}": str(cur["topics"]),
        "{{GENERATED_AT}}": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "{{SOURCE_FILE}}": esc(stats.get("source_file", "")),
        "{{TOP_N}}": str(top_n),
        "{{KPI_CARDS}}": build_kpi_cards(cur, prev),
        "{{SPEAKER_ROWS}}": build_speaker_rows(stats, top_n),
        "{{TOPIC_ROWS}}": build_topic_rows(heat, top_n),
        "{{NOTES_HTML}}": build_notes(digest.get("key_notes"), "key", "•"),
        "{{CAUTIONS_HTML}}": build_notes(digest.get("cautions"), "warn", "!"),
        "{{SECTIONS_HTML}}": build_sections(digest.get("sections") or [], cat_meta, topic_names),
        "{{NEGATIVE_HTML}}": build_negative(digest.get("negative") or [], topic_names),
        "{{GOVERNANCE_HTML}}": build_governance(digest.get("blocked"), stats, cfg),
        "{{STATS_STRIP}}": (f"原始消息 {stats.get('raw_messages', '-')} 条 · 有效 {cur['messages']} 条 · "
                            f"发言人 {cur['speakers']} 人 · 主题 {cur['topics']} 个 · "
                            f"屏蔽 {cur['blocked']} 条"
                            + (f" · 昨日同比：发言 {('+' if cur['messages'] - prev['messages'] >= 0 else '-')}"
                               f"{abs(cur['messages'] - prev['messages'])} 条" if prev else "")),
    }

    out = tpl
    for k, v in mapping.items():
        out = out.replace(k, v)

    out_file = html_dir / f"{args.date}_{args.group}_群聊日报.html"
    out_file.write_text(out, encoding="utf-8")
    print(f"[完成] 日报已生成：{out_file}")
    print(f"   主题 {cur['topics']} 个 · 有效发言 {cur['messages']} 条 · 发言人 {cur['speakers']} 人 · 屏蔽 {cur['blocked']} 条")
    if prev is None:
        print("   （未找到昨日数据，同比显示为「无昨日数据」）")


if __name__ == "__main__":
    main()
