# Marketplace 发布说明

- Skill：`capcut-desktop-editing-assistant`
- 状态：第二批脱敏候选包。上传前确认原创/授权并选择 `LICENSE`。
- 凭据：只允许通过环境变量、Secret Store 或系统 Keychain 注入。
- 费用：付费服务必须标为可选，调用前披露费用和数据去向。
- 副作用：真实发布、支付、账户修改、部署与删除动作默认关闭，执行前确认。
- 隐私：不得附带 Cookie、Token、真实账号、截图、日志、客户数据或内部基础设施信息。
