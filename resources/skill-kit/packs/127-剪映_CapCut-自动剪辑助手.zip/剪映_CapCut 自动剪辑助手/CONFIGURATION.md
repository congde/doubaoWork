# 配置与依赖

- 平台：macOS；剪映专业版/CapCut 桌面端。
- 自动化：宿主提供的 Computer Use。
- 可选命令：`ffprobe`。
- 可选适配器：ASR/自动粗剪服务；Provider、API Key、地区和费用由用户配置。
- 核心 Skill 不需要 API Key，不修改原始素材，导出前确认路径和参数。
