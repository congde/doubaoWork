---
name: nk-douyin-image-publish-workflow
description: 南柯版抖音图文发布闭环，通过 Windows 独立 Edge 和 CDP 准备并核验图片、标题与正文，严格选择抖音平台 BGM 与现有合集，执行发布前人工确认门禁，并在发布后回读标题、图片数量、状态、合集和配乐证据。当用户明确要求准备或发布抖音图文、给抖音图文选择 BGM 或合集、核验抖音图文发布结果时使用。仅处理抖音图文，不用于抖音视频发布、单纯文案创作、图片生成或未经人工确认的自动发布。
---

# 南柯抖音图文发布工作流

## 核心边界

- 只处理抖音图文。抖音视频、文章、直播和纯内容创作转交对应工作流。
- 只使用抖音平台曲库。不得在发布流程中生成或上传来源不明的音乐。
- 默认只准备，不发布。没有用户对当前标题、正文、图片、BGM、合集的明确确认时，禁止进入发布阶段。
- 外部发布前扫描 L2/L3 信息。命中商务敏感、个人隐私、健康数据或凭据时，中止并按青喵科技 AI 治理规范处理。
- 全程使用独立 Edge profile；不得连接用户日常 Edge。
- 同一时间只允许一个南柯抖音发布任务持有全局发布锁。发现锁文件时先核对旧进程，不得直接绕过并发门禁。
- 默认保留浏览器并停留在内容管理页。仅在用户明确要求时关闭独立浏览器。

## 工具与目录

- Windows、Edge、Node.js 22 及以上。
- 默认调试端口：`9231`。可用 `NK_DOUYIN_CDP_PORT` 覆盖。
- 默认独立 profile：`C:\temp\nk-douyin-image-publish`。
- 所有脚本都在 `scripts/`。配置字段见 [references/config-schema.md](references/config-schema.md)。验收分层见 [references/acceptance.md](references/acceptance.md)。
- 创建合集、等待审核或给历史作品补合集时，先读 [references/collection-admin.md](references/collection-admin.md)。

## 执行流程

### 1. 启动独立浏览器并检查登录

```powershell
powershell -ExecutionPolicy Bypass -File scripts/start_edge.ps1
$env:NK_DOUYIN_CDP_PORT='9231'
node scripts/login_check.js D:\evidence\douyin-login.png
```

启动和登录规则：

- `start_edge.ps1` 只启动默认独立 profile，不复制其他浏览器的 Cookie 或会话目录。
- 调试端口已被其他进程占用或 CDP 无响应时中止。准备后始终使用 `state.targetId` 锁定原编辑页；临时只读页只能用于账号和作品基线复核。
- 未登录时保留扫码页给用户。无人值守模式设置 `UNATTENDED=1`，遇到扫码直接中止。

### 2. 生成唯一配置并验证

每次发布使用新的绝对 `evidenceDir` 和 `runId`。不要复用历史证据目录。

```json
{
  "runId": "20260813-ai-busy-01",
  "files": ["D:\\cards\\01.png", "D:\\cards\\02.png"],
  "title": "标题最多20字",
  "body": "正文最多1000字",
  "music": {
    "mode": "platform",
    "keyword": "轻音乐",
    "prefer": "缓慢生活",
    "artist": "轻音乐馆",
    "avoid": ["强人声", "伤感"],
    "required": true,
    "allowFallback": false
  },
  "collection": {
    "title": "AI应用提效",
    "visibility": "public",
    "required": true
  },
  "visibility": "public",
  "publishAt": "immediate",
  "allowDuplicate": false,
  "verifyDetail": true,
  "evidenceDir": "D:\\evidence\\douyin-20260813-ai-busy-01"
}
```

先运行离线校验：

```powershell
node scripts/workflow.js validate D:\path\to\config.json
```

### 3. 只准备并生成证据

```powershell
node scripts/workflow.js prepare D:\path\to\config.json
```

准备阶段必须：

1. 检查配置、文件存在性、内容指纹和有序图片 SHA-256 清单。
2. 用完整作品身份基线查找同标题作品。默认发现重复即中止；只有用户明确允许时才设置 `allowDuplicate: true`。
3. 清空并填写标题、正文，上传当前配置的图片；浏览器 FileList 必须与本地有序 SHA-256 清单一致，编辑器缩略图有序摘要必须从准备到发布前保持不变。
4. 严格匹配 BGM 当前结果行的曲名、作者和时长。
5. 精确选择现有合集。找不到唯一同名合集时中止，不自动创建或选第一项。
   选择前先在合集卡片内核验审核状态、可见性和作品数基线。
6. 从专属控件结构化回读标题、正文、FileList、缩略图序列、BGM、合集、公开权限、立即发布状态和平台明确检测成功。
7. 保存 `state.json`、`prepared.json`、`prepared.png`，输出本次 `runId`，但不点击发布。

### 4. 人工复核门禁

向用户展示或概述以下字段：

- 标题、正文、标签；
- 实际图片数量、顺序摘要和封面；
- BGM 曲名与作者；
- 合集名和集数；
- 可见范围、发布时间；
- 平台检测结果与敏感信息复核结论。

只有用户明确确认当前版本发布后，才运行：

```powershell
node scripts/workflow.js publish D:\path\to\config.json --confirm 20260813-ai-busy-01
```

`--confirm` 必须与配置和 `state.json` 的 `runId` 一致。发布阶段只复核并点击已经准备好的页面，绝不重新上传图片或重填正文。
平台会重编码缩略图，因此脚本不宣称能用字节摘要自动证明“源文件 A 等于缩略图 A”。人工确认必须以 `prepared.png` 实际看到的封面和图片顺序为准；未完成该项不得传入 `--confirm`。

### 5. 发布与回读

发布阶段必须：

1. 重新计算内容指纹、有序图片清单，并与准备阶段一致。
2. 要求 `state.phase` 为 `prepared`。若已是 `publish-intent`、`publish-clicked`、`reviewing`、`rejected` 或 `published`，禁止再次点击，改跑 `verify`。
3. 用抖音号 `accountId` 复核账号、重新扫描作品基线，再从专属控件严格断言所有字段；任一变化要求新 runId 重新准备和人工确认。
4. 点击前先写入 `publish-intent`，点击后立即写入 `publish-clicked`，防止进程中断后重复发布。
5. 只处理文本明确的标准发布确认弹窗。未知弹窗截图后中止。
6. 刷新并完整扫描内容管理页，要求相对准备基线只出现一个新作品身份，再锁定本次作品。
7. 验证该作品标题、图片数量和发布时间；“审核中”写为 `reviewing`，“审核不通过”写为 `rejected`，仅“已发布”写为 `published`。
8. `verifyDetail: true` 时只读打开作品编辑预览，核对 BGM 和合集，绝不点击“提交修改”。完成后返回内容管理页。
9. 再次读取合集卡片，确认审核状态与可见性未变，且作品数相对准备阶段基线增加 1。

中断后只运行：

```powershell
node scripts/workflow.js verify D:\path\to\config.json
```

不得为了“重试”再次运行 `prepare` 或 `publish`。

任何失败都应在本次证据目录生成 `error.json`，并尽可能保存 `error.png`、`page-state.json` 和脱敏后的 `targets.json`。若 `error.json` 标记 `publishMayHaveBeenClicked: true`，恢复动作只能是 `verify`。

## 合集规则

- 普通发布只允许选择已存在且审核通过的合集。
- 合集可见性必须显式配置为 `public` 或 `private`，并在发布前从合集卡片反向操作文案中核验当前状态。
- 候选必须按合集标题精确匹配，不能按包含关系或列表顺序选择。
- 候选作品数必须与合集基线一致；专属选择控件必须精确显示合集名和非空集数，且不得显示“不选择合集”。
- 新建合集和给历史作品补合集属于独立外部写入，分别获得用户确认。历史作品必须用作品 ID 或“标题 + 发布时间”锁定，禁止只按标题第一条处理。

## BGM 规则

- `music: null` 或 `music.mode: none` 时，专属音乐控件必须保持未选择，预览中不得出现平台音乐 credit；发现任何已选音乐即中止。
- `prefer` 默认必需；找不到时保存候选并中止。
- 只有用户明确接受候选替代时才设置 `allowFallback: true`。
- `avoid` 命中任一候选行时排除该行。
- 搜索候选、专属音乐控件、预览 credit 或发布后详情任一字段缺失、不唯一或不精确时，都不得宣称 BGM 全链路成功。
- `music.mode: local` 明确不支持并中止。

## 验收与表述

按四层分别报告，不得合并夸大：

1. 内容准备通过；
2. BGM 发布前挂载通过；
3. 管理页发布回读通过；
4. 发布后详情中的 BGM 与合集通过。

某层未完成时明确写“未验证”。所有外部发布结果末尾保留人工复核提醒。

## 故障处理

- CDP 卡死：只读核对命令行包含独立 profile 的 Edge 进程；不要粗粒度结束所有 Edge。
- 端口无法恢复：新建空 profile 让用户重新登录，禁止复制 Cookie、Local Storage 或会话数据。
- 页面目标不唯一：中止并让用户确认要保留的标签页；禁止连接任意首个目标。
- 发布锁残留：先核对锁中 PID 对应任务是否仍在运行；不得在另一个发布任务进行中删除锁。
- 页面结构变化：保存 DOM 摘要和截图，停止点击；只使用文本、placeholder、role 和稳定属性，不依赖完整哈希类名。
- 回读暂未出现：先刷新并运行 `verify`，禁止再次点击发布。
