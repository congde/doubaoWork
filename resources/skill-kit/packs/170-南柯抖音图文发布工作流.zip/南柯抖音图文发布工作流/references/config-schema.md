# 配置字段

## 必填字段

| 字段 | 规则 |
| --- | --- |
| `runId` | 本次运行唯一标识，只能含字母、数字、点、下划线和连字符 |
| `files` | 至少 1 个绝对路径，扩展名为 png、jpg 或 jpeg，文件必须存在；数组顺序即发布顺序，字节摘要和顺序进入状态门禁 |
| `title` | 非空，最多 20 个字符 |
| `body` | 非空，最多 1000 个字符 |
| `visibility` | 当前只允许显式设置 `public`、`friends` 或 `private` |
| `publishAt` | 当前只允许 `immediate`；定时发布尚未实现 |
| `evidenceDir` | 绝对路径；一次运行只使用一个新目录 |

## 音乐

- `music: null` 或 `{ "mode": "none" }`：不选 BGM。
- `mode: "platform"`：必须提供 `keyword`；建议同时提供 `prefer` 和 `artist`。
- `required` 如填写只能为 `true`。不支持“找不到音乐也继续”；明确无 BGM 请使用 `music: null` 或 `mode: "none"`。
- `allowFallback` 默认 `false`。
- `mode: "local"` 保留语义但不执行。

## 合集

- `collection: null`：不选择合集。
- `collection.title`：现有合集的精确标题。
- `collection.visibility`：必须显式为 `public` 或 `private`。
- `collection.required` 如填写只能为 `true`。不支持“找不到合集也继续”；明确不选合集请使用 `collection: null`。

## 防重复与验证

- `allowDuplicate` 默认 `false`。仅在用户明确要发同标题第二版时设为 `true`。
- `verifyDetail` 默认 `true`。为 `true` 时发布后只读进入编辑预览核对 BGM 与合集。
- 配置不包含 `publish: true`。发布授权通过命令行 `--confirm <runId>` 单独传入，避免重跑准备流程。

## 状态文件

`state.json` 的阶段只向前推进：

`prepared` → `publish-intent` → `publish-clicked` → `reviewing` → `published`

`publish-clicked` 或 `reviewing` 也可能进入 `rejected`。

`reviewing` 表示已提交但仍在审核；`rejected` 表示本次提交审核不通过，两者都不能写成已发布。状态保存准备账号 `accountId`、有序图片清单、作品基线和本次作品身份。任何 `publish-intent` 之后的阶段都禁止再次点击发布；恢复或复查时只运行 `verify`。
