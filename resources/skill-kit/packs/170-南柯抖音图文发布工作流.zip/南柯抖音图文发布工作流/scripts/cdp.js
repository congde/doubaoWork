'use strict';

const http = require('http');

function resolvePort() {
  const raw = process.env.NK_DOUYIN_CDP_PORT || process.env.CDP_PORT || '9231';
  const port = Number(raw);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error(`invalid CDP port: ${raw}`);
  return port;
}

const PORT = resolvePort();

function requestJson(requestPath, options = {}) {
  const method = options.method || 'GET';
  const timeoutMs = options.timeoutMs || 8000;
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port: PORT, path: requestPath, method }, res => {
      let data = '';
      res.setEncoding('utf8');
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        if (res.statusCode < 200 || res.statusCode >= 300) {
          reject(new Error(`CDP HTTP ${res.statusCode}: ${data.slice(0, 300)}`));
          return;
        }
        try { resolve(JSON.parse(data)); } catch (error) { reject(new Error(`invalid CDP JSON: ${error.message}`)); }
      });
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error(`CDP HTTP timeout after ${timeoutMs}ms`)));
    req.on('error', reject);
    req.end();
  });
}

async function listPages() {
  return (await requestJson('/json')).filter(target => target.type === 'page');
}

async function exactPage(urlFragment) {
  const pages = await listPages();
  const matches = pages.filter(page => page.url.includes(urlFragment));
  if (matches.length !== 1) {
    const summary = pages.map(page => `${page.id} ${page.url}`).join('\n');
    const error = new Error(`expected exactly one page matching ${urlFragment}, got ${matches.length}\n${summary}`);
    error.code = 'TARGET_AMBIGUOUS';
    throw error;
  }
  return matches[0];
}

async function singleCreatorPage() {
  return exactPage('creator.douyin.com');
}

async function pageById(targetId) {
  const pages = await listPages();
  const matches = pages.filter(page => {
    try { return page.id === targetId && new URL(page.url).origin === 'https://creator.douyin.com'; }
    catch (_) { return false; }
  });
  if (matches.length !== 1) {
    const error = new Error(`prepared creator page ${targetId} is missing or ambiguous`);
    error.code = 'TARGET_AMBIGUOUS';
    throw error;
  }
  return matches[0];
}

class CDP {
  constructor(wsUrl) {
    this.ws = new WebSocket(wsUrl);
    this.id = 0;
    this.pending = new Map();
    this.listeners = new Map();
    this.ready = new Promise((resolve, reject) => {
      this.ws.onopen = resolve;
      this.ws.onerror = event => reject(new Error(`CDP websocket error: ${event.message || 'unknown'}`));
    });
    this.ws.onmessage = event => {
      const message = JSON.parse(typeof event.data === 'string' ? event.data : event.data.toString());
      if (message.id && this.pending.has(message.id)) {
        const pending = this.pending.get(message.id);
        this.pending.delete(message.id);
        message.error ? pending.reject(new Error(message.error.message)) : pending.resolve(message.result);
        return;
      }
      if (message.method) {
        for (const listener of this.listeners.get(message.method) || []) listener(message.params);
      }
    };
    this.ws.onclose = () => {
      for (const pending of this.pending.values()) pending.reject(new Error('CDP websocket closed'));
      this.pending.clear();
    };
  }

  async send(method, params = {}, timeoutMs = 30000) {
    await this.ready;
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`timeout: ${method}`));
      }, timeoutMs);
      this.pending.set(id, {
        resolve: result => { clearTimeout(timer); resolve(result); },
        reject: error => { clearTimeout(timer); reject(error); },
      });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }

  close() {
    try { this.ws.close(); } catch (_) {}
  }
}

async function connect(target) {
  if (!target?.webSocketDebuggerUrl) throw new Error('target websocket URL missing');
  const cdp = new CDP(target.webSocketDebuggerUrl);
  await cdp.ready;
  return cdp;
}

async function evaluate(cdp, expression, timeoutMs = 15000) {
  const response = await cdp.send('Runtime.evaluate', { expression, returnByValue: true }, timeoutMs);
  if (response.exceptionDetails) {
    throw new Error(response.exceptionDetails.exception?.description || response.exceptionDetails.text || 'browser evaluation failed');
  }
  return response.result.value;
}

async function evaluateAwait(cdp, expression, timeoutMs = 30000) {
  const response = await cdp.send('Runtime.evaluate', {
    expression, returnByValue: true, awaitPromise: true,
  }, timeoutMs);
  if (response.exceptionDetails) {
    throw new Error(response.exceptionDetails.exception?.description || response.exceptionDetails.text || 'browser async evaluation failed');
  }
  return response.result.value;
}

const sleep = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));

module.exports = { PORT, requestJson, listPages, exactPage, singleCreatorPage, pageById, connect, evaluate, evaluateAwait, sleep };
