'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const {
  normalizeMusic, validateConfig, chooseMusicCandidate, contentFingerprint,
  fileManifest, sameManifest, imageBadge, classifyMusicEvidence, classifyPlatformDetectorEvidence,
  assertPublishAuthorization, assertVerifyState,
} = require('./policy.js');

test('platform music requires keyword', () => {
  assert.throws(() => normalizeMusic({ mode: 'platform' }), /keyword/);
  assert.throws(() => normalizeMusic({ mode: 'platform', keyword: '轻音乐', required: false }), /optional music/);
  assert.throws(() => normalizeMusic({ mode: 'none', required: false }), /optional music/);
});

test('preferred music also respects artist and avoid terms', () => {
  const music = normalizeMusic({
    mode: 'platform', keyword: '轻音乐', prefer: '缓慢生活', artist: '轻音乐馆', avoid: ['强人声'],
  });
  const result = chooseMusicCandidate([
    { index: 0, title: '缓慢生活 Remix', artist: '轻音乐馆', text: '缓慢生活 Remix | 轻音乐馆 | 01:52' },
    { index: 1, title: '缓慢生活', artist: '轻音乐馆', text: '缓慢生活 | 轻音乐馆 | 强人声' },
    { index: 2, title: '缓慢生活', artist: '轻音乐馆', text: '缓慢生活 | 轻音乐馆 | 01:52' },
  ], music);
  assert.equal(result.status, 'selected');
  assert.equal(result.candidate.index, 2);
});

test('missing preferred row fails closed', () => {
  const music = normalizeMusic({ mode: 'platform', keyword: '轻音乐', prefer: '缓慢生活', artist: '轻音乐馆' });
  const result = chooseMusicCandidate([{ index: 0, title: '别的歌', artist: '别的作者', text: '别的歌 | 别的作者' }], music);
  assert.equal(result.status, 'no-match');
});

test('collection visibility must be explicit', () => {
  const base = {
    runId: 'collection-01', files: [path.resolve('a.png')], title: '标题', body: '正文',
    visibility: 'public', publishAt: 'immediate', evidenceDir: path.resolve('evidence'), music: null,
  };
  assert.throws(() => validateConfig({ ...base, collection: { title: 'AI应用提效' } }, { checkFiles: false }), /collection\.visibility/);
  assert.throws(() => validateConfig({
    ...base, collection: { title: 'AI应用提效', visibility: 'public', required: false },
  }, { checkFiles: false }), /optional collection/);
  const config = validateConfig({
    ...base, collection: { title: 'AI应用提效', visibility: 'public', required: true },
  }, { checkFiles: false });
  assert.equal(config.collection.visibility, 'public');
});

test('config requires explicit visibility and immediate publish mode', () => {
  const base = {
    runId: 'case-01', files: [path.resolve('a.png')], title: '标题', body: '正文',
    evidenceDir: path.resolve('evidence'), music: null,
  };
  assert.throws(() => validateConfig(base, { checkFiles: false }), /visibility/);
  assert.throws(() => validateConfig({ ...base, visibility: 'public' }, { checkFiles: false }), /publishAt/);
});

test('legacy publish true is never treated as authorization', () => {
  const config = validateConfig({
    runId: 'case-02', files: [path.resolve('a.png')], title: '标题', body: '正文',
    visibility: 'public', publishAt: 'immediate', evidenceDir: path.resolve('evidence'), music: null,
    publish: true,
  }, { checkFiles: false });
  assert.equal('publish' in config, false);
});

test('publish authorization is bound to runId, fingerprint, and prepared phase', () => {
  const context = { confirmation: 'run-1', runId: 'run-1', fingerprint: 'hash-1' };
  assert.equal(assertPublishAuthorization({ phase: 'prepared', fingerprint: 'hash-1' }, context), true);
  assert.throws(() => assertPublishAuthorization({ phase: 'publish-clicked', fingerprint: 'hash-1' }, context), /forbidden/);
  assert.throws(() => assertPublishAuthorization({ phase: 'prepared', fingerprint: 'other' }, context), /changed/);
});

test('intent and clicked phases can only reconcile through verify', () => {
  assert.equal(assertVerifyState({ phase: 'publish-intent', fingerprint: 'hash-1' }, 'hash-1'), true);
  assert.equal(assertVerifyState({ phase: 'publish-clicked', fingerprint: 'hash-1' }, 'hash-1'), true);
  assert.equal(assertVerifyState({ phase: 'reviewing', fingerprint: 'hash-1' }, 'hash-1'), true);
  assert.equal(assertVerifyState({ phase: 'rejected', fingerprint: 'hash-1' }, 'hash-1'), true);
  assert.throws(() => assertVerifyState({ phase: 'prepared', fingerprint: 'hash-1' }, 'hash-1'), /forbidden/);
});

test('content fingerprint includes verification policy', () => {
  const base = {
    runId: 'run-1', files: [__filename], title: '测试', body: '正文', music: { mode: 'none' },
    collection: null, visibility: 'public', publishAt: 'immediate', allowDuplicate: false, verifyDetail: true,
  };
  assert.notEqual(contentFingerprint({ ...base, verifyDetail: true }), contentFingerprint({ ...base, verifyDetail: false }));
  assert.notEqual(contentFingerprint({ ...base, allowDuplicate: true }), contentFingerprint({ ...base, allowDuplicate: false }));
});

test('ordered file manifest detects bytes and order changes', () => {
  const first = path.resolve(__dirname, 'policy.js');
  const second = path.resolve(__dirname, 'login_policy.js');
  const manifest = fileManifest([first, second]);
  assert.equal(sameManifest(manifest, fileManifest([first, second])), true);
  assert.equal(sameManifest(manifest, fileManifest([second, first])), false);
  assert.equal(manifest[0].index, 0);
  assert.match(manifest[0].sha256, /^[a-f0-9]{64}$/);
});

test('Chinese image badge is parsed without ASCII word boundaries', () => {
  assert.equal(imageBadge('6张\n标题'), '6张');
  assert.equal(imageBadge('标题\n12张\n已发布'), '12张');
  assert.equal(imageBadge('正文含有16张截图说明'), '');
});

test('no-BGM evidence rejects any selected control or platform music credit', () => {
  const clean = {
    mode: 'none', controlRowCount: 1, matchingControlRowCount: 0, selectedControlMarkerCount: 0,
    modifyMusicCount: 0, durationCount: 0, emptyControlMarkerCount: 1,
    previewLocated: true, creditCount: 0, originalSoundMarkerCount: 1,
  };
  assert.deepEqual(classifyMusicEvidence(clean), { controlVerified: true, previewVerified: true });
  assert.equal(classifyMusicEvidence({ ...clean, modifyMusicCount: 1 }).controlVerified, false);
  assert.equal(classifyMusicEvidence({ ...clean, creditCount: 1 }).previewVerified, false);
  assert.equal(classifyMusicEvidence({ ...clean, previewLocated: false }).previewVerified, false);
  assert.equal(classifyMusicEvidence({ ...clean, emptyControlMarkerCount: 0 }).controlVerified, false);
  assert.equal(classifyMusicEvidence({ ...clean, originalSoundMarkerCount: 0 }).previewVerified, false);
});

test('platform music evidence requires exact control and preview credit', () => {
  const exact = {
    mode: 'platform', matchingControlRowCount: 1, exactCreditCount: 2, unexpectedCreditCount: 0,
  };
  assert.deepEqual(classifyMusicEvidence(exact), { controlVerified: true, previewVerified: true });
  assert.equal(classifyMusicEvidence({ ...exact, unexpectedCreditCount: 1 }).previewVerified, false);
});

test('platform detector only passes one dedicated success status', () => {
  assert.equal(classifyPlatformDetectorEvidence(1, ['作品未见异常']).platformCheckPassed, true);
  assert.equal(classifyPlatformDetectorEvidence(1, ['检测中16%']).platformCheckPending, true);
  assert.equal(classifyPlatformDetectorEvidence(1, ['作品存在异常']).platformIssue, true);
  assert.equal(classifyPlatformDetectorEvidence(0, []).platformCheckUnknown, true);
  const mixed = classifyPlatformDetectorEvidence(1, ['作品未见异常', '检测中16%']);
  assert.equal(mixed.platformCheckPassed, false);
  assert.equal(mixed.platformIssue, true);
});
