'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  sameStringSet, uniqueNewItemIds, assertDuplicateBaselineUnchanged, assertSameAccount,
  assertPreparedTargetUrl, lockOwnershipMatches, assertWorkCardEvidence, workImageBadgeMatches,
} = require('./workflow.js');

test('prepared account is bound by account ID rather than display name', () => {
  assert.doesNotThrow(() => assertSameAccount({ accountId: 'abc123', displayName: '新昵称' }, { accountId: 'abc123', displayName: '旧昵称' }, 'publish'));
  assert.throws(() => assertSameAccount({ accountId: 'other', displayName: '同昵称' }, { accountId: 'abc123', displayName: '同昵称' }, 'publish'), /account ID/);
  assert.throws(() => assertSameAccount({}, { accountId: 'abc123' }, 'verify'), /account ID/);
});

test('work baseline is order independent but rejects any changed work identity', () => {
  assert.equal(sameStringSet(['cover:a', 'item:2'], ['item:2', 'cover:a']), true);
  assert.deepEqual(uniqueNewItemIds(['a', 'b'], ['a', 'b', 'c']), ['c']);
  assert.doesNotThrow(() => assertDuplicateBaselineUnchanged(
    { worksCount: 2, workKeys: ['a', 'b'] },
    { worksCount: 2, workKeys: ['b', 'a'] },
  ));
  assert.throws(() => assertDuplicateBaselineUnchanged(
    { worksCount: 2, workKeys: ['a', 'b'] },
    { worksCount: 2, workKeys: ['a', 'c'] },
  ), /changed/);
});

test('first readback requires exactly one unique added identity', () => {
  assert.deepEqual(uniqueNewItemIds(['a'], ['a', 'b']), ['b']);
  assert.deepEqual(uniqueNewItemIds(['a'], ['a']), []);
  assert.deepEqual(uniqueNewItemIds(['a'], ['a', 'b', 'c']).sort(), ['b', 'c']);
});

test('prepared target accepts only the creator origin and expected editor path', () => {
  assert.equal(assertPreparedTargetUrl(
    'https://creator.douyin.com/creator-micro/content/post/image?enter_from=publish',
    '/creator-micro/content/post/image',
  ), true);
  assert.throws(() => assertPreparedTargetUrl(
    'https://creator.douyin.com.evil.example/creator-micro/content/post/image',
    '/creator-micro/content/post/image',
  ), /prepared editor target/);
  assert.throws(() => assertPreparedTargetUrl(
    'https://creator.douyin.com/creator-micro/content/manage',
    '/creator-micro/content/post/image',
  ), /prepared editor target/);
  assert.throws(() => assertPreparedTargetUrl(
    'https://creator.douyin.com/creator-micro/content/post/image-fake',
    '/creator-micro/content/post/image',
  ), /prepared editor target/);
  assert.throws(() => assertPreparedTargetUrl(
    'https://creator.douyin.com/foo/creator-micro/content/post/image',
    '/creator-micro/content/post/image',
  ), /prepared editor target/);
});

test('lock release ownership requires the exact acquisition token', () => {
  assert.equal(lockOwnershipMatches(JSON.stringify({ token: 'owner-1' }), 'owner-1'), true);
  assert.equal(lockOwnershipMatches(JSON.stringify({ token: 'owner-2' }), 'owner-1'), false);
  assert.equal(lockOwnershipMatches('not-json', 'owner-1'), false);
});

test('work cards require dedicated title evidence and never parse image count from body text', () => {
  assert.equal(assertWorkCardEvidence({ workKey: 'item:1', titleText: '标题', shapeVerified: true }), true);
  assert.throws(() => assertWorkCardEvidence({ workKey: 'item:1', titleText: '', shapeVerified: false }), /dedicated title/);
  assert.equal(workImageBadgeMatches({ text: '6张\n正文', imageBadgeText: '' }, 6), false);
  assert.equal(workImageBadgeMatches({ text: '正文', imageBadgeText: '6张' }, 6), true);
});
