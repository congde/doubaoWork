'use strict';

function classifyLoginState(page) {
  const url = String(page?.url || '');
  const body = String(page?.body || '');
  if (body.includes('扫码登录') || body.includes('验证码登录') || body.includes('密码登录')) return 'logged_out';
  const positive = url.includes('creator.douyin.com/creator-micro/')
    && body.includes('作品发布')
    && body.includes('内容管理')
    && /抖音号：?\s*\d+/.test(body);
  return positive ? 'logged_in' : 'unknown';
}

module.exports = { classifyLoginState };
