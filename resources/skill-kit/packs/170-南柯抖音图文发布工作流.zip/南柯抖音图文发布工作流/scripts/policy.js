'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg']);
const MUSIC_MODES = new Set(['none', 'platform', 'local']);
const VISIBILITY = new Set(['public', 'friends', 'private']);
const clean = value => typeof value === 'string' ? value.trim() : '';

function normalizeStringList(value, field) {
  if (value == null) return [];
  if (!Array.isArray(value)) throw new Error(`${field} must be an array`);
  return value.map(clean).filter(Boolean);
}

function normalizeMusic(input) {
  if (input && typeof input === 'object' && !Array.isArray(input) && input.required === false) {
    throw new Error('optional music is not supported; use music: null for no BGM');
  }
  if (input == null || input === false) return { mode: 'none' };
  if (typeof input !== 'object' || Array.isArray(input)) throw new Error('music must be an object or null');
  const mode = clean(input.mode || 'platform').toLowerCase();
  if (!MUSIC_MODES.has(mode)) throw new Error('music.mode must be none, platform, or local');
  if (mode === 'none') return { mode };
  if (mode === 'local') return { mode, file: clean(input.file) };
  const keyword = clean(input.keyword);
  if (!keyword) throw new Error('music.keyword is required for platform mode');
  return {
    mode,
    keyword,
    prefer: clean(input.prefer),
    artist: clean(input.artist),
    avoid: normalizeStringList(input.avoid, 'music.avoid'),
    required: true,
    allowFallback: input.allowFallback === true,
  };
}

function normalizeCollection(input) {
  if (input == null || input === false) return null;
  if (typeof input !== 'object' || Array.isArray(input)) throw new Error('collection must be an object or null');
  const title = clean(input.title);
  if (!title) throw new Error('collection.title is required');
  if (input.required === false) throw new Error('optional collection selection is not supported; use collection: null for no collection');
  const visibility = clean(input.visibility);
  if (!['public', 'private'].includes(visibility)) throw new Error('collection.visibility must explicitly be public or private');
  return { title, visibility, required: true };
}

function validateConfig(input, options = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('config must be an object');
  const runId = clean(input.runId);
  if (!/^[a-zA-Z0-9._-]+$/.test(runId)) throw new Error('runId must contain only letters, digits, dot, underscore, and hyphen');
  if (!Array.isArray(input.files) || input.files.length === 0) throw new Error('files must contain at least one image');
  const files = input.files.map((file, index) => {
    if (typeof file !== 'string' || !path.isAbsolute(file)) throw new Error(`files[${index}] must be an absolute path`);
    if (!IMAGE_EXTENSIONS.has(path.extname(file).toLowerCase())) throw new Error(`unsupported image extension: ${file}`);
    if (options.checkFiles !== false && !fs.existsSync(file)) throw new Error(`image not found: ${file}`);
    return path.normalize(file);
  });
  const title = clean(input.title);
  if (!title || [...title].length > 20) throw new Error('title is required and must be at most 20 characters');
  const body = typeof input.body === 'string' ? input.body.trim() : '';
  if (!body || [...body].length > 1000) throw new Error('body is required and must be at most 1000 characters');
  const visibility = clean(input.visibility);
  if (!VISIBILITY.has(visibility)) throw new Error('visibility must explicitly be public, friends, or private');
  if (input.publishAt !== 'immediate') throw new Error('publishAt must be immediate; scheduled publishing is not implemented');
  const evidenceDir = clean(input.evidenceDir);
  if (!evidenceDir || !path.isAbsolute(evidenceDir) || path.parse(evidenceDir).root === path.resolve(evidenceDir)) {
    throw new Error('evidenceDir must be a non-root absolute path');
  }
  const music = normalizeMusic(input.music);
  if (music.mode === 'local') throw new Error('local music upload is not implemented');
  return {
    runId,
    files,
    title,
    body,
    music,
    collection: normalizeCollection(input.collection),
    visibility,
    publishAt: 'immediate',
    allowDuplicate: input.allowDuplicate === true,
    verifyDetail: input.verifyDetail !== false,
    evidenceDir: path.resolve(evidenceDir),
  };
}

function fold(value) {
  return clean(value).replace(/\s+/g, '').toLocaleLowerCase('zh-CN');
}

function chooseMusicCandidate(candidates, music) {
  const rows = (Array.isArray(candidates) ? candidates : []).map((candidate, position) => ({
    index: Number.isInteger(candidate.index) ? candidate.index : position,
    title: clean(candidate.title),
    artist: clean(candidate.artist),
    duration: clean(candidate.duration),
    text: clean(candidate.text || candidate.title),
  })).filter(candidate => candidate.text);
  const avoidTerms = music.avoid.map(fold);
  const safe = rows.filter(row => !avoidTerms.some(term => term && fold(row.text).includes(term)));
  const prefer = fold(music.prefer);
  const artist = fold(music.artist);
  let candidate = null;
  let reason = 'prefer-required';
  if (prefer) {
    candidate = safe.find(row => fold(row.title) === prefer && (!artist || fold(row.artist) === artist)) || null;
    reason = candidate ? 'prefer-and-artist-match' : 'prefer-or-artist-not-found';
  }
  if (!candidate && music.allowFallback) {
    candidate = safe.find(row => row.title && (!artist || fold(row.artist) === artist)) || null;
    reason = candidate ? 'explicit-fallback' : 'no-safe-result';
  }
  return {
    status: candidate ? 'selected' : 'no-match',
    reason,
    candidate,
    candidates: rows.slice(0, 20).map(row => ({ ...row, blocked: !safe.some(item => item.index === row.index) })),
  };
}

function contentFingerprint(config) {
  const hash = crypto.createHash('sha256');
  hash.update(JSON.stringify({
    runId: config.runId,
    title: config.title,
    body: config.body,
    music: config.music,
    collection: config.collection,
    visibility: config.visibility,
    publishAt: config.publishAt,
    allowDuplicate: config.allowDuplicate,
    verifyDetail: config.verifyDetail,
    fileNames: config.files.map(file => path.basename(file)),
  }));
  for (const file of config.files) hash.update(fs.readFileSync(file));
  return hash.digest('hex');
}

function fileManifest(files, options = {}) {
  return files.map((file, index) => {
    const bytes = fs.readFileSync(file);
    return {
      index,
      name: options.includeName === false ? '' : path.basename(file),
      size: bytes.length,
      sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
    };
  });
}

function sameManifest(left, right) {
  return JSON.stringify(left || []) === JSON.stringify(right || []);
}

function imageBadge(text) {
  return (String(text || '').match(/(?:^|\s)(\d+张)(?=\s|$)/m) || [])[1] || '';
}

function classifyMusicEvidence(evidence) {
  const noMusic = evidence?.mode === 'none';
  return {
    controlVerified: noMusic
      ? evidence.controlRowCount === 1 && evidence.matchingControlRowCount === 0
        && evidence.selectedControlMarkerCount === 0 && evidence.modifyMusicCount === 0 && evidence.durationCount === 0
        && evidence.emptyControlMarkerCount === 1
      : evidence?.matchingControlRowCount === 1,
    previewVerified: noMusic
      ? evidence?.previewLocated === true && evidence.creditCount === 0 && evidence.originalSoundMarkerCount > 0
      : evidence?.exactCreditCount > 0 && evidence.unexpectedCreditCount === 0,
  };
}

function classifyPlatformDetectorEvidence(detectorCount, values) {
  const statuses = [...new Set((Array.isArray(values) ? values : []).filter(Boolean))];
  const status = statuses.length === 1 ? statuses[0] : '';
  const ambiguous = detectorCount > 1 || statuses.length > 1;
  const pending = detectorCount === 1 && statuses.length === 1 && /^检测中(?:\d+%)?$/.test(status);
  const passed = detectorCount === 1 && statuses.length === 1 && status === '作品未见异常';
  const knownIssue = detectorCount === 1 && statuses.length === 1
    && /^(作品存在异常|不建议发布|.*风险.*)$/.test(status);
  return {
    platformDetectorStatusCount: statuses.length,
    platformDetectorStatus: status,
    platformCheckPending: pending,
    platformCheckUnknown: !passed && !pending && !knownIssue && !ambiguous,
    platformIssue: ambiguous || knownIssue,
    platformCheckPassed: passed,
  };
}

function writeJsonAtomic(file, value) {
  const temp = `${file}.tmp-${process.pid}`;
  fs.writeFileSync(temp, JSON.stringify(value, null, 2), 'utf8');
  fs.renameSync(temp, file);
}

function assertPublishAuthorization(state, context) {
  if (context.confirmation !== context.runId) throw new Error('confirmation must equal runId');
  if (!state || state.fingerprint !== context.fingerprint) throw new Error('prepared fingerprint changed');
  if (state.phase !== 'prepared') throw new Error('publish click is forbidden from phase ' + (state ? state.phase : 'missing'));
  return true;
}

function assertVerifyState(state, fingerprint) {
  if (!state || state.fingerprint !== fingerprint) throw new Error('verification fingerprint changed');
  if (!['publish-intent', 'publish-clicked', 'reviewing', 'rejected', 'published'].includes(state.phase)) {
    throw new Error('verify is forbidden from phase ' + state.phase);
  }
  return true;
}

module.exports = {
  normalizeMusic, normalizeCollection, validateConfig, chooseMusicCandidate, contentFingerprint,
  fileManifest, sameManifest, imageBadge, classifyMusicEvidence, classifyPlatformDetectorEvidence,
  writeJsonAtomic, assertPublishAuthorization, assertVerifyState,
};
