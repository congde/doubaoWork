'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const {
  PORT, listPages, singleCreatorPage, pageById, connect, evaluate, evaluateAwait, sleep,
} = require('./cdp.js');
const {
  validateConfig, chooseMusicCandidate, contentFingerprint, fileManifest, sameManifest,
  classifyMusicEvidence, classifyPlatformDetectorEvidence, writeJsonAtomic,
  assertPublishAuthorization, assertVerifyState,
} = require('./policy.js');

const command = process.argv[2] || '';
const configPath = process.argv[3] || '';
const confirmIndex = process.argv.indexOf('--confirm');
const confirmation = confirmIndex >= 0 ? process.argv[confirmIndex + 1] : '';

let config = null;
let fingerprint = '';
let currentPhase = command || 'startup';
let activeCdp = null;
let lockFile = '';
let lockHandle = null;
let ownsLock = false;
let lockToken = '';
let imageManifest = null;

function errorWithCode(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}

function loadConfig() {
  if (!configPath || !path.isAbsolute(configPath) || !fs.existsSync(configPath)) {
    throw errorWithCode('CONFIG_INVALID', 'absolute existing config path required');
  }
  const raw = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  config = validateConfig(raw);
  fingerprint = contentFingerprint(config);
  imageManifest = fileManifest(config.files);
  return config;
}

function statePath() {
  return path.join(config.evidenceDir, 'state.json');
}

function saveJson(name, value) {
  fs.mkdirSync(config.evidenceDir, { recursive: true });
  fs.writeFileSync(path.join(config.evidenceDir, name), JSON.stringify(value, null, 2), 'utf8');
}

function loadState() {
  if (!fs.existsSync(statePath())) throw errorWithCode('STATE_MISSING', 'state.json not found; run prepare first');
  return JSON.parse(fs.readFileSync(statePath(), 'utf8'));
}

function writeState(phase, value = {}) {
  currentPhase = phase;
  const previous = fs.existsSync(statePath()) ? JSON.parse(fs.readFileSync(statePath(), 'utf8')) : {};
  const next = {
    ...previous,
    ...value,
    runId: config.runId,
    fingerprint,
    phase,
    cdpPort: PORT,
    updatedAt: new Date().toISOString(),
  };
  writeJsonAtomic(statePath(), next);
  return next;
}

async function saveScreenshot(name, cdp = activeCdp, required = true) {
  if (!cdp) {
    if (required) throw errorWithCode('EVIDENCE_CAPTURE_FAILED', 'no CDP connection for required screenshot ' + name);
    return false;
  }
  try {
    const shot = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true }, 30000);
    const output = path.join(config.evidenceDir, name);
    const bytes = Buffer.from(shot.data || '', 'base64');
    if (!bytes.length) throw new Error('empty screenshot payload');
    fs.writeFileSync(output, bytes);
    if (!fs.existsSync(output) || fs.statSync(output).size === 0) throw new Error('empty screenshot file');
    return true;
  } catch (error) {
    if (required) throw errorWithCode('EVIDENCE_CAPTURE_FAILED', name + ': ' + error.message);
    return false;
  }
}

function acquireLock() {
  lockFile = process.env.NK_DOUYIN_LOCK_FILE || path.join(os.tmpdir(), 'nk-douyin-image-publish.lock');
  try {
    lockHandle = fs.openSync(lockFile, 'wx');
    ownsLock = true;
    lockToken = `${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    fs.writeFileSync(lockHandle, JSON.stringify({
      pid: process.pid, runId: config.runId, token: lockToken, startedAt: new Date().toISOString(),
    }));
    fs.fsyncSync(lockHandle);
  } catch (error) {
    if (ownsLock) releaseLock();
    if (error.code === 'EEXIST') {
      throw errorWithCode('CONCURRENT_RUN', 'another Douyin workflow holds the publish lock; inspect ' + lockFile);
    }
    throw error;
  }
}

function lockOwnershipMatches(content, token) {
  try { return !!token && JSON.parse(String(content || '')).token === token; } catch (_) { return false; }
}

function releaseLock() {
  if (!ownsLock) return;
  if (lockHandle !== null) {
    try { fs.closeSync(lockHandle); } catch (_) {}
    lockHandle = null;
  }
  if (lockFile) {
    try {
      const content = fs.readFileSync(lockFile, 'utf8');
      if (lockOwnershipMatches(content, lockToken)) fs.unlinkSync(lockFile);
    } catch (_) {}
  }
  ownsLock = false;
  lockToken = '';
}

async function browserCall(cdp, fn, args = {}) {
  const expression = '(' + fn.toString() + ')(' + JSON.stringify(args) + ')';
  return evaluate(cdp, expression);
}

async function browserCallAsync(cdp, fn, args = {}) {
  const expression = '(' + fn.toString() + ')(' + JSON.stringify(args) + ')';
  return evaluateAwait(cdp, expression);
}

async function enablePage(cdp) {
  await cdp.send('Page.enable');
  await cdp.send('Runtime.enable');
  await cdp.send('DOM.enable');
  await cdp.send('Emulation.setDeviceMetricsOverride', {
    width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false,
  });
}

async function navigate(cdp, url, fragment) {
  try { await cdp.send('Page.navigate', { url }, 15000); } catch (_) {}
  for (let attempt = 1; attempt <= 30; attempt++) {
    await sleep(500);
    try {
      const current = await evaluate(cdp, 'location.href', 5000);
      if (String(current).includes(fragment)) {
        await sleep(2500);
        return current;
      }
    } catch (_) {}
  }
  throw errorWithCode('PAGE_NAVIGATION_FAILED', 'navigation did not reach ' + fragment);
}

function normalizeBrowserText(value) {
  return String(value || '').replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
}

function chineseMinute(epoch) {
  const date = new Date(epoch);
  const parts = new Intl.DateTimeFormat('zh-CN', {
    timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: false,
  }).formatToParts(date).reduce((output, part) => {
    output[part.type] = part.value;
    return output;
  }, {});
  return parts.year + '年' + parts.month + '月' + parts.day + '日 ' + parts.hour + ':' + parts.minute;
}

async function prepareEvidenceDir() {
  if (fs.existsSync(config.evidenceDir)) {
    const entries = fs.readdirSync(config.evidenceDir);
    if (entries.length) throw errorWithCode('EVIDENCE_DIR_NOT_EMPTY', 'evidenceDir is not empty; use a new runId and directory');
  }
  fs.mkdirSync(config.evidenceDir, { recursive: true });
  saveJson('config.normalized.json', config);
  saveJson('prepare-attempt.json', {
    runId: config.runId, fingerprint, imageManifest, cdpPort: PORT, startedAt: new Date().toISOString(),
  });
}

async function accountProbe(cdp, evidenceName = 'account.json') {
  await navigate(cdp, 'https://creator.douyin.com/creator-micro/home', '/creator-micro/home');
  const result = JSON.parse(await browserCall(cdp, function () {
    const body = String(document.body.innerText || '');
    const lines = body.split(/\n+/).map(line => line.trim()).filter(Boolean);
    const accountIndex = lines.findIndex(line => /^抖音号：?\s*\S+$/.test(line));
    return JSON.stringify({
      url: location.href,
      accountId: accountIndex >= 0 ? lines[accountIndex].replace(/^抖音号：?\s*/, '').trim() : '',
      displayName: accountIndex > 0 ? lines[accountIndex - 1] : '',
      positiveFeatures: body.includes('作品发布') && body.includes('内容管理'),
      loginPage: body.includes('扫码登录') || body.includes('验证码登录'),
    });
  }));
  saveJson(evidenceName, result);
  if (!result.accountId || !result.displayName || !result.positiveFeatures || result.loginPage) {
    throw errorWithCode('LOGIN_UNKNOWN', 'account identity could not be positively verified');
  }
  return result;
}

async function withTemporaryCreatorPage(anchorCdp, task) {
  let targetId = '';
  let temporaryCdp = null;
  try {
    const created = await anchorCdp.send('Target.createTarget', { url: 'about:blank' }, 15000);
    targetId = created.targetId || '';
    if (!targetId) throw errorWithCode('TARGET_AMBIGUOUS', 'temporary creator target could not be created');
    let target = null;
    for (let attempt = 1; attempt <= 20; attempt++) {
      target = (await listPages()).find(page => page.id === targetId) || null;
      if (target) break;
      await sleep(250);
    }
    if (!target) throw errorWithCode('TARGET_AMBIGUOUS', 'temporary creator target was not discoverable');
    temporaryCdp = await connect(target);
    await enablePage(temporaryCdp);
    return await task(temporaryCdp);
  } finally {
    if (temporaryCdp) temporaryCdp.close();
    if (targetId) {
      try { await anchorCdp.send('Target.closeTarget', { targetId }, 10000); } catch (_) {}
    }
  }
}

function assertSameAccount(actual, expected, phase) {
  if (!actual?.accountId || !expected?.accountId || actual.accountId !== expected.accountId) {
    throw errorWithCode('ACCOUNT_CHANGED', `${phase} account ID does not match the prepared account`);
  }
}

function assertPreparedTargetUrl(rawUrl, expectedPath = '') {
  let url = null;
  try { url = new URL(String(rawUrl || '')); } catch (_) {}
  const pathname = url ? url.pathname.replace(/\/+$/, '') || '/' : '';
  const expected = String(expectedPath || '').replace(/\/+$/, '') || '';
  if (!url || url.origin !== 'https://creator.douyin.com' || (expected && pathname !== expected)) {
    throw errorWithCode('TARGET_AMBIGUOUS', 'prepared editor target moved away from the expected page');
  }
  return true;
}

async function openPreparedTarget(state, expectedPath = '') {
  const target = await pageById(state.targetId);
  const cdp = await connect(target);
  await enablePage(cdp);
  const rawUrl = String(await evaluate(cdp, 'location.href'));
  try {
    assertPreparedTargetUrl(rawUrl, expectedPath);
  } catch (error) {
    cdp.close();
    throw error;
  }
  return cdp;
}

async function verifyPreparedAccount(anchorCdp, state, evidenceName, phase) {
  const actual = await withTemporaryCreatorPage(anchorCdp, temporaryCdp => accountProbe(temporaryCdp, evidenceName));
  assertSameAccount(actual, state.account, phase);
  return actual;
}

async function scanManageInTemporaryPage(anchorCdp, evidenceName) {
  return withTemporaryCreatorPage(anchorCdp, temporaryCdp => duplicateProbe(temporaryCdp, evidenceName));
}

async function resetManageFilters(cdp) {
  const result = JSON.parse(await browserCall(cdp, function () {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden';
    };
    const exact = (root, text) => [...root.querySelectorAll('*')]
      .filter(visible)
      .filter(element => String(element.innerText || element.textContent || '').trim() === text)
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const allNodes = [...exact(document, '全部'), ...exact(document, '全部作品')];
    const containers = [];
    for (const allNode of allNodes) {
      let node = allNode.parentElement;
      for (let level = 0; level < 6 && node && node !== document.body; level++, node = node.parentElement) {
        const text = String(node.innerText || '');
        if (text.includes('已发布') && text.includes('审核中') && text.includes('未通过')) {
          containers.push(node);
          break;
        }
      }
    }
    containers.sort((a, b) => String(a.innerText || '').length - String(b.innerText || '').length);
    const container = containers[0];
    if (!container) return JSON.stringify({ ok: false, reason: 'STATUS_FILTER_NOT_FOUND' });
    const buttons = [...exact(container, '全部'), ...exact(container, '全部作品')];
    if (buttons.length !== 1) return JSON.stringify({ ok: false, reason: 'STATUS_ALL_COUNT=' + buttons.length });
    buttons[0].click();
    const inputs = [...document.querySelectorAll('input')].filter(visible);
    const searchInputs = inputs.filter(input =>
      /搜索|标题|作品/.test(String(input.placeholder || ''))
      && !/添加作品标题/.test(String(input.placeholder || ''))
    );
    for (const input of searchInputs) {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
      if (setter) setter.call(input, ''); else input.value = '';
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }
    const typeLabels = exact(document, '体裁');
    if (typeLabels.length !== 1) return JSON.stringify({ ok: false, reason: 'TYPE_LABEL_COUNT=' + typeLabels.length });
    const typeContainers = [];
    let typeNode = typeLabels[0].parentElement;
    for (let level = 0; level < 6 && typeNode && typeNode !== document.body; level++, typeNode = typeNode.parentElement) {
      const all = exact(typeNode, '全部');
      const text = String(typeNode.innerText || '');
      if (all.length === 1 && !text.includes('审核中') && !text.includes('未通过')) typeContainers.push(typeNode);
    }
    typeContainers.sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const typeContainer = typeContainers[0];
    const typeAll = typeContainer ? exact(typeContainer, '全部') : [];
    if (typeAll.length !== 1) return JSON.stringify({ ok: false, reason: 'TYPE_ALL_COUNT=' + typeAll.length });
    typeAll[0].click();
    return JSON.stringify({ ok: true, searchInputCount: searchInputs.length, reason: '' });
  }));
  if (!result.ok) throw errorWithCode('DUPLICATE_SCAN_INCOMPLETE', result.reason);
  await sleep(1200);
  const verification = JSON.parse(await browserCall(cdp, function () {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden';
    };
    const exact = (root, text) => [...root.querySelectorAll('*')]
      .filter(visible)
      .filter(element => String(element.innerText || element.textContent || '').trim() === text)
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const selectionState = element => {
      const wrapper = element.closest('[role=tab], [role=option], label') || element.parentElement;
      if (!wrapper) return null;
      const input = wrapper.matches?.('input') ? wrapper : wrapper.querySelector?.('input');
      if (input && typeof input.checked === 'boolean') return input.checked;
      for (const attribute of ['aria-selected', 'aria-checked']) {
        const value = wrapper.getAttribute?.(attribute);
        if (value === 'true') return true;
        if (value === 'false') return false;
      }
      if (wrapper.dataset?.checked === 'true') return true;
      if (wrapper.dataset?.checked === 'false') return false;
      const className = String(wrapper.className || '');
      if (/(?:^|[-_])(active|selected|checked)(?:[-_]|$)/i.test(className)) return true;
      return null;
    };
    const searchValues = [...document.querySelectorAll('input')]
      .filter(visible)
      .filter(input => /搜索|标题|作品/.test(String(input.placeholder || '')) && !/添加作品标题/.test(String(input.placeholder || '')))
      .map(input => String(input.value || '').trim()).filter(Boolean);
    const statusCandidates = [];
    for (const allNode of [...exact(document, '全部'), ...exact(document, '全部作品')]) {
      let node = allNode.parentElement;
      for (let level = 0; level < 6 && node && node !== document.body; level++, node = node.parentElement) {
        const text = String(node.innerText || '');
        if (text.includes('已发布') && text.includes('审核中') && text.includes('未通过')) {
          statusCandidates.push(node);
          break;
        }
      }
    }
    const statusContainers = [...new Set(statusCandidates)]
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const statusContainer = statusContainers[0] || null;
    const statusAll = statusContainer ? [...exact(statusContainer, '全部'), ...exact(statusContainer, '全部作品')] : [];
    const statusPeers = statusContainer
      ? ['已发布', '审核中', '未通过'].map(text => exact(statusContainer, text))
      : [];
    const statusPeerNodes = statusPeers.flat();
    const statusActive = statusAll.length === 1 && statusPeerNodes.length === 3
      && selectionState(statusAll[0]) === true && statusPeerNodes.every(peer => selectionState(peer) === false);
    const typeLabels = exact(document, '体裁');
    const typeContainers = [];
    if (typeLabels.length === 1) {
      let node = typeLabels[0].parentElement;
      for (let level = 0; level < 6 && node && node !== document.body; level++, node = node.parentElement) {
        const all = exact(node, '全部');
        const text = String(node.innerText || '');
        if (all.length === 1 && !text.includes('审核中') && !text.includes('未通过')) typeContainers.push(node);
      }
    }
    typeContainers.sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const typeContainer = typeContainers[0] || null;
    const typeAll = typeContainer ? exact(typeContainer, '全部') : [];
    let typeSelected = false;
    if (typeAll.length === 1) {
      const nativeSelect = typeAll[0].closest('select');
      if (nativeSelect) typeSelected = String(nativeSelect.selectedOptions?.[0]?.textContent || '').trim() === '全部';
      if (!typeSelected) {
        const combo = typeAll[0].closest('[role=combobox], [aria-haspopup=listbox], [class*=select]');
        const currentValues = combo ? [...combo.querySelectorAll('[class*=selection], [class*=value], [aria-selected=true]')]
          .filter(visible).map(element => String(element.innerText || element.textContent || '').trim()) : [];
        typeSelected = currentValues.filter(value => value === '全部').length === 1;
      }
      if (!typeSelected) typeSelected = selectionState(typeAll[0]) === true;
    }
    return JSON.stringify({ searchValues, statusAllCount: statusAll.length, statusActive, typeAllCount: typeAll.length, typeSelected });
  }));
  if (verification.searchValues.length || verification.statusAllCount !== 1 || !verification.statusActive
    || verification.typeAllCount !== 1 || !verification.typeSelected) {
    throw errorWithCode('DUPLICATE_SCAN_INCOMPLETE', 'manage filters could not be proven clear');
  }
}

function displayedTitleMatches(text, title) {
  const value = normalizeBrowserText(text);
  return [
    normalizeBrowserText(title),
    normalizeBrowserText(title + '。' + config.body),
    normalizeBrowserText(title + config.body),
  ].includes(value);
}

async function scanAllWorks(cdp) {
  const seenCards = new Map();
  const matchedCards = new Map();
  let worksCount = 0;
  let complete = false;
  let stableAtEnd = 0;
  for (let attempt = 1; attempt <= 100; attempt++) {
    const page = JSON.parse(await browserCall(cdp, function (args) {
      const cards = [...document.querySelectorAll('[class*=video-card-content]')];
      const items = cards.map(card => {
        const text = String(card.innerText || '').trim();
        const titleNodes = [...card.querySelectorAll('[class*=info-title-text]')]
          .filter(element => String(element.innerText || '').trim());
        const titleText = titleNodes.length === 1 ? String(titleNodes[0].innerText || '').trim() : '';
        const edit = [...card.querySelectorAll('*')]
          .find(element => String(element.innerText || '').trim() === '编辑作品');
        const operation = edit ? edit.closest('[class*=info-title-operation]') || edit.parentElement : null;
        const identities = new Set();
        for (const element of [card, ...card.querySelectorAll('*')]) {
          for (const attribute of ['data-item-id', 'data-aweme-id', 'data-video-id', 'data-mid']) {
            const value = String(element.getAttribute?.(attribute) || '');
            if (/^\d{10,30}$/.test(value)) identities.add(value);
          }
          if (element.matches?.('a[href]')) {
            try {
              const url = new URL(element.href, location.href);
              for (const key of ['mid', 'item_id', 'aweme_id', 'video_id']) {
                const value = String(url.searchParams.get(key) || '');
                if (/^\d{10,30}$/.test(value)) identities.add(value);
              }
              const pathId = (url.pathname.match(/\/(?:video|item)\/(\d{10,30})(?:\/|$)/) || [])[1] || '';
              if (pathId) identities.add(pathId);
            } catch (_) {}
          }
        }
        const itemId = identities.size === 1 ? [...identities][0] : '';
        const cover = card.querySelector('[class*=video-card-cover]');
        const imageBadgeNodes = cover ? [...cover.querySelectorAll('[class*=badge]')]
          .map(element => String(element.innerText || '').trim())
          .filter(value => /^\d+张$/.test(value)) : [];
        const imageBadgeText = imageBadgeNodes.length === 1 ? imageBadgeNodes[0] : '';
        const background = String(cover ? getComputedStyle(cover).backgroundImage : '');
        const coverUrl = (background.match(/url\(["']?([^"')]+)["']?\)/) || [])[1] || '';
        let coverPath = '';
        try {
          const url = new URL(coverUrl, location.href);
          coverPath = url.origin + url.pathname;
        } catch (_) {}
        const workKey = itemId ? 'item:' + itemId : coverPath ? 'cover:' + coverPath : '';
        const dateNodes = [...card.querySelectorAll('[class*=info-time]')]
          .map(element => String(element.innerText || '').trim())
          .filter(value => /^20\d{2}年\d{2}月\d{2}日 \d{2}:\d{2}$/.test(value));
        const statusNodes = [...card.querySelectorAll('[class*=info-status]')]
          .map(element => String(element.innerText || '').trim())
          .filter(value => /^(审核中|已发布|审核不通过|未通过)$/.test(value));
        const date = dateNodes.length === 1 ? dateNodes[0] : '';
        const status = statusNodes.length === 1 ? statusNodes[0] : '';
        return {
          text, titleText, itemId, workKey, date, status, imageBadgeText,
          shapeVerified: titleNodes.length === 1 && imageBadgeNodes.length <= 1,
        };
      });
      const body = String(document.body.innerText || '');
      const countMatch = body.match(/作品\s*\((\d+)\)/);
      const noMoreVisible = [...document.querySelectorAll('*')].some(element => {
        const rect = element.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && String(element.innerText || '').trim() === '没有更多作品';
      });
      const scrollRoot = document.querySelector('[class*=list-scroll]');
      let moved = false;
      if (scrollRoot) {
        const before = scrollRoot.scrollTop;
        scrollRoot.scrollTop = Math.min(scrollRoot.scrollHeight, before + Math.max(500, scrollRoot.clientHeight * 0.8));
        moved = scrollRoot.scrollTop > before;
      } else {
        const beforeWindow = window.scrollY;
        window.scrollTo(0, Math.min(document.documentElement.scrollHeight, beforeWindow + Math.max(500, window.innerHeight * 0.8)));
        moved = window.scrollY > beforeWindow;
      }
      return JSON.stringify({
        url: location.href,
        worksCount: countMatch ? Number(countMatch[1]) : null,
        countParsed: !!countMatch,
        items,
        noMore: noMoreVisible,
        moved,
      });
    }, { title: config.title }));
    worksCount = page.worksCount;
    for (const item of page.items) {
      assertWorkCardEvidence(item);
      const key = item.workKey;
      seenCards.set(key, item);
      if (displayedTitleMatches(item.titleText, config.title)) matchedCards.set(key, item);
    }
    const allObserved = page.countParsed && Number.isInteger(worksCount) && seenCards.size === worksCount;
    if (page.noMore && allObserved) stableAtEnd += 1;
    else stableAtEnd = 0;
    if (stableAtEnd >= 2) {
      complete = true;
      break;
    }
    await sleep(650);
  }
  await browserCall(cdp, function () {
    window.scrollTo(0, 0);
    for (const element of document.querySelectorAll('*')) {
      if (element.scrollHeight > element.clientHeight + 80) element.scrollTop = 0;
    }
    return true;
  });
  return {
    url: 'https://creator.douyin.com/creator-micro/content/manage',
    worksCount,
    observedCardCount: seenCards.size,
    workKeys: [...seenCards.keys()],
    itemIds: [...seenCards.values()].map(item => item.itemId).filter(Boolean),
    stableIdCount: [...seenCards.values()].filter(item => item.itemId).length,
    items: [...seenCards.values()],
    scanComplete: complete,
    exactTitleMatches: matchedCards.size,
    matchSnippets: [...matchedCards.values()].map(item => item.text.slice(0, 700)),
  };
}

function assertWorkCardEvidence(item) {
  if (!item?.workKey) throw errorWithCode('DUPLICATE_SCAN_INCOMPLETE', 'a work card did not expose a stable item or cover identity');
  if (!item.shapeVerified || !item.titleText) {
    throw errorWithCode('DUPLICATE_SCAN_INCOMPLETE', 'a work card did not expose unique dedicated title and image badge fields');
  }
  return true;
}

function workImageBadgeMatches(item, count) {
  return !!item && item.imageBadgeText === String(count) + '张';
}

async function duplicateProbe(cdp, evidenceName = 'duplicate-probe.json') {
  await navigate(cdp, 'https://creator.douyin.com/creator-micro/content/manage', '/content/manage');
  try { await cdp.send('Page.reload', { ignoreCache: true }, 15000); } catch (_) {}
  await sleep(3500);
  await resetManageFilters(cdp);
  const result = await scanAllWorks(cdp);
  saveJson(evidenceName, result);
  if (!result.scanComplete) {
    throw errorWithCode('DUPLICATE_SCAN_INCOMPLETE', 'could not prove that all works were scanned');
  }
  if (result.exactTitleMatches > 0 && !config.allowDuplicate) {
    throw errorWithCode('DUPLICATE_OR_AMBIGUOUS', 'an exact-title work already exists; allowDuplicate requires explicit user approval');
  }
  return result;
}

function sameStringSet(left, right) {
  const a = [...new Set(left || [])].sort();
  const b = [...new Set(right || [])].sort();
  return a.length === b.length && a.every((value, index) => value === b[index]);
}

function uniqueNewItemIds(baseline, current) {
  const known = new Set(baseline || []);
  return [...new Set(current || [])].filter(itemId => !known.has(itemId));
}

function assertDuplicateBaselineUnchanged(prepared, latest) {
  if (!Number.isInteger(prepared?.worksCount) || !Number.isInteger(latest?.worksCount)
    || prepared.worksCount !== latest.worksCount
    || !sameStringSet(prepared.workKeys, latest.workKeys)) {
    throw errorWithCode('DUPLICATE_BASELINE_CHANGED', 'work list changed after prepare; prepare a new run for human confirmation');
  }
}

async function readCollectionCard(cdp) {
  return JSON.parse(await browserCall(cdp, function (args) {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    const titleNodes = [...document.querySelectorAll('*')]
      .filter(visible)
      .filter(element => String(element.innerText || element.textContent || '').trim() === args.title)
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const cards = [];
    for (const titleNode of titleNodes) {
      let node = titleNode;
      for (let level = 0; level < 10 && node && node !== document.body; level++, node = node.parentElement) {
        const text = String(node.innerText || '');
        if (text.includes('编辑合集') && text.includes(args.title) && /\d+个作品/.test(text)) {
          if (!cards.includes(node)) cards.push(node);
          break;
        }
      }
    }
    cards.sort((a, b) => String(a.innerText || '').length - String(b.innerText || '').length);
    const card = cards[0] || null;
    const cardText = String(card ? card.innerText : '').trim();
    const workCountMatch = cardText.match(/(\d+)个作品/);
    const workCount = workCountMatch ? Number(workCountMatch[1]) : null;
    const statusNodes = card ? [...card.querySelectorAll('*')]
      .filter(element => element.children.length === 0)
      .map(element => String(element.innerText || '').trim())
      .filter(value => /^(待发布|已发布|审核中|未通过)$/.test(value)) : [];
    return JSON.stringify({
      url: location.href,
      exactCardCount: cards.length,
      titlePresent: !!card,
      status: statusNodes.length === 1 ? statusNodes[0] : '',
      visibility: cardText.includes('设为私密') ? 'public' : cardText.includes('设为公开') ? 'private' : 'unknown',
      workCount,
      cardText: cardText.slice(0, 1400),
    });
  }, { title: config.collection.title }));
}

async function collectionEligibilityProbe(cdp) {
  if (!config.collection) return null;
  await navigate(cdp, 'https://creator.douyin.com/creator-micro/content/manage?tab=collections', 'tab=collections');
  await sleep(2500);
  const result = await readCollectionCard(cdp);
  saveJson('collection-baseline.json', result);
  if (result.exactCardCount !== 1) {
    throw errorWithCode(result.exactCardCount === 0 ? 'COLLECTION_NOT_FOUND' : 'COLLECTION_AMBIGUOUS',
      'expected exactly one collection card, got ' + result.exactCardCount);
  }
  if (!Number.isInteger(result.workCount)) {
    throw errorWithCode('COLLECTION_NOT_READY', 'collection work count is missing from the exact card');
  }
  if (result.status !== '已发布' || result.visibility !== config.collection.visibility) {
    throw errorWithCode('COLLECTION_NOT_READY',
      'collection status or visibility mismatch: ' + result.status + '/' + result.visibility);
  }
  return result;
}

async function verifyCollectionAfter(cdp, state) {
  if (!config.collection) return null;
  await navigate(cdp, 'https://creator.douyin.com/creator-micro/content/manage?tab=collections', 'tab=collections');
  await sleep(3000);
  const result = await readCollectionCard(cdp);
  if (!Number.isInteger(result.workCount) || !Number.isInteger(state.collectionBaseline?.workCount)) {
    throw errorWithCode('POST_DETAIL_MISMATCH', 'collection work count could not be parsed from the exact card');
  }
  const baseline = state.collectionBaseline.workCount;
  const expected = baseline + 1;
  result.baselineWorkCount = baseline;
  result.expectedWorkCount = expected;
  const alreadyBound = !!state.submissionWorkKey && state.collectionResult?.workCountIncreased === true;
  result.workCountIncreased = alreadyBound ? true : result.workCount === expected;
  result.workCountCheckMode = alreadyBound ? 'previously-verified' : 'baseline-plus-one';
  saveJson('collection-result.json', result);
  await saveScreenshot('collection-result.png', cdp);
  const passed = result.exactCardCount === 1
    && result.status === '已发布'
    && result.visibility === config.collection.visibility
    && result.workCountIncreased;
  try { await navigate(cdp, 'https://creator.douyin.com/creator-micro/content/manage', '/content/manage'); } catch (_) {}
  if (!passed) throw errorWithCode('POST_DETAIL_MISMATCH', 'collection status, visibility, or work-count readback mismatch');
  return result;
}

async function switchToImagePost(cdp) {
  await navigate(cdp, 'https://creator.douyin.com/creator-micro/content/upload', '/content/upload');
  const result = await browserCall(cdp, function () {
    const active = document.querySelector('[class*=tab-item][class*=active]');
    if (String(active ? active.textContent : '').trim() === '发布图文') return 'ALREADY_IMAGE';
    const matches = [...document.querySelectorAll('*')]
      .filter(element => String(element.textContent || '').trim() === '发布图文')
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    if (matches.length !== 1) return 'IMAGE_TAB_COUNT=' + matches.length;
    matches[0].click();
    return 'IMAGE_TAB_CLICKED';
  });
  if (!['ALREADY_IMAGE', 'IMAGE_TAB_CLICKED'].includes(result)) throw errorWithCode('PAGE_SHAPE_CHANGED', result);
  for (let attempt = 1; attempt <= 20; attempt++) {
    await sleep(500);
    const url = await evaluate(cdp, 'location.href');
    if (String(url).includes('/content/post/image')) return;
  }
  throw errorWithCode('PAGE_SHAPE_CHANGED', 'image post editor did not open');
}

async function uploadImages(cdp) {
  const documentNode = await cdp.send('DOM.getDocument');
  const input = await cdp.send('DOM.querySelector', {
    nodeId: documentNode.root.nodeId, selector: 'input[type=file][accept^="image"]',
  });
  if (!input.nodeId) throw errorWithCode('PAGE_SHAPE_CHANGED', 'image file input not found');
  await cdp.send('DOM.setFileInputFiles', { nodeId: input.nodeId, files: config.files });
  const browserInputManifest = JSON.parse(await browserCallAsync(cdp, async function () {
    const inputs = [...document.querySelectorAll('input[type=file][accept^="image"]')];
    if (inputs.length !== 1) return JSON.stringify({ ok: false, reason: 'IMAGE_INPUT_COUNT=' + inputs.length, items: [] });
    const items = [];
    for (const [index, file] of [...inputs[0].files].entries()) {
      const bytes = await file.arrayBuffer();
      const digest = await crypto.subtle.digest('SHA-256', bytes);
      const sha256 = [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
      items.push({ index, name: file.name, size: file.size, sha256 });
    }
    return JSON.stringify({ ok: true, items });
  }));
  const localInputManifest = fileManifest(config.files);
  if (!browserInputManifest.ok || !sameManifest(browserInputManifest.items, localInputManifest)) {
    throw errorWithCode('IMAGE_INPUT_MANIFEST_MISMATCH', browserInputManifest.reason || 'browser FileList differs from local files');
  }
  for (let attempt = 1; attempt <= 50; attempt++) {
    await sleep(2000);
    const state = JSON.parse(await browserCall(cdp, function () {
      const body = String(document.body.innerText || '');
      const count = Number((body.match(/已添加(\d+)张图片/) || [])[1] || 0);
      return JSON.stringify({ uploading: body.includes('取消上传'), count });
    }));
    if (!state.uploading && state.count === config.files.length) {
      const editorImageManifest = await readEditorImageManifest(cdp);
      return { browserInputManifest: browserInputManifest.items, editorImageManifest };
    }
  }
  throw errorWithCode('UPLOAD_INCOMPLETE', 'uploaded image count did not reach expected value');
}

async function readEditorImageManifest(cdp) {
  const evidence = JSON.parse(await browserCallAsync(cdp, async function (args) {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden';
    };
    const countNodes = [...document.querySelectorAll('*')]
      .filter(visible)
      .filter(element => String(element.innerText || '').trim() === `已添加${args.count}张图片`)
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const regions = [];
    for (const countNode of countNodes) {
      let node = countNode.parentElement;
      for (let level = 0; level < 8 && node && node !== document.body; level++, node = node.parentElement) {
        const text = String(node.innerText || '');
        const images = [...node.querySelectorAll('img')].filter(image => {
          const rect = image.getBoundingClientRect();
          return visible(image) && rect.width >= 40 && rect.height >= 40 && !!image.currentSrc;
        });
        if (text.includes('继续添加') && text.includes('编辑图片') && images.length === args.count) {
          regions.push({ node, images });
          break;
        }
      }
    }
    const uniqueRegions = [...new Set(regions.map(region => region.node))]
      .map(node => regions.find(region => region.node === node));
    uniqueRegions.sort((a, b) => String(a.node.innerText || '').length - String(b.node.innerText || '').length);
    if (uniqueRegions.length !== 1) {
      return JSON.stringify({ ok: false, reason: 'IMAGE_EDITOR_REGION_COUNT=' + uniqueRegions.length, items: [] });
    }
    const items = [];
    try {
      for (const [index, image] of uniqueRegions[0].images.entries()) {
        const response = await fetch(image.currentSrc, { credentials: 'include' });
        if (!response.ok) throw new Error('image fetch HTTP ' + response.status);
        const bytes = await response.arrayBuffer();
        const digest = await crypto.subtle.digest('SHA-256', bytes);
        const sha256 = [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
        items.push({ index, size: bytes.byteLength, sha256, naturalWidth: image.naturalWidth, naturalHeight: image.naturalHeight });
      }
    } catch (error) {
      return JSON.stringify({ ok: false, reason: 'IMAGE_EDITOR_DIGEST_FAILED: ' + error.message, items: [] });
    }
    return JSON.stringify({ ok: items.length === args.count, reason: '', items });
  }, { count: config.files.length }));
  if (!evidence.ok || evidence.items.length !== config.files.length) {
    throw errorWithCode('IMAGE_ORDER_EVIDENCE_MISSING', evidence.reason || 'ordered editor image evidence is incomplete');
  }
  return evidence.items;
}

async function fillContent(cdp) {
  const result = JSON.parse(await browserCall(cdp, function (args) {
    const title = [...document.querySelectorAll('input')].find(element => String(element.placeholder || '').includes('添加作品标题'));
    const editor = document.querySelector('[contenteditable=true]');
    if (!title || !editor) return JSON.stringify({ ok: false, reason: 'title or editor missing' });
    const titleSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    titleSetter.call(title, args.title);
    title.dispatchEvent(new Event('input', { bubbles: true }));
    editor.focus();
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(editor);
    selection.removeAllRanges();
    selection.addRange(range);
    const inserted = document.execCommand('insertText', false, args.body);
    if (!inserted) {
      editor.textContent = args.body;
      editor.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: args.body }));
    }
    return JSON.stringify({ ok: true, title: title.value, body: editor.innerText });
  }, { title: config.title, body: config.body }));
  if (!result.ok || result.title !== config.title || normalizeBrowserText(result.body) !== normalizeBrowserText(config.body)) {
    throw errorWithCode('PAGE_SHAPE_CHANGED', 'title or body fill verification failed');
  }
}

async function selectMusic(cdp) {
  if (config.music.mode === 'none') return { mode: 'none', selected: false };
  const opened = await browserCall(cdp, function () {
    const matches = [...document.querySelectorAll('button, span, div')]
      .filter(element => element.children.length <= 2 && String(element.textContent || '').trim() === '选择音乐');
    if (!matches.length) return 'MUSIC_BUTTON_NOT_FOUND';
    matches[matches.length - 1].click();
    return 'MUSIC_DRAWER_OPENED';
  });
  if (opened !== 'MUSIC_DRAWER_OPENED') throw errorWithCode('PAGE_SHAPE_CHANGED', opened);
  await sleep(3000);
  const searched = await browserCall(cdp, function (args) {
    const input = [...document.querySelectorAll('input')].find(element => String(element.placeholder || '') === '搜索音乐');
    if (!input) return 'SEARCH_INPUT_NOT_FOUND';
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    setter.call(input, args.keyword);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    return 'SEARCH_TYPED';
  }, { keyword: config.music.keyword });
  if (searched !== 'SEARCH_TYPED') throw errorWithCode('PAGE_SHAPE_CHANGED', searched);
  await sleep(3500);
  const candidates = JSON.parse(await browserCall(cdp, function () {
    const buttons = [...document.querySelectorAll('button')].filter(button => String(button.textContent || '').trim() === '使用');
    return JSON.stringify(buttons.slice(0, 30).map((button, index) => {
      const card = button.closest('[class*=card-wrapper]');
      const titleNodes = card ? [...card.querySelectorAll('[class*=song-name]')] : [];
      const artistNodes = card ? [...card.querySelectorAll('[class*=song-author]')] : [];
      const durationNodes = card ? [...card.querySelectorAll('[class*=song-duration]')] : [];
      if (titleNodes.length !== 1 || artistNodes.length !== 1 || durationNodes.length !== 1) return null;
      const title = String(titleNodes[0].textContent || '').trim();
      const artist = String(artistNodes[0].textContent || '').trim();
      const duration = String(durationNodes[0].textContent || '').trim();
      return {
        index,
        title,
        artist,
        duration,
        text: [title, artist, duration].join(' | '),
      };
    }).filter(Boolean));
  }));
  const choice = chooseMusicCandidate(candidates, config.music);
  saveJson('music-candidates.json', choice);
  if (choice.status !== 'selected') {
    await saveScreenshot('music-candidates.png', cdp, false);
    await cdp.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
    await cdp.send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
    throw errorWithCode('MUSIC_NO_MATCH', choice.reason);
  }
  const clicked = await browserCall(cdp, function (args) {
    const normalize = value => String(value || '').replace(/\s+/g, '').toLocaleLowerCase('zh-CN');
    const buttons = [...document.querySelectorAll('button')].filter(button => String(button.textContent || '').trim() === '使用');
    const matches = buttons.filter(button => {
      const card = button.closest('[class*=card-wrapper]');
      const titles = card ? [...card.querySelectorAll('[class*=song-name]')] : [];
      const artists = card ? [...card.querySelectorAll('[class*=song-author]')] : [];
      const durations = card ? [...card.querySelectorAll('[class*=song-duration]')] : [];
      if (titles.length !== 1 || artists.length !== 1 || durations.length !== 1) return false;
      const title = String(titles[0].textContent || '').trim();
      const artist = String(artists[0].textContent || '').trim();
      const duration = String(durations[0].textContent || '').trim();
      return normalize(title) === normalize(args.title)
        && normalize(artist) === normalize(args.artist)
        && normalize(duration) === normalize(args.duration);
    });
    if (matches.length !== 1) return 'MUSIC_EXACT_COUNT=' + matches.length;
    matches[0].click();
    return 'MUSIC_SELECTED';
  }, {
    title: choice.candidate.title || config.music.prefer,
    artist: choice.candidate.artist || config.music.artist,
    duration: choice.candidate.duration,
  });
  if (clicked !== 'MUSIC_SELECTED') throw errorWithCode('MUSIC_NO_MATCH', clicked);
  await sleep(2500);
  await cdp.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
  await cdp.send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
  await sleep(800);
  return { ...choice, selected: true };
}

async function selectCollection(cdp, collectionBaseline) {
  if (!config.collection) return { selected: false, title: '' };
  const opened = await browserCall(cdp, function () {
    const labels = [...document.querySelectorAll('*')]
      .filter(element => String(element.innerText || '').trim() === '添加合集')
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const rows = [...new Set(labels.map(label => label.closest('[class*=content-obt]')).filter(Boolean))];
    if (rows.length !== 1) return 'COLLECTION_ROW_COUNT=' + rows.length;
    const row = rows[0];
    const selects = row ? [...row.querySelectorAll('.semi-select')] : [];
    if (selects.length !== 2) return 'COLLECTION_SELECT_COUNT=' + selects.length;
    selects[1].click();
    return 'COLLECTION_OPENED';
  });
  if (opened !== 'COLLECTION_OPENED') throw errorWithCode('PAGE_SHAPE_CHANGED', opened);
  await sleep(1500);
  const selected = JSON.parse(await browserCall(cdp, function (args) {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    const options = [...document.querySelectorAll('[role=option], .semi-select-option')].filter(visible);
    const matches = options.filter(option => {
      const titles = [...option.querySelectorAll('[class*=option-title]')]
        .filter(element => String(element.textContent || '').trim() === args.title);
      return titles.length === 1;
    });
    if (matches.length !== 1) return JSON.stringify({ ok: false, reason: 'COLLECTION_EXACT_COUNT=' + matches.length });
    const countMatches = String(matches[0].innerText || '').match(/共(\d+)个作品/);
    const optionWorkCount = countMatches ? Number(countMatches[1]) : null;
    if (!Number.isInteger(optionWorkCount) || optionWorkCount !== args.workCount) {
      return JSON.stringify({ ok: false, reason: 'COLLECTION_OPTION_COUNT_MISMATCH', optionWorkCount });
    }
    matches[0].click();
    return JSON.stringify({ ok: true, optionWorkCount });
  }, { title: config.collection.title, workCount: collectionBaseline.workCount }));
  if (!selected.ok) {
    await saveScreenshot('collection-options.png', cdp, false);
    throw errorWithCode(selected.reason.includes('COUNT=0') ? 'COLLECTION_NOT_FOUND' : 'COLLECTION_AMBIGUOUS', selected.reason);
  }
  await sleep(1200);
  const verification = await readCollectionSelectionEvidence(cdp, { selected: true, title: config.collection.title, episode: '' });
  if (!verification.episode) throw errorWithCode('COLLECTION_READBACK_MISMATCH', 'collection episode is missing');
  return { selected: true, title: config.collection.title, episode: verification.episode, optionWorkCount: selected.optionWorkCount };
}

async function setPublishSettings(cdp) {
  const labels = { public: '公开', friends: '好友可见', private: '仅自己可见' };
  const result = JSON.parse(await browserCall(cdp, function (args) {
    const choose = text => {
      const matches = [...document.querySelectorAll('label')].filter(label => String(label.innerText || '').trim() === text);
      if (matches.length !== 1) return false;
      const label = matches[0];
      const input = label.querySelector('input');
      if (label.dataset.checked === 'true' && input && input.checked) return true;
      label.click();
      return true;
    };
    return JSON.stringify({
      visibilityAction: choose(args.visibility),
      publishAtAction: choose('立即发布'),
    });
  }, { visibility: labels[config.visibility] }));
  if (!result.visibilityAction || !result.publishAtAction) throw errorWithCode('PAGE_SHAPE_CHANGED', 'publish setting controls not found');
  await sleep(800);
}

async function readMusicEvidence(cdp, selectedMusic) {
  const result = JSON.parse(await browserCall(cdp, function (args) {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden';
    };
    const normalize = value => String(value || '').replace(/[\s\u200B-\u200D\uFEFF]+/g, '').toLocaleLowerCase('zh-CN');
    const exactNodes = (root, value) => [...root.querySelectorAll('*')]
      .filter(visible)
      .filter(element => normalize(element.textContent) === normalize(value));
    const labels = [...document.querySelectorAll('*')]
      .filter(visible)
      .filter(element => String(element.innerText || '').trim() === '选择音乐')
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const rows = [...new Set(labels.map(label => label.closest('[class*=content-obt]')).filter(Boolean))];
    const matchingRows = rows.filter(row =>
      exactNodes(row, args.title).length === 1
      && exactNodes(row, args.duration).length === 1
    );
    const selectedControlMarkers = rows.length === 1
      ? [...rows[0].querySelectorAll('[class*=song-name], [class*=song-duration], [class*=music-name]')].filter(visible)
      : [];
    const rowLeafTexts = rows.length === 1
      ? [...rows[0].querySelectorAll('*')].filter(visible).filter(element => element.children.length === 0)
        .map(element => String(element.textContent || '').trim()).filter(Boolean)
      : [];
    const modifyMusicCount = rowLeafTexts.filter(text => text === '修改音乐').length;
    const durationCount = rowLeafTexts.filter(text => /^\d{1,2}:\d{2}$/.test(text)).length;
    const emptyControlMarkerCount = rowLeafTexts.filter(text =>
      text === '选择音乐' || text === '点击添加合适作品风格音乐' || text === '添加音乐'
    ).length;
    const previewLabels = [...document.querySelectorAll('*')]
      .filter(visible)
      .filter(element => String(element.innerText || '').trim() === '预览图文')
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    let preview = previewLabels[0] || null;
    let previewLocated = false;
    for (let level = 0; level < 8 && preview && preview !== document.body; level++, preview = preview.parentElement) {
      if (preview.querySelector('[class*=music], [class*=sound], [class*=audio], [class*=marquee]')) {
        previewLocated = true;
        break;
      }
    }
    const expectedCredit = args.title + ' - @' + args.artist;
    const expected = normalize(expectedCredit);
    const credits = preview && preview !== document.body
      ? [...preview.querySelectorAll('*')]
        .filter(visible)
        .filter(element => element.children.length === 0)
        .map(element => normalize(element.textContent))
        .filter(text => text.includes('-@'))
      : [];
    const previewLeafTexts = preview && preview !== document.body
      ? [...preview.querySelectorAll('*')]
        .filter(visible)
        .filter(element => element.children.length === 0)
        .map(element => normalize(element.textContent)).filter(Boolean)
      : [];
    const originalSoundMarkerCount = previewLeafTexts.filter(text => /创作的原声$/.test(text)).length;
    const exactCredits = credits.filter(text => {
      if (!expected || !text) return false;
      const remainder = text.split(expected).join('');
      return remainder === '';
    });
    const unexpectedCredits = credits.filter(text => !exactCredits.includes(text));
    return JSON.stringify({
      required: args.mode !== 'none',
      mode: args.mode,
      controlRowCount: rows.length,
      matchingControlRowCount: matchingRows.length,
      selectedControlMarkerCount: selectedControlMarkers.length,
      modifyMusicCount,
      durationCount,
      emptyControlMarkerCount,
      previewLocated,
      originalSoundMarkerCount,
      expectedCredit,
      creditCount: credits.length,
      exactCreditCount: exactCredits.length,
      unexpectedCreditCount: unexpectedCredits.length,
    });
  }, selectedMusic ? { ...selectedMusic, mode: 'platform' } : { mode: 'none', title: '', artist: '', duration: '' }));
  Object.assign(result, classifyMusicEvidence(result));
  if (!result.controlVerified || !result.previewVerified) {
    throw errorWithCode('MUSIC_READBACK_MISMATCH', 'dedicated music control or preview credit did not match exactly');
  }
  return result;
}

async function readCollectionSelectionEvidence(cdp, expectedSelection) {
  const result = JSON.parse(await browserCall(cdp, function (args) {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    const labels = [...document.querySelectorAll('*')]
      .filter(visible)
      .filter(element => String(element.innerText || '').trim() === '添加合集')
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const rows = [...new Set(labels.map(label => label.closest('[class*=content-obt]')).filter(Boolean))];
    if (rows.length !== 1) return JSON.stringify({ verified: false, reason: 'COLLECTION_ROW_COUNT=' + rows.length });
    const selects = [...rows[0].querySelectorAll('.semi-select')].filter(visible);
    if (selects.length < 2) return JSON.stringify({ verified: false, reason: 'COLLECTION_SELECT_COUNT=' + selects.length });
    const select = selects[1];
    const leafTexts = [...select.querySelectorAll('*')]
      .filter(visible)
      .filter(element => element.children.length === 0)
      .map(element => String(element.textContent || '').trim()).filter(Boolean);
    const titles = leafTexts.filter(text => text === args.title);
    const episodes = [...new Set(leafTexts.filter(text => /^第\d+集$/.test(text)))];
    const notSelected = leafTexts.filter(text => text === '不选择合集').length;
    const selected = !!args.selected;
    return JSON.stringify({
      verified: selected
        ? titles.length === 1 && episodes.length === 1 && (!args.episode || episodes[0] === args.episode) && notSelected === 0
        : notSelected === 1 && titles.length === 0 && episodes.length === 0,
      selected,
      selectedTitle: titles.length === 1 ? titles[0] : '',
      episode: episodes.length === 1 ? episodes[0] : '',
      notSelectedCount: notSelected,
      leafTexts,
    });
  }, {
    selected: !!expectedSelection?.selected,
    title: expectedSelection?.title || '',
    episode: expectedSelection?.episode || '',
  }));
  if (!result.verified) throw errorWithCode('COLLECTION_READBACK_MISMATCH', result.reason || 'dedicated collection control did not match exactly');
  return result;
}

async function currentPreflight(cdp, selectedMusic, expectedAccount, collectionSelection) {
  const musicEvidence = await readMusicEvidence(cdp, selectedMusic);
  const collectionEvidence = await readCollectionSelectionEvidence(cdp, collectionSelection);
  const result = JSON.parse(await browserCall(cdp, function (args) {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden';
    };
    const normalize = value => String(value || '').replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
    const bodyText = String(document.body.innerText || '');
    const titleInputs = [...document.querySelectorAll('input')]
      .filter(element => visible(element) && String(element.placeholder || '').includes('添加作品标题'));
    const editors = [...document.querySelectorAll('[contenteditable=true]')].filter(visible);
    const titleInput = titleInputs.length === 1 ? titleInputs[0] : null;
    const editor = editors.length === 1 ? editors[0] : null;
    const imageCountNodes = [...document.querySelectorAll('*')]
      .filter(visible)
      .filter(element => String(element.innerText || '').trim() === `已添加${args.fileCount}张图片`)
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const imageCountNode = imageCountNodes[0] || null;
    const previewLabel = [...document.querySelectorAll('*')]
      .filter(visible)
      .filter(element => String(element.innerText || '').trim() === '预览图文')
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length)[0];
    let preview = previewLabel;
    for (let level = 0; level < 8 && preview && preview !== document.body; level++, preview = preview.parentElement) {
      if ([...preview.querySelectorAll('*')].some(element => String(element.innerText || '').trim() === '@' + args.accountDisplayName)) break;
    }
    const previewText = String(preview && preview !== document.body ? preview.innerText : '');
    const checked = text => [...document.querySelectorAll('label')].some(label =>
      String(label.innerText || '').trim() === text
      && label.dataset.checked === 'true'
      && label.querySelector('input')?.checked
    );
    const publishButtons = [...document.querySelectorAll('button')]
      .filter(button => visible(button) && String(button.innerText || '').trim() === '发布');
    const dialogs = [...document.querySelectorAll('[role=dialog], .semi-modal')]
      .filter(visible)
      .map(dialog => String(dialog.innerText || '').trim())
      .filter(Boolean);
    const previewLines = previewText.split(/\n+/).map(line => line.trim()).filter(Boolean);
    const previewAccountLine = previewLines.find(line => line.startsWith('@')) || '';
    const creatorDisplay = previewAccountLine.replace(/^@/, '').trim();
    const detectorLabels = [...document.querySelectorAll('*')]
      .filter(visible)
      .filter(element => String(element.innerText || '').trim() === '快速检测')
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    const detectorRegions = [];
    for (const label of detectorLabels) {
      let node = label.parentElement;
      for (let level = 0; level < 8 && node && node !== document.body; level++, node = node.parentElement) {
        const text = String(node.innerText || '');
        if (text.includes('重新检测') && (/作品未见异常|作品存在异常|检测中|风险|不建议发布/.test(text))) {
          detectorRegions.push(node);
          break;
        }
      }
    }
    const detectors = [...new Set(detectorRegions)];
    const detectorStatusNodes = detectors.length === 1
      ? [...detectors[0].querySelectorAll('*')]
        .filter(visible)
        .filter(element => element.children.length === 0)
        .map(element => String(element.innerText || element.textContent || '').trim())
        .filter(text => /^(作品未见异常|作品存在异常|检测中(?:\d+%)?|不建议发布|.*风险.*)$/.test(text))
      : [];
    const detectorStatuses = [...new Set(detectorStatusNodes)];
    return JSON.stringify({
      url: location.href,
      title: titleInput ? titleInput.value : '',
      titleMatch: !!titleInput && titleInput.value === args.title,
      bodyMatch: normalize(editor ? editor.innerText : '') === normalize(args.body),
      imageCount: imageCountNode ? args.fileCount : 0,
      imageCountMatch: !!imageCountNode,
      uploadComplete: !!imageCountNode && !String(imageCountNode.parentElement?.innerText || '').includes('取消上传'),
      creatorDisplay,
      accountDisplayVerified: !args.accountDisplayName || creatorDisplay === args.accountDisplayName,
      visibilityVerified: checked(args.visibilityLabel),
      publishAtVerified: checked('立即发布'),
      publishButtonCount: publishButtons.length,
      publishEnabled: publishButtons.length === 1 && !publishButtons[0].disabled,
      dialogs,
      platformDetectorCount: detectors.length,
      platformDetectorStatuses: detectorStatuses,
    });
  }, {
    title: config.title,
    body: config.body,
    fileCount: config.files.length,
    accountDisplayName: expectedAccount ? expectedAccount.displayName : '',
    visibilityLabel: { public: '公开', friends: '好友可见', private: '仅自己可见' }[config.visibility],
  }));
  Object.assign(result, classifyPlatformDetectorEvidence(result.platformDetectorCount, result.platformDetectorStatuses));
  return {
    ...result,
    musicControlVerified: musicEvidence.controlVerified,
    musicPreviewVerified: musicEvidence.previewVerified,
    musicEvidence,
    collectionVerified: collectionEvidence.verified,
    collectionEvidence,
    selectedMusic,
  };
}

function assertPreflight(result) {
  const checks = {
    url: (() => { try { return assertPreparedTargetUrl(result.url, '/creator-micro/content/post/image'); } catch (_) { return false; } })(),
    title: result.titleMatch,
    body: result.bodyMatch,
    images: result.imageCountMatch && result.uploadComplete,
    music: result.musicControlVerified && result.musicPreviewVerified
      && (config.music.mode === 'none' ? !result.selectedMusic : !!result.selectedMusic),
    collection: result.collectionVerified,
    visibility: result.visibilityVerified,
    publishAt: result.publishAtVerified,
    publishButton: result.publishEnabled,
    dialogs: result.dialogs.length === 0,
    platformIssue: !result.platformIssue,
    platformCheck: result.platformCheckPassed === true,
    account: result.accountDisplayVerified,
  };
  const failed = Object.entries(checks).filter(([, passed]) => !passed).map(([name]) => name);
  if (failed.length) throw errorWithCode('PREVIEW_HASH_CHANGED', 'preflight failed: ' + failed.join(', '));
}

async function waitForCurrentPreflight(cdp, selectedMusic, expectedAccount, collectionSelection) {
  let result = null;
  for (let attempt = 1; attempt <= 30; attempt++) {
    result = await currentPreflight(cdp, selectedMusic, expectedAccount, collectionSelection);
    if (result.platformIssue || result.platformCheckPassed) return result;
    await sleep(2000);
  }
  throw errorWithCode('PLATFORM_CHECK_UNKNOWN', 'platform safety check never reached an explicit success or failure state');
}

async function prepare() {
  currentPhase = 'prepare';
  await prepareEvidenceDir();
  acquireLock();
  const target = await singleCreatorPage();
  activeCdp = await connect(target);
  await enablePage(activeCdp);
  const account = await accountProbe(activeCdp);
  const collectionBaseline = await collectionEligibilityProbe(activeCdp);
  const duplicate = await duplicateProbe(activeCdp);
  await switchToImagePost(activeCdp);
  const uploadEvidence = await uploadImages(activeCdp);
  await fillContent(activeCdp);
  const music = await selectMusic(activeCdp);
  const selectedMusic = music.selected ? {
    title: music.candidate.title,
    artist: music.candidate.artist,
    duration: music.candidate.duration || '',
    text: music.candidate.text,
  } : null;
  const collection = await selectCollection(activeCdp, collectionBaseline);
  await setPublishSettings(activeCdp);
  const prepared = await waitForCurrentPreflight(activeCdp, selectedMusic, account, collection);
  assertPreflight(prepared);
  await saveScreenshot('prepared.png');
  saveJson('prepared.json', {
    ...prepared, runId: config.runId, fingerprint, music, selectedMusic, collection, account, uploadEvidence,
    collectionBaseline, duplicateBaseline: duplicate, preparedAt: new Date().toISOString(),
  });
  writeState('prepared', {
    targetId: target.id,
    imageManifest,
    browserInputManifest: uploadEvidence.browserInputManifest,
    editorImageManifest: uploadEvidence.editorImageManifest,
    account,
    selectedMusic,
    collectionSelection: collection,
    preparedAt: new Date().toISOString(),
    collectionBaseline,
    duplicateBaseline: duplicate,
    lastSuccessfulAction: 'prepared-evidence-saved',
  });
  console.log('PREPARED runId=' + config.runId + ' fingerprint=' + fingerprint);
}

async function inspectPublishDialog(cdp) {
  return JSON.parse(await browserCall(cdp, function () {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    const dialog = [...document.querySelectorAll('[role=dialog], .semi-modal')].find(visible);
    if (!dialog) return JSON.stringify({ present: false });
    return JSON.stringify({
      present: true,
      text: String(dialog.innerText || '').trim(),
      buttons: [...dialog.querySelectorAll('button')].filter(visible)
        .map(button => String(button.innerText || '').trim()).filter(Boolean),
    });
  }));
}

async function clickKnownConfirmation(cdp, buttonText) {
  return browserCall(cdp, function (args) {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    const dialog = [...document.querySelectorAll('[role=dialog], .semi-modal')].find(visible);
    const button = dialog && [...dialog.querySelectorAll('button')]
      .find(item => String(item.innerText || '').trim() === args.buttonText);
    if (!button) return 'CONFIRM_BUTTON_MOVED';
    button.click();
    return 'PUBLISH_CONFIRMED';
  }, { buttonText });
}

async function verifyDetail(cdp, cardSelector, selectedMusic, collectionSelection) {
  const clicked = await browserCall(cdp, function (args) {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    const cards = [...document.querySelectorAll('[class*=video-card-content]')].filter(visible);
    const keyOf = card => {
      const ids = new Set();
      for (const element of [card, ...card.querySelectorAll('*')]) {
        for (const attribute of ['data-item-id', 'data-aweme-id', 'data-video-id', 'data-mid']) {
          const value = String(element.getAttribute?.(attribute) || '');
          if (/^\d{10,30}$/.test(value)) ids.add(value);
        }
        if (element.matches?.('a[href]')) {
          try {
            const url = new URL(element.href, location.href);
            for (const name of ['mid', 'item_id', 'aweme_id', 'video_id']) {
              const value = String(url.searchParams.get(name) || '');
              if (/^\d{10,30}$/.test(value)) ids.add(value);
            }
            const pathId = (url.pathname.match(/\/(?:video|item)\/(\d{10,30})(?:\/|$)/) || [])[1] || '';
            if (pathId) ids.add(pathId);
          } catch (_) {}
        }
      }
      if (ids.size === 1) return 'item:' + [...ids][0];
      const cover = card.querySelector('[class*=video-card-cover]');
      const background = String(cover ? getComputedStyle(cover).backgroundImage : '');
      const raw = (background.match(/url\(["']?([^"')]+)["']?\)/) || [])[1] || '';
      try { const url = new URL(raw, location.href); return 'cover:' + url.origin + url.pathname; }
      catch (_) { return ''; }
    };
    const matches = cards.filter(item => keyOf(item) === args.workKey);
    const card = matches.length === 1 ? matches[0] : null;
    if (!card) return 'CARD_NOT_FOUND';
    const edit = [...card.querySelectorAll('*')]
      .filter(element => String(element.innerText || '').trim() === '编辑作品')
      .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length)[0];
    if (!edit) return 'EDIT_NOT_FOUND';
    edit.click();
    return 'EDIT_CLICKED';
  }, cardSelector);
  if (clicked !== 'EDIT_CLICKED') throw errorWithCode('POST_DETAIL_MISMATCH', clicked);
  for (let attempt = 1; attempt <= 30; attempt++) {
    await sleep(500);
    const url = await evaluate(cdp, 'location.href');
    if (String(url).includes('/content/post/image?mid=')) break;
    if (attempt === 30) throw errorWithCode('POST_DETAIL_MISMATCH', 'edit detail did not open');
  }
  await sleep(3000);
  const musicEvidence = await readMusicEvidence(cdp, selectedMusic);
  const collectionEvidence = await readCollectionSelectionEvidence(cdp, collectionSelection);
  const detail = JSON.parse(await browserCall(cdp, function (args) {
    const titleInputs = [...document.querySelectorAll('input')].filter(element => String(element.placeholder || '').includes('添加作品标题'));
    const titleInput = titleInputs.length === 1 ? titleInputs[0] : null;
    const itemId = (location.href.match(/[?&]mid=(\d+)/) || [])[1] || '';
    return JSON.stringify({
      url: location.href,
      itemId,
      titleVerified: (titleInput ? titleInput.value : '') === args.title,
      submitVisible: String(document.body.innerText || '').includes('提交修改'),
    });
  }, {
    title: config.title,
  }));
  detail.musicPersisted = musicEvidence.controlVerified && musicEvidence.previewVerified;
  detail.collectionPersisted = collectionEvidence.verified;
  detail.musicEvidence = musicEvidence;
  detail.collectionEvidence = collectionEvidence;
  if (cardSelector.itemId && detail.itemId !== cardSelector.itemId) {
    throw errorWithCode('POST_DETAIL_MISMATCH', 'detail item ID changed from the previously bound submission');
  }
  saveJson('post-detail.json', detail);
  await saveScreenshot('post-detail.png', cdp);
  const passed = detail.itemId && detail.titleVerified && detail.musicPersisted && detail.collectionPersisted;
  try { await navigate(cdp, 'https://creator.douyin.com/creator-micro/content/manage', '/content/manage'); } catch (_) {}
  if (!passed) throw errorWithCode('POST_DETAIL_MISMATCH', 'post-publish BGM or collection readback mismatch');
  return detail;
}

async function dismissKnownManageNotices(cdp) {
  const result = await browserCall(cdp, function () {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    const dialogs = [...document.querySelectorAll('[role=dialog], .semi-modal')].filter(visible);
    const known = dialogs.find(dialog => String(dialog.innerText || '').includes('合集管理移到这里啦'));
    if (!known) return 'NO_KNOWN_NOTICE';
    const button = [...known.querySelectorAll('button')]
      .find(item => String(item.innerText || '').trim() === '知道了');
    if (!button) return 'KNOWN_NOTICE_BUTTON_MISSING';
    button.click();
    return 'KNOWN_NOTICE_DISMISSED';
  });
  if (result === 'KNOWN_NOTICE_BUTTON_MISSING') throw errorWithCode('PAGE_SHAPE_CHANGED', result);
  if (result === 'KNOWN_NOTICE_DISMISSED') await sleep(600);
}

async function verifyCore(state) {
  currentPhase = 'verify';
  const cdp = await openPreparedTarget(state);
  activeCdp = cdp;
  try {
    await verifyPreparedAccount(cdp, state, 'account-before-verify.json', 'verify');
    await navigate(cdp, 'https://creator.douyin.com/creator-micro/content/manage', '/content/manage');
    try { await cdp.send('Page.reload', { ignoreCache: true }, 15000); } catch (_) {}
    await sleep(6000);
    await dismissKnownManageNotices(cdp);
    const intentEpoch = Date.parse(state.publishIntentAt || state.publishClickedAt || state.updatedAt || 0);
    if (!Number.isFinite(intentEpoch) || !Number.isInteger(state.duplicateBaseline?.worksCount)) {
      throw errorWithCode('STATE_INVALID_FOR_VERIFY', 'publish intent time or works-count baseline is missing');
    }
    await resetManageFilters(cdp);
    const current = await scanAllWorks(cdp);
    if (!current.scanComplete) throw errorWithCode('MANAGE_READBACK_PENDING', 'could not prove a complete manage-page scan');
    let submissionWorkKey = state.submissionWorkKey || '';
    if (!submissionWorkKey) {
      const added = uniqueNewItemIds(state.duplicateBaseline.workKeys, current.workKeys);
      const removed = uniqueNewItemIds(current.workKeys, state.duplicateBaseline.workKeys);
      if (added.length !== 1 || removed.length || current.worksCount !== state.duplicateBaseline.worksCount + 1) {
        throw errorWithCode('MANAGE_READBACK_PENDING', `expected one unique new work ID, added=${added.length}, removed=${removed.length}`);
      }
      submissionWorkKey = added[0];
    }
    const selected = current.items.find(item => item.workKey === submissionWorkKey) || null;
    const parseChineseDate = text => {
      const match = String(text || '').match(/(\d{4})年(\d{2})月(\d{2})日 (\d{2}):(\d{2})/);
      return match ? new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]), Number(match[4]), Number(match[5])).getTime() : 0;
    };
    const dateEpoch = selected ? parseChineseDate(selected.date) : 0;
    const status = selected ? selected.status : '';
    const result = {
      url: 'https://creator.douyin.com/creator-micro/content/manage',
      workKey: submissionWorkKey,
      itemId: selected ? selected.itemId : '',
      worksCount: current.worksCount,
      baselineWorksCount: state.duplicateBaseline.worksCount,
      titleMatch: !!selected && [
        normalizeBrowserText(config.title),
        normalizeBrowserText(config.title + '。' + config.body),
        normalizeBrowserText(config.title + config.body),
      ].includes(normalizeBrowserText(selected.titleText)),
      imageCountMatch: workImageBadgeMatches(selected, config.files.length),
      timeNearIntent: !!dateEpoch && Math.abs(dateEpoch - intentEpoch) <= 10 * 60 * 1000,
      status,
      date: selected ? selected.date : '',
      cardText: selected ? selected.text.slice(0, 1600) : '',
    };
    saveJson('publish-result.json', result);
    await saveScreenshot('publish-result.png', cdp);
    if (!result.titleMatch || !result.imageCountMatch || !result.timeNearIntent
      || !/^(审核中|已发布|审核不通过|未通过)$/.test(result.status)) {
      throw errorWithCode('MANAGE_READBACK_PENDING', 'unique new work did not match the confirmed submission');
    }
    if (/^(审核不通过|未通过)$/.test(result.status)) {
      const rejectedState = writeState('rejected', {
        submissionWorkKey,
        submissionItemId: selected ? selected.itemId : '',
        rejectedAt: new Date().toISOString(),
        platformStatus: result.status,
        rejectionText: result.cardText,
        readback: result,
        browserRetained: true,
        lastSuccessfulAction: 'submission-readback-rejected',
      });
      const error = errorWithCode('SUBMISSION_REJECTED', 'Douyin reported that the submitted work did not pass review');
      error.state = rejectedState;
      throw error;
    }
    if (result.status === '审核中') {
      const reviewingState = writeState('reviewing', {
        submissionWorkKey,
        submissionItemId: selected ? selected.itemId : '',
        submittedAt: state.submittedAt || new Date().toISOString(),
        lastReviewedAt: new Date().toISOString(),
        platformStatus: result.status,
        readback: result,
        finalUrl: 'https://creator.douyin.com/creator-micro/content/manage',
        browserRetained: true,
        lastSuccessfulAction: 'submission-readback-reviewing',
      });
      console.log('SUBMISSION_VERIFIED ' + JSON.stringify({
        title: config.title, status: result.status, date: result.date,
      }));
      return reviewingState;
    }
    let detail = null;
    if (config.verifyDetail) {
      detail = await verifyDetail(cdp, { workKey: submissionWorkKey, itemId: state.submissionItemId || '' }, state.selectedMusic, state.collectionSelection);
    }
    const collectionResult = await verifyCollectionAfter(cdp, state);
    const publishedState = writeState('published', {
      publishedAt: new Date().toISOString(),
      submissionWorkKey,
      submissionItemId: detail ? detail.itemId : selected ? selected.itemId : '',
      platformStatus: result.status,
      readback: result,
      detail,
      collectionResult,
      itemId: detail ? detail.itemId : '',
      finalUrl: 'https://creator.douyin.com/creator-micro/content/manage',
      browserRetained: true,
      lastSuccessfulAction: detail ? 'detail-readback-verified' : 'manage-readback-verified',
    });
    console.log('PUBLISH_VERIFIED ' + JSON.stringify({
      title: config.title, status: result.status, date: result.date,
      itemId: publishedState.itemId, detailVerified: !!detail,
    }));
    return publishedState;
  } catch (error) {
    try {
      const safeUrl = String(await evaluate(cdp, 'location.href', 5000)).split(/[?#]/)[0];
      saveJson('verify-error-page.json', { url: safeUrl, at: new Date().toISOString() });
      await saveScreenshot('verify-error.png', cdp, false);
    } catch (_) {}
    throw error;
  } finally {
    cdp.close();
    activeCdp = null;
  }
}

async function publish() {
  currentPhase = 'publish';
  acquireLock();
  const state = loadState();
  try {
    assertPublishAuthorization(state, { confirmation, runId: config.runId, fingerprint });
  } catch (error) {
    const code = confirmation !== config.runId ? 'CONFIRMATION_REQUIRED'
      : state.fingerprint !== fingerprint ? 'PREVIEW_HASH_CHANGED' : 'STATE_INVALID_FOR_PUBLISH';
    throw errorWithCode(code, error.message + '; run verify if a publish intent already exists');
  }
  if (!sameManifest(state.imageManifest, imageManifest)) {
    throw errorWithCode('PREVIEW_HASH_CHANGED', 'image file identity or order changed after prepare');
  }
  activeCdp = await openPreparedTarget(state, '/creator-micro/content/post/image');
  await verifyPreparedAccount(activeCdp, state, 'account-before-publish.json', 'publish');
  const latestBaseline = await scanManageInTemporaryPage(activeCdp, 'duplicate-before-publish.json');
  assertDuplicateBaselineUnchanged(state.duplicateBaseline, latestBaseline);
  const currentEditorImageManifest = await readEditorImageManifest(activeCdp);
  if (!sameManifest(state.editorImageManifest, currentEditorImageManifest)) {
    throw errorWithCode('IMAGE_ORDER_EVIDENCE_MISSING', 'editor thumbnail sequence changed after prepare');
  }
  const preflight = await waitForCurrentPreflight(activeCdp, state.selectedMusic, state.account, state.collectionSelection);
  assertPreflight(preflight);
  saveJson('final-before-publish.json', { ...preflight, runId: config.runId, fingerprint, checkedAt: new Date().toISOString() });
  await saveScreenshot('final-before-publish.png');
  const intentAt = new Date().toISOString();
  writeState('publish-intent', {
    publishIntentAt: intentAt,
    intentMinute: chineseMinute(Date.parse(intentAt)),
    lastSuccessfulAction: 'publish-intent-written',
  });
  const clicked = await browserCall(activeCdp, function () {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    const buttons = [...document.querySelectorAll('button')]
      .filter(button => visible(button) && String(button.innerText || '').trim() === '发布');
    if (buttons.length !== 1) return 'PUBLISH_COUNT=' + buttons.length;
    if (buttons[0].disabled) return 'PUBLISH_DISABLED';
    buttons[0].click();
    return 'PUBLISH_CLICKED';
  });
  if (clicked !== 'PUBLISH_CLICKED') throw errorWithCode('PUBLISH_CLICK_AMBIGUOUS', clicked);
  const clickedAt = new Date().toISOString();
  writeState('publish-clicked', {
    publishClickedAt: clickedAt,
    lastSuccessfulAction: 'publish-clicked',
  });
  let redirected = false;
  let confirmationHandled = false;
  for (let attempt = 1; attempt <= 30; attempt++) {
    await sleep(2000);
    try {
      const url = await evaluate(activeCdp, 'location.href', 5000);
      if (String(url).includes('/content/manage')) {
        redirected = true;
        break;
      }
    } catch (_) {}
    const dialog = await inspectPublishDialog(activeCdp);
    if (!dialog.present || /发布成功/.test(dialog.text)) continue;
    const button = dialog.buttons.find(text => /^(确认发布|确定发布|发布)$/.test(text));
    if (!/确认发布|确定发布|发布作品/.test(dialog.text) || !button || confirmationHandled) {
      saveJson('unexpected-dialog.json', dialog);
      await saveScreenshot('unexpected-dialog.png', activeCdp, false);
      throw errorWithCode('PUBLISH_CLICK_AMBIGUOUS', 'unknown or repeated publish dialog');
    }
    const confirmed = await clickKnownConfirmation(activeCdp, button);
    if (confirmed !== 'PUBLISH_CONFIRMED') throw errorWithCode('PUBLISH_CLICK_AMBIGUOUS', confirmed);
    confirmationHandled = true;
  }
  activeCdp.close();
  activeCdp = null;
  if (!redirected) {
    writeState('publish-clicked', { lastSuccessfulAction: 'redirect-not-observed-run-verify' });
  }
  return verifyCore(loadState());
}

async function verify() {
  acquireLock();
  const state = loadState();
  try { assertVerifyState(state, fingerprint); } catch (error) {
    throw errorWithCode(state.fingerprint !== fingerprint ? 'PREVIEW_HASH_CHANGED' : 'STATE_INVALID_FOR_VERIFY', error.message);
  }
  return verifyCore(state);
}

function safePathOnly(value) {
  try {
    const url = new URL(String(value || ''));
    return url.origin + url.pathname;
  } catch (_) { return ''; }
}

async function recordError(error) {
  if (!config) return;
  if (error.code === 'EVIDENCE_DIR_NOT_EMPTY') return;
  try { fs.mkdirSync(config.evidenceDir, { recursive: true }); } catch (_) { return; }
  let state = {};
  try { state = fs.existsSync(statePath()) ? JSON.parse(fs.readFileSync(statePath(), 'utf8')) : {}; } catch (_) {}
  let pageState = null;
  if (activeCdp) {
    try {
      pageState = JSON.parse(await evaluate(activeCdp,
        "JSON.stringify({url:location.href,readyState:document.readyState})",
        5000));
      pageState.url = safePathOnly(pageState.url);
      saveJson('page-state.json', pageState);
      await saveScreenshot('error.png', activeCdp, false);
    } catch (_) {}
  }
  try {
    const targets = (await listPages()).map(target => ({
      id: target.id, type: target.type, url: safePathOnly(target.url),
    }));
    saveJson('targets.json', targets);
  } catch (_) {}
  try {
    saveJson('error.json', {
      runId: config.runId,
      phase: state.phase || currentPhase,
      code: error.code || 'UNEXPECTED_ERROR',
      message: error.message,
      at: new Date().toISOString(),
      currentUrl: pageState ? pageState.url : '',
      cdpPort: PORT,
      fingerprint,
      lastSuccessfulAction: state.lastSuccessfulAction || '',
      publishIntentWritten: ['publish-intent', 'publish-clicked', 'reviewing', 'rejected', 'published'].includes(state.phase),
      publishMayHaveBeenClicked: ['publish-intent', 'publish-clicked', 'reviewing', 'rejected', 'published'].includes(state.phase),
      recovery: ['publish-intent', 'publish-clicked', 'reviewing', 'rejected', 'published'].includes(state.phase)
        ? 'Run verify only. Never run publish again.'
        : 'Inspect evidence, correct the issue, and start a new runId/evidenceDir.',
    });
  } catch (_) {}
}

async function main() {
  if (!['validate', 'prepare', 'publish', 'verify', 'status'].includes(command)) {
    throw errorWithCode('COMMAND_INVALID', 'usage: node workflow.js <validate|prepare|publish|verify|status> <config.json> [--confirm runId]');
  }
  loadConfig();
  if (command === 'validate') {
    console.log(JSON.stringify({ valid: true, runId: config.runId, fingerprint, config }, null, 2));
    return;
  }
  if (command === 'status') {
    console.log(JSON.stringify(loadState(), null, 2));
    return;
  }
  if (command === 'prepare') await prepare();
  if (command === 'publish') await publish();
  if (command === 'verify') await verify();
}

if (require.main === module) {
  main().catch(async error => {
    await recordError(error);
    console.error((error.code || 'UNEXPECTED_ERROR') + ': ' + error.message);
    process.exitCode = 1;
  }).finally(() => {
    if (activeCdp) activeCdp.close();
    releaseLock();
  });
}

module.exports = {
  sameStringSet, uniqueNewItemIds, assertDuplicateBaselineUnchanged, assertSameAccount,
  displayedTitleMatches, assertPreflight, assertPreparedTargetUrl, lockOwnershipMatches,
  assertWorkCardEvidence, workImageBadgeMatches,
};
