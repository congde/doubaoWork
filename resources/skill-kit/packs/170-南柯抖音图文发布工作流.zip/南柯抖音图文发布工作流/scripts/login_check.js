'use strict';

const fs = require('fs');
const path = require('path');
const { PORT, singleCreatorPage, connect, evaluate, sleep } = require('./cdp.js');
const { classifyLoginState } = require('./login_policy.js');

const outputPng = process.argv[2] || path.join(process.env.TEMP || 'C:\\temp', 'nk-douyin-login.png');
const stateFile = path.join(path.dirname(outputPng), 'nk-douyin-login-state.json');
const unattended = process.env.UNATTENDED === '1';

(async () => {
  fs.mkdirSync(path.dirname(outputPng), { recursive: true });
  const target = await singleCreatorPage();
  const cdp = await connect(target);
  try {
    await cdp.send('Page.enable');
    await cdp.send('Runtime.enable');
    await cdp.send('Emulation.setDeviceMetricsOverride', { width: 1280, height: 900, deviceScaleFactor: 1, mobile: false });
    try { await cdp.send('Page.navigate', { url: 'https://creator.douyin.com/creator-micro/home' }, 15000); } catch (_) {}
    await sleep(6000);

    for (let attempt = 1; attempt <= 12; attempt++) {
      const page = JSON.parse(await evaluate(cdp, `JSON.stringify({url: location.href, body: String(document.body.innerText || '').slice(0, 6000), readyState: document.readyState})`));
      const status = classifyLoginState(page);
      const account = (page.body.match(/抖音号：?\s*(\d+)/) || [])[1] || '';
      fs.writeFileSync(stateFile, JSON.stringify({ status, account, url: page.url, port: PORT, checkedAt: new Date().toISOString() }, null, 2), 'utf8');

      if (status === 'logged_in') {
        console.log(`LOGGED_IN account=${account} url=${page.url}`);
        return;
      }
      if (status === 'unknown') {
        const shot = await cdp.send('Page.captureScreenshot', { format: 'png' });
        fs.writeFileSync(outputPng, Buffer.from(shot.data, 'base64'));
        const error = new Error(`LOGIN_UNKNOWN: page is neither a confirmed account home nor a login page; see ${outputPng}`);
        error.code = 'LOGIN_UNKNOWN';
        throw error;
      }
      if (unattended) {
        const error = new Error('LOGIN_REQUIRED: unattended mode refuses QR login');
        error.code = 'LOGIN_REQUIRED';
        throw error;
      }

      await evaluate(cdp, `(() => {
        if (!/已失效|点击刷新|重新获取/.test(document.body.innerText)) return 'FRESH';
        const button = [...document.querySelectorAll('*')].filter(el => el.children.length === 0).find(el => /刷新|重新获取/.test(String(el.textContent || '')));
        if (!button) return 'EXPIRED_WITHOUT_REFRESH';
        button.click();
        return 'REFRESHED';
      })()`);
      await sleep(1500);
      const shot = await cdp.send('Page.captureScreenshot', { format: 'png' });
      fs.writeFileSync(outputPng, Buffer.from(shot.data, 'base64'));
      console.log(`LOGIN_REQUIRED attempt=${attempt} qr=${outputPng}`);
      await sleep(5000);
    }
    const error = new Error('LOGIN_REQUIRED: QR login timed out');
    error.code = 'LOGIN_REQUIRED';
    throw error;
  } finally {
    cdp.close();
  }
})().catch(error => {
  console.error(error.message);
  process.exitCode = error.code === 'LOGIN_REQUIRED' ? 2 : 1;
});
