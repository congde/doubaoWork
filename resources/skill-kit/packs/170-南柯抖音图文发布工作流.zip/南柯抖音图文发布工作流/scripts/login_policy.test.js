'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { classifyLoginState } = require('./login_policy.js');

test('login requires positive account and navigation features', () => {
  assert.equal(classifyLoginState({
    url: 'https://creator.douyin.com/creator-micro/home',
    body: '作品发布\n内容管理\nAI 南柯\n抖音号：363705620',
  }), 'logged_in');
});

test('login page is logged out', () => {
  assert.equal(classifyLoginState({
    url: 'https://creator.douyin.com/creator-micro/home', body: '扫码登录\n验证码登录',
  }), 'logged_out');
});

test('blank and error pages remain unknown', () => {
  assert.equal(classifyLoginState({ url: 'https://creator.douyin.com/error', body: '加载失败' }), 'unknown');
});
