param(
  [int]$Port = 9231,
  [string]$ProfileDir = 'C:\temp\nk-douyin-image-publish',
  [string]$StartUrl = 'https://creator.douyin.com/creator-micro/home'
)

$ErrorActionPreference = 'Stop'
$NkEdgeExe = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
$NkProfilePath = [System.IO.Path]::GetFullPath($ProfileDir)
$NkProfileRoot = [System.IO.Path]::GetPathRoot($NkProfilePath)

if (-not (Test-Path -LiteralPath $NkEdgeExe)) { throw "Edge not found: $NkEdgeExe" }
if ($Port -lt 1024 -or $Port -gt 65535) { throw "Invalid port: $Port" }
if ($NkProfilePath -eq $NkProfileRoot) { throw 'ProfileDir must not be a drive root' }

$NkExisting = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($NkExisting) {
  try {
    $NkVersion = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/version" -TimeoutSec 5
  } catch {
    throw "Port $Port is occupied but does not expose a healthy CDP endpoint"
  }
  $NkOwner = Get-CimInstance Win32_Process -Filter "ProcessId=$($NkExisting[0].OwningProcess)" -ErrorAction SilentlyContinue
  if (-not $NkOwner -or $NkOwner.CommandLine -notlike "*$NkProfilePath*") {
    throw "Port $Port belongs to a different or unverified browser profile"
  }
  [pscustomobject]@{ status = 'already-running'; port = $Port; profileDir = $NkProfilePath; browser = $NkVersion.Browser } | ConvertTo-Json
  exit 0
}

New-Item -ItemType Directory -Path $NkProfilePath -Force | Out-Null
$NkArguments = @(
  "--remote-debugging-port=$Port",
  "--user-data-dir=$NkProfilePath",
  '--no-first-run',
  '--no-default-browser-check',
  '--disable-extensions',
  $StartUrl
)
$NkProcess = Start-Process -FilePath $NkEdgeExe -ArgumentList $NkArguments -PassThru

$NkReady = $false
for ($NkAttempt = 1; $NkAttempt -le 15; $NkAttempt++) {
  Start-Sleep -Seconds 1
  try {
    $NkVersion = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/version" -TimeoutSec 2
    $NkReady = $true
    break
  } catch {}
}
if (-not $NkReady) { throw "Edge started but CDP port $Port did not become ready" }

[pscustomobject]@{
  status = 'started'
  processId = $NkProcess.Id
  port = $Port
  profileDir = $NkProfilePath
  browser = $NkVersion.Browser
  startUrl = $StartUrl
} | ConvertTo-Json
