#!/usr/bin/env python3
"""图表生成：CSV → 零依赖 SVG 图表（柱状/折线/饼图），自动排序、TopN+其他、数值标注。"""
import argparse
import csv
import html
import re
import sys
from collections import defaultdict
from pathlib import Path

PALETTE = ["#2563eb", "#dc2626", "#16a34a", "#d97706", "#7c3aed", "#0891b2", "#db2777", "#65a30d"]


def load_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def to_num(v):
    try:
        return float(re.sub(r"[￥¥$,\s]", "", v))
    except ValueError:
        return None


def svg_header(w, h, title, desc=""):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" font-family="PingFang SC,Microsoft YaHei,sans-serif">',
            f'<rect width="{w}" height="{h}" fill="#fff"/>',
            f'<text x="{w / 2}" y="36" text-anchor="middle" font-size="19" font-weight="600" fill="#111">{html.escape(title)}</text>']
    + ([f'<text x="{w / 2}" y="56" text-anchor="middle" font-size="12" fill="#666">{html.escape(desc)}</text>'] if desc else [])


def bar_chart(labels, values, title, unit="", horizontal=None):
    horizontal = horizontal if horizontal is not None else len(labels) > 6 or max((len(l) for l in labels), default=0) > 6
    w, pad = 860, 70
    row_h = 34 if horizontal else 46
    h = 90 + row_h * len(labels) + 30
    lines = svg_header(w, h, title)
    vmax = max(values) if values else 1
    if horizontal:
        label_w = 170
        x0, chart_w = pad + label_w, w - pad - label_w - 110
        y0 = 80
        for i, (lab, v) in enumerate(zip(labels, values)):
            y = y0 + i * row_h
            bw = chart_w * v / vmax
            lines.append(f'<text x="{x0 - 8}" y="{y + 18}" text-anchor="end" font-size="13" fill="#333">{html.escape(str(lab))}</text>')
            lines.append(f'<rect x="{x0}" y="{y + 2}" width="{max(bw, 2)}" height="22" rx="3" fill="{PALETTE[0]}"/>')
            lines.append(f'<text x="{x0 + max(bw, 2) + 8}" y="{y + 18}" font-size="13" fill="#111" font-weight="600">{v:,.0f}{unit}</text>')
    else:
        y0, chart_h = h - 60, h - 130
        x0, chart_w = pad, w - 2 * pad
        bw = chart_w / len(labels) * 0.62
        lines.append(f'<line x1="{pad}" y1="{y0}" x2="{w - pad}" y2="{y0}" stroke="#ccc"/>')
        for i, (lab, v) in enumerate(zip(labels, values)):
            cx = x0 + chart_w * (i + 0.5) / len(labels)
            bh = chart_h * v / vmax
            lines.append(f'<rect x="{cx - bw / 2}" y="{y0 - bh}" width="{bw}" height="{bh}" rx="3" fill="{PALETTE[0]}"/>')
            lines.append(f'<text x="{cx}" y="{y0 - bh - 8}" text-anchor="middle" font-size="13" fill="#111" font-weight="600">{v:,.0f}{unit}</text>')
            lines.append(f'<text x="{cx}" y="{y0 + 20}" text-anchor="middle" font-size="12" fill="#555">{html.escape(str(lab))}</text>')
    lines.append("</svg>")
    return "\n".join(lines)


def line_chart(labels, values, title, unit=""):
    w, h = 860, 460
    lines = svg_header(w, h, title)
    x0, y0, cw, ch = 70, 80, w - 110, h - 150
    vmax, vmin = max(values), min(values)
    rng = (vmax - vmin) or 1
    pts = []
    for i, v in enumerate(values):
        x = x0 + cw * i / max(len(values) - 1, 1)
        y = y0 + ch - ch * (v - vmin) / rng
        pts.append((x, y, v))
    lines.append(f'<line x1="{x0}" y1="{y0 + ch}" x2="{x0 + cw}" y2="{y0 + ch}" stroke="#ccc"/>')
    lines.append('<polyline points="' + " ".join(f"{x:.1f},{y:.1f}" for x, y, _ in pts) + '" fill="none" stroke="' + PALETTE[0] + '" stroke-width="2.5"/>')
    step = max(1, len(pts) // 10)
    for i, (x, y, v) in enumerate(pts):
        if i % step == 0 or i == len(pts) - 1:
            lines.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="3.5" fill="{PALETTE[0]}"/>')
            lines.append(f'<text x="{x:.1f}" y="{y - 10:.1f}" text-anchor="middle" font-size="11" fill="#111">{v:,.0f}{unit}</text>')
            lines.append(f'<text x="{x:.1f}" y="{y0 + ch + 20}" text-anchor="middle" font-size="11" fill="#555">{html.escape(str(labels[i]))}</text>')
    lines.append("</svg>")
    return "\n".join(lines)


def pie_chart(labels, values, title):
    w, h = 720, 480
    lines = svg_header(w, h, title)
    total = sum(values)
    cx, cy, r = 300, 260, 150
    import math
    angle = -math.pi / 2
    for i, (lab, v) in enumerate(zip(labels, values)):
        frac = v / total
        a2 = angle + frac * 2 * math.pi
        x1, y1 = cx + r * math.cos(angle), cy + r * math.sin(angle)
        x2, y2 = cx + r * math.cos(a2), cy + r * math.sin(a2)
        large = 1 if frac > 0.5 else 0
        color = PALETTE[i % len(PALETTE)]
        lines.append(f'<path d="M{cx},{cy} L{x1:.1f},{y1:.1f} A{r},{r} 0 {large} 1 {x2:.1f},{y2:.1f} Z" fill="{color}" stroke="#fff" stroke-width="2"/>')
        ly = 90 + i * 30
        lines.append(f'<rect x="520" y="{ly - 12}" width="14" height="14" rx="3" fill="{color}"/>')
        lines.append(f'<text x="542" y="{ly}" font-size="13" fill="#333">{html.escape(str(lab))}  {v:,.0f}（{frac:.0%}）</text>')
        angle = a2
    lines.append("</svg>")
    return "\n".join(lines)


def aggregate(headers, rows, cat_col, val_col, topn):
    i_cat, i_val = headers.index(cat_col), headers.index(val_col)
    agg = defaultdict(float)
    for r in rows:
        if max(i_cat, i_val) >= len(r):
            continue
        num = to_num(r[i_val])
        if num is not None:
            agg[r[i_cat].strip()] += num
    items = sorted(agg.items(), key=lambda kv: -kv[1])
    if topn and len(items) > topn:
        rest = sum(v for _, v in items[topn:])
        items = items[:topn] + [("其他", rest)]
    return [k for k, _ in items], [v for _, v in items]


def main():
    ap = argparse.ArgumentParser(description="CSV → SVG 图表（零依赖，浏览器直接打开）")
    ap.add_argument("input", nargs="?", help="CSV 文件")
    ap.add_argument("--type", choices=["bar", "hbar", "line", "pie"], help="图表类型（默认自动：类别列+数值列→bar，两数值列→line）")
    ap.add_argument("--cat", help="分类列名（bar/pie 必需）")
    ap.add_argument("--value", help="数值列名")
    ap.add_argument("--top", type=int, default=10, help="分类过多时保留 Top N + 其他（默认 10）")
    ap.add_argument("--title", help="图表标题（建议写结论）")
    ap.add_argument("--unit", default="", help="数值单位（如 元、人）")
    ap.add_argument("--out", help="输出 SVG 路径")
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()

    if args.demo:
        skill_root = Path(__file__).resolve().parent.parent
        exdir = skill_root / "examples"
        exdir.mkdir(parents=True, exist_ok=True)
        src = exdir / "orders_demo.csv"
        src.write_text(
            "月份,渠道,销售额\n"
            "2026-03,搜索,128000\n2026-03,社群,96000\n2026-03,广告,41000\n"
            "2026-04,搜索,135000\n2026-04,社群,104000\n2026-04,广告,44000\n"
            "2026-05,搜索,142000\n2026-05,社群,118000\n2026-05,广告,39000\n"
            "2026-06,搜索,151000\n2026-06,社群,126000\n2026-06,广告,47000\n"
            "2026-07,搜索,158000\n2026-07,社群,133000\n2026-07,广告,52000\n", encoding="utf-8")
        args.input, args.cat, args.value = str(src), "渠道", "销售额"
        args.title, args.unit = args.title or "各渠道贡献：搜索+社群占 80%+，广告持续偏低", "元"
        args.out = str(exdir / "渠道销售额.svg")
    elif not args.input:
        ap.error("请提供 CSV 文件，或用 --demo 演示")

    headers, rows = load_csv(args.input)

    if args.cat and args.value:
        labels, values = aggregate(headers, rows, args.cat, args.value, args.top)
        ctype = args.type or ("pie" if len(labels) <= 5 else "hbar")
    elif args.value:
        i_val = headers.index(args.value)
        labels = [r[0] for r in rows]
        values = [to_num(r[i_val]) for r in rows]
        if any(v is None for v in values):
            sys.exit(f"列 {args.value} 含非数字，请同时用 --cat 指定分类列做聚合")
        ctype = args.type or "line"
    else:
        # 自动：找一列类别 + 一列数值
        num_cols = [h for h in headers if sum(1 for r in rows if to_num(r[headers.index(h)]) is not None) > 0.9 * len(rows)]
        cat_cols = [h for h in headers if h not in num_cols]
        if not (num_cols and cat_cols):
            ap.error("无法自动判断列，请显式指定 --cat 与 --value")
        args.cat, args.value = cat_cols[0], num_cols[0]
        labels, values = aggregate(headers, rows, args.cat, args.value, args.top)
        ctype = args.type or "hbar"
        print(f"[自动选型] 分类列「{args.cat}」× 数值列「{args.value}」")

    title = args.title or f"{args.value} 按 {args.cat if args.cat else ''} 分布"
    if ctype == "bar":
        svg = bar_chart(labels, values, title, args.unit, horizontal=False)
    elif ctype == "hbar":
        svg = bar_chart(labels, values, title, args.unit, horizontal=True)
    elif ctype == "line":
        svg = line_chart(labels, values, title, args.unit)
    else:
        svg = pie_chart(labels, values, title)

    out = Path(args.out) if args.out else Path(args.input).with_suffix(".svg")
    out.write_text(svg, encoding="utf-8")
    print(f"已生成 {ctype} 图：{out}（浏览器直接打开，可无损缩放）")
    if args.demo:
        # 再出一张趋势折线图演示 line 用法
        by_month = defaultdict(float)
        for r in rows:
            by_month[r[0]] += to_num(r[2])
        months = sorted(by_month)
        line = line_chart(months, [by_month[m] for m in months], "月度销售额稳步增长（3~7 月 +37%）", "元")
        (exdir / "月度趋势_折线.svg").write_text(line, encoding="utf-8")
        print("已生成 line 图：examples/月度趋势_折线.svg")


if __name__ == "__main__":
    main()
