---
name: safe-skill-install
description: Securely audit and install Agent Skills from external sources such as GitHub repository URLs, npx skills add, marketplace links, or folder imports. Use this skill when the user asks to install, add, import, download, clone, or update a skill from any non-local source. It enforces a verify-then-audit-then-install workflow that avoids blindly executing remote code, checks whether the skill already exists locally, and validates the repository URL before any download. Use it as the fallback when the skills-security-check skill is unavailable.
agent_created: true
---

# Safe Skill Install

## Overview

Installing a skill from an external source means executing code written by
someone else. A naive `npx skills add <url>` or direct `git clone` into the
skills directory can pull malicious or broken content straight into the user's
environment. This skill provides a deterministic, safe workflow: verify the
source exists, clone to a throwaway temp location, audit the contents, then —
only after explicit confirmation — copy the skill into the proper skills
directory.

## When To Use

Trigger this skill whenever the user:

- Asks to install/add/import/download a skill from a GitHub URL, `npx skills add`,
  a marketplace link, or a local folder path outside the current skills dirs.
- Pastes a `npx ... skills ...` or `git clone ...` command intended to add a
  skill.
- Mentions updating an existing skill "from GitHub" or "latest version".

Do **not** trigger for routine use of an already-installed skill, or for
creating a brand-new skill from scratch (use `skill-creator` for that).

## Core Rules (Non-Negotiable)

1. **Never run `npx skills add` blindly.** `npx <pkg>` downloads and executes
   remote code. In WorkBuddy it also installs to the wrong location — `npx
   skills add` is Claude Code tooling, not WorkBuddy's skill system. Treat any
   such command as external execution requiring an audit first.
2. **Check local first.** The requested skill may already be installed. Inspect
   the available-skills list and the directories `~/.workbuddy/skills/` (user)
   and `{workspace}/.workbuddy/skills/` (project) before fetching anything.
3. **Verify the URL before cloning.** A 404 means the repo or path does not
   exist. Typos are common (e.g. `anthropics/skills--skill` vs the real
   `anthropics/skills`). Confirm correct owner/repo spelling via WebFetch.
4. **Temp, never prod.** Clone only into a system temp directory. No writes to
   user skills paths until the audit passes and the user confirms.
5. **Audit, then confirm, then install.** Never install without presenting the
   audit result and getting explicit go-ahead, especially for P0/P1 findings.

## Workflow

### Step 1 — Local check

List installed skills and grep the skills directories for the requested skill
name. If found locally, report it and stop unless the user explicitly wants the
external/latest version.

### Step 2 — Verify the source URL

Use WebFetch on the repository URL. Confirm:

- The page is not a 404 / "Page not found".
- The owner/repo spelling matches the intended official source.
- A `SKILL.md` (or skill folder) actually exists in the repo.

If the URL is invalid, stop and tell the user the correct address (verify the
real one before suggesting it).

### Step 3 — Clone to temp

Clone into a system temp directory only:

```bash
git clone <verified-url> <temp-dir>
```

If the skill lives in a subfolder, locate the specific skill directory inside
the clone.

### Step 4 — Audit

Inspect the skill manually and run the bundled scanner for deterministic
pattern detection:

```bash
python scripts/scan_skill.py <cloned-skill-dir>
```

Read `references/audit-checklist.md` for the full checklist and severity
definitions (P0 / P1 / P2). Manually review any flagged file and any bundled
`scripts/` for logic that executes external commands, reads sensitive files, or
exfiltrates data.

### Step 5 — Report and require confirmation

Present the audit summary:

- **P0 (critical):** strongly warn, require explicit written confirmation
  before any install.
- **P1 (review):** warn and require confirmation.
- **P2 (informational):** note and proceed.

State the final risk level clearly. Do not proceed until the user confirms.

### Step 6 — Install and clean up

After confirmation, copy the skill folder into the proper location:

- User scope (default): `~/.workbuddy/skills/<skill-name>/`
- Project scope (when sharing with a repo): `{workspace}/.workbuddy/skills/<skill-name>/`

Verify the skill now appears in the available-skills list, then delete the temp
clone.

## Resources

- `scripts/scan_skill.py` — deterministic scanner for risky patterns in a cloned
  skill directory. Run before install.
- `references/audit-checklist.md` — detailed audit checklist, severity levels,
  and how to interpret scanner output.
