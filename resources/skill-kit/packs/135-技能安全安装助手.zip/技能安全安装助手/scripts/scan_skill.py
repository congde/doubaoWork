#!/usr/bin/env python3
"""Scan a cloned skill directory for risky patterns.

Usage:
    python scan_skill.py <skill-directory> [--json]

Walks every file under <skill-directory>, reads text files, and flags lines
that match known risky patterns grouped by severity (P0/P1/P2). This is a
heuristic scanner: it catches patterns, not intent. Always combine with manual
review of the flagged files.

Exit code is 0 unless the directory is invalid, so it can be used in pipelines
without aborting the parent workflow. The risk level is printed in a VERDICT
line for machines/humans to read.
"""

import os
import re
import sys
import json

# Each entry: (regex, human-readable reason)
PATTERNS = {
    "P0": [
        (r"curl\s+[^\n|]*\|\s*(sh|bash|powershell|pwsh)", "download piped to shell"),
        (r"wget\s+[^\n|]*\|\s*(sh|bash|powershell|pwsh)", "download piped to shell"),
        (r"\|\s*(sh|bash|powershell|pwsh)\s*$", "pipe output to shell"),
        (r"bash\s+-i", "interactive bash (possible reverse shell)"),
        (r"/dev/tcp/", "bash /dev/tcp (possible reverse shell)"),
        (r"nc\s+-e\s", "netcat exec (possible reverse shell)"),
        (r"mkfifo", "fifo + netcat (possible reverse shell)"),
        (r"base64\s+-d[^\n]*\|\s*(sh|bash)", "base64 decode piped to shell"),
    ],
    "P1": [
        (r"\b(curl|wget)\b", "network download tool"),
        (r"(requests\.(get|post|put|delete)|urllib|httpx|aiohttp)", "HTTP client library"),
        (r"(Invoke-WebRequest|Invoke-RestMethod|\biwr\b)", "PowerShell web request"),
        (r"(~/\.ssh|~/\.aws|id_rsa|credentials\.|\.env\b|/etc/passwd|token|secret)",
         "reads sensitive file/path"),
        (r"(rm\s+-rf|rmdir\s+/S|del\s+/S|sudo\s|chmod\s+777|format\s+[a-z]:)",
         "destructive / privileged op"),
        (r"(subprocess|os\.system|popen|shell=True)", "spawns subprocess"),
        (r"(shutil\.rmtree|os\.remove|os\.unlink)", "filesystem delete call"),
    ],
    "P2": [
        (r"\b(eval|exec|compile)\s*\(", "dynamic code execution"),
        (r"base64", "base64 (possible obfuscation)"),
        (r"__import__\s*\(", "dynamic import"),
    ],
}

# File extensions we treat as text and scan.
TEXT_EXTS = {
    ".md", ".py", ".sh", ".bash", ".ps1", ".js", ".ts", ".json", ".yaml",
    ".yml", ".toml", ".txt", ".cfg", ".ini", ".bat", ".cmd", ".rb", ".pl",
    ".php", ".go", ".rs", ".c", ".cpp", ".h", ".html", ".css", ".xml",
}


def is_text_file(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in TEXT_EXTS:
        return True
    # Fallback: try to read first bytes as utf-8 text.
    try:
        with open(path, "r", encoding="utf-8") as f:
            f.read(4096)
        return True
    except (UnicodeDecodeError, OSError):
        return False


def scan_directory(root):
    findings = {sev: [] for sev in PATTERNS}
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            path = os.path.join(dirpath, name)
            if not is_text_file(path):
                continue
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    lines = f.readlines()
            except OSError:
                continue
            rel = os.path.relpath(path, root)
            for lineno, line in enumerate(lines, start=1):
                for sev, rules in PATTERNS.items():
                    for pattern, reason in rules:
                        if re.search(pattern, line, re.IGNORECASE):
                            findings[sev].append(
                                {"file": rel, "line": lineno, "reason": reason,
                                 "text": line.strip()[:200]}
                            )
    return findings


def risk_level(findings):
    if findings["P0"]:
        return "HIGH"
    if findings["P1"]:
        return "MEDIUM"
    if findings["P2"]:
        return "LOW"
    return "NONE"


def main():
    if len(sys.argv) < 2:
        print("Usage: python scan_skill.py <skill-directory> [--json]")
        sys.exit(2)
    root = sys.argv[1]
    as_json = "--json" in sys.argv[2:]
    if not os.path.isdir(root):
        print(f"ERROR: not a directory: {root}")
        sys.exit(2)

    findings = scan_directory(root)

    if as_json:
        print(json.dumps(findings, indent=2, ensure_ascii=False))
    else:
        for sev in ("P0", "P1", "P2"):
            items = findings[sev]
            print(f"\n=== {sev} ({len(items)}) ===")
            for item in items:
                print(f"  [{item['reason']}] {item['file']}:{item['line']}")
                print(f"      {item['text']}")

    n_p0 = len(findings["P0"])
    n_p1 = len(findings["P1"])
    n_p2 = len(findings["P2"])
    level = risk_level(findings)
    print(f"\n[VERDICT] P0: {n_p0}, P1: {n_p1}, P2: {n_p2}  ->  "
          f"RISK LEVEL: {level}")
    sys.exit(0)


if __name__ == "__main__":
    main()
