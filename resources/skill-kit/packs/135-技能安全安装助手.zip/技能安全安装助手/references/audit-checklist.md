# Skill Audit Checklist

Use this checklist when auditing a skill cloned from an external source before
installing it into WorkBuddy. Pair it with `scripts/scan_skill.py` for
deterministic pattern detection, but always combine automated scanning with
human review — the scanner catches patterns, not intent.

## Severity Levels

- **P0 — Critical (hard block):** The skill can execute attacker-controlled or
  remote code, open a reverse shell, or exfiltrate data with no user action.
  Strongly warn and require explicit written confirmation before any install.
- **P1 — Review (confirm):** The skill performs network calls, runs
  subprocesses, reads sensitive files, or does destructive filesystem ops.
  Acceptable for legit skills, but warn and require confirmation.
- **P2 — Informational (note):** Obfuscation or dynamic execution that is
  usually benign (e.g. `eval`, `base64`, dynamic import). Note it; proceed.

## Manual Review Steps

1. **Read `SKILL.md` frontmatter.**
   - `name` matches the folder name and uses hyphen-case.
   - `description` is complete and describes a real, specific capability.
   - Watch for vague or copied descriptions that hide the skill's true purpose.

2. **Read every file in `scripts/`.**
   - Understand what each script does before trusting it.
   - Flag any script that downloads and runs code, contacts external servers,
     or writes outside its own directory.

3. **Check `references/` and `assets/`.**
   - References are documentation — confirm they don't contain executable
     payloads disguised as markdown.
   - Assets should be static (templates, images, fonts) — not scripts.

4. **Look for hidden behavior.**
   - Post-install hooks, `cron`/`at` jobs, or startup persistence.
   - Encoded blobs (base64/hex) that decode to commands.
   - Requests to non-official domains or exfiltration endpoints.

## Pattern Categories (also covered by the scanner)

| Pattern | Why it matters | Severity |
| --- | --- | --- |
| `curl ... \| sh` / `wget ... \| bash` | Downloads and executes remote code | P0 |
| `bash -i`, `/dev/tcp/`, `nc -e`, `mkfifo` | Reverse shell | P0 |
| `base64 -d \| bash` | Decodes then executes hidden payload | P0 |
| `curl` / `wget` / `requests` / `urllib` / `Invoke-WebRequest` | Network egress | P1 |
| Reads `~/.ssh`, `id_rsa`, `.env`, `/etc/passwd`, credentials, tokens | Secrets theft | P1 |
| `rm -rf`, `sudo`, `chmod 777`, `del /S /Q`, `shutil.rmtree` | Destructive / privileged | P1 |
| `subprocess`, `os.system`, `popen` | Spawns processes | P1 |
| `eval(`, `exec(`, `compile(`, `__import__(`, `base64` | Dynamic / obfuscated code | P2 |

## How To Interpret Scanner Output

The scanner prints findings grouped by severity with file:line references, then
a verdict like:

```
[VERDICT] P0: 0, P1: 2, P2: 1  ->  RISK LEVEL: MEDIUM
```

- **P0 > 0** → do not install without explicit user override.
- **P1 > 0** → confirm with the user; explain what each finding does.
- **P2 only** → safe to proceed; note the findings.

Always show the user the actual flagged lines, not just the counts.

## Reporting Template

```
来源: <url>
本地已装?: <是/否>
URL 校验: <有效/404/拼写错误>
审计结果:
  P0: <n> — <摘要>
  P1: <n> — <摘要>
  P2: <n> — <摘要>
风险等级: <LOW/MEDIUM/HIGH>
建议: <安装/需确认/禁止>
```
