# 周计划数据结构（plan.json）

生成周菜单后，先把结构化数据写成 `plan.json`，再运行 `scripts/build_board.py` 产出 Markdown 与 HTML 看板。这样两份文件内容 100% 同步，不会出现改了一处忘改另一处的问题。

## 顶层结构

```jsonc
{
  "meta": { ... },      // 必填：计划元信息
  "days": [ ... ],      // 必填：7 天
  "shopping": [ ... ],  // 必填：买菜清单
  "prep": [ ... ],      // 必填：备菜流程
  "check": [ ... ]      // 必填：营养自检
}
```

## meta

```jsonc
{
  "week_label": "2026-09-01 ~ 2026-09-07",
  "people": 1,                          // int
  "people_desc": "成年女性，轻体力活动",
  "goal": "均衡健康",                    // 均衡健康 | 减脂控卡 | 增肌高蛋白 | 控糖
  "daily_kcal": 1750,                   // int，目标日均能量
  "macro": { "protein_g": 80, "carb_g": 220, "fat_g": 55 },
  "meal_ratio": "3 : 4 : 3",
  "avoid": ["香菜", "花生"],             // 忌口/过敏，无则 []
  "budget_per_week": 260,               // 元，可为 null
  "notes": "按你的作息，晚餐尽量 25 分钟内完成"  // 可选
}
```

## days[]

```jsonc
{
  "date": "周一",
  "full_date": "2026-09-01",
  "meals": {
    "breakfast": [ {菜}, {菜} ],   // 数组，1-2 道
    "lunch":     [ {菜}, {菜} ],
    "dinner":    [ {菜}, {菜} ],
    "snack":     [ {菜} ]          // 可选，无则 []
  },
  "day_kcal": 1745,        // 计算值
  "day_protein": 82,       // 计算值
  "highlight": "今天鱼虾日，补 n-3"   // 可选一句话
}
```

## 菜（dish）

```jsonc
{
  "name": "清蒸鲈鱼",
  "role": "主菜",                  // 主菜 | 副菜 | 汤 | 主食 | 加餐
  "kcal": 260,                     // int
  "protein": 38,                   // int，克
  "time_min": 18,                  // int，从备料到出锅
  "difficulty": "简单",             // 简单 | 中等 | 进阶
  "items": ["鲈鱼 400g", "姜 5片", "葱 2根", "蒸鱼豉油 15ml", "油 8g"],
  "steps": [
    "鱼两面各划 3 刀，腹腔塞姜片，身下垫葱段架空。",
    "蒸锅水完全烧开后放入，大火蒸 8 分钟，关火虚蒸 2 分钟。",
    "倒掉盘中腥水，拣去葱姜，重新铺新鲜葱丝姜丝。",
    "淋蒸鱼豉油，另起锅烧 8g 油至冒青烟，浇在葱丝上。"
  ],
  "tip": "水开下锅 + 倒掉蒸鱼水 + 最后泼热油，三步决定成败。",
  "source": "B1"                   // 菜品库编号，自创则写 "自创"
}
```

## shopping[]

```jsonc
{
  "category": "蔬菜",               // 蔬菜 | 肉蛋 | 水产 | 豆制品 | 主食谷物 | 奶类 | 水果 | 干货调料
  "name": "菠菜",
  "amount": "300g",
  "price": 6.0,                    // 元，估算；可 null
  "used_in": ["周一晚", "周三午"],   // 便于判断能否一次用完
  "store": "冷藏 3 天，厨房纸包裹",   // 保存提示，可省略
  "buy_day": "周日"                 // 周日主采购 | 周三补货
}
```

## prep[]

```jsonc
{
  "phase": "肉类分装腌制",
  "minutes": 20,
  "tasks": [
    "猪里脊按每顿 100g 分装，加生抽/料酒/淀粉抓匀上浆，最后封油，装密封袋标注菜名日期。",
    "鸡腿肉 150g 分装，加蚝油生抽腌制备用。"
  ]
}
```

## check[]

```jsonc
{ "item": "日均能量", "target": "1750 kcal", "actual": "1745 kcal", "status": "ok" }
```
`status` 取值：`ok`（达标）｜ `warn`（轻微偏离）｜ `over`（超标）｜ `under`（不足）

## 运行

```bash
python scripts/build_board.py plan.json --out-dir <输出目录> --name <文件名前缀>
```

产出：`<out-dir>/<name>.md` 与 `<out-dir>/<name>.html`。
