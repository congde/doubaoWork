#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
从 plan.json 生成一周饮食计划的 Markdown 文档与 HTML 看板。

用法:
    python build_board.py plan.json --out-dir ./output --name 一周饮食计划

产出:
    <out-dir>/<name>.md
    <out-dir>/<name>.html
"""

import argparse
import html
import json
import os
import sys
from collections import OrderedDict

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

MEAL_LABEL = OrderedDict([
    ("breakfast", "早餐"),
    ("lunch", "午餐"),
    ("dinner", "晚餐"),
    ("snack", "加餐"),
])

CATEGORY_ORDER = ["蔬菜", "肉蛋", "水产", "豆制品", "主食谷物", "奶类", "水果", "干货调料"]

STATUS_MARK = {"ok": "✅", "warn": "⚠️", "over": "❌", "under": "⬇️"}
STATUS_TEXT = {"ok": "达标", "warn": "轻微偏离", "over": "超标", "under": "不足"}


def esc(s):
    return html.escape(str(s if s is not None else ""), quote=True)


def g(d, key, default=""):
    v = d.get(key, default)
    return default if v is None else v


# ---------------------------------------------------------------- Markdown

def build_markdown(plan):
    meta = plan.get("meta", {})
    days = plan.get("days", [])
    shopping = plan.get("shopping", [])
    prep = plan.get("prep", [])
    checks = plan.get("check", [])
    savings = plan.get("savings", [])

    macro = meta.get("macro", {}) or {}
    avoid = meta.get("avoid", []) or []
    L = []

    L.append("# 一周饮食计划 · {}".format(g(meta, "week_label")))
    L.append("")
    L.append("> 生成依据：中国居民膳食指南（2022）+ DRIs（2023），按营养师角度配比。")
    L.append("")

    # 概览
    L.append("## 一、计划概览")
    L.append("")
    L.append("| 项目 | 内容 |")
    L.append("|---|---|")
    L.append("| 用餐人数 | {} 人（{}） |".format(g(meta, "people", 1), g(meta, "people_desc")))
    L.append("| 营养目标 | {} |".format(g(meta, "goal")))
    L.append("| 每日能量 | {} kcal |".format(g(meta, "daily_kcal")))
    L.append("| 三大营养素 | 蛋白质 {} g ｜ 碳水 {} g ｜ 脂肪 {} g |".format(
        g(macro, "protein_g", "-"), g(macro, "carb_g", "-"), g(macro, "fat_g", "-")))
    L.append("| 三餐配比 | {} |".format(g(meta, "meal_ratio")))
    L.append("| 忌口 / 过敏 | {} |".format("、".join(avoid) if avoid else "无"))
    if meta.get("budget_per_week"):
        L.append("| 预算参考 | 约 {} 元 / 周 |".format(meta["budget_per_week"]))
    if meta.get("notes"):
        L.append("| 特别说明 | {} |".format(meta["notes"]))
    L.append("")

    # 每日菜单
    L.append("## 二、一周菜单总览")
    L.append("")
    L.append("| | 早餐 | 午餐 | 晚餐 | 加餐 | 当日合计 |")
    L.append("|---|---|---|---|---|---|")
    for d in days:
        row = ["**{}**".format(g(d, "date"))]
        for k in ["breakfast", "lunch", "dinner", "snack"]:
            dishes = (d.get("meals", {}) or {}).get(k, []) or []
            row.append("<br>".join(g(x, "name") for x in dishes) if dishes else "—")
        row.append("{} kcal / 蛋白 {} g".format(g(d, "day_kcal", "-"), g(d, "day_protein", "-")))
        L.append("| " + " | ".join(row) + " |")
    L.append("")

    # 逐日详情 + 做法
    L.append("## 三、每日菜单与做法")
    L.append("")
    for d in days:
        L.append("### {} · {}{}".format(
            g(d, "date"), g(d, "full_date"),
            " · " + g(d, "highlight") if d.get("highlight") else ""))
        L.append("")
        for k, label in MEAL_LABEL.items():
            dishes = (d.get("meals", {}) or {}).get(k, []) or []
            if not dishes:
                continue
            L.append("**{}**".format(label))
            L.append("")
            for dish in dishes:
                L.append("#### {} · {}".format(g(dish, "name"), g(dish, "role", "主菜")))
                L.append("")
                bits = ["{} kcal".format(g(dish, "kcal", "-")),
                        "蛋白 {} g".format(g(dish, "protein", "-")),
                        "{} 分钟".format(g(dish, "time_min", "-"))]
                if dish.get("difficulty"):
                    bits.append(g(dish, "difficulty"))
                L.append("`{}`".format(" ｜ ".join(bits)))
                L.append("")
                items = dish.get("items", []) or []
                if items:
                    L.append("- **食材**：" + "、".join(items))
                steps = dish.get("steps", []) or []
                if steps:
                    L.append("- **做法**：")
                    for i, s in enumerate(steps, 1):
                        L.append("  {}. {}".format(i, s))
                if dish.get("tip"):
                    L.append("- **关键**：{}".format(g(dish, "tip")))
                L.append("")

    # 买菜清单
    L.append("## 四、买菜清单")
    L.append("")
    grouped = OrderedDict()
    for it in shopping:
        grouped.setdefault(g(it, "category", "其他"), []).append(it)
    ordered = [c for c in CATEGORY_ORDER if c in grouped] + \
              [c for c in grouped if c not in CATEGORY_ORDER]
    total = 0.0
    for cat in ordered:
        L.append("### {}".format(cat))
        L.append("")
        L.append("| 采购 | 食材 | 用量 | 用在 | 保存 | 预估价 |")
        L.append("|---|---|---|---|---|---|")
        for it in grouped[cat]:
            if isinstance(it.get("price"), (int, float)):
                total += float(it["price"])
            L.append("| {} | {} | {} | {} | {} | {} |".format(
                g(it, "buy_day", "周日"),
                g(it, "name"),
                g(it, "amount"),
                "、".join(it.get("used_in", []) or []) or "—",
                g(it, "store", "—"),
                "{} 元".format(it["price"]) if it.get("price") is not None else "—",
            ))
        L.append("")
    if total:
        L.append("**食材合计约 {} 元**（不含已有调料，实际随菜价浮动 ±20%）".format(round(total, 1)))
        L.append("")
        L.append("> 采购节奏：周日出动买 70%（肉鱼蛋奶、耐放菜、主食），周三补一次绿叶菜和豆制品。")
        L.append("")

    # 备菜
    L.append("## 五、周日备菜流程（一次搞定整周）")
    L.append("")
    tp = 0
    for p in prep:
        tp += int(p.get("minutes", 0) or 0)
    L.append("预计总耗时 **{} 分钟**，做完后工作日每天只需 15-25 分钟下锅。".format(tp))
    L.append("")
    L.append("| 顺序 | 环节 | 耗时 | 具体动作 |")
    L.append("|---|---|---|---|")
    for i, p in enumerate(prep, 1):
        tasks = "<br>".join(p.get("tasks", []) or [])
        L.append("| {} | {} | {} 分钟 | {} |".format(
            i, g(p, "phase"), g(p, "minutes", "-"), tasks))
    L.append("")

    # 自检
    L.append("## 六、营养自检")
    L.append("")
    L.append("| 指标 | 目标 | 实际 | 结论 |")
    L.append("|---|---|---|---|")
    for c in checks:
        st = g(c, "status", "ok")
        L.append("| {} | {} | {} | {} {} |".format(
            g(c, "item"), g(c, "target"), g(c, "actual"),
            STATUS_MARK.get(st, ""), STATUS_TEXT.get(st, "")))
    L.append("")

    if savings:
        L.append("## 七、省钱开关（预算超了就按顺序打开）")
        L.append("")
        L.append("| 动作 | 省下 | 营养代价 |")
        L.append("|---|---|---|")
        for s in savings:
            L.append("| {} | 约 {} 元 | {} |".format(
                g(s, "action"), g(s, "save", "-"), g(s, "cost", "无")))
        L.append("")

    L.append("---")
    L.append("")
    L.append("**执行提醒**：")
    L.append("")
    L.append("1. 每天饮水量 1500-1700 ml，餐前 30 min 喝 200 ml 有助于控制食量。")
    L.append("2. 进餐顺序：蔬菜 → 蛋白质 → 主食，血糖更平稳，也更容易吃饱。")
    L.append("3. 如果某天没时间，用「一锅出」或「零烹饪日」方案替代，别直接跳过一餐。")
    L.append("4. 每周称一次体重（固定早晨空腹），连续两周同向变化超过 1.5 kg 再调整热量。")
    L.append("")
    return "\n".join(L)


# ---------------------------------------------------------------- HTML

CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei","Segoe UI",sans-serif;
background:#f6f7f9;color:#1f2328;line-height:1.6;padding:28px 18px 60px}
.wrap{max-width:1180px;margin:0 auto}
header{background:#fff;border:1px solid #e6e8eb;border-radius:16px;padding:26px 28px;margin-bottom:18px;
box-shadow:0 1px 3px rgba(16,24,40,.05)}
h1{font-size:23px;font-weight:700;letter-spacing:-.2px}
.sub{color:#6b7280;font-size:13.5px;margin-top:6px}
.meta{display:grid;grid-template-columns:repeat(auto-fit,minmax(132px,1fr));gap:12px;margin-top:20px}
.mi{background:#fafbfc;border:1px solid #eceef1;border-radius:11px;padding:12px 14px}
.mi .k{font-size:11.5px;color:#8b929c;letter-spacing:.3px}
.mi .v{font-size:16px;font-weight:650;margin-top:3px;color:#1f2328}
h2{font-size:17px;font-weight:700;margin:26px 0 12px;display:flex;align-items:center;gap:8px}
h2::before{content:"";width:3px;height:15px;background:#e8734a;border-radius:2px}
.week{display:grid;grid-template-columns:repeat(auto-fit,minmax(268px,1fr));gap:14px}
.day{background:#fff;border:1px solid #e6e8eb;border-radius:14px;padding:16px 16px 18px;
box-shadow:0 1px 3px rgba(16,24,40,.04);display:flex;flex-direction:column}
.day.today{border-color:#e8734a;box-shadow:0 0 0 3px rgba(232,115,74,.1)}
.dh{display:flex;align-items:baseline;justify-content:space-between;margin-bottom:4px}
.dn{font-size:16px;font-weight:700}
.dd{font-size:11.5px;color:#9aa1ab}
.hl{font-size:12px;color:#c2622f;background:#fdf1ec;border-radius:6px;padding:5px 8px;margin:8px 0 4px}
.kcal{font-size:12px;color:#6b7280;margin-bottom:10px;padding-bottom:10px;border-bottom:1px dashed #e6e8eb}
.kcal b{color:#1f2328;font-size:13.5px}
.meal{margin-top:11px}
.ml{font-size:11px;color:#8b929c;letter-spacing:1px;margin-bottom:5px;font-weight:600}
.dish{background:#fafbfc;border:1px solid #eceef1;border-radius:9px;margin-bottom:6px;overflow:hidden}
.dsum{cursor:pointer;padding:8px 10px;display:flex;align-items:center;gap:8px;user-select:none}
.dsum:hover{background:#f3f4f6}
.dn2{font-size:13.5px;font-weight:600;flex:1}
.tag{font-size:10.5px;color:#7a828c;background:#fff;border:1px solid #e2e5e9;border-radius:20px;padding:1px 7px;white-space:nowrap}
.ptag{color:#c2622f;background:#fdf1ec;border-color:#f6ddd2}
.dbody{display:none;padding:2px 12px 12px;border-top:1px solid #eceef1;background:#fff}
.dish.open .dbody{display:block}
.dish.open .dsum{background:#f3f4f6}
.arrow{font-size:10px;color:#a8aeb8;transition:transform .15s}
.dish.open .arrow{transform:rotate(90deg)}
.sec{font-size:11px;color:#8b929c;letter-spacing:.5px;margin:10px 0 4px;font-weight:600}
.ing{font-size:12.5px;color:#4b5563}
ol.st{margin:0;padding-left:18px}
ol.st li{font-size:12.5px;color:#374151;margin-bottom:5px}
.tip{font-size:12px;color:#0f766e;background:#ecfdf5;border-left:3px solid #10b981;
padding:7px 10px;border-radius:0 7px 7px 0;margin-top:8px}
table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #e6e8eb;
border-radius:12px;overflow:hidden;font-size:13px}
th{background:#fafbfc;text-align:left;padding:10px 12px;font-weight:600;color:#4b5563;
font-size:12px;border-bottom:1px solid #e6e8eb}
td{padding:10px 12px;border-bottom:1px solid #f1f3f5;vertical-align:top}
tr:last-child td{border-bottom:none}
.shopgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:14px}
.scard{background:#fff;border:1px solid #e6e8eb;border-radius:14px;padding:14px 16px;
box-shadow:0 1px 3px rgba(16,24,40,.04)}
.scard h3{font-size:14px;font-weight:700;margin-bottom:8px;display:flex;align-items:center;gap:7px}
.scard h3 .cnt{font-size:11px;color:#8b929c;font-weight:500}
.row{display:flex;align-items:flex-start;gap:9px;padding:7px 0;border-bottom:1px solid #f4f5f7}
.row:last-child{border-bottom:none}
.row.done .nm{text-decoration:line-through;color:#b3b9c2}
.cb{width:16px;height:16px;border:1.5px solid #cfd4db;border-radius:4px;cursor:pointer;flex-shrink:0;
margin-top:3px;display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;transition:.12s}
.cb:hover{border-color:#e8734a}
.row.done .cb{background:#e8734a;border-color:#e8734a}
.nm{font-size:13px;font-weight:550;flex:1}
.amt{font-size:12.5px;color:#e8734a;font-weight:600;white-space:nowrap}
.use{font-size:11.5px;color:#9aa1ab;width:100%;margin-top:1px}
.pr{font-size:11.5px;color:#6b7280;white-space:nowrap}
.prog{height:5px;background:#eef0f3;border-radius:3px;overflow:hidden;margin-top:10px}
.prog i{display:block;height:100%;background:#e8734a;width:0;transition:width .2s}
.timeline{background:#fff;border:1px solid #e6e8eb;border-radius:14px;padding:6px 18px;
box-shadow:0 1px 3px rgba(16,24,40,.04)}
.tl{display:flex;gap:14px;padding:14px 0;border-bottom:1px solid #f1f3f5}
.tl:last-child{border-bottom:none}
.tn{width:26px;height:26px;border-radius:50%;background:#fdf1ec;color:#c2622f;font-size:12px;
font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.tb{flex:1}
.tp{font-size:14px;font-weight:650;display:flex;justify-content:space-between}
.tm{font-size:12px;color:#e8734a;font-weight:600}
.tt{font-size:12.5px;color:#4b5563;margin-top:4px}
.tt li{margin-left:16px;margin-bottom:3px}
.chk td:last-child{font-weight:600;font-size:12.5px}
.ok{color:#0f766e}.warn{color:#b45309}.bad{color:#b91c1c}
.notes{background:#fff;border:1px solid #e6e8eb;border-left:3px solid #e8734a;border-radius:0 12px 12px 0;
padding:14px 18px;font-size:13px;color:#374151}
.notes li{margin-left:18px;margin-bottom:5px}
.savewrap{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:10px}
.sv{background:#fff;border:1px solid #e6e8eb;border-left:3px solid #0f766e;border-radius:0 12px 12px 0;
padding:11px 15px}
.sva{font-size:13px;font-weight:600;color:#1f2328}
.svm{margin-top:5px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.svp{font-size:12px;font-weight:700;color:#0f766e;background:#ecfdf5;border-radius:5px;padding:1px 7px}
.svc{font-size:11.5px;color:#8b929c}
.foot{text-align:center;color:#9aa1ab;font-size:12px;margin-top:32px}
@media print{body{background:#fff;padding:0}.day,.scard,table,.timeline{box-shadow:none;break-inside:avoid}}
"""


def build_html(plan):
    meta = plan.get("meta", {})
    days = plan.get("days", [])
    shopping = plan.get("shopping", [])
    prep = plan.get("prep", [])
    checks = plan.get("check", [])
    savings = plan.get("savings", [])
    macro = meta.get("macro", {}) or {}
    avoid = meta.get("avoid", []) or []

    P = []
    P.append("<!DOCTYPE html><html lang='zh-CN'><head><meta charset='utf-8'>")
    P.append("<meta name='viewport' content='width=device-width,initial-scale=1'>")
    P.append("<title>一周饮食计划 · {}</title>".format(esc(g(meta, "week_label"))))
    P.append("<style>{}</style></head><body><div class='wrap'>".format(CSS))

    # header
    P.append("<header>")
    P.append("<h1>一周饮食计划 · {}</h1>".format(esc(g(meta, "week_label"))))
    P.append("<div class='sub'>营养师视角配比 ｜ 依据《中国居民膳食指南（2022）》与 DRIs（2023）｜ 点击每道菜展开做法</div>")
    P.append("<div class='meta'>")
    for k, v in [("用餐人数", "{} 人".format(g(meta, "people", 1))),
                 ("营养目标", g(meta, "goal")),
                 ("每日能量", "{} kcal".format(g(meta, "daily_kcal"))),
                 ("蛋白质", "{} g/日".format(g(macro, "protein_g", "-"))),
                 ("碳水", "{} g/日".format(g(macro, "carb_g", "-"))),
                 ("脂肪", "{} g/日".format(g(macro, "fat_g", "-"))),
                 ("三餐配比", g(meta, "meal_ratio")),
                 ("预算/周", "{} 元".format(meta["budget_per_week"]) if meta.get("budget_per_week") else "—")]:
        P.append("<div class='mi'><div class='k'>{}</div><div class='v'>{}</div></div>".format(esc(k), esc(v)))
    P.append("</div>")
    if avoid:
        P.append("<div class='sub' style='margin-top:12px'>忌口 / 过敏：<b>{}</b></div>".format(esc("、".join(avoid))))
    if meta.get("notes"):
        P.append("<div class='sub' style='margin-top:4px'>{}</div>".format(esc(meta["notes"])))
    P.append("</header>")

    # week
    P.append("<h2>一周菜单（点击菜名看做法）</h2>")
    P.append("<div class='week'>")
    for d in days:
        P.append("<div class='day'>")
        P.append("<div class='dh'><span class='dn'>{}</span><span class='dd'>{}</span></div>".format(
            esc(g(d, "date")), esc(g(d, "full_date"))))
        P.append("<div class='kcal'><b>{}</b> kcal ｜ 蛋白 <b>{}</b> g</div>".format(
            esc(g(d, "day_kcal", "-")), esc(g(d, "day_protein", "-"))))
        if d.get("highlight"):
            P.append("<div class='hl'>{}</div>".format(esc(d["highlight"])))
        for k, label in MEAL_LABEL.items():
            dishes = (d.get("meals", {}) or {}).get(k, []) or []
            if not dishes:
                continue
            P.append("<div class='meal'><div class='ml'>{}</div>".format(label))
            for dish in dishes:
                P.append("<div class='dish'><div class='dsum'>")
                P.append("<span class='arrow'>▶</span>")
                P.append("<span class='dn2'>{}</span>".format(esc(g(dish, "name"))))
                P.append("<span class='tag ptag'>{}g 蛋白</span>".format(esc(g(dish, "protein", "-"))))
                P.append("<span class='tag'>{} kcal</span>".format(esc(g(dish, "kcal", "-"))))
                P.append("<span class='tag'>{} min</span>".format(esc(g(dish, "time_min", "-"))))
                P.append("</div><div class='dbody'>")
                items = dish.get("items", []) or []
                if items:
                    P.append("<div class='sec'>食材（{} 人份）</div>".format(esc(g(meta, "people", 1))))
                    P.append("<div class='ing'>{}</div>".format(esc("、".join(items))))
                steps = dish.get("steps", []) or []
                if steps:
                    P.append("<div class='sec'>做法</div><ol class='st'>")
                    for s in steps:
                        P.append("<li>{}</li>".format(esc(s)))
                    P.append("</ol>")
                if dish.get("tip"):
                    P.append("<div class='tip'><b>关键：</b>{}</div>".format(esc(dish["tip"])))
                P.append("</div></div>")
            P.append("</div>")
        P.append("</div>")
    P.append("</div>")

    # shopping
    P.append("<h2>买菜清单（可勾选，自动保存）</h2>")
    grouped = OrderedDict()
    for it in shopping:
        grouped.setdefault(g(it, "category", "其他"), []).append(it)
    ordered = [c for c in CATEGORY_ORDER if c in grouped] + \
              [c for c in grouped if c not in CATEGORY_ORDER]
    total = sum(float(it["price"]) for it in shopping
                if isinstance(it.get("price"), (int, float)))
    P.append("<div class='shopgrid'>")
    idx = 0
    for cat in ordered:
        items = grouped[cat]
        P.append("<div class='scard'><h3>{}<span class='cnt'>{} 项</span></h3>".format(esc(cat), len(items)))
        for it in items:
            idx += 1
            P.append("<div class='row' data-i='{}'><div class='cb'>✓</div><div style='flex:1'>".format(idx))
            P.append("<div class='nm'>{} <span class='amt'>{}</span></div>".format(
                esc(g(it, "name")), esc(g(it, "amount"))))
            used = it.get("used_in", []) or []
            extra = []
            if used:
                extra.append("用于 " + "、".join(used))
            if it.get("buy_day"):
                extra.append(g(it, "buy_day") + "买")
            if it.get("store"):
                extra.append(g(it, "store"))
            if extra:
                P.append("<div class='use'>{}</div>".format(esc(" · ".join(extra))))
            P.append("</div>")
            if it.get("price") is not None:
                P.append("<div class='pr'>{} 元</div>".format(esc(it["price"])))
            P.append("</div>")
        P.append("<div class='prog'><i></i></div></div>")
    P.append("</div>")
    if total:
        P.append("<div class='sub' style='margin-top:12px'>食材合计约 <b>{} 元</b>（不含已有调料，随菜价浮动 ±20%）。"
                 "节奏：周日买 70%，周三补绿叶菜和豆制品。</div>".format(round(total, 1)))

    # prep
    P.append("<h2>周日备菜流程</h2>")
    tp = sum(int(p.get("minutes", 0) or 0) for p in prep)
    P.append("<div class='timeline'>")
    if prep:
        P.append("<div class='sub' style='padding:12px 0 0'>预计 <b>{} 分钟</b> 一次搞定，"
                 "之后工作日每天只需 15-25 分钟下锅。</div>".format(tp))
    for i, p in enumerate(prep, 1):
        P.append("<div class='tl'><div class='tn'>{}</div><div class='tb'>".format(i))
        P.append("<div class='tp'><span>{}</span><span class='tm'>{} 分钟</span></div>".format(
            esc(g(p, "phase")), esc(g(p, "minutes", "-"))))
        tasks = p.get("tasks", []) or []
        if tasks:
            P.append("<ul class='tt'>")
            for t in tasks:
                P.append("<li>{}</li>".format(esc(t)))
            P.append("</ul>")
        P.append("</div></div>")
    P.append("</div>")

    # check
    P.append("<h2>营养自检</h2>")
    P.append("<table class='chk'><thead><tr><th>指标</th><th>目标</th><th>实际</th><th>结论</th></tr></thead><tbody>")
    for c in checks:
        st = g(c, "status", "ok")
        cls = {"ok": "ok", "warn": "warn", "over": "bad", "under": "warn"}.get(st, "")
        P.append("<tr><td>{}</td><td>{}</td><td>{}</td><td class='{}'>{} {}</td></tr>".format(
            esc(g(c, "item")), esc(g(c, "target")), esc(g(c, "actual")),
            cls, STATUS_MARK.get(st, ""), STATUS_TEXT.get(st, "")))
    P.append("</tbody></table>")

    if savings:
        P.append("<h2>省钱开关（预算超了就按顺序打开）</h2>")
        P.append("<div class='savewrap'>")
        for s in savings:
            P.append("<div class='sv'><div class='sva'>{}</div>".format(esc(g(s, "action"))))
            P.append("<div class='svm'><span class='svp'>−{} 元</span>".format(esc(g(s, "save", "-"))))
            if s.get("cost"):
                P.append("<span class='svc'>{}</span>".format(esc(s["cost"])))
            P.append("</div></div>")
        P.append("</div>")

    P.append("<h2>执行提醒</h2>")
    P.append("<div class='notes'><ul>")
    for t in ["每天饮水 1500-1700 ml，餐前 30 分钟喝 200 ml 有助于控制食量。",
              "进餐顺序：蔬菜 → 蛋白质 → 主食，血糖更平稳，也更容易吃饱。",
              "没时间就用「一锅出」或「零烹饪日」方案替代，别直接跳过一餐。",
              "每周固定早晨空腹称重一次，连续两周同向变化超 1.5 kg 再调整热量。",
              "剩菜冷藏不超 2 天，复热必须彻底煮沸；绿叶菜尽量当顿吃完。"]:
        P.append("<li>{}</li>".format(t))
    P.append("</ul></div>")

    P.append("<div class='foot'>点击菜名展开做法 ｜ 买菜勾选状态保存在本浏览器</div>")
    P.append("</div><script>{}</script></body></html>".format(JS))
    return "\n".join(P)


JS = """
(function(){
  var KEY='wmp_checked_v1';
  var st={};
  try{st=JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){st={}}
  document.querySelectorAll('.dsum').forEach(function(s){
    s.addEventListener('click',function(){s.parentNode.classList.toggle('open')});
  });
  var rows=[].slice.call(document.querySelectorAll('.row'));
  function paint(){
    var cards=document.querySelectorAll('.scard');
    rows.forEach(function(r){
      var i=r.getAttribute('data-i');
      r.classList.toggle('done',!!st[i]);
    });
    cards.forEach(function(c){
      var rs=[].slice.call(c.querySelectorAll('.row'));
      var dn=rs.filter(function(r){return r.classList.contains('done')}).length;
      var bar=c.querySelector('.prog i');
      if(bar) bar.style.width=(rs.length?dn/rs.length*100:0)+'%';
    });
  }
  rows.forEach(function(r){
    r.querySelector('.cb').addEventListener('click',function(e){
      e.stopPropagation();
      var i=r.getAttribute('data-i');
      st[i]=!st[i];
      try{localStorage.setItem(KEY,JSON.stringify(st))}catch(err){}
      paint();
    });
  });
  paint();
})();
"""


def main():
    ap = argparse.ArgumentParser(description="生成一周饮食计划 Markdown 与 HTML 看板")
    ap.add_argument("plan", help="plan.json 路径")
    ap.add_argument("--out-dir", default=".", help="输出目录")
    ap.add_argument("--name", default="一周饮食计划", help="输出文件名前缀")
    a = ap.parse_args()

    with open(a.plan, "r", encoding="utf-8") as f:
        plan = json.load(f)

    os.makedirs(a.out_dir, exist_ok=True)
    md_path = os.path.join(a.out_dir, a.name + ".md")
    html_path = os.path.join(a.out_dir, a.name + ".html")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write(build_markdown(plan))
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(build_html(plan))

    n_dish = sum(len((d.get("meals", {}) or {}).get(k, []) or [])
                 for d in plan.get("days", []) for k in MEAL_LABEL)
    print("OK")
    print("  markdown -> " + os.path.abspath(md_path))
    print("  html     -> " + os.path.abspath(html_path))
    print("  {} 天 / {} 道菜 / {} 项采购 / {} 个备菜环节".format(
        len(plan.get("days", [])), n_dish, len(plan.get("shopping", [])), len(plan.get("prep", []))))


if __name__ == "__main__":
    main()
