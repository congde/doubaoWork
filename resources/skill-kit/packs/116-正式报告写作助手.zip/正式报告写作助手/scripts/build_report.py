#!/usr/bin/env python3
"""正式报告成文：把结构化 Markdown 转成可直接打印/转 PDF 的规范 HTML 文档。

输入 Markdown 支持：# 标题、##/### 章节、无序列表、有序列表、表格、**加粗**、段落。
输出 A4 版式 HTML（浏览器打开 → 打印 → 存为 PDF）。零第三方依赖。
"""
import argparse
import html
import re
from datetime import date
from pathlib import Path

CSS = """
body{font-family:"Songti SC","SimSun",serif;max-width:210mm;margin:0 auto;padding:24mm 20mm;
     color:#1a1a1a;font-size:12pt;line-height:1.8;}
h1{font-size:20pt;text-align:center;margin:0 0 4mm;}
.meta{text-align:center;color:#555;font-size:10.5pt;margin-bottom:10mm;}
h2{font-size:15pt;border-left:4pt solid #1a3c6e;padding-left:8px;margin-top:10mm;}
h3{font-size:13pt;margin-top:7mm;}
table{border-collapse:collapse;width:100%;margin:4mm 0;font-size:11pt;}
th,td{border:1px solid #999;padding:6px 10px;text-align:left;}
th{background:#eef2f7;}
blockquote{color:#666;border-left:3px solid #ccc;margin:4mm 0;padding-left:10px;}
.pending{color:#b00;background:#fff3f3;padding:1px 4px;border-radius:3px;}
@page{size:A4;margin:0;}
@media print{.no-print{display:none;}}
.footer-note{margin-top:12mm;color:#777;font-size:10pt;border-top:1px solid #ccc;padding-top:3mm;}
"""

TAG_RE = re.compile(r"\*\*(.+?)\*\*")
PENDING_RE = re.compile(r"(\[待补充[^\]]*\])")


def inline(text: str) -> str:
    out = html.escape(text)
    out = PENDING_RE.sub(r'<span class="pending">\1</span>', out)
    return TAG_RE.sub(r"<strong>\1</strong>", out)


def render(md: str) -> str:
    lines = md.splitlines()
    body, i, title, meta = [], 0, "文档", []
    while i < len(lines):
        line = lines[i]
        s = line.strip()
        if not s:
            i += 1
            continue
        if s.startswith("# ") and not s.startswith("## "):
            title = s[2:].strip()
        elif s.startswith("### "):
            body.append(f"<h3>{inline(s[4:])}</h3>")
        elif s.startswith("## "):
            body.append(f"<h2>{inline(s[3:])}</h2>")
        elif s.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            if rows:
                thead = "".join(f"<th>{inline(c)}</th>" for c in rows[0])
                trs = "".join("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in r) + "</tr>" for r in rows[1:])
                body.append(f"<table><thead><tr>{thead}</tr></thead><tbody>{trs}</tbody></table>")
            continue
        elif re.match(r"^\d+\.\s", s):
            body.append(f"<p>{inline(s)}</p>")
        elif s.startswith("- ") or s.startswith("* "):
            body.append(f"<p>• {inline(s[2:])}</p>")
        elif s.startswith(">"):
            body.append(f"<blockquote>{inline(s.lstrip('> '))}</blockquote>")
        else:
            body.append(f"<p>{inline(s)}</p>")
        i += 1
    meta_html = f'<div class="meta">{html.escape(" ｜ ".join(meta) if meta else date.today().strftime("%Y-%m-%d"))}</div>'
    return f"<!DOCTYPE html><html lang=\"zh\"><head><meta charset=\"utf-8\"><title>{html.escape(title)}</title><style>{CSS}</style></head><body><h1>{inline(title)}</h1>{meta_html}{''.join(body)}<div class=\"footer-note no-print\">打印：浏览器打开本文件 → Ctrl/Cmd+P → 另存为 PDF（A4，默认边距关闭以使用内置版式）</div></body></html>"


DEMO_MD = """# 关于社区便利店选品优化的调研报告
（运营部 ｜ 2026-08-20）

## 摘要
本月对 3 家门店 452 个 SKU 的销售数据进行了分析，**动销率仅 61%**，长尾滞销品占用货架与资金。建议首批淘汰 78 个 SKU，引入高频日用品补位，预计月度周转提升 15%。

## 一、背景与目标
社区店客流稳定但客单价下降 8%，需要通过选品调整提升坪效。本次调研目标：找出滞销品并给出替换建议。

## 二、发现
### （一）滞销品集中在外购零食
- 外购零食动销率 42%，显著低于自有品牌 78%
- Top 10 滞销 SKU 平均库龄 97 天

| 品类 | SKU 数 | 动销率 | 平均库龄（天） |
|------|--------|--------|----------------|
| 外购零食 | 120 | 42% | 97 |
| 自有品牌 | 80 | 78% | 31 |
| 日用百货 | 150 | 69% | 45 |

## 三、结论与建议
1. 淘汰库龄超 90 天且动销率低于 30% 的 78 个 SKU
2. 引入高频刚需日用品补位（数据来源：周边小区团购订单）[待补充：补位品类的具体清单]
3. 建立月度动销复盘机制，滞销标准写入采购 SOP
"""


def main():
    ap = argparse.ArgumentParser(description="Markdown → 正式报告 HTML")
    ap.add_argument("input", nargs="?", help="结构化 Markdown 文件")
    ap.add_argument("--out", help="输出 HTML 路径（默认同名 .html）")
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()

    if args.demo:
        skill_root = Path(__file__).resolve().parent.parent
        src = skill_root / "examples" / "demo_input.md"
        src.parent.mkdir(parents=True, exist_ok=True)
        src.write_text(DEMO_MD, encoding="utf-8")
        args.input, args.out = str(src), str(skill_root / "examples" / "调研报告示例.html")
    elif not args.input:
        ap.error("请提供 Markdown 文件，或用 --demo 演示")

    md = Path(args.input).read_text(encoding="utf-8")
    out = Path(args.out) if args.out else Path(args.input).with_suffix(".html")
    out.write_text(render(md), encoding="utf-8")
    print(f"已生成正式报告：{out}")
    print("下一步：浏览器打开 → 打印 → 存为 PDF；或粘贴进 Word 使用正文样式。")


if __name__ == "__main__":
    main()
