#!/usr/bin/env python3
import argparse
import os
import subprocess
import sys
import webbrowser
from pathlib import Path


HTML_TEMPLATE = """<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1, width=device-width">
  <title>{title}</title>
  <style>
    body {{
      margin: 0;
      padding: 84px 0 24px;
      background: #f5f5f5;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }}
    .toolbar {{
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 10;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      padding: 12px;
      background: rgba(255, 255, 255, 0.94);
      border-bottom: 1px solid #e5e7eb;
      box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
      backdrop-filter: blur(10px);
    }}
    .toolbar button {{
      min-height: 40px;
      border: 0;
      border-radius: 8px;
      padding: 0 16px;
      color: #fff;
      background: #2563eb;
      font-size: 15px;
      font-weight: 700;
      cursor: pointer;
    }}
    .toolbar span {{
      color: #4b5563;
      font-size: 13px;
    }}
    .wechat-preview {{
      width: min(680px, calc(100% - 24px));
      margin: 0 auto;
      background: #ffffff;
      padding: 16px;
    }}
  </style>
</head>
<body>
  <div class="toolbar">
    <button id="copy-rich-text" type="button">复制排版内容</button>
    <span id="copy-status">复制后粘贴到公众号后台</span>
  </div>
  <main id="wechat-content" class="wechat-preview">
{body}
  </main>
  <script>
    const button = document.getElementById("copy-rich-text");
    const status = document.getElementById("copy-status");
    const content = document.getElementById("wechat-content");

    async function copyRichText() {{
      const html = content.innerHTML;
      const text = content.innerText;
      if (navigator.clipboard && window.ClipboardItem) {{
        const item = new ClipboardItem({{
          "text/html": new Blob([html], {{ type: "text/html" }}),
          "text/plain": new Blob([text], {{ type: "text/plain" }})
        }});
        await navigator.clipboard.write([item]);
      }} else {{
        const range = document.createRange();
        range.selectNodeContents(content);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
        document.execCommand("copy");
        selection.removeAllRanges();
      }}
    }}

    button.addEventListener("click", async () => {{
      try {{
        await copyRichText();
        status.textContent = "已复制，去公众号后台粘贴即可";
      }} catch (error) {{
        status.textContent = "复制失败，请手动全选正文区域复制";
      }}
    }});
  </script>
</body>
</html>
"""


def main():
    parser = argparse.ArgumentParser(description="Wrap a WeChat HTML fragment as a browser preview page.")
    parser.add_argument("--input", required=True, help="HTML fragment file.")
    parser.add_argument("--output", required=True, help="Preview HTML output path.")
    parser.add_argument("--title", default="公众号排版预览")
    parser.add_argument("--open", action="store_true", help="Open the generated preview file in the default browser.")
    args = parser.parse_args()

    body = Path(args.input).expanduser().read_text(encoding="utf-8")
    output = Path(args.output).expanduser()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(HTML_TEMPLATE.format(title=args.title, body=body), encoding="utf-8")
    print(output)
    if args.open:
        open_preview(output)


def open_preview(path):
    path = path.resolve()
    try:
        if sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=True)
        elif os.name == "nt":
            os.startfile(str(path))
        else:
            webbrowser.open(path.as_uri())
    except Exception as exc:
        print(f"Preview file was created but could not be opened automatically: {exc}", file=sys.stderr)


if __name__ == "__main__":
    main()
