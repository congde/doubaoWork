#!/usr/bin/env python3
import argparse
import html
import re
from pathlib import Path


THEMES = {
    "knowledge-blue": {
        "primary": "#2563eb",
        "primary_soft": "#eff6ff",
        "text": "#1f2937",
        "muted": "#6b7280",
        "border": "#bfdbfe",
        "bg": "#ffffff",
    }
}


def inline_markdown(text):
    text = html.escape(text.strip())
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"`([^`]+)`", r'<span style="font-family:Menlo,Consolas,monospace;background:#f3f4f6;padding:2px 5px;border-radius:4px;">\1</span>', text)
    return text


def paragraph(text, theme):
    return (
        f'<p style="margin:14px 0;color:{theme["text"]};font-size:16px;'
        f'line-height:1.9;letter-spacing:0.2px;">{inline_markdown(text)}</p>'
    )


def h1(text, theme):
    return f"""
<section style="margin:0 0 24px;padding:24px 20px;border-radius:16px;background:{theme["primary_soft"]};border:1px solid {theme["border"]};">
  <p style="margin:0 0 8px;color:{theme["primary"]};font-size:13px;font-weight:700;">公众号主题排版</p>
  <h1 style="margin:0;color:{theme["text"]};font-size:26px;line-height:1.35;font-weight:800;">{inline_markdown(text)}</h1>
</section>""".strip()


def h2(text, theme):
    return f"""
<h2 style="margin:32px 0 14px;padding:0 0 0 12px;border-left:5px solid {theme["primary"]};color:{theme["text"]};font-size:21px;line-height:1.45;font-weight:800;">{inline_markdown(text)}</h2>""".strip()


def h3(text, theme):
    return f'<h3 style="margin:24px 0 10px;color:{theme["primary"]};font-size:18px;line-height:1.5;font-weight:800;">{inline_markdown(text)}</h3>'


def quote(text, theme):
    return (
        f'<blockquote style="margin:18px 0;padding:14px 16px;border-left:4px solid {theme["primary"]};'
        f'background:{theme["primary_soft"]};color:{theme["text"]};font-size:15px;line-height:1.8;">{inline_markdown(text)}</blockquote>'
    )


def list_block(items, ordered, theme):
    tag = "ol" if ordered else "ul"
    body = "\n".join(
        f'<li style="margin:8px 0;color:{theme["text"]};font-size:16px;line-height:1.8;">{inline_markdown(item)}</li>'
        for item in items
    )
    return f'<{tag} style="margin:14px 0;padding-left:24px;">\n{body}\n</{tag}>'


def flush_paragraph(parts, out, theme):
    if parts:
        out.append(paragraph(" ".join(parts), theme))
        parts.clear()


def flush_list(items, ordered, out, theme):
    if items:
        out.append(list_block(items, ordered, theme))
        items.clear()


def convert(markdown_text, theme_name="knowledge-blue"):
    theme = THEMES[theme_name]
    out = []
    para = []
    list_items = []
    list_ordered = False

    for raw in markdown_text.splitlines():
        line = raw.rstrip()
        stripped = line.strip()
        if not stripped:
            flush_paragraph(para, out, theme)
            flush_list(list_items, list_ordered, out, theme)
            continue
        if stripped.startswith("# "):
            flush_paragraph(para, out, theme)
            flush_list(list_items, list_ordered, out, theme)
            out.append(h1(stripped[2:], theme))
        elif stripped.startswith("## "):
            flush_paragraph(para, out, theme)
            flush_list(list_items, list_ordered, out, theme)
            out.append(h2(stripped[3:], theme))
        elif stripped.startswith("### "):
            flush_paragraph(para, out, theme)
            flush_list(list_items, list_ordered, out, theme)
            out.append(h3(stripped[4:], theme))
        elif stripped.startswith("> "):
            flush_paragraph(para, out, theme)
            flush_list(list_items, list_ordered, out, theme)
            out.append(quote(stripped[2:], theme))
        elif stripped.startswith("- "):
            flush_paragraph(para, out, theme)
            if list_items and list_ordered:
                flush_list(list_items, list_ordered, out, theme)
            list_ordered = False
            list_items.append(stripped[2:])
        elif re.match(r"^\d+\.\s+", stripped):
            flush_paragraph(para, out, theme)
            if list_items and not list_ordered:
                flush_list(list_items, list_ordered, out, theme)
            list_ordered = True
            list_items.append(re.sub(r"^\d+\.\s+", "", stripped))
        else:
            para.append(stripped)

    flush_paragraph(para, out, theme)
    flush_list(list_items, list_ordered, out, theme)
    body = "\n".join(out)
    return f'<section style="max-width:680px;margin:0 auto;padding:8px 4px;background:{theme["bg"]};">\n{body}\n</section>\n'


def main():
    parser = argparse.ArgumentParser(description="Convert a Markdown article to inline-styled WeChat HTML.")
    parser.add_argument("--input", required=True, help="Markdown input file.")
    parser.add_argument("--output", required=True, help="HTML fragment output file.")
    parser.add_argument("--theme", default="knowledge-blue", choices=sorted(THEMES))
    args = parser.parse_args()

    source = Path(args.input).expanduser().read_text(encoding="utf-8")
    output = Path(args.output).expanduser()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(convert(source, args.theme), encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
