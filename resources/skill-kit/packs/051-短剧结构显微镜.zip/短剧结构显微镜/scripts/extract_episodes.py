#!/usr/bin/env python3
"""短剧正片批量预处理：发现集数 → 提取时长和音轨 → 定时抽帧拼图 → 语音转写。

跨平台（macOS / Windows / Linux），无 Shell 依赖。

用法:
    python extract_episodes.py <正片目录> <输出目录> [起始集号] [结束集号]

    正片目录: 存放纯数字命名 mp4 的目录（1.mp4、2.mp4 …）
    输出目录: 每集生成 <输出目录>/ep<N>/{duration.txt, audio.wav, sheet_XX.png, transcript.txt}

断点恢复（磁盘产物即状态，缺哪步补哪步）:
    - duration.txt 缺失/为空   → 重新 ffprobe
    - audio.wav 缺失/零字节    → 重新抽取（临时文件+原子替换）
    - sheet_XX.png 数量不符    → 整组重抽
    - transcript.txt 缺失/为空 → 重新转写；确认无可识别语音时写入标记行，
      同样视为有效完成态，保证幂等

依赖:
    - ffmpeg / ffprobe 在 PATH（启动时自检，缺失给出安装方式并以退出码 2 结束）
    - Python 依赖 faster-whisper（未安装时明确报错并给出绑定当前解释器的安装命令，不自动安装）

网络:
    - 默认使用官方 Hugging Face；联网失败自动降级用本地已缓存模型。
      如需国内镜像，设置环境变量 HF_USE_MIRROR=1，或自行设置 HF_ENDPOINT。
    - 脚本不修改、不清除用户的任何网络与代理配置。
"""

from __future__ import annotations

import math
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

NO_SPEECH_MARK = "[无可识别语音]"


def fail(msg: str) -> None:
    print(f"✗ {msg}", file=sys.stderr)


def precheck_tools() -> None:
    """启动前检查外部命令，缺失直接说明并以退出码 2 结束。"""
    missing = [t for t in ("ffmpeg", "ffprobe") if shutil.which(t) is None]
    if missing:
        fail(f"缺少外部依赖: {', '.join(missing)}（需要 ffmpeg，内含 ffprobe）")
        fail("安装方式：macOS `brew install ffmpeg`｜Windows `winget install ffmpeg`｜"
             "Debian/Ubuntu `sudo apt install ffmpeg`")
        sys.exit(2)


def ffprobe_duration(video: Path) -> float | None:
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "quiet", "-show_entries", "format=duration", "-of", "csv=p=0", str(video)],
            capture_output=True, text=True,
        ).stdout.strip()
        return float(out)
    except (subprocess.CalledProcessError, FileNotFoundError, ValueError):
        return None


def run_ffmpeg(args: list[str]) -> tuple[bool, str]:
    """执行 ffmpeg；保留 stderr 末尾几行用于失败时展示真实原因。"""
    try:
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", *args],
                           capture_output=True, text=True)
    except FileNotFoundError:
        return False, "找不到 ffmpeg 命令（PATH 中不存在）"
    if r.returncode == 0:
        return True, ""
    lines = [ln for ln in (r.stderr or "").strip().splitlines() if ln.strip()]
    return False, "\n".join(lines[-5:]) if lines else f"退出码 {r.returncode}"


# ---------------- faster-whisper（惰性加载，全剧复用同一模型） ----------------
_whisper_model = None


def get_model():
    global _whisper_model
    if _whisper_model is None:
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            fail("缺少 Python 依赖 faster-whisper。请用当前解释器安装（建议隔离环境）：")
            fail(f'    "{sys.executable}" -m pip install faster-whisper')
            fail("Windows 示例：py -3 -m pip install faster-whisper")
            sys.exit(2)
        if os.environ.get("HF_USE_MIRROR") == "1" and not os.environ.get("HF_ENDPOINT"):
            os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
        try:
            _whisper_model = WhisperModel("small", device="cpu", compute_type="int8")
        except Exception as e:
            # 联网失败（代理不通/断网等）→ 自动降级用本地已缓存模型，不改动用户网络配置
            print(f"⚠ 在线获取模型失败（{type(e).__name__}），尝试使用本地缓存…")
            _whisper_model = WhisperModel("small", device="cpu", compute_type="int8",
                                          local_files_only=True)
    return _whisper_model


def transcribe(audio: Path, dst: Path) -> bool:
    try:
        model = get_model()
        segments, _info = model.transcribe(str(audio), language="zh", vad_filter=True)
        seg_list = list(segments)
        tmp = dst.with_suffix(".txt.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            if seg_list:
                for seg in seg_list:
                    f.write(f"[{seg.start:6.1f}-{seg.end:6.1f}] {seg.text}\n")
            else:
                # 无对白视频：写入明确标记，既告知后续阅读者，也保证幂等（非空=已完成）
                f.write(NO_SPEECH_MARK + "\n")
        os.replace(tmp, dst)  # 原子替换：中断不会留下"非空但不完整"的转写
        return True
    except KeyboardInterrupt:
        raise
    except SystemExit:
        raise
    except Exception as e:  # 转写失败要可见，不吞错
        fail(f"{dst.parent.name} 转写异常: {type(e).__name__}: {e}")
        return False


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    precheck_tools()

    src, out = Path(sys.argv[1]), Path(sys.argv[2])
    lo = int(sys.argv[3]) if len(sys.argv) > 3 else None
    hi = int(sys.argv[4]) if len(sys.argv) > 4 else None

    if not src.is_dir():
        fail(f"正片目录不存在: {src}")
        return 1
    out.mkdir(parents=True, exist_ok=True)

    # 发现集数：纯数字命名 mp4，按数字排序
    eps = []
    for f in src.glob("*.mp4"):
        if re.fullmatch(r"\d+", f.stem):
            n = int(f.stem)
            if (lo is None or n >= lo) and (hi is None or n <= hi):
                eps.append((n, f))
    eps.sort(key=lambda x: x[0])
    if not eps:
        fail(f"未在 {src} 发现纯数字命名的 mp4")
        return 1
    print(f"发现 {len(eps)} 集: {', '.join(str(n) for n, _ in eps)}")

    failed: list[str] = []
    for n, video in eps:
        ep = out / f"ep{n:02d}"
        ep.mkdir(exist_ok=True)
        ok = True

        # ---- 产物1: duration.txt（ffprobe 真实时长，拆解稿以此为准）----
        dur_path = ep / "duration.txt"
        dur = None
        if dur_path.exists() and dur_path.stat().st_size > 0:
            try:
                dur = float(dur_path.read_text().strip())
            except ValueError:
                pass
        if dur is None:
            dur = ffprobe_duration(video)
            if dur is None:
                fail(f"ep{n} 取时长失败（ffprobe 无法读取该文件，可能是视频损坏或编码不支持）")
                ok = False
            else:
                tmp = dur_path.with_suffix(".txt.tmp")
                tmp.write_text(f"{dur}\n")
                os.replace(tmp, dur_path)

        # ---- 产物2: audio.wav（零字节视为损坏，临时文件+原子替换）----
        audio = ep / "audio.wav"
        if ok and not (audio.exists() and audio.stat().st_size > 0):
            tmp = ep / "audio.wav.tmp"
            good, err = run_ffmpeg(["-i", str(video), "-vn", "-ac", "1", "-ar", "16000",
                                    "-f", "wav", str(tmp)])
            if not good:
                fail(f"ep{n} 音频抽取失败:\n{err}")
                ok = False
            else:
                os.replace(tmp, audio)

        # ---- 产物3: sheet_XX.png（数量不符整组重抽；每张覆盖约 45 秒）----
        if ok and dur is not None:
            want = max(1, math.ceil(dur / 45))
            have = len(list(ep.glob("sheet_*.png")))
            if have != want:
                for old_sheet in ep.glob("sheet_*.png"):
                    old_sheet.unlink()
                good, err = run_ffmpeg(["-i", str(video),
                                        "-vf", "fps=1/3,scale=300:-1,tile=5x3",
                                        "-frames:v", str(want), str(ep / "sheet_%02d.png")])
                if not good:
                    fail(f"ep{n} 抽帧拼图失败:\n{err}")
                    ok = False
                have = len(list(ep.glob("sheet_*.png")))
            if ok and have != want:
                fail(f"ep{n} 拼图数量不对（有{have}/应{want}）")
                ok = False

        # ---- 产物4: transcript.txt（非空才算完成；"[无可识别语音]"是有效完成态）----
        tr = ep / "transcript.txt"
        if ok and not (tr.exists() and tr.stat().st_size > 0):
            if not transcribe(audio, tr):
                ok = False

        if ok:
            sheets = len(list(ep.glob("sheet_*.png")))
            first_line = open(tr, encoding="utf-8").readline().strip() if tr.exists() else ""
            note = "（无对白）" if first_line == NO_SPEECH_MARK else f"转写 {sum(1 for _ in open(tr, encoding='utf-8'))} 行"
            print(f"ep{n} ✓ 时长{dur:.1f}s / {sheets} 张拼图 / {note}")
        else:
            failed.append(str(n))

    print("===== 全部完成 =====")
    if failed:
        print(f"⚠ 失败集（修复后重跑同一命令即可续）：{', '.join(failed)}")
        return 1
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n已中断——重跑同一命令即可从断点续跑")
        sys.exit(130)
