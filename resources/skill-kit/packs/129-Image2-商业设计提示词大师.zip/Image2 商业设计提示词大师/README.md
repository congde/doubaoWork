# Image2 商业设计提示词大师

这是一个面向 ChatGPT Images 2.0 / gpt-image-2 的指令型 Skill。

## 文件

- `SKILL.md`：核心 Skill
- `references/prompt-framework.md`：商业设计提示词补全框架
- `references/examples.md`：触发和测试样例

## 推荐使用方式

在 ChatGPT 的 Skills 页面创建或导入 Skill；也可以将 `SKILL.md` 内容直接粘贴到 Skill 创建界面。

使用时只需输入一句简单想法，例如：

> 帮我做一个现代东方的酒店大堂，安静高级。

Skill 将自动输出可直接复制使用的完整提示词。
