#!/usr/bin/env python3
"""
Lightweight reference scanner for industrial code-change impact review.

It searches C/C++/Qt/Python/QML source files for a target symbol and
common surrounding patterns such as connect, emit, assignments, and
state-machine keywords.

No third-party dependencies are required.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, List

EXTENSIONS = {".cpp", ".cc", ".cxx", ".c", ".h", ".hpp", ".hh", ".py", ".qml"}
SKIP_DIRS = {
    ".git", ".hg", ".svn", ".idea", ".vscode",
    "build", "debug", "release", "__pycache__",
    ".venv", "venv", "env", "dist", "node_modules",
}

CONTEXT_PATTERNS = [
    ("connect", re.compile(r"\bconnect\s*\(")),
    ("emit", re.compile(r"\bemit\b")),
    ("qt-queued", re.compile(r"Qt::QueuedConnection")),
    ("qt-blocking", re.compile(r"Qt::BlockingQueuedConnection")),
    ("qt-direct", re.compile(r"Qt::DirectConnection")),
    ("moveToThread", re.compile(r"\bmoveToThread\s*\(")),
    ("state-case", re.compile(r"\bcase\s+\w+")),
    ("timeout", re.compile(r"timeout|TimeOut|TIMEOUT", re.I)),
    ("retry", re.compile(r"retry|Retry|RETRY")),
    ("queue", re.compile(r"queue|Queue|commandQueue|pollQueue")),
    ("write", re.compile(r"\bwrite\s*\(|writeData|serial\.write|send\s*\(")),
    ("read", re.compile(r"\bread\s*\(|readyRead|recv\s*\(")),
]

@dataclass
class Hit:
    file: str
    line: int
    kind: str
    text: str

def iter_files(root: Path) -> Iterable[Path]:
    if root.is_file():
        if root.suffix.lower() in EXTENSIONS:
            yield root
        return

    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in EXTENSIONS:
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        yield p

def read_text(path: Path) -> str:
    encodings = ("utf-8-sig", "utf-8", "gb18030", "latin-1")
    last = None
    for enc in encodings:
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError as exc:
            last = exc
        except Exception:
            raise
    raise last if last else UnicodeDecodeError("utf-8", b"", 0, 1, "decode error")

def classify(line: str, symbol_re: re.Pattern) -> str:
    if re.search(r"\bconnect\s*\(", line) and symbol_re.search(line):
        return "connect"
    if re.search(r"\bemit\b", line) and symbol_re.search(line):
        return "emit"
    if re.search(rf"\b{symbol_re.pattern}\b\s*=", line):
        return "assignment"
    if re.search(r"\b(case|if|while)\b", line) and symbol_re.search(line):
        return "condition/state"
    return "reference"

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Search code for symbol references and change-impact candidates."
    )
    parser.add_argument("path", help="Project directory or source file")
    parser.add_argument("symbol", help="Symbol/text to search")
    parser.add_argument("--json", action="store_true", help="Output JSON")
    parser.add_argument("--context", type=int, default=0,
                        help="Include N lines of surrounding context in plain output")
    args = parser.parse_args()

    root = Path(args.path).expanduser().resolve()
    if not root.exists():
        print(f"Path does not exist: {root}", file=sys.stderr)
        return 2

    escaped = re.escape(args.symbol)
    symbol_re = re.compile(escaped)
    hits: List[Hit] = []
    context_cache = {}

    for path in iter_files(root):
        try:
            text = read_text(path)
        except Exception as exc:
            continue

        lines = text.splitlines()
        try:
            display = str(path.relative_to(root)) if root.is_dir() else path.name
        except ValueError:
            display = str(path)

        for i, line in enumerate(lines, 1):
            if symbol_re.search(line):
                hits.append(Hit(
                    file=display,
                    line=i,
                    kind=classify(line, symbol_re),
                    text=line.strip()[:500]
                ))
                if args.context:
                    start = max(0, i - 1 - args.context)
                    end = min(len(lines), i + args.context)
                    context_cache[(display, i)] = [
                        (n + 1, lines[n]) for n in range(start, end)
                    ]

    hits.sort(key=lambda h: (h.file, h.line))

    if args.json:
        print(json.dumps([asdict(h) for h in hits], ensure_ascii=False, indent=2))
        return 0

    print(f"Symbol: {args.symbol}")
    print(f"Candidate references: {len(hits)}")

    current = None
    for hit in hits:
        if hit.file != current:
            current = hit.file
            print(f"\n## {current}")
        print(f"{hit.line:>6} [{hit.kind}] {hit.text}")
        if args.context:
            for n, txt in context_cache.get((hit.file, hit.line), []):
                marker = ">" if n == hit.line else " "
                print(f"   {marker} {n:>5}: {txt}")

    print("\nNOTE: Search hits are candidates only. Trace callers, threads, state machines,")
    print("protocol paths, persistence, and safety logic before concluding impact.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
