# industrial-change-impact-review

用于工业软件已有项目的“修改前影响分析”和“修改后回归审查”。

## 适用场景

- Qt/C++ 上位机
- Python 工业软件
- 多线程
- QSerialPort
- Modbus
- TCP/IP
- 状态机
- 运动控制
- PLC/HMI
- CSV/JSON/数据库
- AI 辅助修改已有项目

## 安装

解压后，把整个目录放到：

```text
C:\Users\<你的用户名>\.agents\skills\
```

最终应为：

```text
C:\Users\<用户名>\.agents\skills\
└── industrial-change-impact-review\
    ├── SKILL.md
    ├── README.md
    ├── references\
    └── scripts\
```

## 推荐使用方式

### 修改前

```text
$industrial-change-impact-review

我准备把 Water_Chiller_Send 的连接方式从 QueuedConnection
改成 BlockingQueuedConnection。

先分析影响，不要修改代码。
```

### 修改共享变量

```text
$industrial-change-impact-review

准备把 target.ftoolFactor 从全局变量改成 signal 参数。
分析所有调用、线程、状态机和数据保存影响。
```

### 修改后复查

```text
$industrial-change-impact-review

这次修改已经完成。
检查所有受影响路径是否同步修改，并判断有没有新增回归风险。
不要继续改代码。
```

## impact_scan.py

可以先做引用候选扫描：

```bash
python scripts/impact_scan.py E:\project Water_Chiller_Send
```

支持常见：

- `.cpp`
- `.cc`
- `.cxx`
- `.c`
- `.h`
- `.hpp`
- `.py`
- `.qml`

可选 JSON：

```bash
python scripts/impact_scan.py E:\project target_flag --json
```

注意：脚本结果只是候选位置，不是最终影响结论。
