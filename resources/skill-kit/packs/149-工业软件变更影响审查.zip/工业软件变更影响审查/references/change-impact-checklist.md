# Industrial Change Impact Checklist

## 1. 变更定位
- [ ] 修改了哪个文件？
- [ ] 哪个类？
- [ ] 哪个函数？
- [ ] 哪个变量？
- [ ] 哪个 enum/macro/constant？
- [ ] 哪个 protocol register？
- [ ] 哪个 signal/slot？
- [ ] 哪个 state/step？
- [ ] 哪个数据字段？

## 2. 引用关系
- [ ] declaration
- [ ] definition
- [ ] read
- [ ] write
- [ ] assignment
- [ ] comparison
- [ ] caller
- [ ] callee
- [ ] getter/setter
- [ ] callback
- [ ] emit
- [ ] connect
- [ ] serialization
- [ ] persistence
- [ ] UI binding

## 3. 线程
- [ ] sender thread
- [ ] receiver thread
- [ ] object thread affinity
- [ ] moveToThread
- [ ] DirectConnection
- [ ] QueuedConnection
- [ ] BlockingQueuedConnection
- [ ] shared state readers
- [ ] shared state writers
- [ ] QTimer thread
- [ ] QSerialPort thread
- [ ] Python Thread/Task/Executor

## 4. 设备通讯
- [ ] command creation
- [ ] command queue
- [ ] encoding
- [ ] write/send
- [ ] response
- [ ] parser
- [ ] CRC/checksum
- [ ] frame length
- [ ] address/function
- [ ] timeout
- [ ] retry
- [ ] stale response
- [ ] polling interaction
- [ ] reconnect
- [ ] final device-state confirmation

## 5. 状态机
- [ ] previous state
- [ ] entry condition
- [ ] action
- [ ] success condition
- [ ] next state
- [ ] timeout
- [ ] retry
- [ ] failure state
- [ ] pause
- [ ] resume
- [ ] abort
- [ ] stale state

## 6. 数据结构
- [ ] initializer
- [ ] default value
- [ ] constructor
- [ ] copy/assignment
- [ ] serializer
- [ ] deserializer
- [ ] file format
- [ ] DB schema
- [ ] CSV header/order
- [ ] JSON key
- [ ] enum numeric compatibility
- [ ] old data compatibility

## 7. 安全与报警
- [ ] start permission
- [ ] interlock
- [ ] alarm condition
- [ ] alarm clear
- [ ] emergency stop
- [ ] abnormal shutdown
- [ ] online/offline
- [ ] watchdog

## 8. UI / HMI
- [ ] display
- [ ] input validation
- [ ] enable/disable state
- [ ] table row/index
- [ ] unit
- [ ] decimal precision
- [ ] status color
- [ ] confirmation dialog

## 9. 持久化
- [ ] save
- [ ] load
- [ ] default
- [ ] backup
- [ ] migration
- [ ] encoding
- [ ] partial write
- [ ] version compatibility

## 10. 回归测试
- [ ] normal path
- [ ] timeout
- [ ] communication failure
- [ ] reconnect
- [ ] invalid input
- [ ] repeated command
- [ ] pause/resume
- [ ] abort
- [ ] software restart
- [ ] device restart
- [ ] long-running test
- [ ] boundary value
