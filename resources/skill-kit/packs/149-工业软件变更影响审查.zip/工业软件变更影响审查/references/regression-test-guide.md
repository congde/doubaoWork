# Regression Test Guide

变更影响审查结束后，应根据影响面选择回归测试。

## 通用

1. 正常路径。
2. 边界值。
3. 非法输入。
4. 重复操作。
5. 快速连续操作。
6. 软件重启。
7. 设备重启。
8. 异常退出后恢复。

## 串口/Modbus/TCP

1. 正常应答。
2. 无应答 timeout。
3. CRC/格式错误。
4. 半帧。
5. 多帧粘连。
6. 迟到响应。
7. 连续重试。
8. polling 与控制命令同时发生。
9. 断线。
10. 重连。
11. 重连后状态重新同步。

## 线程

1. 快速重复 emit/call。
2. 高负载。
3. UI 与 worker 同时读写共享状态。
4. 退出线程。
5. 重启 worker。
6. queued backlog。
7. potential deadlock path。

## 状态机

1. 正常 NEXT。
2. success 永远不来。
3. timeout。
4. retry exhausted。
5. stale status。
6. pause。
7. resume。
8. abort。
9. device disconnect mid-step。

## 数据文件

1. 新文件。
2. 旧版本文件。
3. 空文件。
4. 损坏文件。
5. 字段缺失。
6. 字段多余。
7. 编码异常。
8. 写入失败。
9. 磁盘空间不足（可模拟）。
10. 中途退出。

## 运动控制

1. 0 点。
2. 正负限位。
3. 跨 0°。
4. 最大角度。
5. 多圈边界。
6. 正反向。
7. 急停。
8. 通讯断开。
