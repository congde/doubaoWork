# High-Risk Change Patterns

以下模式需要优先检查。

## 1. Queued -> BlockingQueued

修改：

```cpp
Qt::QueuedConnection
```

为：

```cpp
Qt::BlockingQueuedConnection
```

必须检查：

- sender/receiver 是否可能同线程
- slot 是否会回调 sender
- slot 是否执行耗时 I/O
- 是否错误地把 slot 返回当成设备应答

## 2. 共享状态代替参数

```cpp
target.value = 10;
emit Send();
target.value = 20;
```

slot：

```cpp
write(target.value);
```

如果异步执行，实际发送值可能变化。

修改影响可能涉及：

- signal signature
- slot signature
- connect
- queue payload
- command struct
- log
- retry

## 3. timeout 修改

例如：

```cpp
timeout = 300;
```

改成：

```cpp
timeout = 1000;
```

不能只判断“等待更久”。

要检查：

- UI 响应
- retry cadence
- state-machine timeout
- queue throughput
- polling delay
- stale response window
- watchdog

## 4. 数据类型 int -> float

影响可能包括：

- protocol representation
- memcpy
- endian
- register count
- QByteArray length
- QString display precision
- CSV
- database
- validation
- equality comparison

## 5. Modbus 地址修改

必须确认：

- read
- write
- verify readback
- polling
- documentation mapping
- unit/scale
- function code
- register count

## 6. enum 插入新值

```cpp
enum State {
    IDLE = 0,
    START,
    RUN,
    STOP
};
```

中间插入值可能影响：

- persisted numeric value
- PLC protocol
- DB
- switch
- array indexing

## 7. CSV 新增字段

必须同步：

- Header
- row write
- import parser
- size validation
- backward compatibility
- UI table
- historical data

## 8. 状态机新增一步

必须检查：

- 前一步 next
- 新步骤 entry
- timeout
- success
- retry
- failure
- pause/resume
- abort
- 后一步

## 9. 运动换算修改

例如：

- pulse per degree
- gear ratio
- multi-turn
- absolute position
- zero offset

必须检查：

- command conversion
- display conversion
- limit
- homing
- swing
- wrap-around
- alarm threshold
- persisted parameter

## 10. Python queue payload change

从：

```python
queue.put("SET")
```

改为：

```python
queue.put(("SET", value))
```

通常是改善，但仍需同步：

- producer
- consumer
- retry
- logging
- serialization
- test
