# Change Risk Model

## R0 — Critical change risk

修改可能影响：

- 安全联锁
- 急停
- 危险运动
- 真空/气体关键阀门
- 设备不可逆动作
- 关键工艺数据不可恢复
- 多模块共享核心协议/状态结构

R0 修改在发布前必须有明确回归测试和恢复方案。

## R1 — High change risk

例如：

- thread ownership
- Queued/BlockingQueued connection type
- shared global state
- command queue
- protocol register/data type/endian
- timeout/retry
- state transition
- reconnect
- key device confirmation
- motion scaling
- enum numeric values used externally

可能造成：

- 命令丢失
- 重复命令
- 状态误判
- 死锁
- UI freeze
- 设备异常
- 工艺提前/卡死

## R2 — Medium change risk

例如：

- CSV/JSON 字段
- 非关键配置
- UI-to-model mapping
- logging/alarm presentation
- edge-case validation
- non-critical background task

## R3 — Low change risk

例如：

- 无外部行为影响的命名整理
- 局部日志文本
- 不影响接口的注释
- 纯内部等价重构

## Confidence

### Confirmed
影响关系从代码可直接证明。

### High
绝大多数链路已确认，仅少量运行条件未知。

### Medium
存在合理依赖，但调用路径或运行配置未完全确认。

### Requires runtime verification
需要硬件、日志、抓包、压力测试或故障注入才能确认。
