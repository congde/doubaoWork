# 书稿示意图 HTML 模板

以下是一个完整的单图 HTML 模板，包含所有常用元素。出图时基于此模板修改即可。

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>书稿示意图模板</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: "PingFang SC", "Microsoft YaHei", "Helvetica Neue", Arial, sans-serif;
    background: #f0f2f5;
    color: #1a1a2e;
    padding: 32px 20px;
  }
  h1.page-title {
    text-align: center;
    font-size: 22px;
    font-weight: 700;
    color: #1a1a2e;
    margin-bottom: 8px;
  }
  .page-subtitle {
    text-align: center;
    font-size: 13px;
    color: #888;
    margin-bottom: 40px;
  }
  .fig-card {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 2px 16px rgba(0,0,0,0.08);
    padding: 32px 28px 24px;
    margin-bottom: 48px;
    max-width: 900px;
    margin-left: auto;
    margin-right: auto;
  }
  .fig-label {
    font-size: 13px;
    font-weight: 600;
    color: #0ea5e9;
    letter-spacing: 1px;
    text-transform: uppercase;
    margin-bottom: 4px;
  }
  .fig-title {
    font-size: 18px;
    font-weight: 700;
    color: #1a1a2e;
    margin-bottom: 24px;
  }
  .fig-caption {
    text-align: center;
    font-size: 13px;
    color: #666;
    margin-top: 16px;
    font-style: italic;
  }
  svg text { font-family: "PingFang SC", "Microsoft YaHei", Arial, sans-serif; }
  .toc {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.07);
    padding: 20px 28px;
    max-width: 900px;
    margin: 0 auto 40px;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
  }
  .toc a {
    display: inline-block;
    background: #f0f9ff;
    color: #0284c7;
    border-radius: 8px;
    padding: 6px 14px;
    font-size: 13px;
    text-decoration: none;
    font-weight: 500;
    transition: background 0.2s;
  }
  .toc a:hover { background: #0284c7; color: #fff; }
</style>
</head>
<body>

<h1 class="page-title">第X章 示意图</h1>
<p class="page-subtitle">第X章：章节名 | 共 N 张插图 | 供审阅后使用</p>

<div class="toc">
  <a href="#figX-1">图X-1 名称</a>
</div>

<!-- ==================== 图X-1 ==================== -->
<div class="fig-card" id="figX-1">
  <div class="fig-label">图 X-1</div>
  <div class="fig-title">图标题</div>

  <svg viewBox="0 0 860 420" width="100%" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <!-- 渐变 -->
      <linearGradient id="g-primary" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#6366f1"/><stop offset="100%" stop-color="#4f46e5"/>
      </linearGradient>
      <linearGradient id="g-secondary" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#0ea5e9"/><stop offset="100%" stop-color="#0284c7"/>
      </linearGradient>
      <linearGradient id="g-accent" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#f59e0b"/><stop offset="100%" stop-color="#d97706"/>
      </linearGradient>
      <!-- 投影 -->
      <filter id="shadow"><feDropShadow dx="0" dy="2" stdDeviation="5" flood-color="rgba(0,0,0,0.10)"/></filter>
      <!-- 箭头 -->
      <marker id="arrow" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
        <polygon points="0 0, 8 3, 0 6" fill="#6366f1"/>
      </marker>
    </defs>

    <!-- 画布背景 -->
    <rect width="860" height="420" fill="#f8f9ff" rx="12"/>

    <!-- 节点示例：渐变圆角矩形 -->
    <rect x="100" y="160" width="160" height="80" rx="12" fill="url(#g-primary)" filter="url(#shadow)"/>
    <text x="180" y="195" text-anchor="middle" fill="white" font-size="14" font-weight="700">主节点</text>
    <text x="180" y="215" text-anchor="middle" fill="rgba(255,255,255,0.85)" font-size="11">描述文字</text>

    <!-- 节点示例：卡片式（标题栏+内容区） -->
    <rect x="400" y="100" width="180" height="200" rx="10" fill="white" stroke="#e0e7ff" stroke-width="2" filter="url(#shadow)"/>
    <rect x="400" y="100" width="180" height="36" rx="10" fill="#6366f1"/>
    <rect x="400" y="123" width="180" height="13" fill="#6366f1"/>
    <text x="490" y="122" text-anchor="middle" fill="white" font-size="12" font-weight="700">步骤①</text>
    <text x="490" y="155" text-anchor="middle" fill="#374151" font-size="11">内容行1</text>
    <text x="490" y="175" text-anchor="middle" fill="#374151" font-size="11">内容行2</text>
    <!-- 标签 -->
    <rect x="430" y="195" width="120" height="24" rx="6" fill="#ede9fe"/>
    <text x="490" y="211" text-anchor="middle" fill="#4f46e5" font-size="10.5">输出标签</text>

    <!-- 连线+箭头 -->
    <line x1="260" y1="200" x2="398" y2="200" stroke="#6366f1" stroke-width="2" marker-end="url(#arrow)"/>

    <!-- 连线上的标签（白底衬底） -->
    <rect x="298" y="185" width="60" height="20" rx="4" fill="white" opacity="0.9"/>
    <text x="328" y="199" text-anchor="middle" fill="#6366f1" font-size="10.5" font-weight="600">数据流</text>

    <!-- 输出节点 -->
    <rect x="660" y="160" width="160" height="80" rx="12" fill="#fef9c3" stroke="#fbbf24" stroke-width="2" filter="url(#shadow)"/>
    <text x="740" y="195" text-anchor="middle" fill="#92400e" font-size="13" font-weight="700">输出</text>
    <text x="740" y="215" text-anchor="middle" fill="#78350f" font-size="11">写入钉钉文档</text>
  </svg>

  <p class="fig-caption">图X-1　图的完整标题</p>
</div>

</body>
</html>
```
