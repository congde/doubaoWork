#!/usr/bin/env python3
"""Build a URL with validated UTM parameters."""
import argparse
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode


def main():
    p=argparse.ArgumentParser(description="Build UTM tracking URL")
    p.add_argument("url")
    p.add_argument("--source", required=True)
    p.add_argument("--medium", required=True)
    p.add_argument("--campaign", required=True)
    p.add_argument("--content")
    p.add_argument("--term")
    args=p.parse_args()
    parts=urlsplit(args.url)
    if parts.scheme not in {"http","https"} or not parts.netloc:
        raise SystemExit("ERROR url must be absolute http(s)")
    query=dict(parse_qsl(parts.query, keep_blank_values=True))
    query.update({"utm_source":args.source,"utm_medium":args.medium,"utm_campaign":args.campaign})
    if args.content: query["utm_content"]=args.content
    if args.term: query["utm_term"]=args.term
    print(urlunsplit((parts.scheme,parts.netloc,parts.path,urlencode(query),parts.fragment)))

if __name__ == "__main__": main()
