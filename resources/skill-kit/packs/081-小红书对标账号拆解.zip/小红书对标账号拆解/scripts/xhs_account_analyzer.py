#!/usr/bin/env python3
"""Collect Xiaohongshu account info and recent posted notes."""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

BASE_URL = "https://api.tikhub.io"
CONFIG_PATH = Path(__file__).resolve().parents[1] / "config" / "tikhub.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="采集小红书账号资料和近期笔记")
    parser.add_argument("--profile", required=True, help="账号主页链接、分享文本或 user_id")
    parser.add_argument("--limit", type=int, default=30, help="最多采集笔记数")
    parser.add_argument("--out", default="", help="保存 JSON 路径")
    return parser.parse_args()


def request_json(path: str, params: dict[str, Any], token: str) -> dict[str, Any]:
    url = BASE_URL + path + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0",
        },
    )
    with urllib.request.urlopen(req, timeout=45) as resp:
        return json.loads(resp.read().decode("utf-8", errors="replace"))


def load_api_key() -> str:
    token = os.environ.get("TIKHUB_API_KEY", "").strip()
    if token:
        return token
    if not CONFIG_PATH.exists():
        return ""
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ""
    value = str(data.get("api_key", "")).strip()
    if not value or "填在这里" in value or value.startswith("把你的"):
        return ""
    return value


def walk_values(obj: Any):
    if isinstance(obj, dict):
        yield obj
        for value in obj.values():
            yield from walk_values(value)
    elif isinstance(obj, list):
        for item in obj:
            yield from walk_values(item)


def first_value(obj: dict[str, Any], keys: list[str], default: Any = "") -> Any:
    for key in keys:
        if key in obj and obj[key] not in (None, ""):
            return obj[key]
    return default


def to_int(value: Any) -> int:
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        text = value.strip().replace(",", "")
        multiplier = 1
        if text.endswith(("万", "w", "W")):
            multiplier = 10000
            text = text[:-1]
        try:
            return int(float(text) * multiplier)
        except ValueError:
            return 0
    return 0


def clean_profile_text(value: Any) -> str:
    text = str(value or "")
    text = re.sub(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", "[邮箱已隐藏]", text)
    return text[:240]


def profile_params(profile: str) -> dict[str, str]:
    if "xiaohongshu.com" in profile or "http" in profile:
        return {"share_text": profile}
    return {"user_id": profile}


def extract_user_info(payload: dict[str, Any]) -> dict[str, Any]:
    best = payload.get("data", {}) if isinstance(payload.get("data"), dict) else {}
    for item in walk_values(payload):
        if first_value(item, ["fans", "fans_count", "follower_count", "followers", "fansCount"]):
            best = item
            break
        if not best and first_value(item, ["user_id", "userId", "id"]) and first_value(item, ["nickname", "name", "nick_name"]):
            best = item
    return {
        "user_id": first_value(best, ["user_id", "userId", "userid", "id"]),
        "nickname": first_value(best, ["nickname", "name", "nick_name"]),
        "desc": clean_profile_text(first_value(best, ["desc", "description", "bio", "intro"])),
        "followers": to_int(first_value(best, ["fans", "fans_count", "follower_count", "followers", "fansCount"])),
        "following": to_int(first_value(best, ["follows", "following_count", "follow_count"])),
        "notes_count": to_int(first_value(best, ["notes_count", "note_count", "notesCount", "ndiscovery"])),
    }


def extract_notes(payload: dict[str, Any]) -> tuple[list[dict[str, Any]], str]:
    notes: dict[str, dict[str, Any]] = {}
    cursor = ""
    for item in walk_values(payload):
        if not cursor:
            cursor = str(first_value(item, ["cursor", "next_cursor", "nextCursor"], ""))
        note_id = first_value(item, ["note_id", "noteId", "id"])
        title = first_value(item, ["title", "display_title", "displayTitle", "desc", "description"])
        if not note_id or not title:
            continue
        interact = first_value(item, ["interact_info", "interactInfo", "interaction"], {})
        if not isinstance(interact, dict):
            interact = {}
        notes[str(note_id)] = {
            "note_id": str(note_id),
            "title": str(title),
            "type": first_value(item, ["type", "note_type", "noteType"]),
            "url": first_value(item, ["url", "webUrl", "web_url", "share_link", "shareLink"]),
            "liked_count": to_int(first_value(item, ["liked_count", "likedCount", "like_count", "likeCount"], first_value(interact, ["liked_count", "likedCount", "like_count", "likeCount"]))),
            "collected_count": to_int(first_value(item, ["collected_count", "collectedCount", "collect_count", "collectCount"], first_value(interact, ["collected_count", "collectedCount", "collect_count", "collectCount"]))),
            "comment_count": to_int(first_value(item, ["comments_count", "comment_count", "commentCount"], first_value(interact, ["comment_count", "commentCount"]))),
            "share_count": to_int(first_value(item, ["shared_count", "share_count", "shareCount"], first_value(interact, ["share_count", "shareCount"]))),
            "desc": str(first_value(item, ["desc", "description"], ""))[:160],
        }
    return list(notes.values()), cursor


def median(values: list[int]) -> float:
    vals = sorted(v for v in values if v)
    if not vals:
        return 0
    mid = len(vals) // 2
    if len(vals) % 2:
        return float(vals[mid])
    return (vals[mid - 1] + vals[mid]) / 2


def main() -> int:
    args = parse_args()
    token = load_api_key()
    result: dict[str, Any] = {
        "status": "missing_api_key" if not token else "ok",
        "query": vars(args),
        "account": {},
        "notes": [],
        "summary": {},
        "warnings": [],
    }
    if not token:
        result["warnings"].append("未检测到 TikHub 密钥，无法自动采集账号。请把密钥填到本技能目录的 config/tikhub.json 里的 api_key 字段，或设置环境变量 TIKHUB_API_KEY；暂时没有密钥时，可以粘贴账号资料和近期笔记数据后继续分析。")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    try:
        user_payload = request_json("/api/v1/xiaohongshu/app_v2/get_user_info", profile_params(args.profile), token)
        account = extract_user_info(user_payload)
        if not account.get("user_id") and args.profile and "http" not in args.profile:
            account["user_id"] = args.profile
        user_id = account.get("user_id")
        if not user_id:
            raise ValueError("没有解析到 user_id，请确认主页链接或用户 ID 是否有效。")
        result["account"] = account

        notes: list[dict[str, Any]] = []
        cursor = ""
        while len(notes) < args.limit:
            payload = request_json(
                "/api/v1/xiaohongshu/app_v2/get_user_posted_notes",
                {"user_id": user_id, "cursor": cursor},
                token,
            )
            page_notes, next_cursor = extract_notes(payload)
            if not page_notes:
                break
            notes.extend(page_notes)
            cursor = next_cursor
            if not cursor:
                break
            time.sleep(0.2)
        notes = notes[: args.limit]
        med_like = median([to_int(n.get("liked_count")) for n in notes])
        for note in notes:
            liked = to_int(note.get("liked_count"))
            if med_like and liked >= med_like * 1.5:
                note["performance_band"] = "high"
            elif med_like and liked <= med_like * 0.5:
                note["performance_band"] = "low"
            else:
                note["performance_band"] = "normal"
        result["notes"] = notes
        result["summary"] = {
            "notes_collected": len(notes),
            "median_likes": med_like,
            "high_count": sum(1 for n in notes if n.get("performance_band") == "high"),
            "low_count": sum(1 for n in notes if n.get("performance_band") == "low"),
        }
    except (ValueError, urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
        result["status"] = "failed"
        result["warnings"].append(str(exc))

    if args.out:
        Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] in {"ok", "missing_api_key"} else 1


if __name__ == "__main__":
    sys.exit(main())
