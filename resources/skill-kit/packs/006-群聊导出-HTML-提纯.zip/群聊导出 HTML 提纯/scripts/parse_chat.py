# -*- coding: utf-8 -*-
"""
微信/飞书群聊导出 HTML -> 纯文本
用法: python parse_chat.py <导出.html> [输出.txt]
输出格式:
  ===== 2026年8月25日 12:21 =====   (时间分隔)
  [系统] xxx                        (系统消息)
  昵称: 正文                        (普通消息)
"""
import re
import sys
import html as htmlmod

# 正文容器白名单。坑: 不要写成 msg-[a-z-]*content,
# 会误匹配外层 msg-content 容器(它包着 user-name),导致昵称在正文里重复。
CONTENT_CLASSES = r'msg-text-content|msg-refer-content|msg-share-body'

TYPE_FALLBACK = [
    ('msg-is-image', '[图片]'),
    ('msg-is-sticker', '[表情]'),
    ('msg-is-emoji', '[表情]'),
    ('msg-is-voice', '[语音]'),
    ('msg-is-video', '[视频]'),
    ('msg-is-file', '[文件]'),
]


def strip_tags(frag):
    frag = re.sub(r'<img[^>]*>', '[图片]', frag)
    frag = re.sub(r'<br\s*/?>', '\n', frag)
    # 微信表情: <span title="[强]" class="wx-emoji">...</span>
    frag = re.sub(r'<span title="(\[[^\]]*\])"[^>]*>.*?</span>', r'\1', frag, flags=re.S)
    frag = re.sub(r'<span title="([^"]*)"[^>]*></span>', r'\1', frag)
    frag = re.sub(r'<[^>]+>', '', frag)
    return htmlmod.unescape(frag).strip()


def parse(path):
    s = open(path, encoding='utf-8', errors='replace').read()
    # 坑: 必须先跳过 <style> 块,否则样式里的 .msg-item 选择器会被当成消息
    i = s.find('</style>')
    body = s[s.find('</style>', i + 1) + 8:] if i != -1 else s

    recs = []
    for p in re.split(r'(?=<div class="msg-item )', body):
        if not p.startswith('<div class="msg-item '):
            continue
        m = re.match(r'<div class="msg-item ([^"]*)"', p)
        cls = m.group(1) if m else ''

        if 'msg-is-grouptime' in cls:
            recs.append(('TIME', strip_tags(p), ''))
            continue
        if 'msg-is-system' in cls:
            recs.append(('SYS', '', strip_tags(p)))
            continue

        nm = re.search(r'<div class="user-name"[^>]*>(.*?)</div>', p, re.S)
        name = strip_tags(nm.group(1)) if nm else ''

        segs = [strip_tags(mc.group(2))
                for mc in re.finditer(r'<div class="(%s)"[^>]*>(.*?)</div>' % CONTENT_CLASSES, p, re.S)]
        text = ' '.join(x for x in segs if x)

        if not text:
            text = next((v for k, v in TYPE_FALLBACK if k in cls), '[其他消息]')
        recs.append(('MSG', name, text))
    return recs


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    src = sys.argv[1]
    dst = sys.argv[2] if len(sys.argv) > 2 else src.rsplit('.', 1)[0] + '_raw.txt'

    recs = parse(src)
    with open(dst, 'w', encoding='utf-8') as f:
        for typ, a, b in recs:
            if typ == 'TIME':
                f.write('\n===== %s =====\n' % a)
            elif typ == 'SYS':
                f.write('[系统] %s\n' % b)
            else:
                f.write('%s: %s\n' % (a, b))

    speakers = {}
    for typ, a, b in recs:
        if typ == 'MSG':
            speakers[a] = speakers.get(a, 0) + 1
    print('记录数: %d ｜ 发言人: %d' % (len(recs), len(speakers)))
    print('已写入: %s' % dst)
    for k, v in sorted(speakers.items(), key=lambda x: -x[1])[:10]:
        print('  %4d  %s' % (v, k))


if __name__ == '__main__':
    main()
