# -*- coding: utf-8 -*-
"""Markdown -> 单文件 HTML 报告（浅色主题）。

用法：
    python md2html.py <input.md> [output.html] [--title 标题]

不传输出路径时，默认写到输入文件同目录、同名的 .html。
"""
import argparse
import html
import os
import re
import sys

# 精简后的通用样式：不绑定任何字体文件与外部资源，单文件即可打开
CSS = (
    "*{box-sizing:border-box}"
    "body{margin:0;background:#f7f8fa;color:#1b1f24;"
    "font:15px/1.75 'PingFang SC','Microsoft YaHei',Arial,sans-serif}"
    ".wrap{max-width:980px;margin:0 auto;padding:36px 22px 80px}"
    "h1{font-size:27px;margin:0 0 6px;padding-bottom:16px;border-bottom:2px solid #1b1f24}"
    "h2{font-size:20px;margin:44px 0 14px;padding-left:11px;border-left:4px solid #1f6feb}"
    "h3{font-size:16.5px;margin:28px 0 10px;color:#4a5160}"
    "p{margin:9px 0;color:#4a5160}"
    "strong{color:#1b1f24}"
    "hr{border:0;border-top:1px solid #e6e9ef;margin:30px 0}"
    "blockquote{margin:14px 0;padding:12px 16px;background:#eaf2ff;"
    "border-left:3px solid #1f6feb;color:#4a5160}"
    "ul{margin:9px 0;padding-left:22px;color:#4a5160}"
    "code{background:#f0f2f5;padding:1px 5px;border-radius:4px;font-size:13px;color:#b4335a}"
    "pre{background:#1e2430;color:#dbe3f0;padding:16px 18px;border-radius:9px;"
    "overflow-x:auto;font-size:12.5px}"
    "pre code{background:none;color:inherit;padding:0}"
    ".tw{overflow-x:auto;margin:16px 0;border:1px solid #e6e9ef;border-radius:9px;background:#fff}"
    "table{border-collapse:collapse;width:100%;font-size:13.6px}"
    "th{background:#f2f5f9;text-align:left;padding:10px 13px;border-bottom:1px solid #e6e9ef}"
    "td{padding:9px 13px;border-bottom:1px solid #e6e9ef;color:#4a5160;vertical-align:top}"
)

TPL = (
    '<!DOCTYPE html>\n<html lang="zh-CN"><head><meta charset="UTF-8">\n'
    '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
    "<title>__TITLE__</title>\n<style>__CSS__</style></head>\n"
    '<body><div class="wrap">\n__CONTENT__\n</div></body></html>'
)


def inline(t):
    t = html.escape(t, quote=False)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
    return t


def convert(md):
    lines = md.split("\n")
    out, i, n = [], 0, len(lines)
    while i < n:
        ln = lines[i]
        s = ln.strip()

        if s.startswith("```"):
            i += 1
            buf = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(html.escape(lines[i]))
                i += 1
            i += 1
            out.append("<pre><code>" + "\n".join(buf) + "</code></pre>")
            continue

        if s.startswith("|") and i + 1 < n and re.match(r"^\|[\s:\-\|]+\|$", lines[i + 1].strip()):
            header = [c.strip() for c in s.strip("|").split("|")]
            i += 2
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            out.append(
                '<div class="tw"><table><thead><tr>'
                + "".join("<th>%s</th>" % inline(h) for h in header)
                + "</tr></thead><tbody>"
            )
            for r in rows:
                out.append("<tr>" + "".join("<td>%s</td>" % inline(c) for c in r) + "</tr>")
            out.append("</tbody></table></div>")
            continue

        if s.startswith("#"):
            lvl = len(s) - len(s.lstrip("#"))
            txt = inline(s.lstrip("#").strip())
            out.append("<h%d>%s</h%d>" % (lvl, txt, lvl))
            i += 1
            continue

        if s.startswith("> "):
            buf = []
            while i < n and lines[i].strip().startswith("> "):
                buf.append(inline(lines[i].strip()[2:]))
                i += 1
            out.append("<blockquote>" + "<br>".join(buf) + "</blockquote>")
            continue

        if s.startswith("---"):
            out.append("<hr>")
            i += 1
            continue

        m = re.match(r"^(\s*)- (.+)$", ln)
        if m:
            out.append("<li>%s</li>" % inline(m.group(2)))
            i += 1
            continue

        if s:
            out.append("<p>%s</p>" % inline(s))
        i += 1

    body, buf = [], []
    for tag in out:
        if tag.startswith("<li>"):
            buf.append(tag)
        else:
            if buf:
                body.append("<ul>" + "".join(buf) + "</ul>")
                buf = []
            body.append(tag)
    if buf:
        body.append("<ul>" + "".join(buf) + "</ul>")
    return "\n".join(body)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Markdown -> 单文件 HTML 报告")
    ap.add_argument("input", help="输入 .md 文件")
    ap.add_argument("output", nargs="?", help="输出 .html 文件，默认与输入同目录同名")
    ap.add_argument("--title", default=None, help="HTML <title>，默认取输入文件名")
    args = ap.parse_args(argv)

    if not os.path.isfile(args.input):
        print("错误：找不到输入文件 %s" % args.input, file=sys.stderr)
        return 1

    dst = args.output
    if not dst:
        dst = os.path.splitext(args.input)[0] + ".html"
    title = args.title or os.path.splitext(os.path.basename(args.input))[0]

    with open(args.input, encoding="utf-8") as f:
        md = f.read()
    content = convert(md)
    doc = TPL.replace("__TITLE__", html.escape(title)).replace("__CSS__", CSS).replace("__CONTENT__", content)

    out_dir = os.path.dirname(os.path.abspath(dst))
    if out_dir and not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    with open(dst, "w", encoding="utf-8") as f:
        f.write(doc)
    print("written", dst, len(content))
    return 0


if __name__ == "__main__":
    sys.exit(main())
