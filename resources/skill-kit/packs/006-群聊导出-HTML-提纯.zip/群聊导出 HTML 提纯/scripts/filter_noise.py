# -*- coding: utf-8 -*-
"""
群聊纯文本去噪。移除纯媒体占位、冗余确认、超短回复;保留时间戳与系统消息。
用法: python filter_noise.py <输入.txt> [输出.txt]
"""
import re
import sys

MEDIA = re.compile(r'^(\[图片\]|\[表情\]|\[语音\]|\[视频\]|\[文件\]|\[其他消息\])$')

PLEASANTRY = set("""收到 好的 好 明白 了解 谢谢 感谢 辛苦了 辛苦 赞 棒 牛 6 哈哈 哈哈哈 嘻嘻
呵呵 哦 嗯 嗯嗯 是的 对 对对 同意 支持 欢迎 恭喜 加油 厉害 强 ok OK Ok
收到谢谢 好的谢谢 谢谢老师 好的好的 收到收到 哈哈哈 哦哦 嗯嗯嗯 好嘞 行 可以 没问题""".split())


def is_pleasantry(msg):
    if msg in PLEASANTRY:
        return True
    # 去掉尾部表情后仍是客套话
    core = re.sub(r'\[[^\]]{1,6}\]', '', msg).strip()
    return bool(core) and core in PLEASANTRY


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    src = sys.argv[1]
    dst = sys.argv[2] if len(sys.argv) > 2 else src.rsplit('.', 1)[0] + '_clean.txt'

    stats = {'media': 0, 'pleasantry': 0, 'short': 0, 'keep': 0}
    out = []
    for ln in open(src, encoding='utf-8'):
        t = ln.strip()
        if not t:
            continue
        if t.startswith('=====') or t.startswith('[系统]') or ':' not in t:
            out.append(t)
            continue
        name, _, msg = t.partition(':')
        msg = msg.strip()
        if MEDIA.match(msg):
            stats['media'] += 1
            continue
        if is_pleasantry(msg):
            stats['pleasantry'] += 1
            continue
        if len(msg) <= 3:
            stats['short'] += 1
            continue
        out.append('%s: %s' % (name.strip(), msg))
        stats['keep'] += 1

    text = '\n'.join(out)
    open(dst, 'w', encoding='utf-8').write(text)
    print('过滤: 媒体%d 客套%d 过短%d -> 保留%d 条, %.1fKB'
          % (stats['media'], stats['pleasantry'], stats['short'], stats['keep'],
             len(text.encode('utf-8')) / 1024))
    print('已写入: %s' % dst)


if __name__ == '__main__':
    main()
