# article-publish-reviewer

文章发布前质量审核 Skill。

## 适用场景

适合以下内容在正式发布前进行复核：

- 微信公众号文章
- 小红书笔记
- 知乎文章/回答
- 今日头条文章
- 博客与 SEO 内容
- 品牌内容
- 内容工厂批量生成稿件

## 主要能力

- 事实依据检查
- 标题与正文一致性检查
- 内容结构与逻辑检查
- AI 味风险检查
- 平台适配检查
- 版权、合规与发布风险提示
- 素材完整性检查
- 人工确认项整理
- 固定 JSON 输出

## 文件结构

```text
article-publish-reviewer/
├── SKILL.md
├── README.md
├── references/
│   ├── review-rules.md
│   └── platform-guidelines.md
├── examples/
│   └── sample-review.md
└── schemas/
    └── review-output.schema.json
```

## 使用方式

将整个 `article-publish-reviewer` 文件夹作为 Skill 导入支持 Agent Skills / SkillsMP 类格式的平台。

不同平台的安装入口可能不同，但应保留目录结构，不要只单独上传 `SKILL.md`，这样引用文件和 Schema 才能一起使用。

## 版本

0.1.0
