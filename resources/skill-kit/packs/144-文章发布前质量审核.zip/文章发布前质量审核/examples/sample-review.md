# 示例：发布前审核

## 输入

平台：微信公众号

标题：
《3个月让团队效率提升80%的AI方法》

正文节选：
“我们使用这套方法以后，团队效率提升了80%，而且任何公司都可以复制。”

输入资料仅说明：
“团队在3个月内完成内容产量从每周10篇提升到每周16篇。”

## 期望判断

- “效率提升80%”与输入数据不一致，属于关键事实风险；
- “任何公司都可以复制”属于无依据的绝对化结论；
- 标题沿用了未被证实的“80%”；
- 应判为 `PUBLISH_AFTER_EDIT` 或在事实无法确认时判为 `NEEDS_HUMAN_CONFIRMATION`；
- 不需要重写整篇，只需指出标题和对应正文的具体修改位置。

## 示例输出节选

```json
{
  "workspacePatch": {
    "kind": "workspace_patch",
    "projectId": "demo-project",
    "reviewReport": {
      "publishStatus": "PUBLISH_AFTER_EDIT",
      "summary": "文章主体可用，但标题和核心数据存在依据不一致问题，发布前需修改。",
      "issues": [
        {
          "priority": "P1",
          "category": "fact",
          "location": "标题及正文核心结论",
          "issue": "80%效率提升缺少输入依据",
          "evidence": "现有资料只显示内容产量由每周10篇提升到16篇，不能直接等同于团队效率提升80%。",
          "action": "使用可验证的产量变化描述，或补充效率指标与计算依据。"
        }
      ],
      "factCheck": [],
      "aiToneRisks": [],
      "platformFit": [],
      "publishingRisks": [],
      "missingAssets": [],
      "humanConfirmation": [],
      "recommendedActions": [
        "修改标题中的80%效率提升",
        "删除或弱化‘任何公司都可以复制’的绝对化表述"
      ]
    },
    "assetPack": {
      "summary": {
        "ready": 0,
        "needsEdit": 1,
        "blocked": 0
      }
    },
    "skillEvidence": [
      {
        "skill": "article-publish-reviewer",
        "version": "0.1.0",
        "summary": "完成事实依据、标题和发布风险复核。"
      }
    ]
  }
}
```
