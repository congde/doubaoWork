#!/usr/bin/env node
/*
 * build_workbench.cjs — 按用户配置生成定制工作台
 * 用法：
 *   node build_workbench.cjs --brand "我的工作台" --field "AI × 心理学" --accent "#7aa2ff" --tasks "写文章,发朋友圈,做小程序" --projects "项目A,项目B" --out my.html
 * 未提供的参数保留模板默认值。脚本只改顶部 CONFIG，不触碰任何数据源/链接。
 */
const fs = require('fs');
const path = require('path');

const tplPath = path.join(__dirname, '..', 'assets', 'template', 'index.html');
let html = fs.readFileSync(tplPath, 'utf8');

function setStr(key, val){
  const re = new RegExp('(' + key + ':\\s*")([^"]*)(")');
  if (re.test(html)) html = html.replace(re, '$1' + val + '$3');
}
function setArr(key, arr){
  const re = new RegExp('(' + key + ':\\s*\\[)[\\s\\S]*?(\\])');
  if (re.test(html)) html = html.replace(re, '$1' + arr.map(s => '"' + s.replace(/"/g, '\\"') + '"').join(', ') + '$2');
}

const args = process.argv.slice(2);
const get = (name) => { const i = args.indexOf('--' + name); return i >= 0 ? args[i + 1] : null; };

const brand = get('brand');
const field = get('field');
const accent = get('accent');
const tasks = get('tasks');
const projects = get('projects');
const out = get('out') || 'workbench.html';

if (brand) setStr('brand', brand);
if (field) setStr('field', field);
if (accent) setStr('accent', accent);
if (tasks) setArr('fixedTasks', tasks.split(',').map(s => s.trim()).filter(Boolean));
if (projects) setArr('defaultProjects', projects.split(',').map(s => s.trim()).filter(Boolean));

fs.writeFileSync(out, html);
console.log('✅ 生成完毕：' + path.resolve(out));
console.log('   品牌=' + (brand || '默认') + '  领域=' + (field || '默认') + '  主色=' + (accent || '默认'));
if (tasks) console.log('   固定任务=' + tasks);
if (projects) console.log('   默认项目=' + projects);
