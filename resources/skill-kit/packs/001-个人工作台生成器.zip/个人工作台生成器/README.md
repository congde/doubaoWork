# 个人工作台生成器 workbench-generator

一句话把"个人专属工作台"封装成可复用的单文件网页，别人一键拿到，也能改成自己的领域。

## 能做什么

输入你的领域、风格、关键词，自动生成一套单文件 HTML 个人工作台：
- 左侧纵向导航 + 7 大功能页面（每日计划 / 项目 / 灵感记录 / 爆款选题 / AI 学习 / 审美学习 / 心理学学习）
- 毛玻璃拟态风格、卡片式布局
- 所有数据本地存储（localStorage），支持每日重置或累积
- 右下角"今日总览"悬浮图标，一屏看全七页完成情况

## 两种用法（任君挑选）

1. **生成器模式**：说"帮我生成我的工作台"，它会问你的领域、风格、关键词，现场长出一套属于你的工作台。
2. **模板库模式**：直接拿 `assets/template/index.html`，改顶部 `CONFIG` 几个字就是你的。

内置一份已配置好的示例（`assets/examples/ercheng-taotao/`），展示 AI × 心理学领域的成品长什么样。

## 安全说明

模板与示例均不含任何真实账号凭证、API key 或私有链接。所有外部数据接入一律使用"模拟数据框架 + 预留接口注释"，真实数据源由使用者自行配置。

## 文件结构

```
workbench-generator/
├── SKILL.md                      # 技能引导（双模式 + 安全边界）
├── references/
│   ├── workbench-spec.md         # 7 页面完整规格（来自原始需求提示词）
│   ├── design-guide.md           # 视觉规范
│   └── data-source-guide.md      # 数据源策略（模拟 + 预留接口）
├── assets/
│   ├── template/index.html       # 干净单文件模板
│   └── examples/ercheng-taotao/  # 示例工作台
└── scripts/build_workbench.cjs   # 参数化生成脚本
```

## 部署

单文件 HTML 双击即可打开；也可部署到静态托管（如 CloudStudio）以便手机访问、加桌面图标（PWA）。
