#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""短篇小说导语校验脚本。

用法:
    python validate_intro.py intro.txt              # 校验单个文件
    python validate_intro.py dir/                   # 校验目录下所有 .txt
    python validate_intro.py -                      # 从 stdin 读取
    python validate_intro.py intro.txt --min 60 --max 200

每个 .txt 文件视为一篇导语（或用单独分隔行 '---' 分隔多条）。
输出校验报告；发现问题退出码为 1，全部通过为 0。
"""

import argparse
import io
import os
import re
import sys

# ---------- 词表 ----------

# 广告法极限词 / 平台违规词（按需扩充）
FORBIDDEN_WORDS = [
    "最牛", "最强", "最好看", "第一名", "第一名作", "顶级", "绝无仅有",
    "100%", "百分之百", "必看", "不看后悔", "熬夜也要", "全网最",
    "点进来看", "点击领取", "点我", "关注我", "快来看", "赶紧戳",
]

# 导流/联系方式模式（正则）
LEAD_PATTERNS = [
    (r"(?:微信|weixin|wx|V信|扣扣|企鹅|qq|QQ)[:：\s]*[a-zA-Z0-9_-]{5,}", "疑似微信号/QQ导流"),
    (r"(?:公众号|粉丝群|书友群|交流群)[:：\s]*[a-zA-Z0-9\u4e00-\u9fff]{2,}", "疑似社群导流"),
    (r"1[3-9]\d{9}", "疑似手机号"),
]

# emoji / 特殊符号（平台易乱码）
EMOJI_RE = re.compile(
    "[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F000-\U0001F0FF"
    "\U0000FE00-\U0000FE0F\U0001F900-\U0001F9FF\u2B50\u2764]"
)

# markdown 残留
MARKDOWN_RE = re.compile(r"(\*\*|##+|```)")

# 半角标点（导语应使用全角中文标点）
HALFWIDTH_PUNCT_RE = re.compile(r"[,;:!?](?!\d)")


def check_intro(text: str, min_len: int, max_len: int) -> list:
    """校验单条导语，返回问题列表。"""
    issues = []
    # 去掉首尾空白后统计字数（不含空白符）
    compact = re.sub(r"\s+", "", text)
    n = len(compact)

    if n == 0:
        return ["内容为空"]
    if n < min_len:
        issues.append(f"字数偏少：{n} 字（建议 ≥{min_len}）")
    if n > max_len:
        issues.append(f"字数超标：{n} 字（建议 ≤{max_len}）")

    # 首句钩子检查：前 30 字内是否有冲突/悬念提示词（宽松启发式）
    first30 = compact[:30]
    hook_hints = ["离婚", "死了", "通缉", "背叛", "出轨", "真相", "秘密", "居然",
                  "竟然", "却", "直到", "第一次", "三年", "十年", "下跪", "逼我",
                  "偷", "抢", "报警", "重生", "替身", "隐藏", "身份"]
    if not any(h in first30 for h in hook_hints):
        issues.append(f"前30字未见明显冲突/悬念钩子：「{first30[:15]}…」")

    # 违禁词
    for w in FORBIDDEN_WORDS:
        if w in text:
            issues.append(f"含违规/极限词：{w}")

    # 导流
    for pat, desc in LEAD_PATTERNS:
        if re.search(pat, text):
            issues.append(desc)

    # emoji / 特殊符号
    m = EMOJI_RE.search(text)
    if m:
        issues.append(f"含 emoji/特殊符号：{m.group(0)!r}（部分平台乱码）")

    # markdown
    if MARKDOWN_RE.search(text):
        issues.append("含 markdown 语法残留（** / ## / ```）")

    # 半角标点
    hm = HALFWIDTH_PUNCT_RE.search(text)
    if hm:
        pos = hm.start()
        issues.append(f"含半角标点 {hm.group(0)!r}（建议改全角），位置：…{text[max(0, pos-8):pos+8]}…")

    # 段落数
    paras = [p for p in text.strip().splitlines() if p.strip()]
    if len(paras) > 3:
        issues.append(f"段落数 {len(paras)} 超过 3 段")

    return issues


def split_intros(raw: str) -> list:
    """按 '---' 分隔行拆分多条导语。"""
    parts = re.split(r"(?m)^\s*-{3,}\s*$", raw)
    intros = [p.strip() for p in parts if p.strip()]
    return intros if intros else [raw.strip()]


def load_texts(path: str) -> dict:
    """返回 {标签: 原始文本}。path 为 '-' 时读 stdin。"""
    if path == "-":
        return {"<stdin>": sys.stdin.read()}
    if os.path.isdir(path):
        result = {}
        for name in sorted(os.listdir(path)):
            if name.lower().endswith(".txt"):
                fp = os.path.join(path, name)
                with io.open(fp, "r", encoding="utf-8", errors="replace") as f:
                    result[name] = f.read()
        return result
    with io.open(path, "r", encoding="utf-8", errors="replace") as f:
        return {os.path.basename(path): f.read()}


def main() -> int:
    ap = argparse.ArgumentParser(description="短篇小说导语校验")
    ap.add_argument("path", help="导语 txt 文件 / 目录 / '-'（stdin）")
    ap.add_argument("--min", type=int, default=60, help="最小字数（默认60）")
    ap.add_argument("--max", type=int, default=200, help="最大字数（默认200）")
    args = ap.parse_args()

    sources = load_texts(args.path)
    if not sources:
        print("未找到可校验的内容（目录下需有 .txt 文件）")
        return 1

    total, failed = 0, 0
    for label, raw in sources.items():
        intros = split_intros(raw)
        for i, intro in enumerate(intros, 1):
            total += 1
            tag = f"{label}" if len(intros) == 1 else f"{label}#{i}"
            issues = check_intro(intro, args.min, args.max)
            n = len(re.sub(r"\s+", "", intro))
            if issues:
                failed += 1
                print(f"[FAIL] {tag}（{n}字）")
                for it in issues:
                    print(f"    - {it}")
            else:
                print(f"[PASS] {tag}（{n}字）")

    print(f"\n合计 {total} 条，通过 {total - failed}，问题 {failed}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
