#!/usr/bin/env python3
"""数据清洗：体检 → 安全清洗 → 清洗日志。零第三方依赖（标准库 csv）。

安全设计：只输出新文件，绝不改原文件；异常值只标记不删除。
"""
import argparse
import csv
import re
import statistics
from datetime import datetime
from pathlib import Path

DATE_PATTERNS = [
    (re.compile(r"^\d{4}/\d{1,2}/\d{1,2}$"), "%Y/%m/%d"),
    (re.compile(r"^\d{4}-\d{1,2}-\d{1,2}$"), "%Y-%m-%d"),
    (re.compile(r"^\d{1,2}/\d{1,2}/\d{4}$"), "%m/%d/%Y"),
    (re.compile(r"^\d{4}\.\d{1,2}\.\d{1,2}$"), "%Y.%m.%d"),
]


def sniff_types(rows, headers):
    """推断每列类型：numeric / date / text。"""
    info = {}
    for idx, h in enumerate(headers):
        vals = [r[idx] for r in rows if r[idx].strip()]
        n = len(vals)
        if not n:
            info[h] = {"type": "empty", "missing": len(rows)}
            continue
        num_ok = sum(1 for v in vals if re.fullmatch(r"[-￥¥$]?\s*-?\d[\d,，]*(\.\d+)?", v.strip()))
        date_ok = 0
        for v in vals:
            for pat, _ in DATE_PATTERNS:
                if pat.match(v.strip()):
                    date_ok += 1
                    break
        if num_ok / n > 0.9:
            t = "numeric"
        elif date_ok / n > 0.7:
            t = "date"
        else:
            t = "text"
        info[h] = {"type": t, "missing": len(rows) - n}
    return info


def normalize_date(v: str):
    for pat, fmt in DATE_PATTERNS:
        m = pat.match(v.strip())
        if m:
            return datetime.strptime(v.strip(), fmt).strftime("%Y-%m-%d"), fmt
    return v, None


def clean(input_path: Path):
    with open(input_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        headers = next(reader)
        rows = [r for r in reader if any(c.strip() for c in r)]

    log = []
    info = sniff_types(rows, headers)

    # 1) 整行去重
    seen, deduped = set(), []
    for r in rows:
        key = tuple(c.strip() for c in r)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)
    if len(deduped) < len(rows):
        log.append(("整行去重", len(rows) - len(deduped), "内容完全一致的行只保留一条"))
    rows = deduped

    # 2) 空白修剪 + 日期统一 + 文本数字标准化
    date_fixed = trim_fixed = num_fixed = 0
    date_example = None
    for r in rows:
        for i, h in enumerate(headers):
            if i >= len(r):
                continue
            raw = r[i]
            v = raw.strip()
            if v != raw:
                trim_fixed += 1
                r[i] = v
            if not v:
                continue
            if info[h]["type"] == "date":
                nv, fmt = normalize_date(v)
                if nv != v:
                    date_fixed += 1
                    date_example = date_example or (v, nv)
                    r[i] = nv
            elif info[h]["type"] == "numeric":
                nv = v
                if re.fullmatch(r"[-￥¥$]?\s*-?\d[\d,，]*(\.\d+)?", v):
                    nv = re.sub(r"[￥¥$\s，]", "", v).replace(",", "")
                    nv = nv.replace("--", "-") if nv.startswith("--") else nv
                if nv != v:
                    num_fixed += 1
                    r[i] = nv
    if trim_fixed:
        log.append(("空白修剪", trim_fixed, "去掉首尾多余空格/换行"))
    if date_fixed:
        log.append(("日期统一", date_fixed, f"多格式 → YYYY-MM-DD，示例：{date_example[0]} → {date_example[1]}"))
    if num_fixed:
        log.append(("数字标准化", num_fixed, "去除千分位逗号，统一为可计算数字"))

    # 3) 类别值归一（大小写/全半角差异导致的变体）
    for i, h in enumerate(headers):
        if info[h]["type"] != "text":
            continue
        vals = [r[i] for r in rows if i < len(r) and r[i]]
        if len(vals) < 10:
            continue
        canon = {}
        for v in set(vals):
            canon.setdefault(v.lower().replace("　", " "), v)
        variant = {v: c for v, c in ((v, canon[v.lower().replace('　', ' ')]) for v in set(vals)) if v != c}
        if variant:
            cnt = sum(1 for r in rows if i < len(r) and r[i] in variant)
            for r in rows:
                if i < len(r) and r[i] in variant:
                    r[i] = variant[r[i]]
            example = next(iter(variant.items()))
            log.append((f"类别归一（{h}）", cnt, f"{example[0]} → {example[1]} 等变体合并"))

    # 4) 数值列异常标记（IQR 规则，只标记不删）
    outlier_cols = []
    for i, h in enumerate(headers):
        if info[h]["type"] != "numeric":
            continue
        nums = []
        for r in rows:
            if i < len(r) and re.fullmatch(r"-?\d+(\.\d+)?", r[i] or ""):
                nums.append(float(r[i]))
        if len(nums) < 8:
            continue
        q = statistics.quantiles(nums, n=4)
        iqr = q[2] - q[0]
        lo, hi = q[0] - 3 * iqr, q[2] + 3 * iqr
        out = [(j, v) for j, v in enumerate(nums) if v < lo or v > hi]
        if out:
            outlier_cols.append((h, len(out), [v for _, v in out[:3]]))

    # 5) 缺失统计
    missing = [(h, info[h]["missing"]) for h in headers if info[h]["missing"]]

    return headers, rows, log, outlier_cols, missing, info


def main():
    ap = argparse.ArgumentParser(description="CSV 数据清洗（输出新文件，不改原文件）")
    ap.add_argument("input", nargs="?", help="输入 CSV 文件")
    ap.add_argument("--out", help="输出清洗后 CSV（默认 <原名>_cleaned.csv）")
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()

    if args.demo:
        skill_root = Path(__file__).resolve().parent.parent
        src = skill_root / "examples" / "dirty_demo.csv"
        src.parent.mkdir(parents=True, exist_ok=True)
        src.write_text(
            "订单号,下单日期,城市,金额,数量\n"
            "A001,2026/8/3,北京,\"1,280\",2\n"
            "A002,2026-08-04,上海 ,\"￥1,299\",1\n"
            "A002,2026-08-04,上海 ,\"￥1,299\",1\n"   # 整行重复
            "A003,2026.8.5,北京市,990,3\n"
            "A004,08/06/2026,深圳,690,\n"
            "A005,2026-08-07,杭州,450,1\n"
            "A006,2026-08-08,广州,320,5\n"
            "A007,2026/8/9,北京,199,2\n"
            "A008,2026-08-10,成都,99999,1\n"      # 异常值
            "A009,2026-08-11,武汉,150,10\n"
            "A010,2026-08-12,西安,88,4\n"
            "A011,2026-08-13,北京市,260,2\n"
            "A012,2026-08-14,深圳,540,3\n", encoding="utf-8")
        args.input, args.out = str(src), str(skill_root / "examples" / "dirty_demo_cleaned.csv")
    elif not args.input:
        ap.error("请提供 CSV 文件，或用 --demo 演示")

    headers, rows, log, outliers, missing, info = clean(Path(args.input))
    out = Path(args.out) if args.out else Path(args.input).with_name(Path(args.input).stem + "_cleaned.csv")

    with open(out, "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows([headers] + rows)

    report = [f"# 数据清洗日志（{Path(args.input).name} → {out.name}）",
              f"- 规模：{len(rows)} 行 × {len(headers)} 列（清洗后）", "",
              "## 已执行的清洗规则", "| 规则 | 影响行/值数 | 说明 |", "|---|---|---|"]
    report += [f"| {n} | {c} | {d} |" for n, c, d in log] or ["| （数据本身较干净，无需修复） | - | - |"]
    if outliers:
        report += ["", "## 异常值标记（IQR × 3，仅提示，未删除）"]
        report += [f"- {h}：{c} 个疑似异常，如 {vs}" for h, c, vs in outliers]
    if missing:
        report += ["", "## 缺失值分布"]
        report += [f"- {h}：{c} 个空值（建议按业务含义选择填充或删除）" for h, c in missing]
    report += ["", "## 待人工决策", "- 类别归一的映射是否符合业务口径（如 北京市→北京）",
               "- 异常值是录入错误还是真实大单，确认后再决定处理方式"]
    report_path = out.with_name(out.stem + "_report.md")
    report_path.write_text("\n".join(report), encoding="utf-8")

    print("\n".join(report))
    print(f"\n产出：{out}（清洗后数据）\n      {report_path}（清洗日志）")


if __name__ == "__main__":
    main()
