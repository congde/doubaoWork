# 使用与排错

## 常用命令

所有命令从 Skill 根目录运行：

```text
node scripts/wenyan.mjs status
node scripts/wenyan.mjs install
node scripts/wenyan.mjs credential
node scripts/wenyan.mjs themes
node scripts/wenyan.mjs render --file article.md --theme lapis --highlight solarized-light
node scripts/wenyan.mjs publish --file article.md --theme lapis --highlight solarized-light
```

可选参数：

- `--account <AppID或别名>`：选择 Wenyan 凭据存储中的公众号账号。
- `--env-file <path>`：显式加载 `.env` 文件。
- `--no-mac-style`：关闭 Mac 风格代码块。
- `--no-footnote`：关闭链接转脚注。
- `--custom-theme <path>`：使用自定义 CSS 主题。
- `--server <https-url>`、`--api-key-file <path>`：通过用户指定的 Wenyan 服务发布。
- `--proxy <url>`：使用用户明确指定的代理。

## Markdown 检查

推荐 frontmatter：

```markdown
---
title: 文章标题
cover: ./assets/cover.jpg
---
```

不同 Wenyan 版本对封面推断规则可能变化，不要把旧版“封面必填”的经验写死。若 CLI 报封面错误，再要求用户指定 `cover`。

## 凭据

首选：

```text
wenyan credential --set
```

该命令交互式保存 AppID 和 AppSecret；配置多账号时可填写别名，发布时使用 `--account` 选择。

备选环境变量：

- `WECHAT_APP_ID`
- `WECHAT_APP_SECRET`

不得输出变量值。`status` 只汇报变量是否存在，或凭据文件是否存在。

## 错误分类

- `wenyan-cli-not-installed`：先征得安装许可，再运行 `install`。
- `credentials-missing`：运行 `credential`；不要让用户把密钥发进聊天。
- `ip not in whitelist`：指导用户在公众号后台将当前出口 IP 加入白名单。
- `title` / `cover` 错误：修正 Markdown frontmatter 或图片路径。
- 图片读取失败：核对相对路径、文件权限、网络 URL 和文件格式。
- 401/403：区分凭据无效、账号权限不足、IP 白名单和远程服务 API Key 错误。
- 网络超时：保留原文件与参数，先检查网络；不要无上限重试以免生成重复草稿。

## 兼容性

适配脚本通过 Node.js 调用 Wenyan CLI，避免依赖 Bash、`source`、`grep` 和固定的 `/Users/...` 路径。Windows 使用 npm 生成的 `wenyan.cmd` 所在目录解析 CLI 入口，macOS/Linux 使用 PATH 中的 `wenyan`。
