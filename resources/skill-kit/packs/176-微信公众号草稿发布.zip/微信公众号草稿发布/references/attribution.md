# 来源说明

- 原工作流：`0731coderlee-sudo/wechat-publisher`
- 原工作流地址：https://github.com/0731coderlee-sudo/wechat-publisher
- 原工作流许可证：MIT
- 底层 CLI：`caol64/wenyan-cli`
- 底层 CLI 地址：https://github.com/caol64/wenyan-cli
- 底层 CLI 许可证：Apache License 2.0
- 破局适配：Windows/macOS/Linux 跨平台启动、显式依赖安装、Wenyan 原生凭据存储、发布边界与脱敏错误处理。

商城作者应署名 `0731coderlee-sudo`；商品说明中注明底层由 `caol64/wenyan-cli` 提供。若商城作者字段只能绑定提交账号，审核通过后由管理员将作者资料改为原作者，并标记“外部开源”。
