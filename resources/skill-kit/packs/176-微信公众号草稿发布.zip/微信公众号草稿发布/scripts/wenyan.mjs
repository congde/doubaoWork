#!/usr/bin/env node

import { access, constants, realpath } from "node:fs/promises";
import { delimiter, dirname, isAbsolute, join, resolve } from "node:path";
import { spawn } from "node:child_process";
import process from "node:process";

const PINNED_VERSION = "2.0.11";
const HELP = `用法：
  node scripts/wenyan.mjs status
  node scripts/wenyan.mjs install
  node scripts/wenyan.mjs credential
  node scripts/wenyan.mjs themes
  node scripts/wenyan.mjs render --file <markdown> [选项]
  node scripts/wenyan.mjs publish --file <markdown> [选项]

选项：
  --theme <id>            排版主题，默认 default
  --highlight <id>        代码高亮主题，默认 solarized-light
  --custom-theme <path>   自定义主题 CSS
  --account <id-or-alias> 公众号 AppID 或凭据别名
  --env-file <path>       显式加载 .env 文件
  --server <https-url>    用户指定的 Wenyan 发布服务
  --api-key-file <path>   发布服务 API Key 文件
  --proxy <url>           用户指定的代理
  --no-mac-style          关闭 Mac 风格代码块
  --no-footnote           关闭链接转脚注
`;

function fail(message, code = 1) {
  console.error(message);
  process.exitCode = code;
}

async function exists(path) {
  try {
    await access(path, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

function pathEntries() {
  return (process.env.PATH ?? "").split(delimiter).filter(Boolean);
}

async function resolveWenyan() {
  if (process.platform === "win32") {
    for (const binDir of pathEntries()) {
      const shim = join(binDir, "wenyan.cmd");
      const cli = join(binDir, "node_modules", "@wenyan-md", "cli", "dist", "cli.js");
      if ((await exists(shim)) && (await exists(cli))) {
        return { command: process.execPath, prefix: [cli], display: shim };
      }
    }
    return null;
  }

  for (const binDir of pathEntries()) {
    const command = join(binDir, "wenyan");
    if (!(await exists(command))) continue;
    try {
      const target = await realpath(command);
      if (target.endsWith(".js")) {
        return { command: process.execPath, prefix: [target], display: command };
      }
    } catch {
      // Fall back to the executable from PATH.
    }
    return { command, prefix: [], display: command };
  }
  return null;
}

function run(command, args, { capture = false } = {}) {
  return new Promise((resolveRun, reject) => {
    const child = spawn(command, args, {
      stdio: capture ? ["ignore", "pipe", "pipe"] : "inherit",
      windowsHide: true,
      shell: false,
    });
    let stdout = "";
    let stderr = "";
    if (capture) {
      child.stdout.setEncoding("utf8");
      child.stderr.setEncoding("utf8");
      child.stdout.on("data", (chunk) => { stdout += chunk; });
      child.stderr.on("data", (chunk) => { stderr += chunk; });
    }
    child.once("error", reject);
    child.once("close", (code, signal) => {
      resolveRun({ code: code ?? 1, signal, stdout: stdout.trim(), stderr: stderr.trim() });
    });
  });
}

async function runWenyan(args, options) {
  const resolved = await resolveWenyan();
  if (!resolved) {
    throw new Error("wenyan-cli-not-installed：未找到 @wenyan-md/cli。请先明确同意安装，再运行 install。");
  }
  return run(resolved.command, [...resolved.prefix, ...args], options);
}

function takeOption(args, index, name) {
  const value = args[index + 1];
  if (!value || value.startsWith("--")) {
    throw new Error(`${name} 缺少参数值。`);
  }
  return value;
}

function parseContentArgs(args) {
  const forwarded = [];
  let input = null;
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    switch (arg) {
      case "--file": {
        const value = takeOption(args, index, arg);
        input = value;
        forwarded.push("--file", value);
        index += 1;
        break;
      }
      case "--theme":
        forwarded.push("--theme", takeOption(args, index, arg));
        index += 1;
        break;
      case "--highlight":
        forwarded.push("--highlight", takeOption(args, index, arg));
        index += 1;
        break;
      case "--custom-theme":
        forwarded.push("--custom-theme", takeOption(args, index, arg));
        index += 1;
        break;
      case "--account":
        forwarded.push("--app-id", takeOption(args, index, arg));
        index += 1;
        break;
      case "--env-file":
      case "--server":
      case "--api-key-file":
      case "--proxy":
        forwarded.push(arg, takeOption(args, index, arg));
        index += 1;
        break;
      case "--no-mac-style":
      case "--no-footnote":
        forwarded.push(arg);
        break;
      default:
        throw new Error(`不支持的参数：${arg}`);
    }
  }
  if (!input) throw new Error("必须提供 --file <Markdown 路径或 URL>。");
  return { input, forwarded };
}

async function assertInput(input) {
  if (/^https?:\/\//iu.test(input)) return;
  const path = isAbsolute(input) ? input : resolve(process.cwd(), input);
  if (!(await exists(path))) throw new Error(`Markdown 文件不存在：${path}`);
}

async function status() {
  const wenyan = await resolveWenyan();
  let version = null;
  let credentialLocation = null;
  let credentialFileExists = false;
  if (wenyan) {
    const versionResult = await run(wenyan.command, [...wenyan.prefix, "--version"], { capture: true });
    if (versionResult.code === 0) version = versionResult.stdout;
    const credentialResult = await run(wenyan.command, [...wenyan.prefix, "credential", "--location"], { capture: true });
    if (credentialResult.code === 0 && credentialResult.stdout) {
      credentialLocation = credentialResult.stdout.split(/\r?\n/u).at(-1)?.trim() ?? null;
      credentialFileExists = credentialLocation ? await exists(credentialLocation) : false;
    }
  }
  console.log(JSON.stringify({
    node: process.version,
    platform: process.platform,
    wenyanInstalled: Boolean(wenyan),
    wenyanVersion: version,
    credentials: {
      storedCredentialFile: credentialFileExists,
      environmentAppId: Boolean(process.env.WECHAT_APP_ID),
      environmentAppSecret: Boolean(process.env.WECHAT_APP_SECRET),
    },
  }, null, 2));
}

async function install() {
  const existing = await resolveWenyan();
  if (existing) {
    const result = await run(existing.command, [...existing.prefix, "--version"], { capture: true });
    console.log(`Wenyan CLI 已安装：${result.stdout || "版本未知"}`);
    return;
  }
  const packageSpec = `@wenyan-md/cli@${PINNED_VERSION}`;
  if (process.platform === "win32") {
    const npmCmd = pathEntries().map((entry) => join(entry, "npm.cmd")).find((candidate) => requireExistsSync(candidate));
    if (!npmCmd) throw new Error("未找到 npm.cmd，请先安装 Node.js（含 npm）。");
    const comspec = process.env.ComSpec ?? "cmd.exe";
    const commandLine = `\"${npmCmd.replaceAll('"', '""')}\" install -g ${packageSpec}`;
    const result = await run(comspec, ["/d", "/s", "/c", commandLine]);
    if (result.code !== 0) throw new Error(`npm 安装失败，退出码 ${result.code}。`);
  } else {
    const result = await run("npm", ["install", "-g", packageSpec]);
    if (result.code !== 0) throw new Error(`npm 安装失败，退出码 ${result.code}。`);
  }
  const installed = await resolveWenyan();
  if (!installed) throw new Error("npm 已结束，但仍未找到 wenyan 命令。请检查 npm 全局 bin 是否在 PATH 中。");
  const result = await run(installed.command, [...installed.prefix, "--version"], { capture: true });
  console.log(`Wenyan CLI 安装完成：${result.stdout || PINNED_VERSION}`);
}

function requireExistsSync(path) {
  try {
    return Boolean(process.getBuiltinModule("node:fs").existsSync(path));
  } catch {
    return false;
  }
}

async function main() {
  const [command, ...args] = process.argv.slice(2);
  if (!command || command === "help" || command === "--help") {
    console.log(HELP);
    return;
  }
  if (command === "status") return status();
  if (command === "install") return install();
  if (command === "credential") {
    const result = await runWenyan(["credential", "--set"]);
    if (result.code !== 0) throw new Error(`凭据配置失败，退出码 ${result.code}。`);
    return;
  }
  if (command === "themes") {
    const result = await runWenyan(["theme", "--list"]);
    if (result.code !== 0) throw new Error(`主题查询失败，退出码 ${result.code}。`);
    return;
  }
  if (command === "render" || command === "publish") {
    const { input, forwarded } = parseContentArgs(args);
    await assertInput(input);
    const result = await runWenyan([command, ...forwarded]);
    if (result.code !== 0) throw new Error(`${command === "publish" ? "草稿发布" : "排版预览"}失败，退出码 ${result.code}。`);
    return;
  }
  throw new Error(`未知命令：${command}\n\n${HELP}`);
}

main().catch((error) => {
  fail(error instanceof Error ? error.message : String(error));
});
