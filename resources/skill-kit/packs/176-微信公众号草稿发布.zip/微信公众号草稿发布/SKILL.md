---
name: wechat-publisher
description: 将 Markdown 文章排版并发布到微信公众号草稿箱。用户提到公众号文章、微信公众号草稿、Markdown
  排版、文颜/Wenyan、主题或代码高亮、上传文章图片、检查公众号发布条件时使用；只创建草稿，不执行群发。
---

# 微信公众号草稿发布

使用 `@wenyan-md/cli` 把 Markdown 渲染为微信公众号格式，并写入公众号草稿箱。适用于 Windows、macOS 和 Linux；不要沿用原版 Skill 中的 OpenClaw 固定目录、Bash 脚本或明文凭据读取方式。

## 路由

根据用户意图选择最短路径：

1. 查询是否可用或排查环境：运行 `node scripts/wenyan.mjs status`。
2. 明确要求安装：运行 `node scripts/wenyan.mjs install`。不得在发布过程中静默安装。
3. 配置公众号凭据：运行 `node scripts/wenyan.mjs credential`，在交互式终端输入；不得让用户在聊天中发送 AppSecret。
4. 查看主题：运行 `node scripts/wenyan.mjs themes`。
5. 预览排版：运行 `node scripts/wenyan.mjs render --file <markdown>`，将 HTML 输出写入用户指定文件或临时文件后打开。
6. 发布草稿：先完成下方检查，再运行 `node scripts/wenyan.mjs publish --file <markdown>`。

完整参数与错误处理见 [使用与排错](references/usage.md)。

## 发布流程

### 1. 核对输入

- 只接受用户明确指定的 Markdown 文件或 URL。
- 本地文件必须存在，网络 URL 必须是 `http` 或 `https`。
- 检查 frontmatter，至少确认文章标题；封面可由 `cover` 指定，也可按 Wenyan 当前规则从正文图片推断。
- 相对图片路径以 Markdown 文件目录为基准。发布前检查引用的本地图片存在。

### 2. 检查运行条件

运行：

```text
node scripts/wenyan.mjs status
```

若缺少 Node.js，说明缺失项和官方下载入口，不伪造已安装状态。若仅缺少 Wenyan CLI，只有在用户明确要求安装或已授权完成发布环境配置时才运行安装命令。

凭据优先使用 Wenyan 自带的安全凭据存储：

```text
node scripts/wenyan.mjs credential
```

也可使用进程环境中的 `WECHAT_APP_ID`、`WECHAT_APP_SECRET`，或由用户明确指定的 `.env` 文件。不要读取聊天记录、Markdown、TOOLS.md 或项目源码来猜测密钥；任何输出都不得回显 AppSecret。

### 3. 预览与发布

用户只要求排版或预览时，运行 `render`，不要创建公众号草稿。

用户明确要求发布到草稿箱时，说明目标文件、主题和目标公众号（若选择了账号别名），然后遵循当前访问模式执行。命令示例：

```text
node scripts/wenyan.mjs publish --file article.md --theme lapis --highlight solarized-light
```

发布成功必须以 CLI 返回成功和 Media ID 为准。不得把“已开始”“已渲染”表述成“已发布”。发布失败时保留原文，不自动重复创建草稿；先按错误类型修复再重试。

### 4. 交付

返回：

- 草稿是否创建成功；
- 文章标题、主题和代码高亮主题；
- CLI 返回的 Media ID（如有）；
- 微信公众平台草稿箱入口；
- 尚需用户处理的 IP 白名单、封面或凭据问题。

## 边界

- 仅创建微信公众号草稿，不群发、不发表、不删除历史草稿。
- 不绕过公众号权限、IP 白名单或微信平台限制。
- 不自动安装其他 Agent，不修改 Codex、Claude Code、Hermes、OpenClaw 等配置。
- 不采集浏览器 Cookie，不把 AppID、AppSecret、Access Token 写入文章或回显到对话。
- 自定义服务器和代理仅在用户明确提供并授权时使用。

## 来源与署名

本适配版基于 `0731coderlee-sudo/wechat-publisher` 的工作流重新实现；底层使用 `caol64/wenyan-cli`。原包装层采用 MIT License，Wenyan CLI 采用 Apache License 2.0。破局 Agent 负责跨平台适配、权限边界与凭据安全加固，不替代原作者署名。详见 [来源说明](references/attribution.md)。
