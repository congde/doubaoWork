#!/usr/bin/env python3
"""按平台计算回复效果比例，只使用显式提供的页面可见数据。"""

from __future__ import annotations

import argparse
import json
from collections.abc import Mapping
from typing import Any


PLATFORM_ALIASES = {
    "x": "X/Twitter",
    "twitter": "X/Twitter",
    "reddit": "Reddit",
    "product-hunt": "Product Hunt",
    "producthunt": "Product Hunt",
    "ph": "Product Hunt",
}


def parse_object(value: str, label: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"{label}不是有效 JSON：{exc}") from exc
    if not isinstance(parsed, dict):
        raise SystemExit(f"{label}必须是 JSON 对象")
    return parsed


def number(data: Mapping[str, Any], *keys: str) -> float | None:
    for key in keys:
        value = data.get(key)
        if value is None:
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise SystemExit(f"字段 {key} 必须是数字或 null")
        return float(value)
    return None


def add_ratio(
    ratios: dict[str, dict[str, Any]],
    notes: list[str],
    name: str,
    numerator: float | None,
    denominator: float | None,
) -> None:
    if numerator is None:
        notes.append(f"{name}不可计算：分子未显示")
        return
    if denominator is None:
        notes.append(f"{name}不可计算：分母未显示")
        return
    if denominator <= 0:
        notes.append(f"{name}不可计算：分母小于或等于零")
        return
    value = numerator / denominator
    ratios[name] = {
        "小数": round(value, 6),
        "百分比": f"{value * 100:.2f}%",
        "分子": numerator,
        "分母": denominator,
    }


def x_metrics(
    mine: Mapping[str, Any], best: Mapping[str, Any]
) -> tuple[dict[str, Any], list[str]]:
    ratios: dict[str, dict[str, Any]] = {}
    notes: list[str] = []
    views = number(mine, "views", "浏览量")
    likes = number(mine, "likes", "点赞数")
    replies = number(mine, "replies", "comments", "回复数", "评论数")
    reposts = number(mine, "reposts", "retweets", "转帖数", "转发数")
    bookmarks = number(mine, "bookmarks", "书签数", "收藏数")

    add_ratio(ratios, notes, "点赞浏览比", likes, views)
    add_ratio(ratios, notes, "回复浏览比", replies, views)
    add_ratio(ratios, notes, "转帖浏览比", reposts, views)
    add_ratio(ratios, notes, "收藏浏览比", bookmarks, views)

    visible_parts = {
        "点赞": likes,
        "回复": replies,
        "转帖": reposts,
        "书签": bookmarks,
    }
    included = {key: value for key, value in visible_parts.items() if value is not None}
    if included:
        add_ratio(ratios, notes, "总互动浏览比", sum(included.values()), views)
        notes.append(f"总互动口径：{'+'.join(included.keys())}")
    else:
        notes.append("总互动浏览比不可计算：互动指标均未显示")

    add_ratio(
        ratios,
        notes,
        "相对最佳点赞比",
        likes,
        number(best, "likes", "点赞数"),
    )
    add_ratio(
        ratios,
        notes,
        "相对最佳讨论比",
        replies,
        number(best, "replies", "comments", "回复数", "评论数"),
    )
    return ratios, notes


def reddit_metrics(
    mine: Mapping[str, Any], best: Mapping[str, Any]
) -> tuple[dict[str, Any], list[str]]:
    ratios: dict[str, dict[str, Any]] = {}
    notes = ["Reddit 通常不显示单条评论浏览量，不计算浏览相关比例"]
    score = number(mine, "score", "得分")
    replies = number(mine, "replies", "comments", "子回复数", "评论数")
    add_ratio(
        ratios,
        notes,
        "相对最佳得分比",
        score,
        number(best, "score", "得分"),
    )
    add_ratio(
        ratios,
        notes,
        "相对最佳讨论比",
        replies,
        number(best, "replies", "comments", "子回复数", "评论数"),
    )
    return ratios, notes


def product_hunt_metrics(
    mine: Mapping[str, Any], best: Mapping[str, Any]
) -> tuple[dict[str, Any], list[str]]:
    ratios: dict[str, dict[str, Any]] = {}
    notes = ["Product Hunt 通常不显示单条评论浏览量，不计算浏览相关比例"]
    upvotes = number(mine, "upvotes", "likes", "点赞数", "Upvote")
    replies = number(mine, "replies", "comments", "子回复数", "评论数")
    add_ratio(
        ratios,
        notes,
        "相对最佳点赞比",
        upvotes,
        number(best, "upvotes", "likes", "点赞数", "Upvote"),
    )
    add_ratio(
        ratios,
        notes,
        "相对最佳讨论比",
        replies,
        number(best, "replies", "comments", "子回复数", "评论数"),
    )
    if "maker_replied" in mine or "Maker回应" in mine:
        maker_replied = mine.get("maker_replied", mine.get("Maker回应"))
        if not isinstance(maker_replied, bool):
            raise SystemExit("字段 maker_replied / Maker回应 必须是 true 或 false")
        notes.append(f"Maker 是否回应：{'是' if maker_replied else '否'}")
    return ratios, notes


def main() -> int:
    parser = argparse.ArgumentParser(
        description="根据页面可见数据计算 X、Reddit 或 Product Hunt 回复效果比例"
    )
    parser.add_argument(
        "--platform",
        required=True,
        choices=sorted(PLATFORM_ALIASES),
        help="平台：x、reddit 或 product-hunt",
    )
    parser.add_argument("--mine", required=True, help="我的回复指标 JSON")
    parser.add_argument("--best", default="{}", help="同帖最佳回复指标 JSON")
    args = parser.parse_args()

    mine = parse_object(args.mine, "--mine")
    best = parse_object(args.best, "--best")
    platform = PLATFORM_ALIASES[args.platform]

    if platform == "X/Twitter":
        ratios, notes = x_metrics(mine, best)
    elif platform == "Reddit":
        ratios, notes = reddit_metrics(mine, best)
    else:
        ratios, notes = product_hunt_metrics(mine, best)

    print(
        json.dumps(
            {
                "平台": platform,
                "我的原始数据": mine,
                "最佳回复原始数据": best,
                "计算结果": ratios,
                "说明": notes,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
