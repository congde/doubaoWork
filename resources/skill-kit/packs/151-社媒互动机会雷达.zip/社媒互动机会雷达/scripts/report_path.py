#!/usr/bin/env python3
"""按本地时间生成不会覆盖历史文件的报告路径。"""

from __future__ import annotations

import argparse
import time
from datetime import datetime
from pathlib import Path


DEFAULT_DIRECTORY = Path.cwd() / "社媒回复报告"
TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="输出下一份可用的社媒回复机会报告路径。"
    )
    parser.add_argument(
        "--directory",
        type=Path,
        default=DEFAULT_DIRECTORY,
        help="报告目录；默认在当前目录下创建“社媒回复报告”。",
    )
    parser.add_argument(
        "--timestamp",
        help="供测试使用的固定本地时间，格式为 YYYY-MM-DD HH:MM:SS。",
    )
    return parser.parse_args()


def report_path(directory: Path, moment: datetime) -> Path:
    filename = f"社媒回复机会_{moment.strftime(TIMESTAMP_FORMAT)}.md"
    return directory / filename


def main() -> int:
    args = parse_args()
    directory = args.directory.expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True)

    if args.timestamp:
        moment = datetime.strptime(args.timestamp, TIMESTAMP_FORMAT)
        candidate = report_path(directory, moment)
        if candidate.exists():
            raise SystemExit(f"拒绝覆盖已经存在的报告：{candidate}")
        print(candidate)
        return 0

    while True:
        candidate = report_path(directory, datetime.now().astimezone())
        if not candidate.exists():
            print(candidate)
            return 0
        time.sleep(0.1)


if __name__ == "__main__":
    raise SystemExit(main())
