#!/usr/bin/env python3
"""规范化比较建议回复和页面可见回复，辅助人工确认匹配。"""

from __future__ import annotations

import argparse
import json
import re
import unicodedata
from difflib import SequenceMatcher


MARKDOWN_LINK = re.compile(r"\[([^\]]+)\]\([^)]+\)")
NON_WORD = re.compile(r"[^\w\u3400-\u9fff]+", re.UNICODE)


def normalize(text: str) -> str:
    value = unicodedata.normalize("NFKC", text).casefold()
    value = MARKDOWN_LINK.sub(r"\1", value)
    value = NON_WORD.sub("", value)
    return value


def main() -> int:
    parser = argparse.ArgumentParser(
        description="比较两段回复文本；输出仅用于辅助，最终必须核验账号和上下文"
    )
    parser.add_argument("--expected", required=True, help="记录中的建议或实际回复")
    parser.add_argument("--actual", required=True, help="页面中读取到的候选回复")
    args = parser.parse_args()

    expected = normalize(args.expected)
    actual = normalize(args.actual)
    if not expected or not actual:
        raise SystemExit("规范化后的文本不能为空")

    similarity = SequenceMatcher(None, expected, actual).ratio()
    if expected == actual:
        status = "规范化文本完全一致"
    elif similarity >= 0.9:
        status = "高度相似，必须结合当前登录账号和上下文人工确认"
    elif similarity >= 0.75:
        status = "部分相似，标记为匹配不确定"
    else:
        status = "不匹配"

    print(
        json.dumps(
            {
                "状态": status,
                "相似度": round(similarity, 4),
                "规范化建议长度": len(expected),
                "规范化页面回复长度": len(actual),
                "提醒": "相似度不能替代作者账号、原帖上下文和回复链接核验",
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
