#!/usr/bin/env python3
"""随机生成本次时间线与搜索入口的候选采样比例。"""

from __future__ import annotations

import json
import secrets


SOURCE_RATIOS = ((3, 7), (4, 6), (5, 5), (6, 4), (7, 3))


def main() -> int:
    timeline_parts, search_parts = secrets.choice(SOURCE_RATIOS)
    result = {
        "比例": f"{timeline_parts}:{search_parts}",
        "时间线份数": timeline_parts,
        "搜索份数": search_parts,
        "时间线占比": timeline_parts * 10,
        "搜索占比": search_parts * 10,
    }
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
