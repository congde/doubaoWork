# -*- coding: utf-8 -*-
"""
split_novel.py — 整本小说 txt 批量切分章节 + 按平台规范导出

用法示例:
  python split_novel.py 小说.txt                        # 默认导出到 ./novel_output/
  python split_novel.py 小说.txt -o 输出目录 --platform fanqie
  python split_novel.py 小说.txt --pattern "第[一二三]章.*" --dry-run

输出:
  <outdir>/chapters/0001_第1章_标题.txt   每章一个文件, 编号保证上传顺序
  <outdir>/manifest.json                 章节清单(标题/字数/文件名/序号)
  <outdir>/deploy_report.md              部署检查报告(字数异常/疑似切分错误)
"""
import argparse
import json
import re
import sys
from pathlib import Path

# 章节标题正则(每条须为整行匹配并含一个捕获组, 组合后同时识别各类标题,
# 保证「第X章...番外」「楔子...第X章」等混排结构都能切出)
DEFAULT_PATTERNS = [
    r"^\s*(第\s*[0-9０-９零〇一二三四五六七八九十百千万两]+\s*[章節节回卷集部篇幕]\s*[^\n]{0,30})\s*$",
    r"^\s*((?:序章|序言|楔子|引子|前言|后记|尾声|终章|番外[^\n]{0,20}|完本感言)[^\n]{0,20})\s*$",
    r"^\s*(Chapter\s+\d+[^\n]{0,30})\s*$",
    r"^\s*(\d{1,4}[、.．]\s*[^\n]{1,30})\s*$",
]

# 各平台导出规范: 文件命名模板 / 正文要求
PLATFORMS = {
    "generic":  {"name_tpl": "{idx:04d}_{title}.txt", "min_words": 300,  "max_words": 20000},
    "fanqie":   {"name_tpl": "{idx:04d}_{title}.txt", "min_words": 500,  "max_words": 6000},   # 番茄小说
    "qidian":   {"name_tpl": "{idx:04d}_{title}.txt", "min_words": 1000, "max_words": 8000},   # 起点中文网
    "jjwxc":    {"name_tpl": "{idx:04d}_{title}.txt", "min_words": 1000, "max_words": 30000},  # 晋江文学城
    "qimao":    {"name_tpl": "{idx:04d}_{title}.txt", "min_words": 500,  "max_words": 6000},   # 七猫
}

TITLE_MAX_LEN = 30          # 标题最长保留字符(各平台普遍上限)
ILLEGAL_FN = re.compile(r'[\\/:*?"<>|\r\n\t]')  # 文件名非法字符


def read_text_auto(path: Path) -> str:
    """自动探测编码读取整本 txt (GBK 优先级兜底)。"""
    raw = path.read_bytes()
    # 去 BOM
    for enc in ("utf-8-sig", "utf-8", "gb18030", "big5"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    raise SystemExit(f"[错误] 无法解码文件 {path}，请手动转换为 UTF-8 后重试")


def split_chapters(text: str, patterns):
    """将所有标题正则组合为一条(整行锚定), 一次识别全部章节标题并切分。
    返回 [(title, body)] 列表; 无有效结构时返回 None。"""
    combined = re.compile("|".join(f"(?:{p})" for p in patterns), re.MULTILINE)
    matches = [m for m in combined.finditer(text) if m.group(0).strip()]
    # 至少 2 个标题且标题行总长不超过全文的 5%, 否则视为误判
    if len(matches) < 2:
        return None
    title_chars = sum(len(m.group(0)) for m in matches)
    if title_chars > len(text) * 0.05:
        return None
    chapters = []
    # 标题前的内容作为"正文开头"(常是简介/设定), 不足 50 字则并入第一章
    head = text[: matches[0].start()].strip()
    for i, m in enumerate(matches):
        title = m.group(1).strip() if m.group(1) else m.group(0).strip()
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        body = text[start:end].strip()
        if i == 0 and head and len(head) >= 50:
            chapters.append(("作品简介（正文前内容）", head))
        chapters.append((title, body))
    return chapters


def clean_title(title: str, idx_fallback: int) -> str:
    t = ILLEGAL_FN.sub("_", title).strip().strip("　 ")
    t = re.sub(r"\s+", " ", t)
    if len(t) > TITLE_MAX_LEN:
        t = t[:TITLE_MAX_LEN]
    return t or f"第{idx_fallback}节"


def count_words(body: str) -> int:
    """中文按字计数(去空白), 兼容英文单词。"""
    body2 = re.sub(r"\s+", "", body)
    return len(body2)


def main():
    ap = argparse.ArgumentParser(description="整本小说批量切章导出")
    ap.add_argument("input", help="整本小说 txt 路径")
    ap.add_argument("-o", "--outdir", default=None, help="输出目录, 默认 ./novel_output")
    ap.add_argument("--platform", default="generic", choices=list(PLATFORMS),
                    help="目标平台规范 (默认 generic)")
    ap.add_argument("--pattern", default=None, help="自定义章节标题正则(覆盖内置)")
    ap.add_argument("--dry-run", action="store_true", help="只预览切分结果, 不写文件")
    args = ap.parse_args()

    src = Path(args.input)
    if not src.is_file():
        raise SystemExit(f"[错误] 找不到文件: {src}")

    spec = PLATFORMS[args.platform]
    outdir = Path(args.outdir) if args.outdir else Path("novel_output")
    patterns = [args.pattern] if args.pattern else DEFAULT_PATTERNS
    text = read_text_auto(src)
    chapters = split_chapters(text, patterns)
    if not chapters:
        raise SystemExit(
            "[错误] 未识别出章节结构。请用 --pattern 传入该书的章节标题正则，例如:\n"
            '  --pattern "^\\s*(卷[一二三四五六七八九十]+[^\n]{0,20})\\s*$"'
        )

    if args.dry_run:
        print(f"[预览] 共识别 {len(chapters)} 章 (platform={args.platform}, dry-run 不写文件)")
        for i, (title, body) in enumerate(chapters[:20], 1):
            print(f"  {i:4d}. {title}  ({count_words(body)} 字)")
        if len(chapters) > 20:
            print(f"  ... 其余 {len(chapters) - 20} 章省略")
        return

    ch_dir = outdir / "chapters"
    ch_dir.mkdir(parents=True, exist_ok=True)

    manifest, warnings = [], []
    for i, (title, body) in enumerate(chapters, 1):
        title_clean = clean_title(title, i)
        words = count_words(body)
        fname = spec["name_tpl"].format(idx=i, title=title_clean)
        (ch_dir / fname).write_text(body + "\n", encoding="utf-8")
        manifest.append({"index": i, "title": title_clean, "file": fname, "words": words})
        if words < spec["min_words"]:
            warnings.append(f"第{i}章「{title_clean}」仅 {words} 字, 低于 {args.platform} 建议下限 {spec['min_words']} 字")
        elif words > spec["max_words"]:
            warnings.append(f"第{i}章「{title_clean}」{words} 字, 超过 {args.platform} 建议上限 {spec['max_words']} 字, 建议拆分")
        if words == 0:
            warnings.append(f"第{i}章「{title_clean}」正文为空, 可能是误切的标题行")

    (outdir / "manifest.json").write_text(
        json.dumps({"source": src.name, "platform": args.platform,
                    "total_chapters": len(manifest),
                    "total_words": sum(m["words"] for m in manifest),
                    "chapters": manifest}, ensure_ascii=False, indent=2),
        encoding="utf-8")

    lines = [f"# 部署检查报告 — {src.name}",
             f"- 目标平台: {args.platform}",
             f"- 总章数: {len(manifest)}",
             f"- 总字数: {sum(m['words'] for m in manifest):,}",
             f"- 输出目录: {ch_dir}",
             "", "## 待人工确认项" if warnings else "## 无异常, 可直接批量上传"]
    lines += [f"- {w}" for w in warnings] if warnings else []
    (outdir / "deploy_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"[完成] {len(manifest)} 章 -> {ch_dir}")
    print(f"       清单: {outdir / 'manifest.json'}")
    print(f"       报告: {outdir / 'deploy_report.md'}")
    if warnings:
        print(f"[注意] {len(warnings)} 项待确认, 详见 deploy_report.md")


if __name__ == "__main__":
    sys.exit(main())
