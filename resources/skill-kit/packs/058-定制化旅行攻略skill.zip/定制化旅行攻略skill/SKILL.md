---
name: travel-guide-planner
description: Build customized travel itineraries by progressively collecting key constraints, checking current season/traffic/policy facts, and producing a practical guide with route, lodging, meals, timing, attractions, photo spots, and checklists.
---

# Travel Guide Planner

Use this skill when the user wants a customized travel route, road-trip plan, destination攻略, itinerary table, Feishu/Markdown travel document, or a revision of an existing trip plan. It is especially useful when the route depends on dates, season, road openings, reservation rules, local policies, vehicle constraints, or source material such as screenshots, videos, Xiaohongshu posts, maps, or an existing Feishu doc.

## Core Outcome

Produce an itinerary that the user can actually travel with:

- A clear route direction and daily schedule.
- Distance and driving-time estimates for each leg.
- Recommended住宿地点 by night, not only景区名.
- Meal and supply suggestions where they affect timing.
- 景点介绍,特点,游玩方式,取舍理由,拍照打卡点.
- A booking and departure checklist.
- Current policy/traffic/reservation notes with dates and sources when facts may have changed.
- Backup plans for weather, road closure, fatigue driving, missed reservations, or overlong days.

## Progressive Intake

Guide the user step by step. Do not demand a long form all at once unless they explicitly ask for one. Ask the smallest set of missing questions needed for the next decision, usually no more than 3 questions per turn.

First collect hard constraints:

- Destination or region.
- Start and end city.
- Exact arrival and departure dates/times.
- Number of travelers.
- Transport mode: self-drive, chartered car, train, flight, public transit, mixed.
- Driver count and daily driving tolerance.
- Must-go places and must-skip places.
- Existing route, screenshots, links, videos, or documents to preserve.

Then collect preference constraints:

- Travel pace: relaxed, balanced, intense, photography-first, parent-child, budget-first, luxury.
- Accommodation level and whether the user accepts景区内/县城/机场周边.
- Food preferences and dietary restrictions.
- Photography priorities: sunrise, sunset, drone, portraits, road scenery, lakes, snow mountains, city life.
- Tolerance for hikes, gravel roads, altitude, border areas, early starts, and long transfer days.

If the user already provided enough context, proceed using explicit assumptions instead of stalling. Mark assumptions clearly and adjust when the user corrects them.

## Current Fact Checking

Always verify volatile facts with current sources before giving firm guidance. This includes:

- Road openings, seasonal closures, traffic controls, reservation rules, vehicle restrictions, border permits, scenic-area rules, ferry/rail/flight schedules, prices, and weather-sensitive access.
- For China road trips, prioritize official or primary sources where possible: local government, traffic police, scenic-area official accounts/websites, official ticketing platforms, and major map/navigation estimates.
- If using social posts or creator videos, treat them as experience references, not final authority for policy or road status.
- Include the check date in the output, especially for seasonal roads.

Separate:

- Confirmed current facts.
- Route-planning estimates.
- Inferences from user material.
- Things the user must recheck 1-3 days before departure.

## Source Material

When the user provides links, screenshots, videos, or documents:

- Extract route logic, day order, timing anchors, scenic priorities, and warnings.
- Preserve the user's preferred route as the baseline unless it is clearly unsafe or infeasible.
- Compare the source route against the user's constraints; explain what to keep, what to drop, and why.
- For videos, take screenshots only when local video access or an available browser/tool permits it. Use screenshots as visual support, not proof of current road or policy status.
- For Xiaohongshu or other social content, summarize mechanisms and useful details without copying long phrasing.

## Route Simulation

Before writing the final攻略, mentally simulate the whole trip day by day:

- Start from the real arrival time, pickup time, and return-flight deadline.
- Convert each scenic stop into realistic on-site time plus parking, ticketing, shuttle, meals, fuel, and photo time.
- Flag any day with more than about 6-7 hours of driving as a hard day, and any consecutive hard days as a risk.
- Avoid planning intense activities after late-night arrival, long mountain-road drives, or uncertain border/seasonal roads.
- Put critical roads and popular attractions earlier in the day when crowds, weather, or control windows matter.
- Build one downgrade option for each risky segment, such as skipping a scenic detour, staying in a nearer town, or moving a full-day hike to a short-viewpoint version.

For road trips, evaluate directionality:

- Compare clockwise vs counterclockwise based on likely traffic flow, road-control windows, scenic timing, lodging scarcity, and final return pressure.
- Explain the recommendation with concrete dates and route segments.
- Avoid absolute claims such as "一定不堵"; use risk language and the user's dates.

## Output Structure

Use Chinese by default when the user writes Chinese. Prefer visual, skimmable formatting.

For a full guide, include:

1. **一句话结论**: whether the route is reasonable and the recommended direction.
2. **总路线图文字版**: `A → B → C` route chain, plus optional Mermaid route diagram if the target document supports it.
3. **总行程表** with columns: 日期, 起点, 终点/住宿, 里程, 车程, 核心安排, 注意事项.
4. **每日详细安排**: morning, noon, afternoon, evening,住宿,吃饭,补给/加油.
5. **景点介绍与取舍**: why each stop is worth it, what to skip if time/weather is bad.
6. **拍照打卡点**: viewpoint, best time, lens/drone notes where relevant.
7. **住宿建议**: by date and town, including when to stay near airport, scenic gate, county town, or transit city.
8. **吃饭建议**: local meals that fit the day, plus avoid-overrunning reminders for long driving days.
9. **必备完成清单**: flights, rental car, hotel, tickets, road status, reservation screenshots, IDs/permits, offline maps, insurance, medicine, clothing, chargers, water/food.
10. **风险与备选方案**: weather, road closure, fatigue, missed reservation, route compression.

Keep the plan detailed enough to act on, but do not invent exact restaurant names, hotel names, prices, or official rules unless verified.

## Document Delivery

If the user asks for a Feishu document or provides a Feishu doc link, use the available Feishu document tooling and follow the local lark-doc workflow:

- Fetch the existing document before editing.
- Preserve user-modified content and images unless the user asks for a rewrite.
- Prefer targeted section edits for existing docs.
- Re-fetch after updating to confirm the result.

If the user asks for图文结合:

- Use screenshots from user-provided media where available and relevant.
- Generate or search for a simple route visualization only when it improves understanding.
- Label AI-generated or illustrative images clearly when they are not real trip photos.

## Tone and Decision Style

Be practical, candid, and travel-partner-like. Give a recommendation rather than leaving every option open, but keep tradeoffs visible. When the user changes route constraints, update the plan around the newest constraints and explicitly remove now-excluded destinations.

Do not over-optimize for打卡数量. A good itinerary should leave room for meals, fuel, rest, weather, and unexpected beautiful stops.
