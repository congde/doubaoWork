---
name: lijigang-skills-collection
description: >-
  李继刚大佬的 Skill 合集：收录 20 个面向深度思考、阅读、写作与知识表达的用户型 Skill，覆盖拆书、论文阅读、伴读、概念解剖、盲区扫描、约束/降秩/本质/结构分析、白话改写、问答提炼、写作、古文精读、内容卡片、演讲、投资、关系与圆桌讨论。开源仓库：https://github.com/lijigang/ljg-skills；截至 2026-08-20 获得 7,143 Stars。合集排除了仅供上游作者维护仓库的 ljg-push。
license: MIT
metadata:
  display_name: "李继刚大佬的 Skill 合集"
  display_summary: "20 个深度思考、阅读、写作与知识表达 Skill，来源于李继刚开源的 ljg-skills。"
  breakout_manifest: "./breakout-publisher.json"
  source_repository: "https://github.com/lijigang/ljg-skills"
  source_commit: "edfe3f58da80d0b01a8df44189d23f2154cb0969"
  source_stars: 7143
  source_stars_as_of: "2026-08-20"
  bundled_skill_count: 20
  upstream_author: "李继刚"
---

# 李继刚大佬的 Skill 合集

这是一个面向思考、阅读与表达任务的合集路由器。不要一次加载全部子 Skill；应先判断任务的认知动作，再读取最匹配的子目录。

## 使用流程

1. 阅读 [技能目录](references/技能目录.md)，区分用户是在读一本书、读论文、理解概念、追问本质、找结构、写文章还是做视觉表达。
2. 只读取 `bundled-skills/<子 Skill 名>/SKILL.md` 及其明确引用的资源。
3. 确认输入材料、输出格式和保存位置。默认分支中的部分上游 Skill 使用 Org-mode；用户需要 Markdown 时先说明并调整输出。
4. 保留原材料的事实边界，不虚构书中内容、论文证据、人物观点、投资信息或关系背景。

## 选择原则

- 书籍、论文与文本：分别选择 `ljg-book`、`ljg-paper`、`ljg-read`。
- 概念与思考：根据目标选择 `ljg-learn`、`ljg-think`、`ljg-is`、`ljg-rank`、`ljg-constraint` 或 `ljg-structure`。
- 写作与表达：选择 `ljg-writes`、`ljg-plain`、`ljg-qa`、`ljg-card`、`ljg-classic` 或 `ljg-present`。
- 分析对话：投资、关系与多视角讨论分别使用 `ljg-invest`、`ljg-relationship`、`ljg-roundtable`。

## 安全边界

- 不读取用户未授权的私人对话、书库、关系记录、投资材料或本地文件。
- 不把心理分析描述成医学诊断，不把投资分析描述成确定收益或专业执业意见。
- `ljg-card` 等视觉子 Skill 可能需要 Bun、Playwright 或浏览器，安装依赖前先说明影响。
- 本合集不包含 `ljg-push`，防止普通用户误把内容推送到上游作者仓库。

## 来源与更新

上游源码、提交快照和排除项见 [来源与许可说明](来源与许可说明.md)。详细安装与第一次使用步骤见 [使用指南](使用指南.md)。
