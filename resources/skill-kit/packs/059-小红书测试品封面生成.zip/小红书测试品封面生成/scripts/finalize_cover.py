#!/usr/bin/env python3
"""Create a 1080x1440 Xiaohongshu cover with deterministic Chinese text."""

from __future__ import annotations

import argparse
from pathlib import Path

try:
    from PIL import Image, ImageColor, ImageDraw, ImageFont, ImageOps
except ImportError as exc:  # pragma: no cover - dependency error path
    raise SystemExit("Pillow is required. Install it with: python3 -m pip install Pillow") from exc


WIDTH = 1080
HEIGHT = 1440
DEFAULT_FONT = Path("/System/Library/Fonts/STHeiti Medium.ttc")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Crop a background to 3:4 and add exact, readable Chinese cover text."
    )
    parser.add_argument("--input", required=True, type=Path, help="Background image path")
    parser.add_argument("--output", required=True, type=Path, help="New PNG output path")
    parser.add_argument("--title", required=True, help="Exact main title; use \\n for forced breaks")
    parser.add_argument("--subtitle", default="", help="Optional exact subtitle")
    parser.add_argument("--badge", default="", help="Optional short badge text")
    parser.add_argument(
        "--layout", choices=("top", "center", "bottom"), default="center"
    )
    parser.add_argument("--text-color", default="#FFFFFF")
    parser.add_argument("--accent-color", default="#FF3B5C")
    parser.add_argument(
        "--panel-opacity", type=int, default=132, help="0-255; translucent text panel"
    )
    parser.add_argument("--font", type=Path, default=DEFAULT_FONT)
    return parser.parse_args()


def rgba(hex_color: str, alpha: int = 255) -> tuple[int, int, int, int]:
    rgb = ImageColor.getrgb(hex_color)
    return rgb[0], rgb[1], rgb[2], alpha


def load_font(path: Path, size: int) -> ImageFont.FreeTypeFont:
    if not path.exists():
        raise SystemExit(f"Font not found: {path}")
    return ImageFont.truetype(str(path), size=size)


def wrap_by_width(
    draw: ImageDraw.ImageDraw,
    text: str,
    font: ImageFont.FreeTypeFont,
    max_width: int,
) -> list[str]:
    lines: list[str] = []
    for paragraph in text.replace("\\n", "\n").splitlines() or [""]:
        current = ""
        for char in paragraph:
            candidate = current + char
            if current and draw.textlength(candidate, font=font) > max_width:
                lines.append(current.rstrip())
                current = char.lstrip()
            else:
                current = candidate
        if current or not lines:
            lines.append(current)
    return lines


def text_block_height(lines: list[str], font: ImageFont.FreeTypeFont, spacing: int) -> int:
    bbox = font.getbbox("国Ag")
    line_height = bbox[3] - bbox[1]
    return line_height * len(lines) + spacing * max(0, len(lines) - 1)


def main() -> None:
    args = parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite existing output: {args.output}")
    if not 0 <= args.panel_opacity <= 255:
        raise SystemExit("--panel-opacity must be between 0 and 255")
    if not args.input.is_file():
        raise SystemExit(f"Input image not found: {args.input}")

    with Image.open(args.input) as source:
        source = ImageOps.exif_transpose(source).convert("RGB")
        canvas = ImageOps.fit(
            source,
            (WIDTH, HEIGHT),
            method=Image.Resampling.LANCZOS,
            centering=(0.5, 0.5),
        ).convert("RGBA")

    overlay = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    title_size = 100 if len(args.title.replace("\\n", "")) <= 12 else 82
    title_font = load_font(args.font, title_size)
    subtitle_font = load_font(args.font, 42)
    badge_font = load_font(args.font, 34)
    max_text_width = 800
    title_lines = wrap_by_width(draw, args.title, title_font, max_text_width)
    title_spacing = 18
    title_height = text_block_height(title_lines, title_font, title_spacing)
    subtitle_lines = (
        wrap_by_width(draw, args.subtitle, subtitle_font, max_text_width)
        if args.subtitle
        else []
    )
    subtitle_height = text_block_height(subtitle_lines, subtitle_font, 12) if subtitle_lines else 0
    badge_height = 58 if args.badge else 0
    gaps = (30 if args.badge else 0) + (34 if subtitle_lines else 0)
    block_height = badge_height + title_height + subtitle_height + gaps

    panel_x = 86
    panel_w = WIDTH - panel_x * 2
    panel_h = block_height + 116
    if args.layout == "top":
        panel_y = 120
    elif args.layout == "bottom":
        panel_y = HEIGHT - panel_h - 140
    else:
        panel_y = (HEIGHT - panel_h) // 2

    draw.rounded_rectangle(
        (panel_x, panel_y, panel_x + panel_w, panel_y + panel_h),
        radius=38,
        fill=(0, 0, 0, args.panel_opacity),
    )
    draw.rounded_rectangle(
        (panel_x + 38, panel_y + 48, panel_x + 52, panel_y + panel_h - 48),
        radius=7,
        fill=rgba(args.accent_color),
    )

    text_x = panel_x + 88
    y = panel_y + 56
    if args.badge:
        badge_bbox = draw.textbbox((0, 0), args.badge, font=badge_font)
        badge_w = badge_bbox[2] - badge_bbox[0] + 42
        draw.rounded_rectangle(
            (text_x, y, text_x + badge_w, y + badge_height),
            radius=20,
            fill=rgba(args.accent_color),
        )
        draw.text(
            (text_x + 21, y + 9),
            args.badge,
            font=badge_font,
            fill=(255, 255, 255, 255),
        )
        y += badge_height + 30

    line_bbox = title_font.getbbox("国Ag")
    line_height = line_bbox[3] - line_bbox[1]
    for line in title_lines:
        draw.text(
            (text_x + 3, y + 4),
            line,
            font=title_font,
            fill=(0, 0, 0, 150),
        )
        draw.text(
            (text_x, y),
            line,
            font=title_font,
            fill=rgba(args.text_color),
        )
        y += line_height + title_spacing

    if subtitle_lines:
        y += 16
        sub_bbox = subtitle_font.getbbox("国Ag")
        sub_line_height = sub_bbox[3] - sub_bbox[1]
        for line in subtitle_lines:
            draw.text(
                (text_x, y),
                line,
                font=subtitle_font,
                fill=(245, 245, 245, 235),
            )
            y += sub_line_height + 12

    result = Image.alpha_composite(canvas, overlay).convert("RGB")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.save(args.output, format="PNG", optimize=True)

    with Image.open(args.output) as check:
        if check.size != (WIDTH, HEIGHT):
            raise SystemExit(f"Unexpected output dimensions: {check.size}")
    print(args.output.resolve())


if __name__ == "__main__":
    main()
