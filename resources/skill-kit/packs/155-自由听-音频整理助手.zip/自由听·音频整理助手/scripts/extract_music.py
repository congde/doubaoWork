#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlparse
from urllib.request import Request, urlopen


DEFAULT_OUTPUT = Path(
    os.environ.get("LISTEN_FREELY_OUTPUT", str(Path.home() / "Music"))
).expanduser()
SPOTIFY_OEMBED = "https://open.spotify.com/oembed?url="
DEFAULT_TRACKS_FILE = "tracks.todo.json"


class UserError(Exception):
    pass


@dataclass
class Segment:
    index: int
    start: float
    end: float | None
    label: str
    artist: str
    title: str
    source: str


@dataclass
class SpotifyMeta:
    title: str = ""
    artist: str = ""
    url: str = ""
    raw_title: str = ""


def run(
    args: list[str],
    *,
    capture: bool = False,
    check: bool = True,
    timeout: float | None = None,
) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            args,
            text=True,
            capture_output=capture,
            check=check,
            timeout=timeout,
        )
    except FileNotFoundError as exc:
        raise UserError(f"Missing required command: {args[0]}") from exc
    except subprocess.TimeoutExpired as exc:
        raise UserError(
            f"Command timed out after {exc.timeout} seconds: {' '.join(args)}"
        ) from exc
    except subprocess.CalledProcessError as exc:
        if capture:
            detail = (exc.stderr or exc.stdout or "").strip()
        else:
            detail = ""
        message = f"Command failed: {' '.join(args)}"
        if detail:
            message += f"\n{detail}"
        raise UserError(message) from exc


def require_tool(name: str) -> None:
    if shutil.which(name) is None:
        if name == "spotdl":
            install_hint = "请安装 spotDL：uv tool install spotdl"
        else:
            install_hint = (
                "请安装 yt-dlp 与 ffmpeg；macOS 可使用："
                "brew install yt-dlp ffmpeg"
            )
        raise UserError(
            f"Missing required command: {name}\n"
            f"{install_hint}"
        )


def is_spotify_url(url: str) -> bool:
    parsed = urlparse(url)
    return parsed.scheme == "spotify" or "spotify.com" in parsed.netloc.lower()


def is_youtube_url(url: str) -> bool:
    host = urlparse(url).netloc.lower()
    return "youtube.com" in host or "youtu.be" in host


def fetch_spotify_meta(url: str) -> SpotifyMeta:
    request = Request(
        SPOTIFY_OEMBED + url,
        headers={"User-Agent": "listen-freely/1.0"},
    )
    try:
        with urlopen(request, timeout=20) as response:
            data = json.loads(response.read().decode("utf-8"))
    except (HTTPError, URLError, TimeoutError, json.JSONDecodeError):
        return SpotifyMeta(url=url)

    raw_title = str(data.get("title") or "").strip()
    artist = str(data.get("author_name") or "").strip()
    title = raw_title

    # Spotify oEmbed often formats track titles like "Song - Single by Artist".
    if " by " in raw_title and not artist:
        maybe_title, maybe_artist = raw_title.rsplit(" by ", 1)
        title = maybe_title.strip()
        artist = maybe_artist.strip()
    elif " by " in raw_title:
        title = raw_title.rsplit(" by ", 1)[0].strip()

    return SpotifyMeta(title=title, artist=artist, url=url, raw_title=raw_title)


def dump_ytdlp_info(url: str) -> dict[str, Any]:
    require_tool("yt-dlp")
    result = run(
        [
            "yt-dlp",
            "--dump-single-json",
            "--no-playlist",
            "--skip-download",
            "--no-warnings",
            url,
        ],
        capture=True,
    )
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise UserError("yt-dlp did not return valid JSON metadata.") from exc


def download_audio(url: str, temp_dir: Path) -> Path:
    require_tool("yt-dlp")
    output_template = str(temp_dir / "source.%(ext)s")
    run(
        [
            "yt-dlp",
            "-f",
            "bestaudio/best",
            "--no-playlist",
            "-o",
            output_template,
            url,
        ]
    )
    candidates = [
        path
        for path in temp_dir.glob("source.*")
        if path.is_file()
        and not path.name.endswith((".part", ".ytdl", ".json", ".temp"))
    ]
    if not candidates:
        raise UserError("Download finished, but no audio file was found.")
    return max(candidates, key=lambda path: path.stat().st_size)


def parse_time_token(value: str) -> float:
    parts = value.strip().split(":")
    if len(parts) == 2:
        minutes, seconds = parts
        return int(minutes) * 60 + int(seconds)
    if len(parts) == 3:
        hours, minutes, seconds = parts
        return int(hours) * 3600 + int(minutes) * 60 + int(seconds)
    raise ValueError(f"Invalid time value: {value}")


def parse_optional_time(value: str | None) -> float | None:
    if value is None:
        return None
    value = value.strip()
    if not value:
        return None
    if ":" in value:
        return parse_time_token(value)
    return float(value)


def parse_time_value(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return parse_optional_time(str(value))


def parse_url_time(url: str) -> float | None:
    parsed = urlparse(url)
    query = parse_qs(parsed.query)
    raw = (query.get("t") or query.get("start") or [None])[0]
    if not raw:
        return None
    value = str(raw).strip().lower()
    try:
        if value.isdigit():
            return float(value)
        if ":" in value:
            return parse_time_token(value)
        match = re.fullmatch(
            r"(?:(?P<h>\d+)h)?(?:(?P<m>\d+)m)?(?:(?P<s>\d+)s?)?",
            value,
        )
        if match:
            hours = int(match.group("h") or 0)
            minutes = int(match.group("m") or 0)
            seconds = int(match.group("s") or 0)
            total = hours * 3600 + minutes * 60 + seconds
            return float(total) if total else None
    except ValueError:
        return None
    return None


TIME_RE = re.compile(r"(?<!\d)(\d{1,3}:\d{2}(?::\d{2})?)(?!\d)")


def extract_timestamp(line: str) -> tuple[float, str] | None:
    match = TIME_RE.search(line)
    if not match:
        return None
    start = parse_time_token(match.group(1))
    label = (line[: match.start()] + " " + line[match.end() :]).strip()
    label = re.sub(r"^[\s\-–—|:.)\]]+", "", label)
    label = re.sub(r"[\s\-–—|:([ ]+$", "", label)
    return start, label


def clean_label(value: str) -> str:
    value = unicodedata.normalize("NFC", value or "")
    value = re.sub(r"https?://\S+", "", value)
    value = re.sub(r"^\s*(?:track\s*)?\d{1,3}\s*[\).:\-–—]\s*", "", value, flags=re.I)
    value = re.sub(r"\s+", " ", value)
    value = value.strip(" \t-–—|")
    return value or "Untitled"


def normalize_match(value: str) -> str:
    value = unicodedata.normalize("NFKC", value or "").lower()
    return re.sub(r"[^0-9a-z\u4e00-\u9fff]+", "", value)


def split_artist_title(label: str, fallback_artist: str = "") -> tuple[str, str]:
    label = clean_label(label)
    bracketed = re.fullmatch(r"《([^》]+)》\s*(.+)?", label)
    if bracketed:
        title = clean_label(bracketed.group(1))
        artist = clean_label(bracketed.group(2) or "")
        if artist == "Untitled":
            artist = ""
        return artist, title

    for sep in (" - ", " – ", " — ", " | ", " / "):
        if sep in label:
            artist, title = label.split(sep, 1)
            artist = clean_label(artist)
            title = clean_label(title)
            if title:
                return artist, title
    artist = clean_label(fallback_artist) if fallback_artist.strip() else ""
    return artist, label


def info_artist(
    info: dict[str, Any],
    spotify: SpotifyMeta | None = None,
    *,
    include_channel: bool = True,
) -> str:
    if spotify and spotify.artist:
        return spotify.artist
    keys = ["artist", "creator"]
    if include_channel:
        keys.extend(["uploader", "channel"])
    for key in keys:
        value = str(info.get(key) or "").strip()
        if value:
            return value
    return ""


def info_title(info: dict[str, Any], spotify: SpotifyMeta | None = None) -> str:
    if spotify and spotify.title:
        return spotify.title
    return str(info.get("title") or "").strip() or "Untitled"


def duration_from_info(info: dict[str, Any]) -> float | None:
    duration = info.get("duration")
    try:
        return float(duration) if duration is not None else None
    except (TypeError, ValueError):
        return None


def chapters_to_segments(
    info: dict[str, Any],
    fallback_artist: str,
    duration: float | None,
) -> list[Segment]:
    chapters = info.get("chapters") or []
    if not isinstance(chapters, list):
        return []

    raw: list[tuple[float, float | None, str]] = []
    for chapter in chapters:
        if not isinstance(chapter, dict):
            continue
        try:
            start = float(chapter.get("start_time") or 0)
        except (TypeError, ValueError):
            continue
        end_value = chapter.get("end_time")
        try:
            end = float(end_value) if end_value is not None else None
        except (TypeError, ValueError):
            end = None
        title = clean_label(str(chapter.get("title") or ""))
        raw.append((start, end, title))

    raw.sort(key=lambda item: item[0])
    segments: list[Segment] = []
    for idx, (start, end, label) in enumerate(raw, start=1):
        if end is None:
            end = raw[idx][0] if idx < len(raw) else duration
        if end is not None and end <= start:
            continue
        artist, title = split_artist_title(label, fallback_artist)
        segments.append(Segment(idx, start, end, label, artist, title, "chapters"))
    return segments


def description_to_segments(
    info: dict[str, Any],
    fallback_artist: str,
    duration: float | None,
) -> list[Segment]:
    description = str(info.get("description") or "")
    raw: list[tuple[float, str]] = []
    seen: set[float] = set()

    for line in description.splitlines():
        extracted = extract_timestamp(line)
        if extracted is None:
            continue
        start, label = extracted
        if start in seen:
            continue
        seen.add(start)
        raw.append((start, clean_label(label)))

    raw.sort(key=lambda item: item[0])
    if len(raw) < 2 and not (raw and raw[0][0] == 0):
        return []

    segments: list[Segment] = []
    for idx, (start, label) in enumerate(raw, start=1):
        end = raw[idx][0] if idx < len(raw) else duration
        if end is not None and end <= start:
            continue
        artist, title = split_artist_title(label, fallback_artist)
        segments.append(Segment(idx, start, end, label, artist, title, "description"))
    return segments


def build_segments(
    info: dict[str, Any],
    *,
    song: str | None,
    start: float | None,
    end: float | None,
    target_time: float | None,
    spotify: SpotifyMeta | None,
) -> list[Segment]:
    duration = duration_from_info(info)
    fallback_artist = info_artist(info, spotify, include_channel=False)

    if start is not None:
        label = song or info_title(info, spotify)
        artist, title = split_artist_title(label, fallback_artist)
        return [Segment(1, start, end, label, artist, title, "manual")]

    segments = chapters_to_segments(info, fallback_artist, duration)
    if not segments:
        segments = description_to_segments(info, fallback_artist, duration)

    if not segments:
        title = info_title(info, spotify)
        whole_fallback_artist = info_artist(info, spotify, include_channel=True)
        artist, parsed_title = split_artist_title(title, whole_fallback_artist)
        segments = [Segment(1, 0, duration, title, artist, parsed_title, "whole")]

    if target_time is not None and not song:
        matches = [
            segment
            for segment in segments
            if segment.start <= target_time
            and (segment.end is None or target_time < segment.end)
        ]
        if matches:
            for idx, segment in enumerate(matches, start=1):
                segment.index = idx
            return matches

    if song:
        needle = normalize_match(song)
        matches = [
            segment
            for segment in segments
            if needle
            and needle
            in normalize_match(" ".join([segment.label, segment.artist, segment.title]))
        ]
        if matches:
            for idx, segment in enumerate(matches, start=1):
                segment.index = idx
                if segment.title == "Untitled":
                    segment.title = clean_label(song)
            return matches

        if len(segments) == 1 and needle in normalize_match(info_title(info, spotify)):
            segments[0].title = clean_label(song)
            return segments

        available = "\n".join(f"- {s.label}" for s in segments[:20])
        raise UserError(
            f"Could not find a segment matching --song {song!r}.\n"
            "Run with --dry-run to inspect detected chapters/timestamps, "
            "or provide --start and --end manually.\n"
            f"Detected labels:\n{available}"
        )

    return segments


def probe_codec(path: Path) -> str:
    require_tool("ffprobe")
    result = run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "a:0",
            "-show_entries",
            "stream=codec_name",
            "-of",
            "json",
            str(path),
        ],
        capture=True,
    )
    try:
        data = json.loads(result.stdout)
        streams = data.get("streams") or []
        if streams:
            return str(streams[0].get("codec_name") or "").lower()
    except json.JSONDecodeError:
        pass
    return ""


def codec_args(format_name: str, codec: str) -> tuple[str, list[str]]:
    if format_name == "source":
        if codec == "opus":
            return "opus", ["-c:a", "copy"]
        if codec in {"aac", "alac"}:
            return "m4a", ["-c:a", "copy"]
        if codec == "mp3":
            return "mp3", ["-c:a", "copy"]
        if codec == "flac":
            return "flac", ["-c:a", "copy"]
        if codec == "vorbis":
            return "ogg", ["-c:a", "copy"]
        return "mka", ["-c:a", "copy"]

    if format_name == "opus":
        return "opus", ["-c:a", "libopus", "-b:a", "192k"]
    if format_name == "m4a":
        return "m4a", ["-c:a", "aac", "-b:a", "320k"]
    if format_name == "mp3":
        return "mp3", ["-c:a", "libmp3lame", "-q:a", "0"]
    if format_name == "flac":
        return "flac", ["-c:a", "flac"]
    if format_name == "wav":
        return "wav", ["-c:a", "pcm_s16le"]
    raise UserError(f"Unsupported format: {format_name}")


def safe_filename(value: str) -> str:
    value = unicodedata.normalize("NFC", value)
    value = re.sub(r"[\/\\:\0]", "-", value)
    value = re.sub(r"\s+", " ", value)
    value = value.strip(" .")
    if not value:
        value = "Untitled"
    return value[:180]


def formatted_track_name(title: str, artist: str = "") -> str:
    title = clean_label(title)
    artist = clean_label(artist) if artist.strip() else ""
    if artist:
        return f"《{title}》{artist}"
    return f"《{title}》"


def filename_for(segment: Segment, *, total: int, extension: str) -> str:
    title = segment.title or segment.label or "Untitled"
    base = formatted_track_name(title, segment.artist)
    return f"{safe_filename(base)}.{extension}"


def export_segment(
    source: Path,
    output_dir: Path,
    segment: Segment,
    *,
    total: int,
    format_name: str,
    codec: str,
    album: str,
) -> Path:
    require_tool("ffmpeg")
    extension, audio_args = codec_args(format_name, codec)
    output = output_dir / filename_for(segment, total=total, extension=extension)
    if output.exists():
        print(f"Skipped existing file: {output}")
        return output

    args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"]
    if segment.start > 0:
        args.extend(["-ss", f"{segment.start:.3f}"])
    args.extend(["-i", str(source)])

    if segment.end is not None:
        duration = segment.end - segment.start
        if duration <= 0:
            raise UserError(f"Invalid segment duration for {segment.label!r}.")
        args.extend(["-t", f"{duration:.3f}"])

    args.extend(["-vn"])
    args.extend(audio_args)
    args.extend(["-metadata", f"title={segment.title or segment.label}"])
    if segment.artist:
        args.extend(["-metadata", f"artist={segment.artist}"])
    if album:
        args.extend(["-metadata", f"album={album}"])
    args.extend(["-metadata", f"track={segment.index}/{total}"])
    args.append(str(output))

    run(args)
    return output


def print_plan(segments: list[Segment]) -> None:
    for segment in segments:
        start = seconds_to_stamp(segment.start)
        end = seconds_to_stamp(segment.end) if segment.end is not None else "end"
        print(
            f"{segment.index:02d}. {start} - {end} | "
            f"{segment.artist + ' - ' if segment.artist else ''}{segment.title} "
            f"({segment.source})"
        )


def segment_query(segment: Segment) -> str:
    title = clean_label(segment.title or segment.label)
    artist = clean_label(segment.artist) if segment.artist.strip() else ""
    if artist:
        return f"{artist} {title}"
    return title


def has_reliable_split(segments: list[Segment]) -> bool:
    return any(segment.source in {"chapters", "description", "manual", "tracks-file"} for segment in segments)


def is_long_whole_video(segments: list[Segment], duration: float | None) -> bool:
    if len(segments) != 1 or segments[0].source != "whole":
        return False
    if duration is None:
        return True
    return duration >= 15 * 60


def seconds_to_stamp(value: float | None) -> str:
    if value is None:
        return "end"
    value = max(0, int(round(value)))
    hours, rem = divmod(value, 3600)
    minutes, seconds = divmod(rem, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"


def metadata_for_local(path: Path, spotify: SpotifyMeta | None) -> dict[str, Any]:
    title = spotify.title if spotify and spotify.title else path.stem
    return {
        "title": title,
        "artist": spotify.artist if spotify else "",
        "duration": None,
        "description": "",
        "chapters": [],
    }


def load_tracks_file(path: Path) -> list[Segment]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise UserError(f"Tracks file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise UserError(f"Tracks file is not valid JSON: {path}") from exc

    tracks = data.get("tracks") if isinstance(data, dict) else data
    if not isinstance(tracks, list):
        raise UserError("Tracks file must contain a list or an object with a 'tracks' list.")

    segments: list[Segment] = []
    for idx, item in enumerate(tracks, start=1):
        if not isinstance(item, dict):
            continue
        start = parse_time_value(item.get("start"))
        if start is None:
            raise UserError(f"Track {idx} is missing a start time.")
        end = parse_time_value(item.get("end"))
        title = clean_label(str(item.get("title") or item.get("name") or f"Track {idx:02d}"))
        artist = clean_label(str(item.get("artist") or ""))
        if artist == "Untitled":
            artist = ""
        label = formatted_track_name(title, artist)
        segments.append(Segment(idx, start, end, label, artist, title, "tracks-file"))

    if not segments:
        raise UserError(f"No usable tracks found in {path}")
    return segments


def write_tracks_file(
    path: Path,
    *,
    source_url: str,
    info: dict[str, Any],
    segments: list[Segment],
    notes: list[str],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "source_url": source_url,
        "source_title": info_title(info),
        "notes": notes,
        "tracks": [
            {
                "index": segment.index,
                "start": seconds_to_stamp(segment.start),
                "end": seconds_to_stamp(segment.end),
                "title": "" if segment.title.startswith("Track ") else segment.title,
                "artist": segment.artist,
                "detected_label": segment.label,
                "source": segment.source,
            }
            for segment in segments
        ],
    }
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


SILENCE_START_RE = re.compile(r"silence_start:\s*([0-9.]+)")
SILENCE_END_RE = re.compile(r"silence_end:\s*([0-9.]+)")


def detect_candidate_segments(
    source: Path,
    *,
    duration: float | None,
    min_track_length: float = 90.0,
) -> list[Segment]:
    require_tool("ffmpeg")
    result = run(
        [
            "ffmpeg",
            "-hide_banner",
            "-nostats",
            "-i",
            str(source),
            "-af",
            "silencedetect=noise=-35dB:d=1.2",
            "-f",
            "null",
            "-",
        ],
        capture=True,
    )

    silence_start: float | None = None
    boundaries = [0.0]
    for line in (result.stderr or "").splitlines():
        start_match = SILENCE_START_RE.search(line)
        if start_match:
            silence_start = float(start_match.group(1))
            continue
        end_match = SILENCE_END_RE.search(line)
        if end_match and silence_start is not None:
            silence_end = float(end_match.group(1))
            midpoint = (silence_start + silence_end) / 2
            if midpoint - boundaries[-1] >= min_track_length:
                boundaries.append(midpoint)
            silence_start = None

    if duration is not None and duration - boundaries[-1] >= min_track_length:
        boundaries.append(duration)

    segments: list[Segment] = []
    for idx in range(len(boundaries) - 1):
        start = boundaries[idx]
        end = boundaries[idx + 1]
        if end - start < min_track_length:
            continue
        title = f"Track {len(segments) + 1:02d}"
        segments.append(
            Segment(
                len(segments) + 1,
                start,
                end,
                title,
                "",
                title,
                "silence-detect",
            )
        )

    if not segments and duration is not None:
        segments.append(Segment(1, 0, duration, "Track 01", "", "Track 01", "whole"))
    return segments


def spotify_kind(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme == "spotify":
        parts = [part for part in parsed.path.split(":") if part]
    else:
        parts = [part for part in parsed.path.split("/") if part]
    for candidate in ("track", "album", "playlist", "artist"):
        if candidate in parts:
            return candidate
    return "spotify"


def spotdl_format(format_name: str) -> tuple[str, str]:
    if format_name == "source":
        return "m4a", "disable"
    if format_name in {"opus", "m4a"}:
        return format_name, "disable"
    if format_name == "mp3":
        return "mp3", "320k"
    if format_name in {"flac", "wav"}:
        return format_name, "disable"
    raise UserError(f"Unsupported spotDL format: {format_name}")


def spotdl_query(
    spotify_url: str,
    *,
    source_url: str | None,
    song: str | None,
) -> tuple[str, str]:
    if source_url:
        if is_youtube_url(source_url):
            return f"{source_url}|{spotify_url}", "manual YouTube match with Spotify metadata"
        return source_url, "authorized source URL"

    if song and spotify_kind(spotify_url) != "track":
        return song, "song search from --song"

    return spotify_url, "Spotify link"


def build_spotdl_command(
    query: str,
    output_dir: Path,
    *,
    format_name: str,
) -> tuple[list[str], str]:
    output_format, bitrate = spotdl_format(format_name)
    output_template = str(output_dir / "《{title}》{artists}.{output-ext}")
    return [
        "spotdl",
        "--audio",
        "youtube-music",
        "youtube",
        "--format",
        output_format,
        "--bitrate",
        bitrate,
        "--output",
        output_template,
        "--overwrite",
        "skip",
        "--restrict",
        "none",
        "--print-errors",
        "download",
        query,
    ], output_template


def run_spotdl_query(
    query: str,
    output_dir: Path,
    *,
    format_name: str,
    dry_run: bool,
    query_source: str,
) -> int:
    require_tool("spotdl")
    command, output_template = build_spotdl_command(
        query,
        output_dir,
        format_name=format_name,
    )

    if dry_run:
        print("Query will be handled by spotDL.")
        print(f"Query source: {query_source}")
        print(f"Query: {query}")
        print(f"Output template: {output_template}")
        print("Command:")
        print(shlex.join(command))
        return 0

    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Running spotDL for: {query}")
    run(command)
    return 0


def run_spotdl(
    spotify_url: str,
    output_dir: Path,
    *,
    format_name: str,
    song: str | None,
    source_url: str | None,
    dry_run: bool,
) -> int:
    query, query_source = spotdl_query(spotify_url, source_url=source_url, song=song)
    if dry_run:
        print("Spotify link will be handled by spotDL.")
    else:
        print("Running spotDL for Spotify metadata matching.")
        print("spotDL uses Spotify metadata and downloads matching audio from configured providers.")
    return run_spotdl_query(
        query,
        output_dir,
        format_name=format_name,
        dry_run=dry_run,
        query_source=query_source,
    )


def run_clean_source_download(
    segments: list[Segment],
    output_dir: Path,
    *,
    format_name: str,
    dry_run: bool,
) -> int:
    for segment in segments:
        query = segment_query(segment)
        run_spotdl_query(
            query,
            output_dir,
            format_name=format_name,
            dry_run=dry_run,
            query_source=f"{segment.source} segment {segment.index}",
        )
    return 0


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Extract authorized music from YouTube links, or use spotDL for "
            "Spotify metadata matching."
        )
    )
    parser.add_argument("url", help="YouTube URL, Spotify URL, or metadata URL.")
    parser.add_argument("--song", help="Only extract the named song or segment.")
    parser.add_argument(
        "--output",
        default=str(DEFAULT_OUTPUT),
        help=f"Output directory. Default: {DEFAULT_OUTPUT}",
    )
    parser.add_argument(
        "--format",
        default="source",
        choices=["source", "opus", "m4a", "mp3", "flac", "wav"],
        help="Output format. 'source' preserves the original audio codec when possible.",
    )
    parser.add_argument("--start", help="Manual segment start, e.g. 1:23 or 83.")
    parser.add_argument("--end", help="Manual segment end, e.g. 4:56 or 296.")
    parser.add_argument(
        "--source-url",
        help="Authorized audio/video source URL to use with a Spotify metadata link.",
    )
    parser.add_argument(
        "--input-audio",
        help="Local authorized audio file to cut/tag instead of downloading a URL.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print detected metadata and split plan without downloading or writing audio.",
    )
    parser.add_argument(
        "--prefer-clean-source",
        action="store_true",
        help="For YouTube inputs, identify tracks and download cleaner matched sources.",
    )
    parser.add_argument(
        "--identify-tracks",
        action="store_true",
        help="For long YouTube inputs without chapters, create a tracks.todo.json candidate list.",
    )
    parser.add_argument(
        "--tracks-file",
        help="JSON track list with start/end/title/artist fields to use for cutting or clean-source download.",
    )
    parser.add_argument(
        "--write-tracks-file",
        help=f"Path for --identify-tracks output. Default: <output>/{DEFAULT_TRACKS_FILE}",
    )
    parser.add_argument(
        "--fallback-original",
        action="store_true",
        help="When clean-source matching fails, fall back to cutting the original YouTube audio.",
    )
    parser.add_argument(
        "--i-have-rights",
        action="store_true",
        help="Confirm the user has rights to save and process this audio.",
    )
    parser.add_argument(
        "--keep-temp",
        action="store_true",
        help="Keep temporary downloaded source files for inspection.",
    )
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    output_dir = Path(args.output).expanduser()
    start = parse_optional_time(args.start)
    end = parse_optional_time(args.end)
    target_time = None if start is not None or args.song else parse_url_time(args.url)
    spotify_meta: SpotifyMeta | None = None

    if not args.dry_run and not args.i_have_rights:
        raise UserError(
            "Refusing to download or write audio without --i-have-rights. "
            "Use this script only for content you are authorized to save."
        )

    source_url = args.url
    if is_spotify_url(args.url):
        spotify_meta = fetch_spotify_meta(args.url)
        if spotify_meta.raw_title:
            print(f"Spotify metadata: {spotify_meta.raw_title}")
        if (
            not args.input_audio
            and start is None
            and end is None
            and target_time is None
            and (not args.source_url or is_youtube_url(args.source_url))
        ):
            return run_spotdl(
                args.url,
                output_dir,
                format_name=args.format,
                song=args.song,
                source_url=args.source_url,
                dry_run=args.dry_run,
            )
        if args.source_url:
            source_url = args.source_url
        elif not args.input_audio:
            raise UserError(
                "Manual Spotify cutting requires --source-url or --input-audio. "
                "For ordinary Spotify downloads, omit --start and --end so spotDL "
                "can handle matching."
            )

    if args.input_audio:
        source_path = Path(args.input_audio).expanduser()
        if not source_path.is_file():
            raise UserError(f"Input audio file not found: {source_path}")
        info = metadata_for_local(source_path, spotify_meta)
        temp_context = None
    else:
        info = dump_ytdlp_info(source_url)
        temp_context = tempfile.TemporaryDirectory(prefix="listen-freely-")
        source_path = Path(temp_context.name) / "not-downloaded-yet"

    if args.tracks_file:
        segments = load_tracks_file(Path(args.tracks_file).expanduser())
    else:
        segments = build_segments(
            info,
            song=args.song,
            start=start,
            end=end,
            target_time=target_time,
            spotify=spotify_meta,
        )

    duration = duration_from_info(info)
    tracks_file_path = (
        Path(args.write_tracks_file).expanduser()
        if args.write_tracks_file
        else output_dir / DEFAULT_TRACKS_FILE
    )

    if args.identify_tracks:
        if has_reliable_split(segments) and not is_long_whole_video(segments, duration):
            write_tracks_file(
                tracks_file_path,
                source_url=args.url,
                info=info,
                segments=segments,
                notes=[
                    "Reliable chapters or timestamps were found.",
                    "Review title and artist fields before using --tracks-file with --prefer-clean-source.",
                ],
            )
            print(f"Wrote tracks file: {tracks_file_path}")
            print_plan(segments)
            if temp_context:
                temp_context.cleanup()
            return 0

        if args.dry_run:
            print(f"Title: {info_title(info, spotify_meta)}")
            artist = info_artist(info, spotify_meta)
            if artist:
                print(f"Artist: {artist}")
            print("No reliable chapters or timestamped track list found.")
            print(
                "Run without --dry-run to download a temporary audio copy, "
                "detect long silence gaps, and write a tracks.todo.json file."
            )
            if temp_context:
                temp_context.cleanup()
            return 0

        output_dir.mkdir(parents=True, exist_ok=True)
        try:
            if not args.input_audio:
                assert temp_context is not None
                source_path = download_audio(source_url, Path(temp_context.name))
            candidates = detect_candidate_segments(source_path, duration=duration)
            write_tracks_file(
                tracks_file_path,
                source_url=args.url,
                info=info,
                segments=candidates,
                notes=[
                    "These are rough silence-based candidate segments, not confirmed song identities.",
                    "Fill in title and artist for each track, adjust start/end if needed, then rerun with --tracks-file.",
                ],
            )
        finally:
            if temp_context and not args.keep_temp:
                temp_context.cleanup()
            elif temp_context and args.keep_temp:
                print(f"Kept temporary files in: {temp_context.name}")

        print(f"Wrote tracks file: {tracks_file_path}")
        print_plan(candidates)
        return 0

    if args.dry_run:
        print(f"Title: {info_title(info, spotify_meta)}")
        artist = info_artist(info, spotify_meta)
        if artist:
            print(f"Artist: {artist}")
        print("Plan:")
        print_plan(segments)
        if args.prefer_clean_source:
            if is_long_whole_video(segments, duration) and not args.tracks_file and not args.song:
                print(
                    "Clean-source plan: this looks like a long video without reliable splits. "
                    "Run --identify-tracks first, then rerun with --tracks-file."
                )
            else:
                print("Clean-source spotDL plan:")
                run_clean_source_download(
                    segments,
                    output_dir,
                    format_name=args.format,
                    dry_run=True,
                )
        if temp_context:
            temp_context.cleanup()
        return 0

    if args.prefer_clean_source:
        if is_long_whole_video(segments, duration) and not args.tracks_file and not args.song:
            if temp_context:
                temp_context.cleanup()
            raise UserError(
                "This looks like a long YouTube video without reliable track splits. "
                "Run --identify-tracks first, edit the generated tracks file, then rerun "
                "with --tracks-file and --prefer-clean-source."
            )
        try:
            result = run_clean_source_download(
                segments,
                output_dir,
                format_name=args.format,
                dry_run=False,
            )
        except UserError as exc:
            if not args.fallback_original:
                if temp_context:
                    temp_context.cleanup()
                raise
            print(f"Clean-source matching failed; falling back to original audio: {exc}")
        else:
            if temp_context:
                temp_context.cleanup()
            return result

    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        if not args.input_audio:
            assert temp_context is not None
            source_path = download_audio(source_url, Path(temp_context.name))

        codec = probe_codec(source_path)
        album = info_title(info, spotify_meta)
        created = [
            export_segment(
                source_path,
                output_dir,
                segment,
                total=len(segments),
                format_name=args.format,
                codec=codec,
                album=album,
            )
            for segment in segments
        ]
    finally:
        if temp_context and not args.keep_temp:
            temp_context.cleanup()
        elif temp_context and args.keep_temp:
            print(f"Kept temporary files in: {temp_context.name}")

    print("Output files:")
    for path in created:
        print(path)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except UserError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1)
