---
name: listen-freely
description: 在用户确认拥有保存权利时，从用户提供的 YouTube 链接、Spotify 元数据链接或本地音频中提取、切分、命名和整理音频，支持章节、时间戳和人工轨道清单。不得绕过 DRM、付费墙或登录保护，也不得把 Spotify 元数据匹配描述成直接下载受保护音频。
---

# 合法音频整理

只处理用户自己上传、公共领域、Creative Commons、已购买或其他明确授权保存的内容。版权状态不清楚时，先询问确认，不运行下载。

## 第一次使用

引导用户阅读 [使用指南.md](使用指南.md)，检查 `yt-dlp`、`ffmpeg`、`ffprobe` 和可选的 `spotdl`。默认输出到当前用户的 `Music` 目录，也可以通过 `--output` 或 `LISTEN_FREELY_OUTPUT` 指定。

## 安全边界

- 不绕过 DRM、付费墙、登录保护、地区限制或平台访问控制。
- Spotify 链接只用于获取元数据和匹配用户有权保存的公开来源；不能声称直接下载 Spotify 受保护音频。
- 不为权利不清楚的商业音乐执行批量下载。
- 不把转码描述成提升源音质；默认尽量保留实际源质量。

## 标准流程

1. 确认 URL 或本地文件，以及用户的保存权利。
2. 确认输出目录、希望提取一首还是全部、文件格式和命名规则。
3. 先用 `--dry-run` 检查计划；长视频没有章节时先用 `--identify-tracks` 生成待确认清单。
4. 用户确认边界后，使用 `--i-have-rights` 执行。
5. 用 `ffprobe` 或脚本输出核对文件数量、时长、格式和命名。

## 常用命令

完整提取有章节或时间戳的视频：

```bash
python3 scripts/extract_music.py "https://www.youtube.com/watch?v=..." \
  --output "/path/to/output" \
  --i-have-rights
```

只提取一首：

```bash
python3 scripts/extract_music.py "URL" --song "歌曲名" --i-have-rights
```

只预览计划：

```bash
python3 scripts/extract_music.py "URL" --dry-run
```

长视频没有章节时：

```bash
python3 scripts/extract_music.py "URL" --identify-tracks --i-have-rights
```

编辑生成的 `tracks.todo.json`，确认标题、歌手与时间边界后，再通过 `--tracks-file` 执行。

## 切分优先级

1. `--song` 指定曲目。
2. `--start` 和 `--end` 人工边界。
3. URL 中的时间戳所在章节。
4. YouTube 正式章节。
5. 描述中的时间戳列表。
6. 没有可靠边界时保留整段，不假装已经正确拆分。

## 质量与命名

默认使用 `source`，避免无意义的二次有损转码。可选格式包括 `opus`、`m4a`、`mp3`、`flac` 和 `wav`。输出名称应清楚表达标题与作者；用户已有命名规范时优先遵循。

## 失败处理

- 工具缺失：给出安装命令，不擅自安装。
- 无可靠时间边界：生成待确认清单或请求用户给时间戳。
- 匹配到的干净来源不确定：不要自动采用；可回退到用户授权的原始音频。
- 下载或转码失败：保留错误原因，不声称文件已生成。

