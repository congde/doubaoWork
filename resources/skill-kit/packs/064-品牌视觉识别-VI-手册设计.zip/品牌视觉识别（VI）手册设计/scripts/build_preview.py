#!/usr/bin/env python3
"""build_preview.py — 生成品牌手册 HTML 预览画廊（单文件、零依赖）

将一目录下的页面图像按文件名排序，组装为单栏纵向 HTML 预览页，
符合 brand-identity-manual 技能的「HTML 预览页策略」：
- 单列纵向，每行一张页面图
- 图片宽度 100% 视口宽，便于全屏查看
- 无装饰性容器或边框，直接展示图像
- 浏览器右键即可保存单页
- 顶部提供分区跳转导航

用法:
    python build_preview.py <图片目录> [--title "品牌名 Visual Identity Manual"]
                             [--out preview.html]
"""
import argparse
import html
import mimetypes
import re
import sys
from pathlib import Path

IMG_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}


def natural_key(s: str):
    """文件名自然排序：P.2 排在 P.10 之前。"""
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


def collect_images(folder: Path):
    files = [p for p in folder.iterdir()
             if p.is_file() and p.suffix.lower() in IMG_EXTS]
    files.sort(key=lambda p: natural_key(p.name))
    return files


def build(folder: Path, title: str, out: Path):
    images = collect_images(folder)
    if not images:
        sys.exit("错误：目录中未找到图像文件（png/jpg/jpeg/webp/gif/bmp）")

    nav_links = " · ".join(
        f'<a href="#p{i}">{html.escape(p.stem)}</a>'
        for i, p in enumerate(images, 1)
    )

    slides = []
    for i, p in enumerate(images, 1):
        mime = mimetypes.guess_type(p)[0] or "image/png"
        slides.append(
            f'    <section id="p{i}">\n'
            f'      <div class="cap">P.{i:02d} · {html.escape(p.stem)}</div>\n'
            f'      <img src="{html.escape(p.name)}" alt="{html.escape(p.stem)}" '
            f'type="{mime}" loading="lazy">\n'
            f'    </section>'
        )

    doc = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title)}</title>
<style>
  * {{ box-sizing: border-box; }}
  body {{ margin: 0; background: #1a1a1a; color: #ddd;
         font-family: -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif; }}
  header {{ position: sticky; top: 0; z-index: 10;
           background: rgba(20,20,20,.92); backdrop-filter: blur(6px);
           padding: 10px 16px; border-bottom: 1px solid #333; }}
  header h1 {{ font-size: 14px; margin: 0 0 6px; font-weight: 600; }}
  nav {{ font-size: 12px; line-height: 1.9; word-break: break-all; }}
  nav a {{ color: #8ab4f8; text-decoration: none; margin-right: 4px; }}
  nav a:hover {{ text-decoration: underline; }}
  section {{ padding: 24px 0; }}
  .cap {{ text-align: center; font-size: 12px; color: #888; margin: 0 0 12px; }}
  img {{ display: block; width: 100%; height: auto; }}
</style>
</head>
<body>
<header>
  <h1>{html.escape(title)}</h1>
  <nav>{nav_links}</nav>
</header>
{chr(10).join(slides)}
</body>
</html>
"""
    out.write_text(doc, encoding="utf-8")
    print(f"已生成预览页：{out}（{len(images)} 页）")


def main():
    ap = argparse.ArgumentParser(description="生成品牌手册 HTML 预览画廊")
    ap.add_argument("folder", help="包含手册页面图像的目录")
    ap.add_argument("--title", default="Brand Identity Manual",
                    help='预览页标题，如 "品牌名 Visual Identity Manual"')
    ap.add_argument("--out", default=None,
                    help="输出 HTML 路径，默认 <图片目录>/preview.html")
    args = ap.parse_args()

    folder = Path(args.folder)
    if not folder.is_dir():
        sys.exit(f"错误：目录不存在 {folder}")
    out = Path(args.out) if args.out else folder / "preview.html"
    build(folder, args.title, out)


if __name__ == "__main__":
    main()
