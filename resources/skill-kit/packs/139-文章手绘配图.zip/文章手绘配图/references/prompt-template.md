# 生图提示词模板

每张图单独生成。根据正文内容替换变量，不要把多张图拼在一起。

```text
Generate one standalone 16:9 horizontal Chinese article illustration.

Visual DNA:
Pure white background (#FFFFFF), completely flat — NEVER tint it gray/cream/beige even when the character is white-filled; a white-filled IP is separated from the white background only by its black outline. Minimalist black hand-drawn line art. Slightly wobbly pen lines. Lots of empty white space. Sparse red/orange/blue handwritten Chinese annotations. Clean absurd product-sketch feeling. No gradients, no shadows, no paper texture, no complex background, no commercial vector style, no PPT infographic look, no cute mascot poster, no children's illustration, no realistic UI.

Recurring IP character required:
Yuanzai, a round hand-drawn doodle character — a round blob body with simple stick limbs, big simple dot eyes, and an exaggerated deadpan blank expression, drawn with clean black outlines (slightly wobbly, not a heavy scribble). Yuanzai must perform the core conceptual action, not decorate the scene. Make Yuanzai serious, deadpan, and slightly bizarre, not cute — a quiet system operator doing absurd but real work.

(If the user specifies the "小白" / white-filled IP, replace the Yuanzai paragraph above with this Xiaobai paragraph:)
Xiaobai (optional white-filled IP): a white-filled hand-drawn character with clean black outlines — NOT solid black, exactly the same shape as the original "小黑" but with white fill instead of black. Its shape can morph into a cylinder, box, funnel, shadow, or machine-internal cavity (keeps the original deformation ability). **Large white circle eyes with small black pupils** (like the original 小黑 eye style), smooth top of head with NO horns and NO ears, tiny thin legs, blank deadpan straight-line mouth expression, slightly uneven hand-drawn body. Xiaobai must perform the core conceptual action, not decorate. Serious, slightly bizarre, not cute. CRITICAL: keep the background pure white #FFFFFF; do NOT tint or darken it to make the white-filled body visible — the black outline alone separates Xiaobai from the white background.

(If the user specifies the "线条人 / 火柴人风 / 极简线条小人" IP, replace with this Stickman paragraph:)
Stickman: an ultra-minimal hand-drawn line figure — pure thin black lines with NO fill, NO shading, NO gradients. Round head with two simple small black dot eyes (no pupil detail), no visible mouth or just a tiny short line, simple straight-line body with stick arms and legs. Smooth round head top with NO decorations (no hats, ears, horns, tails). Looks like a clean whiteboard sketch person — minimal but not sloppy. Stickman must perform the core conceptual action as the main subject, not decorate. Quiet executor, not cute, not bizarre, not expressive — just doing the work.

Theme:
{正文配图主题}

Structure type:
{结构类型：Workflow / 系统局部 / 前后对比 / 角色状态 / 概念隐喻 / 方法分层 / 地图路线 / 小漫画分镜}

Core idea:
{这张图要表达的核心意思}

Composition:
{具体画面：圆仔在哪里、正在做什么、主要物件是什么、信息如何流动}

Suggested elements:
{元素1} / {元素2} / {元素3} / {元素4}

Chinese handwritten labels:
{标注词1} / {标注词2} / {标注词3} / {标注词4} / {可选标注词5}

Color use:
Black for main line art and 圆仔. Orange for main flow/path/arrows. Red only for key warnings/problems/results. Blue only for secondary notes or feedback/system state.

Constraints:
One image explains only one core structure. Keep the main subject around 40%-60% of the canvas. Preserve at least 35% blank white space. Use at most 5-8 short handwritten Chinese labels. Do not write a title in the top-left corner. Do not write the structure type on the image. Do not make it a formal diagram, course slide, or dense explainer. Do not copy prior examples or reuse known case compositions unless explicitly requested; invent a fresh visual metaphor for this specific article. It should be clear but not instructional, interesting but not childish, strange but clean.
```

## 图像编辑提示

去掉左上角标题：

```text
Edit the provided image. Remove only the handwritten title "{要删除的文字}" and its underline from the top-left corner. Fill that area with the same clean white background, matching the surrounding blank paper. Preserve everything else exactly: characters, labels, paths, line style, composition, aspect ratio, and image quality. Do not add any new text or objects.
```

增强怪诞感：

```text
Regenerate this illustration with the same core meaning and simple layout, but make 圆仔 more central to the conceptual action. 圆仔 should be doing the strange work that explains the idea, not standing beside the diagram. Keep it clean, sparse, hand-drawn, and not cute.
```
