#!/usr/bin/env python3
"""
AI生成场景素材图片

用法:
  python3 generate_scene_images.py --scenes scenes.json --output /path/to/assets/
  
scenes.json 格式:
[
  {"name": "scene_01", "prompt": "描述..."},
  {"name": "scene_02", "prompt": "描述..."}
]
"""

import argparse
import json
import os
import sys
import time
import requests

FAL_KEY = os.environ.get('FAL_KEY', '')


def generate_image(prompt: str, width: int = 768, height: int = 1344) -> bytes:
    """用 fal.ai Flux Schnell 生成图片"""
    resp = requests.post(
        'https://fal.run/fal-ai/flux/schnell',
        json={
            'prompt': prompt,
            'image_size': {'width': width, 'height': height},
            'num_images': 1
        },
        headers={'Authorization': f'Key {FAL_KEY}', 'Content-Type': 'application/json'},
        timeout=60
    )

    if resp.status_code != 200:
        raise Exception(f"HTTP {resp.status_code}: {resp.text[:200]}")

    data = resp.json()
    images = data.get('images', [])
    if not images:
        raise Exception("无图片返回")

    img_resp = requests.get(images[0]['url'], timeout=30)
    return img_resp.content


def main():
    if not FAL_KEY:
        print("错误: 请设置 FAL_KEY 环境变量", file=sys.stderr)
        sys.exit(1)

    parser = argparse.ArgumentParser(description='AI生成场景素材')
    parser.add_argument('--scenes', '-s', required=True, help='场景JSON文件')
    parser.add_argument('--output', '-o', required=True, help='输出目录')
    parser.add_argument('--width', type=int, default=768, help='图片宽度')
    parser.add_argument('--height', type=int, default=1344, help='图片高度')
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    with open(args.scenes, 'r', encoding='utf-8') as f:
        scenes = json.load(f)

    for i, scene in enumerate(scenes):
        name = scene['name']
        prompt = scene['prompt']
        print(f"生成 {i+1}/{len(scenes)}: {name}...")

        try:
            img_bytes = generate_image(prompt, args.width, args.height)
            path = os.path.join(args.output, f"{name}.jpg")
            with open(path, 'wb') as f:
                f.write(img_bytes)
            print(f"  ✅ {name}.jpg ({len(img_bytes)//1024}KB)")
        except Exception as e:
            print(f"  ❌ {e}")

        time.sleep(2)

    print(f"\n✅ 全部完成! 共 {len(scenes)} 张")


if __name__ == '__main__':
    main()
