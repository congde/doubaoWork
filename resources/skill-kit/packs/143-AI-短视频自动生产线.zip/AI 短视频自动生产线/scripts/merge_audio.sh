#!/bin/bash
# 合成视频 + 旁白 + BGM
# 用法: bash merge_audio.sh <video.mp4> <narration.mp3> <bgm.mp3> <output.mp4>

VIDEO="${1:?用法: merge_audio.sh video.mp4 narration.mp3 bgm.mp3 output.mp4}"
NARRATION="${2:?缺少旁白文件}"
BGM="${3:?缺少BGM文件}"
OUTPUT="${4:?缺少输出路径}"
NARR_VOL="${5:-1.0}"
BGM_VOL="${6:-0.12}"

ffmpeg -y \
  -i "$VIDEO" \
  -i "$NARRATION" \
  -i "$BGM" \
  -filter_complex "[1:a]volume=${NARR_VOL}[narr];[2:a]volume=${BGM_VOL}[bgm];[narr][bgm]amix=inputs=2:duration=shortest[aout]" \
  -map 0:v -map "[aout]" -c:v copy -c:a aac -shortest "$OUTPUT"

echo "✅ 输出: $OUTPUT"
ls -lh "$OUTPUT"
