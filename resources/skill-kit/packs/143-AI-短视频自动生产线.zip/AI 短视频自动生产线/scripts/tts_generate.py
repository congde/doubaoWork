#!/usr/bin/env python3
"""
TTS 旁白生成：使用克隆声音生成语音

用法:
  python3 tts_generate.py --voice-id VOICE_ID --text "旁白文案" --output narration.mp3
  python3 tts_generate.py --voice-id VOICE_ID --file script.txt --output narration.mp3
"""

import argparse
import json
import os
import sys
import time
import requests

FAL_KEY = os.environ.get('FAL_KEY', '')


def generate_tts(text: str, voice_id: str, output: str):
    # 提交任务
    resp = requests.post(
        'https://queue.fal.run/fal-ai/minimax/speech-02-hd',
        json={
            'text': text,
            'voice_setting': {
                'voice_id': voice_id,
                'speed': 1.0,
                'vol': 1.0,
                'pitch': 0
            },
            'language_boost': 'Chinese'
        },
        headers={'Authorization': f'Key {FAL_KEY}', 'Content-Type': 'application/json'},
        timeout=30
    )
    data = resp.json()
    request_id = data.get('request_id', '')
    print(f"任务已提交: {request_id}")

    # 轮询等结果
    for i in range(30):
        time.sleep(5)
        result = requests.get(
            f'https://queue.fal.run/fal-ai/minimax/requests/{request_id}',
            headers={'Authorization': f'Key {FAL_KEY}'},
            timeout=15
        ).json()

        if 'audio' in result:
            audio_url = result['audio']['url']
            audio = requests.get(audio_url, timeout=30)
            with open(output, 'wb') as f:
                f.write(audio.content)
            print(f"✅ 旁白已保存: {output} ({len(audio.content)//1024}KB)")
            return

        status = result.get('status', 'unknown')
        print(f"  等待中... ({status})")

    print("❌ 超时，请重试", file=sys.stderr)
    sys.exit(1)


def main():
    if not FAL_KEY:
        print("错误: 请设置 FAL_KEY 环境变量", file=sys.stderr)
        sys.exit(1)

    parser = argparse.ArgumentParser(description='TTS 旁白生成')
    parser.add_argument('--voice-id', '-v', required=True, help='Voice ID')
    parser.add_argument('--text', '-t', help='旁白文案')
    parser.add_argument('--file', '-f', help='文案文件路径')
    parser.add_argument('--output', '-o', required=True, help='输出MP3路径')
    args = parser.parse_args()

    text = args.text
    if args.file:
        with open(args.file, 'r', encoding='utf-8') as f:
            text = f.read()

    if not text:
        print("错误: 需要 --text 或 --file", file=sys.stderr)
        sys.exit(1)

    generate_tts(text, args.voice_id, args.output)


if __name__ == '__main__':
    main()
