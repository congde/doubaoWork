#!/usr/bin/env python3
"""
声音克隆：上传音频样本 → 获取 Voice ID

用法:
  python3 voice_clone.py --audio /path/to/sample.mp3
"""

import argparse
import json
import os
import sys
import requests

FAL_KEY = os.environ.get('FAL_KEY', '')


def upload_to_fal(filepath: str) -> str:
    """上传文件到 fal 存储"""
    init = requests.post(
        'https://rest.alpha.fal.ai/storage/upload/initiate',
        json={'content_type': 'audio/mpeg', 'file_name': os.path.basename(filepath)},
        headers={'Authorization': f'Key {FAL_KEY}'},
        timeout=15
    )
    data = init.json()
    with open(filepath, 'rb') as f:
        requests.put(data['upload_url'], data=f.read(), headers={'Content-Type': 'audio/mpeg'}, timeout=30)
    return data['file_url']


def clone_voice(audio_url: str) -> dict:
    resp = requests.post(
        'https://fal.run/fal-ai/minimax/voice-clone',
        json={'audio_url': audio_url},
        headers={'Authorization': f'Key {FAL_KEY}', 'Content-Type': 'application/json'},
        timeout=60
    )
    return resp.json()


def main():
    if not FAL_KEY:
        print("错误: 请设置 FAL_KEY 环境变量", file=sys.stderr)
        sys.exit(1)

    parser = argparse.ArgumentParser(description='声音克隆')
    parser.add_argument('--audio', '-a', required=True, help='音频样本文件路径')
    args = parser.parse_args()

    print("上传音频...")
    audio_url = upload_to_fal(args.audio)
    print(f"上传完成: {audio_url}")

    print("克隆声音中...")
    result = clone_voice(audio_url)

    print(json.dumps(result, ensure_ascii=False, indent=2))

    if 'custom_voice_id' in result:
        print(f"\n✅ Voice ID: {result['custom_voice_id']}")
        print("⚠️ 7天内需调用一次TTS否则声音被删")


if __name__ == '__main__':
    main()
