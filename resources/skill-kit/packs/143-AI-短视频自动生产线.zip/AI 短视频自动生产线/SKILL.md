---
name: video-skill
description: >
  AI短视频自动生产线。一句话生成竖屏短视频：声音克隆旁白 + AI生成素材 + 赛博科技风动画 + BGM混合。
  触发场景：用户说"做个短视频""生成视频""录一条视频""帮我做个竖屏视频"
  "AI短视频""赛博风视频""用我的声音做视频"等。
  完整流程：写文案 → 声音克隆TTS → AI生成场景素材 → Remotion渲染 → ffmpeg合成音频 → 输出成品。
---

# AI短视频自动生产线

一句话指令 → 文案 → 声音克隆旁白 → AI场景素材 → Remotion渲染 → 成品视频。

## 环境变量（必需）

本 Skill 不包含任何 API Key。使用前请在自己的环境里配置对应服务商密钥，例如：

```bash
export FAL_KEY="<YOUR_FAL_KEY>"
export GEMINI_API_KEY="<YOUR_GEMINI_API_KEY>"
```

不要把真实密钥写进 Skill 文件或提交到仓库。

## 项目路径

Remotion 项目: `<YOUR_REMOTION_PROJECT_DIR>`

## 完整流程

### Step 0: 目标优先与兜底路线

用户要的是可用 MP4 成品，不是解释某条流水线为什么失败。优先按本 skill 的 Remotion 流程执行；如果 Remotion/video-skill 在渲染、音频接入、时长对齐、返修上反复卡住，不要继续死磕，直接切到 HyperFrames：用 HTML/CSS/GSAP 生成画面动画，再用显式 audio track 或 ffmpeg 合成旁白+BGM，最后仍按同一交付门槛验音轨并发附件。

### Step 1: 写视频文案

按短视频节奏写文案，要求：
- 每段2-4秒的口播长度
- 开头3秒必须抓住注意力
- 中间有数据/案例等高潮点
- 结尾引导关注
- 总时长控制在 20-60秒

**文案模板：**
```
场景1 (title, 3s): 开场自我介绍/hook
场景2 (content, 2-3s): 引出话题
场景3 (content, 4s): 核心信息1
场景4 (highlight, 3s): 数据亮点
场景5 (content, 4s): 核心信息2
场景6 (highlight, 3s): 震撼数据
场景7 (content, 3s): 总结/感悟
场景8 (outro, 4s): CTA引导关注
```

### Step 2: 声音克隆 + TTS

使用 fal.ai MiniMax 语音克隆生成旁白。不要用 Hermes 通用 `text_to_speech` 直接生成中文短视频旁白；该工具可能使用非中文默认 voice，导致中文只读关键词、漏字或语音不可懂。

**克隆声音（首次或刷新）：**
```bash
python3 {baseDir}/scripts/voice_clone.py --audio /path/to/sample.mp3
```

**生成旁白：**
```bash
python3 {baseDir}/scripts/tts_generate.py --voice-id VOICE_ID --text "旁白文案" --output narration.mp3
```

关键参数：
- `voice_setting.voice_id`: 克隆后获得的 Voice ID
- `language_boost`: "Chinese"
- `speed`: 1.0（正常语速）

⚠️ **声音7天不用会被删除**，需定期调用 TTS 续命。

当前 Voice ID: `<YOUR_VOICE_ID>`（通过 voice_clone.py 克隆获取；不要把私人 voice_id 写进公开版本）

### Step 3: AI生成场景素材

每个场景生成一张匹配的背景图。用户明确要求：视频里的核心视觉素材要优先用 imagegen / 图片生成模型生成，不要用 SVG/纯矢量块/简单几何图当主素材；SVG 只可用于轻量 UI 装饰、箭头、线框、标签或遮罩，不能替代主体画面，因为纯 SVG 容易显得不美观、廉价。

```bash
python3 {baseDir}/scripts/generate_scene_images.py --scenes scenes.json --output /path/to/assets/
```

**图片生成优先级：**
1. fal.ai Flux Schnell（快速，免费额度多）
2. Gemini Image API（质量高，额度有限）

**图片规格：** 768x1344（9:16竖屏），赛博风格提示词模板：

```
[场景描述], cyberpunk style, dark background, neon blue and green glowing,
vertical portrait orientation, cinematic lighting
```

### Step 4: 更新 Remotion 场景数据

编辑 `src/data/scenes-data.ts`：

```typescript
export const scenesData: SceneData[] = [
  {
    type: 'title',        // title | content | highlight | outro
    text: '场景文字',
    startFrame: 0,        // 开始帧 (30fps)
    durationFrames: 90,   // 持续帧数 (90帧=3秒)
    effect: 'glitch',     // glitch | maskReveal | slam | fadeIn
    bgImage: 'scene_01.jpg',  // 背景图文件名
  },
  // ...更多场景
];
```

**帧数计算：** 30fps，所以 1秒=30帧，3秒=90帧，4秒=120帧

### Step 5: Remotion 渲染

优先在 Remotion composition 内显式加入声音轨：

```tsx
import { Audio, Sequence, staticFile } from 'remotion';

<Audio src={staticFile('audio/narration.mp3')} volume={1} />
<Audio src={staticFile('bgm/cyberpunk.mp3')} volume={0.12} />
<Sequence from={scene.startFrame} durationInFrames={Math.min(20, scene.durationFrames)}>
  <Audio src={staticFile('sfx/slam.mp3')} volume={0.45} />
</Sequence>
```

然后渲染：

```bash
cd <YOUR_REMOTION_PROJECT_DIR>
npx remotion render src/index.ts WireframeVideo out/final.mp4 --codec=h264
```

输出: 1080x1920 竖屏 H.264 视频，必须包含音轨。

### Step 6: 兜底：ffmpeg 合成音频

```bash
ffmpeg -y \
  -i out/video.mp4 \
  -i public/audio/narration.mp3 \
  -i public/bgm/cyberpunk.mp3 \
  -filter_complex "[1:a]volume=1.0[narr];[2:a]volume=0.12[bgm];[narr][bgm]amix=inputs=2:duration=shortest[aout]" \
  -map 0:v -map "[aout]" -c:v copy -c:a aac -shortest out/final.mp4
```

参数说明：
- 旁白音量 1.0（满音量）
- BGM音量要先看素材响度：如果 BGM 源文件本身很低（例如 `mean_volume < -35 dB`），`0.08–0.12` 会几乎听不见。先用 `ffmpeg -af volumedetect` 测响度；用户反馈“BGM 太小/听不见”时，沿用已验证方式：BGM 至少从 `volume=0.12` 起步，必要时先放大到 `3–6x`，再与旁白混合；目标是能明显听到氛围但不盖住人声。
- `-shortest`: 以最短轨道为准

### 发送视频

发送前必须验证输出文件存在音轨：

```bash
ffprobe -v error -show_entries stream=index,codec_type,codec_name,channels,sample_rate:format=duration,size -of json out/final.mp4
```

确认存在 `codec_type=audio` 后，通过 Hermes Telegram 发送附件：

```bash
python <HERMES_HOME>/scripts/media_outbox_prepare.py out/final.mp4
```

把脚本输出的 `MEDIA:<HERMES_HOME>/media_outbox/...mp4` 放进最终回复。不要直接引用非 allowlist 的本地路径，否则 Telegram 可能收不到附件。

## 视觉风格

- **背景色**: #0a0a0f（深黑）
- **主色**: #00ff88（霓虹绿）
- **强调色**: #ff3366（霓虹粉）
- **字体**: 无衬线，粗体
- **效果**: 赛博线框批注体、glitch故障、mask揭示

## BGM 资源

- 赛博风: `public/bgm/cyberpunk.mp3`

## 参考文件

- `references/remotion-audio-checklist.md` — Remotion 视频交付前的声音接入、时长对齐、ffprobe 验证和 ffmpeg 兜底清单。
- `references/chinese-tts-bgm-remix-debug.md` — 中文 TTS 可懂度抽查、错误 TTS 识别特征、BGM/SFX 重新混音模板。
- `references/video-fallback-delivery-lessons.md` — video-skill 失败时切 HyperFrames 的兜底策略，以及 Telegram 附件必须真实发送的复盘。
- `references/imagegen-video-materials-retrofit.md` — 用户反馈“不美观/不要 SVG 主体素材”时，用 imagegen 重做场景图并替换进 Remotion/HyperFrames 的返修流程。

## 踩坑提醒

1. **内存**: Remotion 渲染需要至少 4G 可用内存，渲染前清理缓存
2. **fal.ai TTS**: 用 `queue.fal.run`（异步队列），需要轮询等结果
3. **voice_setting 嵌套**: voice_id 必须在 `voice_setting: {voice_id: xxx}` 内传入
4. **图片格式**: Remotion 的 `<Img>` 组件支持 jpg/png，用 staticFile() 引用
5. **帧数对齐**: 场景总帧数要 >= 旁白时长(秒) × 30
6. **Gemini 429**: 图片生成额度容易用完，优先用 fal.ai Flux
7. **成品必须有声音**: 交付前用 `ffprobe` 验证 final mp4 至少有一个 audio stream；如果 Remotion 输出缺音轨，立刻用 Step 6 的 ffmpeg 兜底合成。
8. **交付不是发路径**: Telegram 交付必须是原生附件。先用 `<HERMES_HOME>/scripts/media_outbox_prepare.py` 准备 outbox 路径；如果最终回复只显示路径或用户没收到，立即用 `send_message(action='send', target='telegram', message='MEDIA:<HERMES_HOME>/media_outbox/xxx.mp4')` 重发，并记录 message_id。
9. **用户反馈“语音读得不对”时先判定 TTS，不要只解释**: 先检查原旁白/最终 MP4 的 ASR 可懂度，再判断是文案问题还是 TTS 问题。若 ASR 只剩 `ChatGPT/AI/Agent` 等关键词，基本是 TTS voice/language 配置错；重做 MiniMax TTS，并按 `references/chinese-tts-bgm-remix-debug.md` 重新混 BGM/SFX。
10. **视频主体素材优先 imagegen**: 视频里的场景图、主视觉、背景环境、关键道具和封面级画面要用 imagegen/图片生成模型生成；不要用 SVG、简单色块、纯几何矢量来冒充主体素材。SVG 只适合做轻量 UI 装饰、线条、箭头、标签、遮罩或动效辅助，不能作为主画面交付。用户说“不美观/用 imagegen 生成所需素材”时，按 `references/imagegen-video-materials-retrofit.md` 直接返修：生成多张 9:16 主体场景图，替换进视频，再重新混音、验收并发原生附件。
