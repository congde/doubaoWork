# video-skill 脱敏版说明

此压缩包已做脱敏处理：

- 不包含真实 API Key；
- 私人 Voice ID 已替换为 `<YOUR_VOICE_ID>`；
- 本机私有绝对路径已替换为占位路径；
- Telegram/media_outbox 真实路径已替换为 `<HERMES_HOME>`；
- 使用前请在自己的环境变量中配置 `FAL_KEY` / `GEMINI_API_KEY` 等密钥。

安装方式：把 `video-skill/` 放到你的 Hermes skills 目录下，或按 Hermes skill 安装流程导入。
