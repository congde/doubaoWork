# Video fallback + Telegram delivery lessons

## Trigger

Use these notes when a generated/返修 video task starts failing around Remotion/video-skill audio, render timing, or delivery, or when the user complains that a `MEDIA:` path appeared as text instead of an actual Telegram attachment.

## Workflow correction

The user's priority is the finished MP4. Do not stop at explaining why `video-skill` or Remotion is stuck.

Fallback order:

1. Try the normal `video-skill` path: script → MiniMax/voice-clone TTS → Remotion visual render → ffmpeg narration+BGM/SFX mux → ffprobe verification.
2. If Remotion/video-skill repeatedly fails or becomes slower than a rebuild, switch to HyperFrames:
   - create an HTML/CSS/GSAP 9:16 composition;
   - keep audio as explicit `<audio data-start data-duration data-track-index ...>` tracks when possible;
   - otherwise render visuals only and use ffmpeg to mux narration + BGM/SFX afterward;
   - validate with HyperFrames lint/validate/inspect when using that pipeline;
   - still run `ffprobe` on the final MP4 before delivery.
3. Preserve the same quality gate regardless of pipeline: readable vertical frame, no obvious crop/corruption, AAC audio stream, narration not truncated.

## TTS/BGM lesson from session

A wrong/general TTS voice can generate an MP3 that has audio but only reads English keywords such as `ChatGPT`, `AI`, `Agent` while dropping Chinese. When the user says the voice reads incorrectly:

- run ASR/transcription on the source narration or final MP4;
- if Chinese is missing, regenerate TTS with the MiniMax voice-clone path and `language_boost: Chinese`;
- inspect duration with ffprobe and resize scene/composition duration to cover the narration;
- if user provides an MP3 afterward, treat it as likely BGM and remix with existing visuals+narration using ffmpeg, not as a replacement for narration unless explicitly stated.

## Telegram delivery lesson

For this user, delivery means a native Telegram attachment, not a visible file path.

Safe pattern:

```bash
python <HERMES_HOME>/scripts/media_outbox_prepare.py out/final.mp4
# returns MEDIA:<HERMES_HOME>/media_outbox/final-xxxx.mp4
```

Then either:

- put only that `MEDIA:` line in the final response when the gateway reliably attaches it; or
- if the user says it showed as a path / did not arrive, immediately use `send_message(action='send', target='telegram', message='MEDIA:<HERMES_HOME>/media_outbox/....mp4')` after validating the outbox path.

Do not apologize with another path-only message. Re-send the actual attachment and include a short confirmation with the Telegram message id if available. If the user replies “可以了/收到了”, treat that as confirmation that the native attachment delivery path worked and preserve this outbox + send_message pattern for future video deliveries.
