# Remotion 成品声音验收清单

用于短视频生产线交付前的固定检查，避免只出画面没有声音。

## 1. Composition 内优先显式声明音轨

```tsx
import {Audio, Sequence, staticFile} from 'remotion';

<Audio src={staticFile('audio/narration.mp3')} volume={1} />
<Audio src={staticFile('bgm/cyberpunk.mp3')} volume={0.12} />

<Sequence from={scene.startFrame} durationInFrames={Math.min(20, scene.durationFrames)}>
  <Audio src={staticFile('sfx/slam.mp3')} volume={0.45} />
</Sequence>
```

不要只依赖视频素材自带声音；旁白、BGM、音效都应该作为独立音轨接入。

## 2. 总时长必须覆盖旁白

```bash
ffprobe -v error -show_entries format=duration -of default=nk=1:nw=1 public/audio/narration.mp3
```

把秒数换成帧数：

```text
frames = ceil(duration_seconds * 30)
```

`Composition.durationInFrames` 或场景总帧数必须 >= 旁白帧数，否则声音会被截断。

## 3. Remotion 渲染后必须验音轨

```bash
ffprobe -v error \
  -show_entries stream=index,codec_type,codec_name,channels,sample_rate:format=duration,size \
  -of json out/final.mp4
```

必须看到至少一个：

```json
{"codec_type":"audio"}
```

如果没有 audio stream，不能交付。

## 4. ffmpeg 兜底合成

当 Remotion 输出没有音轨时，用 ffmpeg 兜底：

```bash
ffmpeg -y \
  -i out/video.mp4 \
  -i public/audio/narration.mp3 \
  -i public/bgm/cyberpunk.mp3 \
  -filter_complex "[1:a]volume=1.0[narr];[2:a]volume=0.12[bgm];[narr][bgm]amix=inputs=2:duration=shortest[aout]" \
  -map 0:v -map "[aout]" -c:v copy -c:a aac -shortest out/final.mp4
```

再次运行 ffprobe 验证。

## 5. Telegram 交付

```bash
python <HERMES_HOME>/scripts/media_outbox_prepare.py out/final.mp4
```

最终回复使用脚本输出的 `MEDIA:<HERMES_HOME>/media_outbox/...mp4`。