# 中文 TTS 可懂度与 BGM 重混排查记录

适用场景：短视频已生成但用户反馈“语音读得不对”“中文旁白怪”“重新加 BGM”。

## 关键教训

1. **有音轨不等于旁白正确**
   - `ffprobe` 只能确认 MP4 是否含 audio stream。
   - 中文短视频还要抽查 TTS 可懂度，尤其是使用通用 TTS、英文默认 voice、或换过供应商后。

2. **错误 TTS 的典型表现**
   - Whisper/ASR 只识别出 `ChatGPT / AI / Agent` 等英文关键词。
   - 中文大段被吞掉、漏读、读成无意义片段。
   - 这种情况通常不是文案逻辑问题，而是 TTS voice/language 配置不适合中文。

3. **正确处理顺序**
   - 保留/整理原始中文旁白文案。
   - 用 video-skill 的 MiniMax voice-clone TTS 重新生成旁白，不要用 Hermes 通用 `text_to_speech` 代替。
   - 用 `ffprobe` 获取新旁白时长。
   - 必要时按旁白时长调整 Remotion composition/scene duration，避免截断。
   - 抽查 ASR 转写，确认中文内容大体完整。
   - 再混入 BGM/SFX，并重新验证最终 MP4。

## 可懂度抽查命令

如果环境里有 `faster_whisper`：

```bash
python3 - <<'PY'
from faster_whisper import WhisperModel
path='public/audio/narration.mp3'  # 或 out/final.mp4
model=WhisperModel('base', device='cpu', compute_type='int8')
segments, info = model.transcribe(path, language='zh', vad_filter=False)
print('duration', info.duration)
for s in segments:
    print(f'[{s.start:.2f}-{s.end:.2f}] {s.text}')
PY
```

判断标准：
- 不是要求逐字完全一致；中文 ASR 会把“粘贴/沾贴”“ChatGPT/刺GPT”等听错。
- 重点看是否大段中文完整、语义连贯、没有只剩英文关键词。
- 如果某个词容易被 TTS/ASR 听成尴尬同音词，改文案用更稳的说法，例如把“草拟”改成“起草”。

## BGM/SFX 重混模板

当画面已可用，只需要重新混音，不必重渲染视频。用原视频的视频流 + 新旁白 + 循环 BGM + SFX 重新 mux：

```bash
ffmpeg -y \
  -i out/source-video.mp4 \
  -i public/audio/narration.mp3 \
  -stream_loop -1 -i public/bgm/cyberpunk.mp3 \
  -i public/sfx/glitch.mp3 \
  -i public/sfx/draw.mp3 \
  -i public/sfx/slam.mp3 \
  -filter_complex "[1:a]volume=1.0[narr];[2:a]atrim=0:VIDEO_SECONDS,asetpts=N/SR/TB,volume=0.10[bgm];[3:a]volume=0.22,adelay=0|0[s0];[4:a]volume=0.16,adelay=11000|11000[s1];[5:a]volume=0.20,adelay=22000|22000[s2];[narr][bgm][s0][s1][s2]amix=inputs=5:duration=first:normalize=0,alimiter=limit=0.95[a]" \
  -map 0:v:0 -map "[a]" -c:v copy -c:a aac -b:a 192k -shortest out/final-with-bgm.mp4
```

音量建议：
- 旁白：`1.0`
- **BGM 先测响度，不要盲用 `0.08–0.12`**。如果源 BGM 本身很小，用户会觉得“听不见”。先跑：
  ```bash
  ffmpeg -i public/bgm/user-bgm.mp3 -af volumedetect -f null - 2>&1 | grep -E 'mean_volume|max_volume'
  ```
- 常规 BGM：`0.10–0.15`；用户明确说上版 BGM 太小时，优先用 `0.12` 起步，并按源文件响度把 BGM 预放大到 `3–6x`。
- 源 BGM `mean_volume < -35 dB`：按“放大后再低音量混”的方式处理，例如 `volume=4.0,atrim=...,afade=...`；目标是听得到氛围但不盖人声。
- 用户发来的 MP3 如果是 BGM，推荐本次验证过的稳定模板：
  ```bash
  ffmpeg -y \
    -i out/source-video.mp4 \
    -i public/audio/narration.mp3 \
    -i /path/to/user-bgm.mp3 \
    -filter_complex "[1:a:0]volume=1.0,aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo[narr];[2:a:0]volume=0.12,atrim=0:VIDEO_SECONDS,afade=t=out:st=FADE_START:d=4,aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo[bgm];[narr][bgm]amix=inputs=2:duration=longest:normalize=0[aout]" \
    -map 0:v:0 -map "[aout]" -c:v copy -c:a aac -b:a 192k -ar 48000 -ac 2 -movflags +faststart out/final.mp4
  ```
- 如果按 `volume=0.12` 仍听不见，把 BGM filter 调成 `volume=3.0` 到 `volume=6.0` 后再试，而不是只说“已经加了 BGM”。
- SFX：`0.16–0.25`，只点缀场景切换。
- 加 `alimiter` 防止混音爆音；最终用耳感/用户确认闭环，不只看 ffprobe。

## 交付前固定验证

```bash
ffprobe -v error \
  -show_entries stream=index,codec_type,codec_name,channels,sample_rate,width,height:format=duration,size \
  -of json out/final-with-bgm.mp4
```

必须确认：
- 有 video stream；
- 有 audio stream；
- 时长不短于旁白有效时长；
- 若用户刚反馈 TTS 异常，必须再做一次 ASR 可懂度抽查。
