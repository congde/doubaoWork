# Imagegen 主体素材重做 / 返修视频流程

## 触发场景

用户反馈视频“不美观”、像 SVG/简单矢量/色块拼出来，或明确要求“用 imagegen 生成所需素材”。这类反馈说明问题不只是排版，而是主体视觉素材质量不够。

## 核心原则

- 视频主体素材（场景图、主视觉、背景环境、关键道具、封面级画面）优先用 imagegen/图片生成模型生成。
- 不要用 SVG、纯几何、简单线框、色块当主画面交付。
- SVG/矢量只适合做 HUD、箭头、标签、遮罩、线条和轻量 UI 装饰。
- 如果已经有可用旁白和时间轴，优先“替换视觉素材 + 重新渲染/混音”，不要重写整条内容链路。

## 快速返修流程

1. 保留已验证过的中文旁白、BGM 和视频文案。
2. 按场景生成 6-8 张 9:16 主体素材，每张 prompt 要对应一个明确叙事节点。
3. 将图片放到 Remotion public 目录，例如：
   ```bash
   mkdir -p public/assets/imggen
   cp /path/to/generated_01.png public/assets/imggen/scene_01.png
   ```
4. 在 Remotion 场景数据里为每个 scene 增加 `img` 字段，例如：
   ```ts
   {from: 0, duration: 330, title: 'ChatGPT 又偷偷变强了', img: 'assets/imggen/scene_01.png'}
   ```
5. 用 `<Img src={staticFile(scene.img)} />` 作为全屏主体画面：
   - `objectFit: 'cover'`
   - 加轻微 Ken Burns：`scale 1.04 → 1.13`、缓慢 `x/y` 漂移
   - 加暗色渐变遮罩，保证文字可读
   - HUD/线条/标签只做前景装饰
6. 渲染视觉版 MP4，再用 ffmpeg 重新混入已验证旁白和 BGM。
7. 抽帧检查 3 个以上时间点，确认画面明显更美观、文字清晰、无裁切。
8. 用 `media_outbox_prepare.py` 准备附件；如果用户要求“直接发附件”，用 `send_message` 发送原生 Telegram 附件并记录 message_id。

## Remotion 图片层示例

```tsx
<Img
  src={staticFile(scene.img)}
  style={{
    position: 'absolute',
    inset: -80,
    width: 'calc(100% + 160px)',
    height: 'calc(100% + 160px)',
    objectFit: 'cover',
    transform: `translate(${imageX}px, ${imageY}px) scale(${imageScale})`,
    filter: 'saturate(1.18) contrast(1.08) brightness(.78)',
  }}
/>
<div style={{position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,.50), rgba(0,0,0,.08) 34%, rgba(0,0,0,.66) 68%, rgba(0,0,0,.94))'}} />
```

## Prompt 模板

```text
Vertical 9:16 cinematic [场景内容], premium cyberpunk tech editorial visual,
dark background, neon green and electric blue lighting, realistic 3D depth,
high-end composition, no readable text, no logo, no watermark
```

场景 prompt 要避免生成可读文字，真正的中文标题和字幕交给 Remotion/HyperFrames 叠加，这样可控且清晰。

## 验收要点

- 主体画面来自 imagegen，不是 SVG/纯矢量。
- 标题和副标题在 1080x1920 上清晰可读。
- BGM 实际可听见，不能只看 ffprobe。
- 最终 MP4 有 h264 video + AAC audio，采样率/声道正常。
- Telegram 交付是原生附件，不是路径文本。
