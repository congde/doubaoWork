---
name: xuejian-breakout-chat-image
description: Call the Breakout/Wenwen OpenAI-compatible chat completions endpoint (`https://breakout.wenwen-ai.com/v1/chat/completions`) with model `gpt-image-2`. Use when the user wants to wrap or use the provided Breakout curl request, customize the Bearer API key, customize the user message content/prompt, or generate images through the chat completions API instead of the Images API.
---

# Xuejian Breakout Chat Image

## Overview

Use this skill to call Breakout's OpenAI-compatible `/v1/chat/completions` endpoint with `gpt-image-2`. Prefer the bundled script so API keys, JSON payloads, response archiving, text extraction, image URL downloads, and base64 image decoding stay consistent.

## Quick Start

PowerShell:

```powershell
python D:\xuejianProjects\xuejian-skills\skills\xuejian-breakout-chat-image\scripts\breakout_chat_image.py --api-key "sk-xxx" --content "draw a cat"
```

Environment variable:

```powershell
$env:BREAKOUT_API_KEY="sk-xxx"
python D:\xuejianProjects\xuejian-skills\skills\xuejian-breakout-chat-image\scripts\breakout_chat_image.py --content "draw a cat"
```

Prompt file with the default skill-local output folder:

```powershell
python scripts\breakout_chat_image.py --api-key "sk-xxx" --content-file prompt.txt
```

## Workflow

1. Turn the user's request into the exact `messages[0].content` value unless the user asks for prompt rewriting.
2. Run `scripts/breakout_chat_image.py` with `--content` or `--content-file`.
3. Pass the API key with `--api-key` or `BREAKOUT_API_KEY`; never print the key.
4. Wait for the slow generation request to complete. The default timeout is 900 seconds.
5. Inspect the script summary. It always saves the raw response JSON into this skill's `output/` folder by default. If the response includes text, image URLs, data URLs, or base64 image fields, the script saves those into the same folder.
6. Report saved file paths and any API error message. Do not paste full raw JSON unless the user asks.

## Script Options

```text
input:
  prompt_arg              Positional shorthand for --content
  --content TEXT          User message content/prompt
  --content-file FILE     Read user message content from a UTF-8 file
  --system TEXT           Optional system message

api:
  --api-key KEY           Bearer token; can also set BREAKOUT_API_KEY or XUEJIAN_BREAKOUT_API_KEY
  --api-url URL           Default: https://breakout.wenwen-ai.com/v1/chat/completions
  --model MODEL           Default: gpt-image-2
  --timeout SECS          Default: 900
  --retries N             Default: 2 for transient 5xx / 429 / network failures
  --retry-delay SECS      Default: 20

output:
  --output-dir DIR        Default: this skill's output folder
  --prefix NAME           Output filename prefix
  --no-download           Do not download discovered HTTP image URLs
```

## Notes

- The request body mirrors the provided curl:

```json
{
  "model": "gpt-image-2",
  "messages": [
    {
      "role": "user",
      "content": "draw a cat"
    }
  ]
}
```

- Use this skill for the Breakout chat-completions endpoint. Use `xuejian-gpt-image-2` for the separate Images API (`/v1/images/generations`).
- If the API returns only text, deliver the text file or summary. If it returns an image URL or base64 image, deliver the saved image path from `output/`.
- If all attempts fail, report the saved `*_error.json` path from `output/`; it includes the error payload and request payload without the API key.
- For non-English prompts, pass UTF-8 text directly through `--content` in PowerShell, or use `--content-file` when the prompt is multi-line.
