#!/usr/bin/env python3
"""Call Breakout chat completions with customizable API key and content."""

from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import re
import sys
import time
from pathlib import Path
from typing import Any
from urllib import error, request

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

DEFAULT_API_URL = "https://breakout.wenwen-ai.com/v1/chat/completions"
DEFAULT_MODEL = "gpt-image-2"
SKILL_DIR = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_DIR = SKILL_DIR / "output"
DEFAULT_TIMEOUT = 900
DEFAULT_RETRIES = 2
DEFAULT_RETRY_DELAY = 20

DATA_URL_RE = re.compile(r"data:(image/[a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=\s]+)")
MARKDOWN_IMAGE_RE = re.compile(r"!\[[^\]]*\]\((https?://[^)\s]+)\)")
HTTP_URL_RE = re.compile(r"https?://[^\s)\"']+")


class ApiRequestError(Exception):
    """API request failed with details safe to save and print."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        payload: Any | None = None,
        retryable: bool = False,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload
        self.retryable = retryable


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Call Breakout/Wenwen chat completions with gpt-image-2."
    )
    parser.add_argument("prompt_arg", nargs="?", help="Single prompt shorthand.")
    parser.add_argument("--content", help="User message content/prompt.")
    parser.add_argument("--content-file", help="Read user message content from a UTF-8 file.")
    parser.add_argument("--system", help="Optional system message.")
    parser.add_argument(
        "--api-key",
        default=os.environ.get("BREAKOUT_API_KEY") or os.environ.get("XUEJIAN_BREAKOUT_API_KEY") or "",
        help="Bearer token. Can also set BREAKOUT_API_KEY or XUEJIAN_BREAKOUT_API_KEY.",
    )
    parser.add_argument("--api-url", default=DEFAULT_API_URL, help="Chat completions endpoint.")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="Model name.")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT, help="Request timeout seconds.")
    parser.add_argument("--retries", type=int, default=DEFAULT_RETRIES, help="Retry count for transient API/network failures.")
    parser.add_argument("--retry-delay", type=int, default=DEFAULT_RETRY_DELAY, help="Seconds to wait between retries.")
    parser.add_argument(
        "--output-dir",
        default=str(DEFAULT_OUTPUT_DIR),
        help="Directory for response files. Defaults to this skill's output folder.",
    )
    parser.add_argument("--prefix", default="breakout", help="Filename prefix.")
    parser.add_argument("--no-download", action="store_true", help="Do not download HTTP image URLs.")
    return parser.parse_args()


def load_content(args: argparse.Namespace) -> str:
    parts: list[str] = []
    if args.content_file:
        parts.append(Path(args.content_file).read_text(encoding="utf-8").strip())
    if args.content:
        parts.append(args.content.strip())
    if args.prompt_arg:
        parts.append(args.prompt_arg.strip())
    content = "\n\n".join(part for part in parts if part)
    if not content:
        raise SystemExit("No content provided. Use --content, --content-file, or a positional prompt.")
    return content


def build_payload(args: argparse.Namespace, content: str) -> dict[str, Any]:
    messages: list[dict[str, str]] = []
    if args.system:
        messages.append({"role": "system", "content": args.system})
    messages.append({"role": "user", "content": content})
    return {"model": args.model, "messages": messages}


def post_json(api_url: str, api_key: str, payload: dict[str, Any], timeout: int) -> dict[str, Any]:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = request.Request(
        api_url,
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            response_body = resp.read().decode("utf-8", errors="replace")
            return json.loads(response_body)
    except error.HTTPError as exc:
        response_body = exc.read().decode("utf-8", errors="replace")
        try:
            parsed = json.loads(response_body)
        except json.JSONDecodeError:
            parsed = {"error": response_body}
        retryable = exc.code == 429 or exc.code >= 500
        raise ApiRequestError(
            f"HTTP {exc.code}: {json.dumps(parsed, ensure_ascii=False)[:1000]}",
            status_code=exc.code,
            payload=parsed,
            retryable=retryable,
        ) from exc
    except error.URLError as exc:
        raise ApiRequestError(f"Network error: {exc}", retryable=True) from exc
    except json.JSONDecodeError as exc:
        raise ApiRequestError(f"API response was not valid JSON: {exc}", retryable=False) from exc


def extension_from_mime(mime_type: str) -> str:
    if mime_type == "image/jpeg":
        return ".jpg"
    return mimetypes.guess_extension(mime_type) or ".png"


def decode_image_data(value: str, fallback_mime: str = "image/png") -> tuple[bytes, str] | None:
    text = value.strip()
    match = DATA_URL_RE.fullmatch(text)
    if match:
        mime_type, data = match.groups()
    else:
        mime_type, data = fallback_mime, text
    try:
        return base64.b64decode(data, validate=False), extension_from_mime(mime_type)
    except Exception:
        return None


def collect_strings(obj: Any) -> list[tuple[str, str]]:
    found: list[tuple[str, str]] = []

    def walk(value: Any, path: str) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                child_path = f"{path}.{key}" if path else str(key)
                if isinstance(child, str):
                    found.append((child_path, child))
                else:
                    walk(child, child_path)
        elif isinstance(value, list):
            for idx, child in enumerate(value):
                walk(child, f"{path}[{idx}]")

    walk(obj, "")
    return found


def looks_like_base64_path(path: str) -> bool:
    lowered = path.lower()
    return any(key in lowered for key in ("b64", "base64", "image_base64"))


def sanitize_url(url: str) -> str:
    return url.rstrip(".,;]")


def save_response_artifacts(response_json: dict[str, Any], output_dir: Path, prefix: str, download: bool) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")

    raw_path = output_dir / f"{prefix}_{stamp}_response.json"
    raw_path.write_text(json.dumps(response_json, ensure_ascii=False, indent=2), encoding="utf-8")

    texts: list[str] = []
    image_paths: list[str] = []
    urls: list[str] = []
    seen_urls: set[str] = set()

    for path, text in collect_strings(response_json):
        if not text.strip():
            continue
        if ".content" in path.lower() or path.endswith(".text"):
            texts.append(text)

        for mime_type, b64_data in DATA_URL_RE.findall(text):
            decoded = decode_image_data(f"data:{mime_type};base64,{b64_data}")
            if decoded:
                image_bytes, extension = decoded
                image_path = output_dir / f"{prefix}_{stamp}_{len(image_paths) + 1:02d}{extension}"
                image_path.write_bytes(image_bytes)
                image_paths.append(str(image_path))

        if looks_like_base64_path(path):
            decoded = decode_image_data(text)
            if decoded:
                image_bytes, extension = decoded
                image_path = output_dir / f"{prefix}_{stamp}_{len(image_paths) + 1:02d}{extension}"
                image_path.write_bytes(image_bytes)
                image_paths.append(str(image_path))

        for url in MARKDOWN_IMAGE_RE.findall(text) + HTTP_URL_RE.findall(text):
            clean = sanitize_url(url)
            if clean not in seen_urls:
                seen_urls.add(clean)
                urls.append(clean)

    text_path = None
    if texts:
        text_path_obj = output_dir / f"{prefix}_{stamp}_content.txt"
        text_path_obj.write_text("\n\n---\n\n".join(texts), encoding="utf-8")
        text_path = str(text_path_obj)

    downloaded: list[str] = []
    if download:
        for idx, url in enumerate(urls, start=1):
            try:
                req = request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with request.urlopen(req, timeout=60) as resp:
                    content_type = resp.headers.get_content_type()
                    if not content_type.startswith("image/"):
                        continue
                    extension = extension_from_mime(content_type)
                    image_path = output_dir / f"{prefix}_{stamp}_url_{idx:02d}{extension}"
                    image_path.write_bytes(resp.read())
                    downloaded.append(str(image_path))
                    image_paths.append(str(image_path))
            except Exception:
                continue

    return {
        "raw_response": str(raw_path),
        "text_file": text_path,
        "image_files": image_paths,
        "discovered_urls": urls,
        "downloaded_url_images": downloaded,
    }


def save_error_artifact(error_info: dict[str, Any], output_dir: Path, prefix: str) -> str:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    error_path = output_dir / f"{prefix}_{stamp}_error.json"
    error_path.write_text(json.dumps(error_info, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(error_path)


def main() -> None:
    args = parse_args()
    if not args.api_key:
        raise SystemExit("No API key. Use --api-key or set BREAKOUT_API_KEY.")

    content = load_content(args)
    payload = build_payload(args, content)

    print(f"Calling Breakout chat completions | model={args.model}")
    print(f"API: {args.api_url}")
    print(f"Content chars: {len(content)}")
    print(f"Output dir: {Path(args.output_dir).resolve()}")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    started = time.time()
    response_json: dict[str, Any] | None = None
    last_error: ApiRequestError | None = None
    total_attempts = max(1, args.retries + 1)
    for attempt in range(1, total_attempts + 1):
        try:
            print(f"Attempt {attempt}/{total_attempts}")
            response_json = post_json(args.api_url, args.api_key, payload, args.timeout)
            break
        except ApiRequestError as exc:
            last_error = exc
            print(str(exc))
            should_retry = exc.retryable and attempt < total_attempts
            if not should_retry:
                break
            print(f"Retrying in {args.retry_delay}s...")
            time.sleep(args.retry_delay)

    if response_json is None:
        elapsed = round(time.time() - started, 1)
        assert last_error is not None
        error_info = {
            "status": "error",
            "message": str(last_error),
            "status_code": last_error.status_code,
            "retryable": last_error.retryable,
            "attempts": total_attempts,
            "elapsed_seconds": elapsed,
            "model": args.model,
            "api_url": args.api_url,
            "payload_without_api_key": payload,
            "api_error_payload": last_error.payload,
        }
        error_path = save_error_artifact(error_info, output_dir, args.prefix)
        print(json.dumps({**error_info, "error_file": error_path}, ensure_ascii=False, indent=2))
        raise SystemExit(1)

    elapsed = round(time.time() - started, 1)

    artifacts = save_response_artifacts(
        response_json=response_json,
        output_dir=output_dir,
        prefix=args.prefix,
        download=not args.no_download,
    )
    artifacts["elapsed_seconds"] = elapsed
    artifacts["model"] = args.model

    print(json.dumps(artifacts, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
