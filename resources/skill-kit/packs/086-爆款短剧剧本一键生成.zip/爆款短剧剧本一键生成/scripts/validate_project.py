#!/usr/bin/env python3
"""Validate a beginner short-drama project without third-party dependencies."""

from __future__ import annotations

import csv
import json
import re
import sys
from pathlib import Path


STATE_NAMES = ("项目状态.json", "project-state.json", ".drama-state.json")
TASK_NAMES = ("生成任务.csv", "10-生成任务.csv", "generation-tasks.csv")
VISUAL_NAMES = ("角色视觉资产.csv", "03A-角色视觉资产.csv", "character-visual-assets.csv")
BENCHMARK_NAMES = ("参考样本.csv", "00A-参考样本.csv", "benchmark-sources.csv")
SIMILARITY_NAMES = ("相似风险检查.csv", "12A-相似风险检查.csv", "similarity-risk.csv")
STORYBOARD_NAMES = ("06-分镜表.csv", "分镜表.csv", "storyboard.csv")
ACTION_NAMES = ("06A-动作与特效表.csv", "动作与特效表.csv", "action-effects.csv")
DELIVERABLE_RULES = (
    (1, "制作卡", ("01-制作卡.md",)),
    (2, "故事圣经", ("02-故事圣经.md",)),
    (2, "角色与资产表", ("03-角色与资产表.md",)),
    (2, "分集目录", ("04-分集目录.md",)),
    (2, "逐集剧本", ("05-逐集剧本.md",)),
    (3, "图片提示词", ("07-图片提示词.md",)),
    (3, "视频提示词", ("08-视频提示词.md",)),
    (3, "配音字幕与剪辑计划", ("09-配音字幕与剪辑计划.md",)),
    (5, "质检报告", ("12-质检报告.md",)),
)
STAGE_LEVELS = {
    "brief": 0,
    "story": 1,
    "assets": 2,
    "storyboard": 3,
    "storyboard_ready": 3,
    "production": 4,
    "generating": 4,
    "review": 5,
    "completed": 6,
}
REQUIRED_STATE = {
    "title",
    "mode",
    "format",
    "aspect_ratio",
    "language",
    "current_stage",
    "total_episodes",
    "completed_episodes",
    "locked_assets",
    "assumptions",
    "spent",
}
REQUIRED_TASK = {
    "task_id",
    "episode",
    "shot_id",
    "task_type",
    "status",
    "attempt_count",
    "cost",
    "output_path",
    "failure_reason",
    "next_action",
}
REQUIRED_VISUAL = {
    "asset_id",
    "name",
    "role_level",
    "visual_mode",
    "front_view",
    "side_view",
    "back_view",
    "three_quarter_face",
    "expression_sheet",
    "status",
    "approved_by",
    "notes",
}
REQUIRED_BENCHMARK = {
    "source_id",
    "source_title",
    "source_type",
    "source_location",
    "rights_status",
    "allowed_use",
    "notes",
}
REQUIRED_SIMILARITY = {
    "category",
    "reference_element",
    "new_element",
    "risk_level",
    "evidence",
    "required_change",
    "status",
}
REQUIRED_STORYBOARD = {
    "episode",
    "scene_id",
    "shot_id",
    "duration_seconds",
    "story_purpose",
    "character_ids",
    "location_id",
    "prop_ids",
    "visible_action",
    "shot_size",
    "camera_angle",
    "camera_movement",
    "composition",
    "lighting_color",
    "dialogue",
    "audio",
    "entry_exit",
    "generation_method",
    "reference_assets",
    "negative_constraints",
    "status",
}
REQUIRED_ACTION = {
    "episode",
    "scene_id",
    "shot_id",
    "action_id",
    "action_type",
    "story_function",
    "start_pose",
    "action_path",
    "end_pose",
    "camera_support",
    "effect_layers",
    "environment_response",
    "power_rule",
    "negative_constraints",
    "fallback",
    "status",
}
ALLOWED_STATUS = {
    "pending",
    "ready",
    "generating",
    "review",
    "passed",
    "retry",
    "blocked",
    "rejected",
}
ALLOWED_VISUAL_STATUS = {
    "draft",
    "review",
    "locked",
    "rejected",
    "blocked",
    "not_required",
}
ALLOWED_ROLE_LEVEL = {"lead", "recurring", "supporting", "background"}
ALLOWED_RIGHTS_STATUS = {
    "owned",
    "licensed",
    "public_domain",
    "analysis_only",
    "unknown",
}
ALLOWED_RISK_LEVEL = {"low", "medium", "high", "blocker"}
ALLOWED_RISK_STATUS = {"pending", "fixed", "not_applicable"}
ALLOWED_SHOT_STATUS = {
    "draft",
    "ready",
    "locked",
    "generating",
    "review",
    "passed",
    "blocked",
    "rejected",
}
VISUAL_GATE_STAGES = {
    "storyboard",
    "storyboard_ready",
    "production",
    "generating",
    "review",
    "completed",
}
ALLOWED_GENRE_PROFILE = {
    "general",
    "manhua",
    "wuxia",
    "xuanhuan",
    "xianxia",
    "wuxia-xuanhuan",
}
FANTASY_GENRES = {"wuxia", "xuanhuan", "xianxia", "wuxia-xuanhuan"}
ALLOWED_STYLE_VALIDATION = {"text_only", "image_tested", "video_tested"}


def find_first(root: Path, names: tuple[str, ...]) -> Path | None:
    for name in names:
        candidate = root / name
        if candidate.exists():
            return candidate
    return None


def stage_level(stage: object) -> int:
    return STAGE_LEVELS.get(str(stage), -1)


def schema_at_least(data: dict[str, object] | None, major: int, minor: int) -> bool:
    raw = str((data or {}).get("schema_version", "0.0"))
    match = re.match(r"^(\d+)\.(\d+)", raw)
    if not match:
        return False
    return (int(match.group(1)), int(match.group(2))) >= (major, minor)


def validate_state(
    path: Path, errors: list[str], warnings: list[str]
) -> dict[str, object] | None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        errors.append(f"无法读取项目状态：{exc}")
        return None

    missing = sorted(REQUIRED_STATE - data.keys())
    if missing:
        errors.append("项目状态缺少字段：" + ", ".join(missing))
    if not isinstance(data.get("total_episodes"), int) or data.get("total_episodes", 0) < 1:
        errors.append("total_episodes 必须是大于 0 的整数")
    if not isinstance(data.get("spent"), (int, float)) or data.get("spent", 0) < 0:
        errors.append("spent 必须是非负数字")
    if not data.get("title"):
        if stage_level(data.get("current_stage")) >= 1:
            errors.append("进入故事阶段前必须填写项目标题")
        else:
            warnings.append("项目标题为空")
    if not data.get("last_updated"):
        if stage_level(data.get("current_stage")) >= 1:
            errors.append("进入故事阶段前必须填写 last_updated")
        else:
            warnings.append("last_updated 为空")
    if not data.get("schema_version"):
        warnings.append("schema_version 缺失，按旧版项目处理")
    if schema_at_least(data, 3, 2):
        genre_profile = str(data.get("genre_profile", ""))
        if genre_profile not in ALLOWED_GENRE_PROFILE:
            errors.append(f"genre_profile 无效：{genre_profile}")
        style_level = str(data.get("style_validation_level", ""))
        if style_level not in ALLOWED_STYLE_VALIDATION:
            errors.append(f"style_validation_level 无效：{style_level}")
        if not str(data.get("style_profile", "")).strip():
            errors.append("V3.2 项目必须填写 style_profile")
    current_stage = str(data.get("current_stage", ""))
    if current_stage not in STAGE_LEVELS:
        errors.append(f"current_stage 无效：{current_stage}")
    if "visual_lock_required" in data and not isinstance(data["visual_lock_required"], bool):
        errors.append("visual_lock_required 必须是布尔值")
    if "benchmark_rewrite" in data and not isinstance(data["benchmark_rewrite"], bool):
        errors.append("benchmark_rewrite 必须是布尔值")
    return data


def as_nonnegative_number(value: str, label: str, errors: list[str]) -> None:
    try:
        if float(value or 0) < 0:
            raise ValueError
    except ValueError:
        errors.append(f"{label} 必须是非负数字")


def validate_tasks(
    path: Path,
    gate_required: bool,
    errors: list[str],
    warnings: list[str],
) -> None:
    try:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            fields = set(reader.fieldnames or [])
            missing = sorted(REQUIRED_TASK - fields)
            if missing:
                errors.append("生成任务表缺少列：" + ", ".join(missing))
                return

            seen: set[str] = set()
            rows = list(reader)
            for index, row in enumerate(rows, start=2):
                task_id = (row.get("task_id") or "").strip()
                if not task_id:
                    errors.append(f"第 {index} 行 task_id 为空")
                elif task_id in seen:
                    errors.append(f"第 {index} 行 task_id 重复：{task_id}")
                seen.add(task_id)

                status = (row.get("status") or "").strip()
                if status not in ALLOWED_STATUS:
                    errors.append(f"第 {index} 行状态无效：{status}")
                as_nonnegative_number(row.get("attempt_count", ""), f"第 {index} 行 attempt_count", errors)
                as_nonnegative_number(row.get("cost", ""), f"第 {index} 行 cost", errors)
                if status == "passed" and not (row.get("output_path") or "").strip():
                    errors.append(f"第 {index} 行已通过但 output_path 为空")
                if status in {"retry", "blocked", "rejected"} and not (row.get("failure_reason") or "").strip():
                    warnings.append(f"第 {index} 行失败状态未记录 failure_reason")
            if not rows:
                if gate_required:
                    errors.append("进入生产阶段前生成任务表至少需要1个任务")
                else:
                    warnings.append("生成任务表目前没有任务；立项阶段可以为空")
    except OSError as exc:
        errors.append(f"无法读取生成任务表：{exc}")


def validate_visuals(
    path: Path,
    gate_required: bool,
    errors: list[str],
    warnings: list[str],
) -> None:
    try:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            fields = set(reader.fieldnames or [])
            missing = sorted(REQUIRED_VISUAL - fields)
            if missing:
                errors.append("角色视觉资产表缺少列：" + ", ".join(missing))
                return

            seen: set[str] = set()
            rows = list(reader)
            for index, row in enumerate(rows, start=2):
                asset_id = (row.get("asset_id") or "").strip()
                if not asset_id:
                    errors.append(f"角色视觉资产表第 {index} 行 asset_id 为空")
                elif asset_id in seen:
                    errors.append(f"角色视觉资产表第 {index} 行 asset_id 重复：{asset_id}")
                seen.add(asset_id)

                role_level = (row.get("role_level") or "").strip()
                if role_level not in ALLOWED_ROLE_LEVEL:
                    errors.append(
                        f"角色视觉资产表第 {index} 行 role_level 无效：{role_level}"
                    )

                status = (row.get("status") or "").strip()
                if status not in ALLOWED_VISUAL_STATUS:
                    errors.append(f"角色视觉资产表第 {index} 行状态无效：{status}")

                if gate_required and role_level in {"lead", "recurring"}:
                    if status != "locked":
                        errors.append(
                            f"角色 {asset_id or index} 在进入分镜或生产前必须设为 locked"
                        )
                    for field in (
                        "front_view",
                        "side_view",
                        "back_view",
                        "three_quarter_face",
                        "expression_sheet",
                    ):
                        value = (row.get(field) or "").strip()
                        if not value:
                            errors.append(
                                f"角色 {asset_id or index} 缺少锁定资产：{field}"
                            )
                            continue
                        candidate = (path.parent / value).resolve()
                        try:
                            candidate.relative_to(path.parent.resolve())
                        except ValueError:
                            errors.append(
                                f"角色 {asset_id or index} 的 {field} 必须位于项目目录内"
                            )
                            continue
                        if not candidate.is_file():
                            errors.append(
                                f"角色 {asset_id or index} 的 {field} 文件不存在：{value}"
                            )
                    if not (row.get("approved_by") or "").strip():
                        errors.append(f"角色 {asset_id or index} 锁定前缺少 approved_by")

            if not rows:
                warnings.append("角色视觉资产表目前没有角色；未要求视觉锁定时可以为空")
    except OSError as exc:
        errors.append(f"无法读取角色视觉资产表：{exc}")


def validate_benchmarks(
    path: Path,
    required: bool,
    errors: list[str],
    warnings: list[str],
) -> None:
    try:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            fields = set(reader.fieldnames or [])
            missing = sorted(REQUIRED_BENCHMARK - fields)
            if missing:
                errors.append("参考样本表缺少列：" + ", ".join(missing))
                return

            seen: set[str] = set()
            rows = list(reader)
            for index, row in enumerate(rows, start=2):
                source_id = (row.get("source_id") or "").strip()
                if not source_id:
                    errors.append(f"参考样本表第 {index} 行 source_id 为空")
                elif source_id in seen:
                    errors.append(f"参考样本表第 {index} 行 source_id 重复：{source_id}")
                seen.add(source_id)

                if not (row.get("source_title") or "").strip():
                    errors.append(f"参考样本表第 {index} 行 source_title 为空")
                rights_status = (row.get("rights_status") or "").strip()
                if rights_status not in ALLOWED_RIGHTS_STATUS:
                    errors.append(
                        f"参考样本表第 {index} 行 rights_status 无效：{rights_status}"
                    )
                elif rights_status == "unknown":
                    warnings.append(
                        f"参考样本 {source_id or index} 权利状态未知，只能进行抽象结构分析"
                    )
                if not (row.get("allowed_use") or "").strip():
                    errors.append(f"参考样本表第 {index} 行 allowed_use 为空")

            if required and not rows:
                errors.append("爆款结构重构项目至少需要登记 1 个参考样本")
    except OSError as exc:
        errors.append(f"无法读取参考样本表：{exc}")


def validate_similarity(
    path: Path,
    gate_required: bool,
    errors: list[str],
    warnings: list[str],
) -> None:
    try:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            fields = set(reader.fieldnames or [])
            missing = sorted(REQUIRED_SIMILARITY - fields)
            if missing:
                errors.append("相似风险检查表缺少列：" + ", ".join(missing))
                return

            rows = list(reader)
            for index, row in enumerate(rows, start=2):
                category = (row.get("category") or "").strip()
                if not category:
                    errors.append(f"相似风险检查表第 {index} 行 category 为空")
                risk_level = (row.get("risk_level") or "").strip()
                if risk_level not in ALLOWED_RISK_LEVEL:
                    errors.append(
                        f"相似风险检查表第 {index} 行 risk_level 无效：{risk_level}"
                    )
                status = (row.get("status") or "").strip()
                if status not in ALLOWED_RISK_STATUS:
                    errors.append(
                        f"相似风险检查表第 {index} 行 status 无效：{status}"
                    )
                if risk_level in {"high", "blocker"}:
                    if not (row.get("required_change") or "").strip():
                        errors.append(
                            f"相似风险检查表第 {index} 行高风险项缺少 required_change"
                        )
                    if gate_required and status != "fixed":
                        errors.append(
                            f"相似风险检查表第 {index} 行 {risk_level} 风险未修复"
                        )
                elif risk_level == "medium" and status == "pending":
                    warnings.append(f"相似风险检查表第 {index} 行中风险仍待处理")

            if gate_required and not rows:
                errors.append("进入生产前必须填写相似风险检查表")
    except OSError as exc:
        errors.append(f"无法读取相似风险检查表：{exc}")


def validate_markdown_deliverables(
    root: Path,
    current_level: int,
    errors: list[str],
    rules: tuple[tuple[int, str, tuple[str, ...]], ...] = DELIVERABLE_RULES,
) -> None:
    for required_level, label, names in rules:
        if current_level < required_level:
            continue
        path = find_first(root, names)
        if path is None:
            errors.append(f"当前阶段缺少{label}文件：{names[0]}")
            continue
        try:
            content = path.read_text(encoding="utf-8")
        except OSError as exc:
            errors.append(f"无法读取{label}文件：{exc}")
            continue
        if len(content.strip()) < 40:
            errors.append(f"{label}文件内容过少：{path.name}")
        if "【必填" in content:
            errors.append(f"{label}仍有未填写占位符：{path.name}")


def validate_storyboard(
    path: Path,
    required: bool,
    production_gate: bool,
    strict_ids: bool,
    errors: list[str],
    warnings: list[str],
) -> set[str]:
    shot_ids: set[str] = set()
    try:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            fields = set(reader.fieldnames or [])
            missing = sorted(REQUIRED_STORYBOARD - fields)
            if missing:
                errors.append("分镜表缺少列：" + ", ".join(missing))
                return shot_ids

            seen: set[str] = set()
            rows = list(reader)
            for index, row in enumerate(rows, start=2):
                shot_id = (row.get("shot_id") or "").strip()
                if not shot_id:
                    errors.append(f"分镜表第 {index} 行 shot_id 为空")
                elif not re.fullmatch(r"EP\d{2}-SC\d{2}-SH\d{2}", shot_id):
                    errors.append(f"分镜表第 {index} 行 shot_id 格式无效：{shot_id}")
                elif shot_id in seen:
                    errors.append(f"分镜表第 {index} 行 shot_id 重复：{shot_id}")
                seen.add(shot_id)
                if shot_id:
                    shot_ids.add(shot_id)

                episode = (row.get("episode") or "").strip()
                scene_id = (row.get("scene_id") or "").strip()
                if strict_ids and not re.fullmatch(r"EP\d{2}", episode):
                    errors.append(f"分镜表第 {index} 行 episode 格式无效：{episode}")
                if strict_ids and not re.fullmatch(r"SC\d{2}", scene_id):
                    errors.append(f"分镜表第 {index} 行 scene_id 格式无效：{scene_id}")
                if shot_id and episode and scene_id:
                    normalized_episode = episode
                    normalized_scene = scene_id
                    if not strict_ids and episode.isdigit():
                        normalized_episode = f"EP{int(episode):02d}"
                    if not strict_ids and scene_id.isdigit():
                        normalized_scene = f"SC{int(scene_id):02d}"
                    expected_prefix = f"{normalized_episode}-{normalized_scene}-"
                    if not shot_id.startswith(expected_prefix):
                        errors.append(
                            f"分镜表第 {index} 行 shot_id 与 episode/scene_id 不一致"
                        )

                try:
                    if float((row.get("duration_seconds") or "").strip()) <= 0:
                        raise ValueError
                except ValueError:
                    errors.append(f"分镜表第 {index} 行 duration_seconds 必须大于0")

                for field in (
                    "episode",
                    "scene_id",
                    "story_purpose",
                    "visible_action",
                    "shot_size",
                    "camera_angle",
                    "camera_movement",
                    "composition",
                    "lighting_color",
                    "entry_exit",
                    "generation_method",
                    "negative_constraints",
                ):
                    if not (row.get(field) or "").strip():
                        errors.append(f"分镜表第 {index} 行 {field} 为空")

                character_ids = (row.get("character_ids") or "").strip()
                if character_ids != "none":
                    for asset_id in re.split(r"[|,; ]+", character_ids):
                        if asset_id and not re.fullmatch(r"CHAR-\d{3}", asset_id):
                            errors.append(
                                f"分镜表第 {index} 行角色ID无效：{asset_id}"
                            )
                location_id = (row.get("location_id") or "").strip()
                if not re.fullmatch(r"LOC-\d{3}", location_id):
                    errors.append(f"分镜表第 {index} 行场景ID无效：{location_id}")
                prop_ids = (row.get("prop_ids") or "").strip()
                if prop_ids != "none":
                    for asset_id in re.split(r"[|,; ]+", prop_ids):
                        if asset_id and not re.fullmatch(r"PROP-\d{3}", asset_id):
                            errors.append(
                                f"分镜表第 {index} 行道具ID无效：{asset_id}"
                            )

                status = (row.get("status") or "").strip()
                if status not in ALLOWED_SHOT_STATUS:
                    errors.append(f"分镜表第 {index} 行 status 无效：{status}")
                elif production_gate and status == "draft":
                    errors.append(f"分镜表第 {index} 行仍为 draft，不能进入生产")
                elif status in {"blocked", "rejected"}:
                    warnings.append(f"分镜 {shot_id or index} 当前状态为 {status}")

            if required and not rows:
                errors.append("进入分镜或生产阶段前至少需要1个镜头")
    except OSError as exc:
        errors.append(f"无法读取分镜表：{exc}")
    return shot_ids


def validate_actions(
    path: Path,
    required: bool,
    storyboard_shot_ids: set[str],
    errors: list[str],
    warnings: list[str],
) -> None:
    try:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            fields = set(reader.fieldnames or [])
            missing = sorted(REQUIRED_ACTION - fields)
            if missing:
                errors.append("动作与特效表缺少列：" + ", ".join(missing))
                return

            seen: set[str] = set()
            rows = list(reader)
            for index, row in enumerate(rows, start=2):
                action_id = (row.get("action_id") or "").strip()
                if not re.fullmatch(r"ACT-\d{3}", action_id):
                    errors.append(f"动作与特效表第 {index} 行 action_id 无效：{action_id}")
                elif action_id in seen:
                    errors.append(f"动作与特效表第 {index} 行 action_id 重复：{action_id}")
                seen.add(action_id)

                shot_id = (row.get("shot_id") or "").strip()
                if not re.fullmatch(r"EP\d{2}-SC\d{2}-SH\d{2}", shot_id):
                    errors.append(f"动作与特效表第 {index} 行 shot_id 无效：{shot_id}")
                elif storyboard_shot_ids and shot_id not in storyboard_shot_ids:
                    errors.append(
                        f"动作与特效表第 {index} 行引用了不存在的分镜：{shot_id}"
                    )

                episode = (row.get("episode") or "").strip()
                scene_id = (row.get("scene_id") or "").strip()
                if shot_id and not shot_id.startswith(f"{episode}-{scene_id}-"):
                    errors.append(
                        f"动作与特效表第 {index} 行 shot_id 与 episode/scene_id 不一致"
                    )

                for field in REQUIRED_ACTION - {"effect_layers", "environment_response"}:
                    if not (row.get(field) or "").strip():
                        errors.append(f"动作与特效表第 {index} 行 {field} 为空")

                status = (row.get("status") or "").strip()
                if status not in ALLOWED_SHOT_STATUS:
                    errors.append(f"动作与特效表第 {index} 行 status 无效：{status}")
                if not (row.get("effect_layers") or "").strip():
                    warnings.append(f"动作 {action_id or index} 未使用特效层；纯武术动作可忽略")

            if required and not rows:
                errors.append("武侠玄幻项目进入分镜阶段前至少需要1条动作或特效记录")
    except OSError as exc:
        errors.append(f"无法读取动作与特效表：{exc}")


def main() -> int:
    if len(sys.argv) != 2:
        print("用法：python3 scripts/validate_project.py <项目目录>")
        return 2

    root = Path(sys.argv[1]).expanduser().resolve()
    if not root.is_dir():
        print(f"错误：项目目录不存在：{root}")
        return 2

    errors: list[str] = []
    warnings: list[str] = []
    state = find_first(root, STATE_NAMES)
    tasks = find_first(root, TASK_NAMES)
    state_data: dict[str, object] | None = None
    if state is None:
        errors.append("未找到项目状态文件")
    else:
        state_data = validate_state(state, errors, warnings)
    current_level = stage_level((state_data or {}).get("current_stage", ""))
    if tasks is None:
        errors.append("未找到生成任务表")
    else:
        validate_tasks(tasks, current_level >= 4, errors, warnings)

    visual_required = bool((state_data or {}).get("visual_lock_required", False))
    visual_stage = str((state_data or {}).get("current_stage", ""))
    visual_gate_required = visual_required and visual_stage in VISUAL_GATE_STAGES
    visuals = find_first(root, VISUAL_NAMES)
    if visual_required and visuals is None:
        errors.append("项目要求角色视觉锁定，但未找到角色视觉资产表")
    elif visuals is not None:
        validate_visuals(visuals, visual_gate_required, errors, warnings)

    benchmark_required = bool((state_data or {}).get("benchmark_rewrite", False))
    benchmark_stage = str((state_data or {}).get("current_stage", ""))
    benchmark_gate_required = benchmark_required and benchmark_stage in VISUAL_GATE_STAGES
    benchmarks = find_first(root, BENCHMARK_NAMES)
    similarity = find_first(root, SIMILARITY_NAMES)
    if benchmark_required and benchmarks is None:
        errors.append("爆款结构重构项目未找到参考样本表")
    elif benchmarks is not None:
        validate_benchmarks(benchmarks, benchmark_required, errors, warnings)
    if benchmark_required and similarity is None:
        errors.append("爆款结构重构项目未找到相似风险检查表")
    elif similarity is not None:
        validate_similarity(similarity, benchmark_gate_required, errors, warnings)

    rules = list(DELIVERABLE_RULES)
    is_v32 = schema_at_least(state_data, 3, 2)
    genre_profile = str((state_data or {}).get("genre_profile", "general"))
    project_format = str((state_data or {}).get("format", ""))
    if is_v32:
        rules.append((1, "画质与风格方案", ("01C-画质与风格方案.md",)))
        if project_format == "animation" or genre_profile == "manhua":
            rules.append((2, "漫剧表现方案", ("02A-漫剧表现方案.md",)))
        if genre_profile in FANTASY_GENRES:
            rules.append((2, "武侠玄幻规则表", ("02B-武侠玄幻规则表.md",)))
    validate_markdown_deliverables(root, current_level, errors, tuple(rules))
    storyboard = find_first(root, STORYBOARD_NAMES)
    storyboard_required = current_level >= 3
    production_gate = current_level >= 4
    storyboard_shot_ids: set[str] = set()
    if storyboard_required and storyboard is None:
        errors.append("当前阶段缺少分镜表：06-分镜表.csv")
    elif storyboard is not None:
        storyboard_shot_ids = validate_storyboard(
            storyboard,
            storyboard_required,
            production_gate,
            is_v32,
            errors,
            warnings,
        )

    actions = find_first(root, ACTION_NAMES)
    actions_required = is_v32 and genre_profile in FANTASY_GENRES and current_level >= 3
    if actions_required and actions is None:
        errors.append("武侠玄幻项目当前阶段缺少动作与特效表：06A-动作与特效表.csv")
    elif actions is not None:
        validate_actions(
            actions, actions_required, storyboard_shot_ids, errors, warnings
        )

    for item in warnings:
        print(f"警告：{item}")
    for item in errors:
        print(f"错误：{item}")
    if errors:
        print(f"校验失败：{len(errors)} 个错误，{len(warnings)} 个警告")
        return 1
    print(f"校验通过：0 个错误，{len(warnings)} 个警告")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
