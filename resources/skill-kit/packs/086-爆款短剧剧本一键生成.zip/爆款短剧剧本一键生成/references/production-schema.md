# 生产字段模板

## 创作简报

```yaml
title:
genre:
audience:
platform:
experience_level: beginner
aspect_ratio: 9:16
episode_count:
episode_duration_seconds:
language: zh-CN
format: animation
visual_style:
genre_profile: manhua
style_profile: 01C-画质与风格方案.md
style_validation_level: text_only
generation_models: []
available_assets: []
content_boundaries: []
budget_limit:
deliverables: []
```

## 角色锁定卡

```yaml
asset_id: CHAR-001
name:
story_function:
age_range:
face_anchors: []
hair_anchors: []
body_anchors: []
wardrobe_palette: []
signature_props: []
voice_and_speech:
voice_id:
allowed_variations: []
forbidden_drift: []
reference_assets: []
```

## 角色视觉包

```yaml
asset_id: CHAR-001
role_level: lead
visual_mode: generated
front_view:
side_view:
back_view:
three_quarter_face:
expression_sheet:
status: draft
approved_by:
notes:
```

主角与常驻角色在动画或 AI 视频项目中使用完整视觉包。`side_view` 默认是完整侧面；角色存在明显左右不对称设计时，补充左右两侧视图。表情表默认九宫格，表情由剧情实际需要决定，不机械复制固定情绪。

`03A-角色视觉资产.csv` 至少包含：

```csv
asset_id,name,role_level,visual_mode,front_view,side_view,back_view,three_quarter_face,expression_sheet,status,approved_by,notes
```

角色视觉状态只使用：`draft`、`review`、`locked`、`rejected`、`blocked`、`not_required`。

## 视觉风格契约

`01C-画质与风格方案.md` 至少锁定：风格 ID、媒介、线条/形体、表面/材质、主光与环境光、主辅强调色、对比度、镜头/景深、动态语言、特效语言、后期方向、必须保持项和必须避免项。

质量档位只表达当前生产策略：`预览`、`标准`、`高质量`。验证等级表达已经取得的证据：

- `text_only`：仅完成文字契约、提示词和一致性检查；
- `image_tested`：至少有角色、场景、动作/特效代表图及证据路径；
- `video_tested`：至少有对话、运镜、复杂动作等代表视频及证据路径。

质量档位高不等于验证等级高。

## 漫剧动态层

每个镜头分别决定：静态层、微动层、镜头层、表演/动作层、特效层、低成本替代。静态画面必须能看懂主体与信息；单镜只保留一个主要视觉意图。复杂动作优先拆镜，不要求一个片段同时完成人物位移、招式交互、口型和复杂运镜。

## 镜头卡

| 字段 | 内容 |
|---|---|
| 镜头 ID | `EP01-SC02-SH03` |
| 时长 | 秒数；同一生成片段通常不超过所用模型限制 |
| 剧情目的 | 这个镜头新增什么信息或情绪 |
| 资产 ID | 角色、场景、道具的固定 ID |
| 主体与动作 | 可见、具体、单一主要动作 |
| 景别 | 大远景/全景/中景/近景/特写 |
| 机位与视角 | 平视/俯视/仰视/过肩/POV 等 |
| 运镜 | 固定/推/拉/摇/移/跟/手持等 |
| 构图 | 主体位置、前中后景、视线方向 |
| 光线与色彩 | 光源、明暗关系、主辅色 |
| 台词与声音 | 台词、环境音、音乐节拍；字幕后期制作 |
| 入镜/出镜 | 与前后镜头如何衔接 |
| 生成方式 | 文生视频/图生视频/首尾帧/参考视频/后期制作 |
| 预算级别 | 预览/标准/高质量 |
| 负面约束 | 只列最关键的漂移或生成风险 |

`06-分镜表.csv` 使用固定表头：

```csv
episode,scene_id,shot_id,duration_seconds,story_purpose,character_ids,location_id,prop_ids,visible_action,shot_size,camera_angle,camera_movement,composition,lighting_color,dialogue,audio,entry_exit,generation_method,reference_assets,negative_constraints,status
```

`character_ids`、`location_id` 和 `prop_ids` 只能引用 `03-角色与资产表.md` 中已登记的固定ID；没有道具时填写 `none`。总镜头时长应与目标单集时长一致，允许因片头片尾存在少量明确记录的差异。

## 武侠玄幻动作与特效

先在 `02B-武侠玄幻规则表.md` 登记世界上限、力量阶梯、功法、势力、法宝/资源、伤势和地图，再写胜负。复杂动作使用：

```csv
episode,scene_id,shot_id,action_id,action_type,story_function,start_pose,action_path,end_pose,camera_support,effect_layers,environment_response,power_rule,negative_constraints,fallback,status
```

`action_id` 使用 `ACT-001` 格式，`shot_id` 必须对应分镜表。动作路径写清起势、运动路线、接触点与终点；`power_rule` 引用已建立的能力与限制；`fallback` 写模型难以完成时的拆镜、剪影、特写或环境反应替代方案。

## 视频提示词模板

```text
[事件与情绪意图]
使用 [资产ID]，保持 [身份/外观/道具锚点]。
[主体] 正在 [可见动作]；[微观物理或表情细节]。
场景：[地点、时间、前中后景、主色与光线]。
镜头：[景别、机位、运镜、节奏、时长]。
声音：[台词/环境音/音乐节拍/无]。
避免：[最关键的身份漂移、肢体错误、文字水印等]。
```

## 独立审片记录

```yaml
shot_id:
severity: blocker | major | minor
dimension: story | continuity | visual | audio | compliance | model-fit
evidence:
root_cause:
repair_action:
upstream_files_to_update: []
```
