# 来源、许可与整合边界

核验日期：2026-07-31。本 Skill 是原创整合工作流，不包含第三方软件代码、模型文件、API 密钥、影视素材或付费数据库。

## 可明确引用的开源方法

- `0xsline/short-drama`：https://github.com/0xsline/short-drama
  - MIT License。用于题材模板、节奏、钩子、角色层级、爽感、商业卡点、状态追踪、条件加载和剧本评分的设计参考。
  - 本 Skill 对结构进行了重写与收敛；保留此来源和 MIT 许可说明。
- `Emily2040/seedance-2.0`：https://github.com/Emily2040/seedance-2.0
  - MIT License。用于意图优先提示、参考素材角色、镜头/动作/光线/声音拆分、版权安全改写和失败诊断原则。
- `alibaba/lumenx`：https://github.com/alibaba/lumenx
  - MIT License。用于流水线生产与独立图片/视频工具台分离的架构参考。

## 只吸收架构思路的项目

- `chatfire-AI/huobao-drama`：https://github.com/chatfire-AI/huobao-drama
  - 用于理解剧本改写、资产提取、分镜、音色、宫格图、TTS 和 FFmpeg 合成的 Agent 分工。核验时仓库主页未清晰展示标准许可证，因此不复制或打包代码。
- `xuanyustudio/LocalMiniDrama`：https://github.com/xuanyustudio/LocalMiniDrama
  - 用于理解本地项目管理、资产复用、专业分镜参数和示例项目。复用代码前单独核对 LICENSE。
- `HBAI-Ltd/Toonflow-app`：https://github.com/HBAI-Ltd/Toonflow-app
  - 用于章节事件图、持久状态、三层 Agent 和多供应商配置思路。其许可证附带商业条款，不能笼统宣传为无限制商业使用。
- `xhadmincn/FastMovieAI`：https://github.com/xhadmincn/FastMovieAI
  - Apache-2.0。只参考用户、支付、内容与任务管理的产品架构，不打包平台代码。
- `waooAI/waoowaoo`：https://github.com/waooAI/waoowaoo
  - 只参考全流程工作台方向。项目曾声明处于测试初期，不能把“工业级”作为已验证事实；复用前核对当前许可证。
- `worldwonderer/drama-skills`：https://github.com/worldwonderer/drama-skills
- `smixs/visual-skills`：https://github.com/smixs/visual-skills
  - 用于核对剧本、资产、分镜、图像/视频提示词、连续性和独立审查的模块边界；复用前核对具体许可证。

## X 发现来源

- 短剧方法 Skill 推荐帖：https://x.com/mnmn94253156337/status/2061264959619924277
- 六款短剧工具推荐帖：https://x.com/huoshan007/status/2047547833403007450
- Seedance Skill OS 推荐帖：https://x.com/NFTCPS/status/2073247329046430047
- 开源剧本与分镜帖：https://x.com/Sirilee2026/status/2082354036318326855
- 分镜转视频提示词帖：https://x.com/Sirilee2026/status/2082459146721657271
- 冰河短剧剧本 Skill 文章：https://x.com/binghe/status/2027685265817694668
  - 原帖及其付费 Skill 未声明开放许可，只吸收行业需求与工作流思想，不复制其专有文件或参考库。

## 销售说明原则

1. 可以销售本 Skill 的原创组织、模板和改写内容，但保留 MIT 来源声明。
2. 不声称买家同时获得第三方软件、模型、商业授权、API 额度或付费素材。
3. 不把 GitHub 可见等同于允许商用；以具体 LICENSE 和附加条款为准。
4. 不承诺成片质量、流量、过审、收益或平台长期兼容。
5. 模型价格、平台规格、API 和政策必须在实际使用时重新核验。
