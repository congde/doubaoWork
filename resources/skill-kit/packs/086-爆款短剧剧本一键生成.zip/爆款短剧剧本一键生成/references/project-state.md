# 项目状态与成本

## 项目状态

完整系列或超过 10 个镜头时维护 `项目状态.json`：

```json
{
  "schema_version": "3.2",
  "title": "",
  "mode": "sample",
  "format": "animation",
  "genre_profile": "manhua",
  "aspect_ratio": "9:16",
  "language": "zh-CN",
  "current_stage": "brief",
  "style_profile": "01C-画质与风格方案.md",
  "style_validation_level": "text_only",
  "visual_lock_required": true,
  "visual_manifest": "03A-角色视觉资产.csv",
  "visual_lock_status": "pending",
  "total_episodes": 1,
  "completed_episodes": [],
  "locked_assets": [],
  "open_questions": [],
  "assumptions": [],
  "budget_limit": null,
  "spent": 0,
  "last_updated": "YYYY-MM-DD"
}
```

## 生成任务表

`生成任务.csv` 至少包含：

```csv
task_id,episode,shot_id,task_type,provider,model,status,attempt_count,cost,output_path,failure_reason,next_action
```

状态只使用：`pending`、`ready`、`generating`、`review`、`passed`、`retry`、`blocked`、`rejected`。

## 状态迁移

```text
pending → ready → generating → review → passed
                              ↘ retry → generating
                              ↘ blocked
                              ↘ rejected
```

进入 `ready` 前必须具备资产、提示词和预算确认。达到重试上限后转为 `blocked`，记录根因和所需决策。

动画或 AI 视频项目默认设置 `visual_lock_required: true`。进入 `storyboard`、`production`、`review` 或 `completed` 前，主角与常驻角色必须在角色视觉资产表中标为 `locked`；纯文字策划或用户只要剧本时可设为 `false`。

`schema_version` 用于识别模板版本。缺失时按旧项目处理并给出警告，不自动假设已经满足新版字段。

V3.2 新增字段：

- `genre_profile`：使用 `general`、`manhua`、`wuxia`、`xuanhuan`、`xianxia` 或 `wuxia-xuanhuan`。
- `style_profile`：指向实际使用的画质与风格文件。
- `style_validation_level`：只能使用 `text_only`、`image_tested` 或 `video_tested`。等级必须由真实测试证据决定，不能只因提示词写得完整就升级。

当 `format` 为 `animation` 或 `genre_profile` 为 `manhua` 时，故事阶段后维护 `02A-漫剧表现方案.md`。当题材为武侠、玄幻、仙侠或武侠玄幻混合时，同时维护 `02B-武侠玄幻规则表.md`，进入分镜阶段前维护 `06A-动作与特效表.csv`。

## 成本记录

`成本记录.csv`：

```csv
date,task_id,provider,model,unit,quantity,estimated_cost,actual_cost,currency,note
```

生成前给出估算区间而非单一数字；生成后记录实际成本。价格会变化，需要实时核对官方定价。

## 版本管理

- 通过版本使用 `shot-id_v01_passed.ext`。
- 失败版本保留失败原因，不反复覆盖。
- 剧本、资产或镜头上游变化时，标记所有受影响的下游任务。
- 只重新生成受影响镜头，避免整集返工。
