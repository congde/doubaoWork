#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_application.py — 建筑工程专利申请书结构自检脚本

用法:
    python validate_application.py <申请文件.md 或 output目录>

目录模式下按文件名识别文件:
    请求书 / claims|权利要求 / specification|说明书 / abstract|摘要

检查项:
    [ERROR] 四件套是否齐全
    [ERROR] 摘要正文是否 <=300 字
    [ERROR] 每项权利要求是否只含一个句号（单句规则）
    [ERROR] 权利要求中是否出现模糊词（约/大约/左右/等——"等"仅在明显惯用语境警告）
    [ERROR] 权利要求中的附图标记是否在说明书中出现
    [ERROR] 发明名称是否一致（权利要求书与说明书首部）
    [WARNING] 说明书五段式章节是否齐全
    [WARNING] 是否存在量化有益效果数据（数字+%或单位）

退出码: 有 ERROR 时为 1, 否则为 0。
"""
import re
import sys
from pathlib import Path

VAGUE_WORDS = ["大约", "左右", "差不多", "接近"]
SECTION_HEADERS = ["技术领域", "背景技术", "发明内容", "附图说明", "具体实施方式"]

errors: list[str] = []
warnings: list[str] = []


def read_text(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return p.read_text(encoding="gbk", errors="ignore")


def strip_instructions(text: str) -> str:
    """去掉模板使用说明块（> 引用块）和自查清单，只留正文。"""
    lines = []
    for line in text.splitlines():
        if line.strip().startswith(">"):
            continue
        lines.append(line)
    text = "\n".join(lines)
    # 去掉自查清单（最后一个 '## 撰写自查' / '---' 之后的内容）
    for marker in ["## 撰写自查", "## 自查"]:
        idx = text.find(marker)
        if idx != -1:
            text = text[:idx]
    return text


def collect_files(target: Path) -> dict[str, Path]:
    """返回 {文件类型: 路径}。"""
    found: dict[str, Path] = {}
    if target.is_file():
        name = target.stem.lower()
        blob = read_text(target)
        if "权利要求" in blob and "说明书" not in name:
            found["claims"] = target
        elif "技术领域" in blob and "背景技术" in blob:
            found["specification"] = target
        else:
            # 单文件混合模式：所有检查用同一文件
            found = {"claims": target, "specification": target, "abstract": target}
        return found
    mapping = {
        "claims": ["claims", "权利要求"],
        "specification": ["specification", "说明书"],
        "abstract": ["abstract", "摘要"],
        "request": ["request", "请求书"],
    }
    for p in sorted(target.rglob("*.md")):
        name = p.stem.lower()
        for key, keys in mapping.items():
            if key not in found and any(k in name for k in keys):
                # "说明书摘要" 归 abstract, "说明书" 归 specification
                if "摘要" in name and key == "specification":
                    continue
                if "摘要" in name:
                    found["abstract"] = p
                else:
                    found[key] = p
    return found


def check_claims(text: str):
    # 提取权利要求条目: 行首数字.
    items = re.findall(r"^\s*(\d+)\s*[\.、]\s*(.+)$", text, re.M)
    if not items:
        errors.append("权利要求书: 未找到任何编号条目（如 '1. 一种……'）")
        return
    for num, body in items:
        period_count = body.count("。")
        if period_count > 1:
            errors.append(
                f"权利要求 {num}: 含 {period_count} 个句号，违反单句规则（每项权利要求只能一句话）"
            )
        for w in VAGUE_WORDS:
            if w in body:
                errors.append(f"权利要求 {num}: 出现模糊词「{w}」")
        if "等" in body:
            warnings.append(f"权利要求 {num}: 出现「等」字，请确认是否造成保护范围不清楚")


def extract_markers(text: str) -> set[str]:
    """提取附图标记，如 （1）(2) 21 41 等括号内数字。"""
    return set(re.findall(r"[（(](\d{1,3})[）)]", text))


def check_abstract(text: str):
    # 摘要正文: 去掉标题行与模板说明
    body = strip_instructions(text)
    body = re.sub(r"^#.*$", "", body, flags=re.M).strip()
    # 去掉最后的"（实用新型专用……）"提示行
    body = re.sub(r"[（(]实用新型专用.*?[）)]", "", body, flags=re.S)
    chars = re.sub(r"\s", "", body)
    if not chars:
        warnings.append("摘要: 未识别到正文内容（可能仍是空模板）")
        return
    if len(chars) > 300:
        errors.append(f"摘要: 正文 {len(chars)} 字，超过 300 字上限")


def check_specification(text: str):
    for h in SECTION_HEADERS:
        if h not in text:
            errors.append(f"说明书: 缺少必备章节「{h}」")
    eff = re.search(r"(有益效果|有益的技术效果)([\s\S]{0,800})", text)
    if eff:
        seg = eff.group(2)
        if not re.search(r"\d+\s*[%％]|\d+\s*(kN|MPa|mm|天|元|kg)", seg):
            warnings.append(
                "说明书: 有益效果部分未发现量化数据（建议补充如 XX%、±Xmm、XXkN 等对比数据）"
            )


def extract_title_from_claims(text: str) -> str | None:
    m = re.search(r"一种[\u4e00-\u9fa5A-Za-z0-9]{2,30}", text)
    return m.group(0) if m else None


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    target = Path(sys.argv[1])
    if not target.exists():
        print(f"[ERROR] 路径不存在: {target}")
        sys.exit(2)

    files = collect_files(target)
    print("=" * 60)
    print("建筑工程专利申请书自检报告")
    print("=" * 60)

    for need in ["claims", "specification", "abstract"]:
        if need not in files:
            errors.append(f"缺少文件: {need}（权利要求书/说明书/摘要）")

    claims_text = read_text(files["claims"]) if "claims" in files else ""
    spec_text = read_text(files["specification"]) if "specification" in files else ""
    abstract_text = read_text(files["abstract"]) if "abstract" in files else ""

    if claims_text:
        check_claims(claims_text)
    if spec_text:
        check_specification(spec_text)
    if abstract_text:
        check_abstract(abstract_text)

    # 附图标记一致性: 权利要求标记须在说明书出现
    if claims_text and spec_text and claims_text != spec_text:
        claims_markers = extract_markers(claims_text)
        spec_markers = extract_markers(spec_text)
        missing = claims_markers - spec_markers
        if missing:
            errors.append(
                f"附图标记不一致: 权利要求中的标记 {sorted(missing, key=int)} 未在说明书中出现"
            )

    # 名称一致性
    if claims_text and spec_text and claims_text != spec_text:
        t1 = extract_title_from_claims(claims_text)
        t2 = extract_title_from_claims(spec_text)
        if t1 and t2 and t1 != t2:
            warnings.append(f"名称疑似不一致: 权利要求「{t1}」vs 说明书「{t2}」，请人工核对")

    print(f"\n检查文件: {', '.join(str(p) for p in files.values())}\n")
    if errors:
        print(f"✘ ERROR（{len(errors)} 项，必须修复）:")
        for e in errors:
            print(f"  [ERROR] {e}")
    else:
        print("✓ 无 ERROR 级问题")
    if warnings:
        print(f"\n⚠ WARNING（{len(warnings)} 项，建议人工确认）:")
        for w in warnings:
            print(f"  [WARN ] {w}")

    print("\n结论: " + ("存在必须修复的问题，修复后再交付。" if errors else "结构自检通过。"))
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
