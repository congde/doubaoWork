import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(ROOT / "scripts"))


class ExportTests(unittest.TestCase):
    def test_json_and_excel_export(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
            old = os.environ.get("RECRUITMENT_MAIL_DATA")
            os.environ["RECRUITMENT_MAIL_DATA"] = tmp
            try:
                from core import connect
                from export_candidates import export
                db = connect()
                account = db.execute("INSERT INTO accounts(email,provider) VALUES('hr@example.com','qq')").lastrowid
                message = db.execute("INSERT INTO messages(account_id,message_id,classification,confidence,status) VALUES(?,?,?,?,?)", (account,"test-1","resume_submission",.95,"confirmed")).lastrowid
                db.execute("INSERT INTO candidates(message_id,name,email,created_at) VALUES(?,?,?,?)", (message,"张三","candidate@example.com","2026-08-04")); db.commit()
                paths = export("both")
                self.assertEqual(len(paths), 2)
                self.assertTrue(all(Path(path).is_file() for path in paths))
                db.close()
            finally:
                if old is None: os.environ.pop("RECRUITMENT_MAIL_DATA", None)
                else: os.environ["RECRUITMENT_MAIL_DATA"] = old


if __name__ == "__main__": unittest.main()
