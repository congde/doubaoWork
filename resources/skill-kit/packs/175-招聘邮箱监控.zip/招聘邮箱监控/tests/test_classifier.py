import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
from classify_resume import classify


class ClassifierTests(unittest.TestCase):
    def test_resume(self):
        result = classify({"subject":"应聘 Java 开发工程师","body_text":"附件是我的简历，电话 13800138000，包含工作经历和教育经历。","attachments":[{"file_name":"张三-简历.pdf","text":"Java Python 项目经历"}]})
        self.assertEqual(result["classification"], "resume_submission")
        self.assertEqual(result["candidate"]["phone"], "13800138000")

    def test_marketing(self):
        result = classify({"subject":"促销广告","body_text":"订阅 newsletter，退订 unsubscribe","attachments":[]})
        self.assertEqual(result["classification"], "non_recruitment")

    def test_uncertain_not_discarded(self):
        result = classify({"subject":"求职咨询","body_text":"希望申请职位：产品经理","attachments":[]})
        self.assertEqual(result["status"], "manual_review")

    def test_resume_content_with_neutral_filename(self):
        result = classify({"subject":"resume","body_text":"","attachments":[{"file_name":"candidate.pdf","text":"电话 13800138000 工作经历 教育经历 项目经历"}]})
        self.assertEqual(result["classification"], "resume_submission")


if __name__ == "__main__": unittest.main()
