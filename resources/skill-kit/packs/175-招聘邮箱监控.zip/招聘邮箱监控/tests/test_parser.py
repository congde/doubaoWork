import sys
import tempfile
import unittest
from email.message import EmailMessage
from pathlib import Path

ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from parse_message import parse


class ParserTests(unittest.TestCase):
    def test_mime_body_and_attachment(self):
        message = EmailMessage()
        message["Message-ID"] = "parser-test"
        message["Subject"] = "应聘测试"
        message["From"] = "张三 <candidate@example.com>"
        message.set_content("这是正文")
        message.add_attachment("工作经历".encode(), maintype="text", subtype="plain", filename="张三-简历.txt")
        with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
            result = parse(message.as_bytes(), Path(tmp))
            self.assertEqual(result["sender_email"], "candidate@example.com")
            self.assertEqual(result["attachments"][0]["parse_status"], "success")
            self.assertIn("工作经历", result["attachments"][0]["text"])


if __name__ == "__main__": unittest.main()
