---
name: monitor-recruitment-emails
description: 在 Windows 本地配置并定时监控网易、QQ、新浪和 Outlook 招聘邮箱，通过 IMAP 或 Microsoft Graph 增量收信，解析正文及 PDF/DOCX/DOC/TXT 附件，识别简历投递，提取候选人字段，使用 SQLite 去重并导出 Excel/JSON 台账。用于招聘邮箱自动化、简历归档、候选人台账、收信故障诊断和任务计划管理。
---

# 招聘邮件监控

## 工作原则

- 先确认用户同意将邮件中的个人信息交给任何已配置的模型服务；未确认时仅运行本地规则。
- 默认只读邮箱，不删除、移动、标记邮件或执行附件内容。
- 不在对话、日志或配置文件中显示密码、授权码或 OAuth Token。
- 将运行数据写入用户数据目录，绝不写入 Skill 安装目录。
- 首次运行前阅读 `references/providers.md`；字段或状态有疑问时阅读 `references/candidate-schema.md`；失败时阅读 `references/troubleshooting.md`。

## 环境

使用 Python 3.11+。基础能力只依赖标准库；Excel 导出需要 `openpyxl`，PDF 文本提取需要 `pypdf`，DOCX 文本提取需要 `python-docx`，Windows 凭据存储需要 `keyring`。DOC 转换可选用 LibreOffice。

在 Skill 根目录执行命令。数据目录默认是 `%LOCALAPPDATA%\RecruitmentMail`，可通过 `RECRUITMENT_MAIL_DATA` 覆盖。

## 标准流程

1. 初始化数据库：`python scripts/account.py init`
2. 添加 IMAP 账户：`python scripts/account.py add --provider qq --email hr@example.com`
3. 添加 Outlook Graph 账户：`python scripts/account.py add --provider outlook --email hr@example.com --auth-type graph --tenant common --client-id <id>`
4. 测试账户：`python scripts/account.py test --email hr@example.com`
5. 同步当天邮件：`python scripts/sync_mail.py --all`
6. 导出：`python scripts/export_candidates.py --format both`
7. 安装五分钟任务：`python scripts/scheduler.py install --interval 5`

添加 IMAP 账户时让命令在终端安全提示中读取授权码，不要把凭据作为命令参数。Graph 账户使用设备代码授权；按终端提示在浏览器完成授权。

## 分类与复核

规则分类器先排除广告、验证码、账单、订阅通知和群发营销，再综合主题、正文、附件名和附件文本计分。阈值固定为：

- `confidence >= 0.80`：确认简历，状态 `confirmed`
- `0.50 <= confidence < 0.80`：状态 `manual_review`
- `confidence < 0.50`：非简历

不得因单个关键词直接确认简历。信息缺失时输出 `null` 或空数组，不得推测。压缩包、可执行文件、宏文件、加密或损坏附件进入人工处理。扫描 PDF 不做 OCR。

## 常用命令

- 列出账户：`python scripts/account.py list`
- 禁用账户：`python scripts/account.py disable --email hr@example.com`
- 删除账户与凭据：`python scripts/account.py remove --email hr@example.com`
- 只同步一个账户：`python scripts/sync_mail.py --email hr@example.com`
- 重试待复核记录：`python scripts/classify_resume.py --pending`
- 查看最近任务：`python scripts/sync_mail.py --status`
- 卸载计划任务：`python scripts/scheduler.py uninstall`

## 验证输出

每次同步仅处理本地时区当天 00:00 之后收到的邮件，不补处理历史邮件。运行后报告账户成功数、邮件新增数、简历确认数、待人工确认数、失败数和导出路径。单个账户或单封邮件失败不得中断其他处理。数据库事务失败时不得推进同步游标。
