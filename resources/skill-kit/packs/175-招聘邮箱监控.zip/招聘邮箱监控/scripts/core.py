from __future__ import annotations

import json
import os
import sqlite3
from pathlib import Path


def data_dir() -> Path:
    root = os.environ.get("RECRUITMENT_MAIL_DATA")
    if not root:
        root = str(Path(os.environ.get("LOCALAPPDATA", Path.home())) / "RecruitmentMail")
    path = Path(root)
    for child in (path, path / "attachments", path / "exports", path / "logs"):
        child.mkdir(parents=True, exist_ok=True)
    return path


def connect() -> sqlite3.Connection:
    db = sqlite3.connect(data_dir() / "recruitment.db")
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("PRAGMA journal_mode=WAL")
    migrate(db)
    return db


def migrate(db: sqlite3.Connection) -> None:
    db.executescript("""
    CREATE TABLE IF NOT EXISTS accounts(
      id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, provider TEXT NOT NULL,
      auth_type TEXT NOT NULL DEFAULT 'imap', config_json TEXT NOT NULL DEFAULT '{}',
      cursor TEXT, enabled INTEGER NOT NULL DEFAULT 1, last_sync_at TEXT, last_error TEXT);
    CREATE TABLE IF NOT EXISTS messages(
      id INTEGER PRIMARY KEY, account_id INTEGER NOT NULL REFERENCES accounts(id),
      provider_id TEXT, message_id TEXT, folder TEXT NOT NULL DEFAULT 'INBOX',
      received_at TEXT, sender_name TEXT, sender_email TEXT, subject TEXT,
      body_text TEXT, body_hash TEXT, classification TEXT, confidence REAL,
      decision_reasons TEXT, status TEXT, processed_at TEXT,
      UNIQUE(account_id, message_id), UNIQUE(account_id, provider_id));
    CREATE TABLE IF NOT EXISTS attachments(
      id INTEGER PRIMARY KEY, message_id INTEGER NOT NULL REFERENCES messages(id),
      file_name TEXT, media_type TEXT, size INTEGER, sha256 TEXT, stored_path TEXT,
      parse_status TEXT, extracted_text TEXT, UNIQUE(message_id, sha256));
    CREATE TABLE IF NOT EXISTS candidates(
      id INTEGER PRIMARY KEY, message_id INTEGER UNIQUE NOT NULL REFERENCES messages(id),
      name TEXT, phone TEXT, email TEXT, city TEXT, applied_position TEXT,
      current_title TEXT, expected_location TEXT, years_of_experience REAL,
      current_company TEXT, highest_education TEXT, school TEXT,
      skills_json TEXT NOT NULL DEFAULT '[]', certificates_json TEXT NOT NULL DEFAULT '[]',
      languages_json TEXT NOT NULL DEFAULT '[]', duplicate_suspected INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS jobs(
      id INTEGER PRIMARY KEY, started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL,
      accounts_ok INTEGER DEFAULT 0, messages_new INTEGER DEFAULT 0,
      resumes INTEGER DEFAULT 0, manual_review INTEGER DEFAULT 0, failures INTEGER DEFAULT 0,
      error_summary TEXT);
    """)
    db.commit()


def load_config(row) -> dict:
    return json.loads(row["config_json"] or "{}")
