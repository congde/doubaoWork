from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

TASK_NAME = "Monitor Recruitment Emails"


def command() -> str:
    script = Path(__file__).with_name("sync_mail.py")
    return f'"{sys.executable}" "{script}" --all'


def main() -> None:
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest="action",required=True); install=sub.add_parser("install"); install.add_argument("--interval",type=int,default=5); sub.add_parser("uninstall"); sub.add_parser("status"); a=p.parse_args()
    if a.action == "install":
        if not 1 <= a.interval <= 1440: raise SystemExit("interval 必须为 1-1440 分钟")
        args=["schtasks","/Create","/F","/TN",TASK_NAME,"/SC","MINUTE","/MO",str(a.interval),"/TR",command()]
    elif a.action == "uninstall": args=["schtasks","/Delete","/F","/TN",TASK_NAME]
    else: args=["schtasks","/Query","/TN",TASK_NAME,"/FO","LIST"]
    result=subprocess.run(args,capture_output=True,text=True,encoding="utf-8",errors="replace")
    print(json.dumps({"returncode":result.returncode,"stdout":result.stdout.strip(),"stderr":result.stderr.strip()},ensure_ascii=False,indent=2))
    raise SystemExit(result.returncode)


if __name__ == "__main__": main()
