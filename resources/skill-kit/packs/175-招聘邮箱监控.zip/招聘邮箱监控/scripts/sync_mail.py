from __future__ import annotations

import argparse
import base64
import hashlib
import imaplib
import json
import time
import urllib.parse
import urllib.request
from datetime import datetime, time as datetime_time, timezone
from email.message import EmailMessage

from account import credential_get
from classify_resume import classify
from core import connect, data_dir, load_config
from parse_message import parse


def now() -> str: return datetime.now(timezone.utc).isoformat()


def today_window() -> tuple[datetime, datetime]:
    local_now = datetime.now().astimezone()
    local_start = datetime.combine(local_now.date(), datetime_time.min, tzinfo=local_now.tzinfo)
    return local_start, local_start.astimezone(timezone.utc)


def store(db, account, provider_id: str, raw: bytes) -> tuple[bool, str]:
    month = datetime.now().strftime("%Y/%m")
    archive = data_dir() / "attachments" / month; archive.mkdir(parents=True, exist_ok=True)
    item = parse(raw, archive)
    message_id = item["message_id"] or hashlib.sha256(raw).hexdigest()
    try:
        cur = db.execute("INSERT INTO messages(account_id,provider_id,message_id,received_at,sender_name,sender_email,subject,body_text,body_hash,status) VALUES(?,?,?,?,?,?,?,?,?,?)", (account["id"], provider_id, message_id, item["received_at"], item["sender_name"], item["sender_email"], item["subject"], item["body_text"], hashlib.sha256(item["body_text"].encode()).hexdigest(), "pending"))
    except Exception as exc:
        if "UNIQUE constraint" in str(exc): return False, "duplicate"
        raise
    mid = cur.lastrowid
    for a in item["attachments"]:
        db.execute("INSERT OR IGNORE INTO attachments(message_id,file_name,media_type,size,sha256,stored_path,parse_status,extracted_text) VALUES(?,?,?,?,?,?,?,?)", (mid, a["file_name"], a["media_type"], a["size"], a["sha256"], a["stored_path"], a["parse_status"], a["text"]))
    result = classify(item)
    db.execute("UPDATE messages SET classification=?,confidence=?,decision_reasons=?,status=?,processed_at=? WHERE id=?", (result["classification"], result["confidence"], json.dumps(result["decision_reasons"], ensure_ascii=False), result["status"], now(), mid))
    c = result["candidate"]
    if result["status"] in ("confirmed", "manual_review"):
        duplicate = db.execute("SELECT 1 FROM candidates WHERE (phone IS NOT NULL AND phone=?) OR (email IS NOT NULL AND email=?)", (c["phone"], c["email"])).fetchone() is not None
        db.execute("INSERT INTO candidates(message_id,name,phone,email,applied_position,skills_json,duplicate_suspected,created_at) VALUES(?,?,?,?,?,?,?,?)", (mid,c["name"],c["phone"],c["email"],c["applied_position"],json.dumps(c["skills"],ensure_ascii=False),int(duplicate),now()))
    return True, result["status"]


def sync_imap(db, account) -> list[str]:
    config = load_config(account); secret = credential_get(account["email"])
    if not secret: raise RuntimeError("credential missing")
    client = imaplib.IMAP4_SSL(config["imap_host"], config.get("imap_port", 993), timeout=30)
    try:
        client.login(account["email"], secret); client.select(config.get("folder", "INBOX"), readonly=True)
        start = int(account["cursor"] or 0) + 1
        local_start, _ = today_window()
        _, data = client.uid("search", None, "UID", f"{start}:*", "SINCE", local_start.strftime("%d-%b-%Y"))
        ids = [x.decode() for x in data[0].split()]
        results = []
        for uid in ids:
            for attempt in range(3):
                try:
                    status, parts = client.uid("fetch", uid, "(RFC822)")
                    if status != "OK": raise RuntimeError("fetch failed")
                    raw = next(part[1] for part in parts if isinstance(part, tuple))
                    added, result = store(db, account, uid, raw); db.commit(); results.append(result if added else "duplicate"); break
                except Exception:
                    db.rollback()
                    if attempt == 2: results.append("failure")
                    else: time.sleep(2 ** attempt)
        if ids: db.execute("UPDATE accounts SET cursor=?,last_sync_at=?,last_error=NULL WHERE id=?", (max(map(int, ids)), now(), account["id"])); db.commit()
        return results
    finally:
        try: client.logout()
        except Exception: pass


def sync_graph(db, account) -> list[str]:
    token = credential_get(account["email"])
    if not token: raise RuntimeError("credential missing")
    _, utc_start = today_window()
    cutoff = utc_start.isoformat().replace("+00:00", "Z")
    select = "id,internetMessageId,receivedDateTime,subject,from,body,hasAttachments"
    query = urllib.parse.urlencode({"$filter": f"receivedDateTime ge {cutoff}", "$select": select})
    url = "https://graph.microsoft.com/v1.0/me/mailFolders/inbox/messages?" + query
    results = []
    while url:
        req = urllib.request.Request(url, headers={"Authorization": "Bearer " + token, "Prefer": 'outlook.body-content-type="text"'})
        with urllib.request.urlopen(req, timeout=30) as response: page = json.load(response)
        for msg in page.get("value", []):
            if "@removed" in msg: continue
            body = (msg.get("body") or {}).get("content", "")
            sender = ((msg.get("from") or {}).get("emailAddress") or {})
            mime = EmailMessage()
            mime["Message-ID"] = msg.get("internetMessageId") or msg["id"]
            mime["Subject"] = msg.get("subject", "")
            mime["From"] = f"{sender.get('name','')} <{sender.get('address','')}>"
            mime["Date"] = msg.get("receivedDateTime", "")
            mime.set_content(body)
            if msg.get("hasAttachments"):
                attachment_url = f"https://graph.microsoft.com/v1.0/me/messages/{msg['id']}/attachments?$select=name,contentType,size,contentBytes"
                attachment_req = urllib.request.Request(attachment_url, headers={"Authorization": "Bearer " + token})
                with urllib.request.urlopen(attachment_req, timeout=30) as response: attachment_page = json.load(response)
                for attachment in attachment_page.get("value", []):
                    encoded = attachment.get("contentBytes")
                    if not encoded: continue
                    media = (attachment.get("contentType") or "application/octet-stream").split("/", 1)
                    mime.add_attachment(base64.b64decode(encoded), maintype=media[0], subtype=media[1] if len(media) > 1 else "octet-stream", filename=attachment.get("name") or "attachment")
            synthetic = mime.as_bytes()
            added, result = store(db, account, msg["id"], synthetic); db.commit(); results.append(result if added else "duplicate")
        url = page.get("@odata.nextLink")
    db.execute("UPDATE accounts SET last_sync_at=?,last_error=NULL WHERE id=?", (now(), account["id"])); db.commit()
    return results


def run(selected: str | None) -> dict:
    db = connect(); job = db.execute("INSERT INTO jobs(started_at,status) VALUES(?,?)", (now(), "running")).lastrowid; db.commit()
    query = "SELECT * FROM accounts WHERE enabled=1"; params = ()
    if selected: query += " AND email=?"; params = (selected,)
    summary = {"accounts_ok":0,"messages_new":0,"resumes":0,"manual_review":0,"failures":0}
    errors = []
    for account in db.execute(query, params).fetchall():
        try:
            results = sync_graph(db, account) if account["auth_type"] == "graph" else sync_imap(db, account)
            summary["accounts_ok"] += 1; summary["messages_new"] += sum(x != "duplicate" for x in results); summary["resumes"] += results.count("confirmed"); summary["manual_review"] += results.count("manual_review"); summary["failures"] += results.count("failure")
        except Exception as exc:
            summary["failures"] += 1; errors.append(f"{account['email']}: {type(exc).__name__}")
            db.execute("UPDATE accounts SET last_error=? WHERE id=?", (type(exc).__name__, account["id"])); db.commit()
    db.execute("UPDATE jobs SET finished_at=?,status=?,accounts_ok=?,messages_new=?,resumes=?,manual_review=?,failures=?,error_summary=? WHERE id=?", (now(), "completed_with_errors" if errors else "completed", *summary.values(), "; ".join(errors), job)); db.commit()
    return summary | {"errors": errors}


if __name__ == "__main__":
    p=argparse.ArgumentParser(); p.add_argument("--all",action="store_true"); p.add_argument("--email"); p.add_argument("--status",action="store_true"); a=p.parse_args()
    if a.status:
        print(json.dumps([dict(x) for x in connect().execute("SELECT * FROM jobs ORDER BY id DESC LIMIT 10")],ensure_ascii=False,indent=2))
    else: print(json.dumps(run(a.email),ensure_ascii=False,indent=2))
