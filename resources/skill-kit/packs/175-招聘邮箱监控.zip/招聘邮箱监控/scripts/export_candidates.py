from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime
from pathlib import Path

from core import connect, data_dir

FIELDS = ["source_mailbox","folder","message_id","received_at","sender_email","name","phone","email","city","applied_position","current_title","expected_location","years_of_experience","current_company","highest_education","school","skills","classification","confidence","status","attachment_paths","processed_at","duplicate_suspected"]


def records() -> list[dict]:
    db = connect()
    try:
        rows = db.execute("""SELECT a.email source_mailbox,m.folder,m.message_id,m.received_at,m.sender_email,
          c.name,c.phone,c.email,c.city,c.applied_position,c.current_title,c.expected_location,
          c.years_of_experience,c.current_company,c.highest_education,c.school,c.skills_json,
          m.classification,m.confidence,m.status,m.processed_at,c.duplicate_suspected,m.id mid
          FROM candidates c JOIN messages m ON m.id=c.message_id JOIN accounts a ON a.id=m.account_id ORDER BY m.received_at DESC""").fetchall()
        output=[]
        for row in rows:
            item=dict(row); item["skills"]="、".join(json.loads(item.pop("skills_json") or "[]"))
            item["attachment_paths"]="; ".join(x[0] for x in db.execute("SELECT stored_path FROM attachments WHERE message_id=? AND stored_path IS NOT NULL",(item.pop("mid"),)))
            output.append(item)
        return output
    finally:
        db.close()


def export(fmt: str) -> list[str]:
    rows=records(); root=data_dir()/"exports"; stamp=datetime.now().strftime("%Y%m%d-%H%M%S"); paths=[]
    if fmt in ("json","both"):
        path=root/f"candidates-{stamp}.json"; path.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding="utf-8-sig"); paths.append(str(path))
    if fmt in ("excel","both"):
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Alignment, Font, PatternFill
            from openpyxl.utils import get_column_letter
        except ImportError as exc: raise SystemExit("Excel 导出需要 openpyxl") from exc
        path=root/f"candidates-{stamp}.xlsx"; wb=Workbook(); ws=wb.active; ws.title="候选人台账"; ws.append(FIELDS)
        for row in rows: ws.append([row.get(f) for f in FIELDS])
        for cell in ws[1]: cell.font=Font(bold=True,color="FFFFFF"); cell.fill=PatternFill("solid",fgColor="1F4E78")
        ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
        for index, field in enumerate(FIELDS,1): ws.column_dimensions[get_column_letter(index)].width=min(40,max(12,len(field)+2))
        for row in ws.iter_rows():
            for cell in row: cell.alignment=Alignment(vertical="top",wrap_text=True)
        wb.save(path); paths.append(str(path))
    return paths


if __name__ == "__main__":
    p=argparse.ArgumentParser(); p.add_argument("--format",choices=("json","excel","both"),default="both"); a=p.parse_args(); print(json.dumps({"count":len(records()),"exports":export(a.format)},ensure_ascii=False,indent=2))
