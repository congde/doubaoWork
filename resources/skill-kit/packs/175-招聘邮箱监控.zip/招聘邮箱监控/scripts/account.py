from __future__ import annotations

import argparse
import getpass
import imaplib
import json
import sys

from core import connect

SERVICE = "monitor-recruitment-emails"
PROVIDERS = {
    "netease": ("imap.163.com", 993), "qq": ("imap.qq.com", 993),
    "sina": ("imap.sina.com", 993), "outlook": ("outlook.office365.com", 993),
}


def credential_set(email: str, secret: str) -> None:
    try:
        import keyring
    except ImportError as exc:
        raise SystemExit("缺少 keyring：请安装后重试；凭据不会降级保存为明文。") from exc
    keyring.set_password(SERVICE, email, secret)


def credential_get(email: str) -> str | None:
    try:
        import keyring
    except ImportError:
        return None
    return keyring.get_password(SERVICE, email)


def credential_delete(email: str) -> None:
    try:
        import keyring
        keyring.delete_password(SERVICE, email)
    except Exception:
        pass


def add(args) -> None:
    config = {}
    if args.auth_type == "imap":
        host, port = PROVIDERS[args.provider]
        config = {"imap_host": args.host or host, "imap_port": args.port or port, "folder": args.folder}
        secret = getpass.getpass("请输入邮箱客户端授权码（不会回显）：")
    else:
        if args.provider != "outlook": raise SystemExit("Graph 仅适用于 Outlook")
        config = {"tenant": args.tenant, "client_id": args.client_id, "folder": args.folder}
        secret = getpass.getpass("请输入 Microsoft Graph access token（不会回显）：")
    credential_set(args.email, secret)
    db = connect()
    db.execute("INSERT INTO accounts(email,provider,auth_type,config_json) VALUES(?,?,?,?) ON CONFLICT(email) DO UPDATE SET provider=excluded.provider,auth_type=excluded.auth_type,config_json=excluded.config_json,enabled=1,last_error=NULL", (args.email, args.provider, args.auth_type, json.dumps(config)))
    db.commit(); print(json.dumps({"email": args.email, "status": "saved"}, ensure_ascii=False))


def test_account(args) -> None:
    row = connect().execute("SELECT * FROM accounts WHERE email=?", (args.email,)).fetchone()
    if not row: raise SystemExit("账户不存在")
    secret = credential_get(args.email)
    if not secret: raise SystemExit("凭据不存在或 keyring 不可用")
    if row["auth_type"] == "graph":
        import urllib.request
        req = urllib.request.Request("https://graph.microsoft.com/v1.0/me?$select=mail", headers={"Authorization": "Bearer " + secret})
        with urllib.request.urlopen(req, timeout=20) as response: response.read()
    else:
        config = json.loads(row["config_json"]); client = imaplib.IMAP4_SSL(config["imap_host"], config["imap_port"], timeout=20)
        try: client.login(args.email, secret); client.select(config.get("folder", "INBOX"), readonly=True)
        finally: client.logout()
    print(json.dumps({"email": args.email, "status": "connected"}, ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser(description="管理招聘邮箱账户")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init")
    add_p = sub.add_parser("add"); add_p.add_argument("--provider", choices=PROVIDERS, required=True); add_p.add_argument("--email", required=True); add_p.add_argument("--auth-type", choices=("imap", "graph"), default="imap"); add_p.add_argument("--host"); add_p.add_argument("--port", type=int); add_p.add_argument("--folder", default="INBOX"); add_p.add_argument("--tenant", default="common"); add_p.add_argument("--client-id")
    test_p = sub.add_parser("test"); test_p.add_argument("--email", required=True)
    for name in ("disable", "remove"):
        p = sub.add_parser(name); p.add_argument("--email", required=True)
    sub.add_parser("list")
    args = parser.parse_args(); db = connect()
    if args.command == "init": print(json.dumps({"database": str(db.execute("PRAGMA database_list").fetchone()[2]), "status": "ready"}, ensure_ascii=False))
    elif args.command == "add": add(args)
    elif args.command == "test": test_account(args)
    elif args.command == "list": print(json.dumps([{k: row[k] for k in ("email", "provider", "auth_type", "enabled", "last_sync_at", "last_error")} for row in db.execute("SELECT * FROM accounts ORDER BY email")], ensure_ascii=False, indent=2))
    elif args.command == "disable": db.execute("UPDATE accounts SET enabled=0 WHERE email=?", (args.email,)); db.commit(); print("disabled")
    elif args.command == "remove":
        db.execute("UPDATE accounts SET enabled=0,last_error='credential_removed' WHERE email=?", (args.email,)); db.commit()
        credential_delete(args.email); print("credential removed; history retained")


if __name__ == "__main__": main()
