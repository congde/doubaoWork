from __future__ import annotations

import hashlib
import html
import re
import subprocess
import tempfile
from email import policy
from email.header import decode_header
from email.parser import BytesParser
from pathlib import Path

MAX_ATTACHMENT = 20 * 1024 * 1024
SAFE_EXTENSIONS = {".pdf", ".docx", ".doc", ".txt"}


def decode(value: str | None) -> str:
    if not value:
        return ""
    parts = []
    for data, charset in decode_header(value):
        if isinstance(data, bytes):
            parts.append(data.decode(charset or "utf-8", errors="replace"))
        else:
            parts.append(data)
    return "".join(parts)


def html_to_text(value: str) -> str:
    value = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", value)
    value = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</li>", "\n", value)
    value = re.sub(r"(?s)<[^>]+>", " ", value)
    return re.sub(r"[ \t]+", " ", html.unescape(value)).strip()


def extract_text(path: Path) -> tuple[str, str]:
    ext = path.suffix.lower()
    try:
        if ext == ".txt":
            return path.read_text(encoding="utf-8", errors="replace"), "success"
        if ext == ".pdf":
            from pypdf import PdfReader
            return "\n".join(page.extract_text() or "" for page in PdfReader(path).pages), "success"
        if ext == ".docx":
            from docx import Document
            doc = Document(path)
            text = [p.text for p in doc.paragraphs]
            text += [" | ".join(c.text for c in row.cells) for t in doc.tables for row in t.rows]
            return "\n".join(text), "success"
        if ext == ".doc":
            with tempfile.TemporaryDirectory() as tmp:
                subprocess.run(["soffice", "--headless", "--convert-to", "docx", "--outdir", tmp, str(path)], check=True, capture_output=True)
                return extract_text(Path(tmp) / (path.stem + ".docx"))
    except ImportError:
        return "", "dependency_missing"
    except Exception:
        return "", "manual_review"
    return "", "unsupported"


def parse(raw: bytes, archive_root: Path) -> dict:
    msg = BytesParser(policy=policy.default).parsebytes(raw)
    plain, rich, attachments = [], [], []
    for part in msg.walk():
        if part.is_multipart():
            continue
        disposition = part.get_content_disposition()
        content_type = part.get_content_type()
        if disposition != "attachment" and content_type == "text/plain":
            plain.append(part.get_content())
        elif disposition != "attachment" and content_type == "text/html":
            rich.append(html_to_text(part.get_content()))
        elif disposition == "attachment" or part.get_filename():
            name = Path(decode(part.get_filename()) or "attachment").name
            payload = part.get_payload(decode=True) or b""
            digest = hashlib.sha256(payload).hexdigest()
            ext = Path(name).suffix.lower()
            status = "too_large" if len(payload) > MAX_ATTACHMENT else "unsupported"
            stored = None
            extracted = ""
            if len(payload) <= MAX_ATTACHMENT and ext in SAFE_EXTENSIONS:
                target = archive_root / f"{digest[:12]}-{name}"
                target.write_bytes(payload)
                stored = str(target)
                extracted, status = extract_text(target)
            attachments.append({"file_name": name, "media_type": content_type, "size": len(payload), "sha256": digest, "stored_path": stored, "parse_status": status, "text": extracted})
    body = "\n".join(plain).strip() or "\n".join(rich).strip()
    sender = msg.get("from", "")
    address = re.search(r"[\w.+-]+@[\w.-]+", sender)
    return {"message_id": (msg.get("message-id") or "").strip(), "received_at": msg.get("date", ""), "sender_name": decode(sender.split("<")[0]).strip(' \"'), "sender_email": address.group(0) if address else "", "subject": decode(msg.get("subject")), "body_text": body, "attachments": attachments}
