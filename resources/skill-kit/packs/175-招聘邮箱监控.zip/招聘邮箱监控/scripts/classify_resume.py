from __future__ import annotations

import argparse
import json
import re
from datetime import datetime, timezone

from core import connect

POSITIVE = ["应聘", "求职", "简历", "申请职位", "resume", "curriculum vitae", "工作经历", "教育经历", "项目经历"]
NEGATIVE = ["验证码", "账单", "订阅", "广告", "促销", "发票", "unsubscribe", "newsletter"]
POSITIONS = re.compile(r"(?:应聘|申请)(?:岗位|职位)?[：:\s]*([^，。\n]{2,30})")
PHONE = re.compile(r"(?<!\d)(1[3-9]\d{9})(?!\d)")
EMAIL = re.compile(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}")


def classify(message: dict) -> dict:
    subject = message.get("subject") or ""
    body = message.get("body_text") or ""
    attachments = message.get("attachments") or []
    attachment_text = "\n".join(a.get("text", "") for a in attachments)
    combined = "\n".join([subject, body] + [a.get("file_name", "") + "\n" + a.get("text", "") for a in attachments])
    reasons, score = [], 0.0
    # Resume project descriptions may mention features such as verification codes;
    # exclusion signals only apply to the envelope text, not attachment content.
    envelope_text = subject + "\n" + body
    negative = [word for word in NEGATIVE if word.lower() in envelope_text.lower()]
    if negative:
        score -= min(0.65, 0.25 * len(negative)); reasons.append("命中非招聘信号：" + "、".join(negative[:3]))
    subject_hits = [word for word in POSITIVE if word.lower() in subject.lower()]
    body_hits = [word for word in POSITIVE if word.lower() in body.lower()]
    attachment_hits = [word for word in POSITIVE if word.lower() in attachment_text.lower()]
    resume_files = [a for a in attachments if any(x in a.get("file_name", "").lower() for x in ("简历", "resume", "cv"))]
    if subject_hits: score += min(0.35, 0.25 * len(subject_hits)); reasons.append("主题包含求职信号")
    if body_hits: score += min(0.35, 0.15 * len(body_hits)); reasons.append("正文包含履历或求职信号")
    if subject_hits and body_hits: score += 0.15; reasons.append("主题与正文的求职语义相互印证")
    if attachment_hits: score += min(0.35, 0.12 * len(attachment_hits)); reasons.append("附件正文包含履历信号")
    if resume_files: score += 0.35; reasons.append("附件名称符合简历特征")
    if attachments and any(a.get("text") for a in attachments): score += 0.10; reasons.append("附件可解析且含文本")
    if PHONE.search(combined) or EMAIL.search(combined): score += 0.10; reasons.append("检测到候选人联系方式")
    score = round(max(0.0, min(1.0, score)), 2)
    classification = "resume_submission" if score >= 0.8 else ("uncertain" if score >= 0.5 else "non_recruitment")
    position = POSITIONS.search(combined)
    phones, emails = PHONE.findall(combined), EMAIL.findall(combined)
    name = None
    for filename in [a.get("file_name", "") for a in attachments]:
        candidate = re.split(r"[-_—\s]", PathLike(filename))[0]
        if 2 <= len(candidate) <= 4 and re.fullmatch(r"[\u4e00-\u9fff]+", candidate): name = candidate; break
    return {"classification": classification, "is_resume": classification == "resume_submission", "confidence": score, "decision_reasons": reasons or ["未检测到充分的简历投递证据"], "status": "confirmed" if score >= .8 else ("manual_review" if score >= .5 else "non_resume"), "candidate": {"name": name, "phone": phones[0] if phones else None, "email": emails[0] if emails else None, "applied_position": position.group(1).strip() if position else None, "skills": sorted(set(re.findall(r"(?i)\b(?:Java|Python|C\+\+|Go|React|Vue|SQL|Redis|MySQL|Kubernetes|Docker)\b", combined)))}}


def PathLike(name: str) -> str:
    return re.sub(r"\.[^.]+$", "", name)


def process_pending() -> int:
    db = connect(); rows = db.execute("SELECT * FROM messages WHERE status='pending'").fetchall()
    for row in rows:
        atts = [dict(x) | {"text": x["extracted_text"] or ""} for x in db.execute("SELECT * FROM attachments WHERE message_id=?", (row["id"],))]
        result = classify(dict(row) | {"attachments": atts})
        db.execute("UPDATE messages SET classification=?,confidence=?,decision_reasons=?,status=?,processed_at=? WHERE id=?", (result["classification"], result["confidence"], json.dumps(result["decision_reasons"], ensure_ascii=False), result["status"], datetime.now(timezone.utc).isoformat(), row["id"]))
    db.commit(); return len(rows)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(); parser.add_argument("--pending", action="store_true"); parser.add_argument("--input")
    args = parser.parse_args()
    if args.pending: print(json.dumps({"processed": process_pending()}, ensure_ascii=False))
    elif args.input:
        with open(args.input, encoding="utf-8") as f: print(json.dumps(classify(json.load(f)), ensure_ascii=False, indent=2))
    else: parser.error("use --pending or --input")
