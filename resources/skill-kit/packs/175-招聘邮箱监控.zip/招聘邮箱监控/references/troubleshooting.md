# 故障排查

## AUTHENTICATIONFAILED

确认已开启 IMAP，输入的是客户端授权码而非网页密码。删除并重新添加账户会更新 Windows keyring 中的凭据。

## credential missing

安装 `keyring`，确认当前运行用户与添加账户时相同。Windows 计划任务必须以同一个用户运行。

## dependency_missing

PDF、DOCX、Excel 分别需要 `pypdf`、`python-docx`、`openpyxl`。基础邮件同步不会因单个解析依赖缺失而停止，附件会进入人工处理。

## DOC 无法解析

安装 LibreOffice 并确保 `soffice` 在 PATH 中；否则 DOC 附件标记为人工处理。

## Graph 401

access token 已过期或权限不足。重新取得带 `Mail.Read` 的 token 并重新添加账户。正式无人值守部署需要实现 refresh token 生命周期管理。

## 重复或漏信

检查账户的 `cursor`。数据库事务失败不会推进游标；重复同步依靠 Message-ID、provider ID 和附件 SHA-256 保证幂等。
