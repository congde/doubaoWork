# 候选人台账字段

| 分类 | 字段 |
|---|---|
| 来源 | source_mailbox、folder、message_id、received_at、sender_email |
| 候选人 | name、phone、email、city |
| 求职 | applied_position、current_title、expected_location |
| 经历 | years_of_experience、current_company、highest_education、school |
| 技能 | skills、certificates、languages |
| 系统 | classification、confidence、status、attachment_paths、processed_at、duplicate_suspected |

`classification` 为 `resume_submission`、`uncertain` 或 `non_recruitment`。`status` 为 `confirmed`、`manual_review` 或 `non_resume`。缺失字段保持 `null`，不可猜测。电话或邮箱相同仅标记 `duplicate_suspected`，不自动合并。
