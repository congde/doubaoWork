# 邮箱提供商配置

## 网易 163

- Provider：`netease`
- IMAP：`imap.163.com:993`，TLS
- 在网页邮箱开启 IMAP/SMTP，使用客户端授权码，不使用登录密码。

## QQ

- Provider：`qq`
- IMAP：`imap.qq.com:993`，TLS
- 在“设置 > 账户”开启 IMAP/SMTP，使用客户端授权码。

## 新浪

- Provider：`sina`
- IMAP：`imap.sina.com:993`，TLS
- `sina.cn`、VIP 或企业邮箱可能需要通过 `--host` 指定服务地址。

## Outlook / Microsoft 365

优先使用 Microsoft Graph 和最小只读权限 `Mail.Read`。当前命令接受已取得的 access token，并将其交给 Windows keyring 保存。生产部署应由企业 Entra 应用完成 OAuth 设备代码或授权码流程，并定期刷新 token。也可用 IMAP OAuth，但普通密码登录通常被禁用。

Graph 每次查询本地时区当天 00:00 之后收到的邮件。默认读取 Inbox，且不会修改已读状态。

## 同步语义

- IMAP 同时使用当天日期条件和 UID 游标；Graph 使用当天起始时间条件。
- 邮件以“账户 + Message-ID”去重；缺失 Message-ID 时使用原始邮件 SHA-256。
- 附件使用 SHA-256 指纹归档。
- 账户首次接入默认从当前可见 UID 范围读取；如邮箱量很大，应先在独立测试账户验证。
