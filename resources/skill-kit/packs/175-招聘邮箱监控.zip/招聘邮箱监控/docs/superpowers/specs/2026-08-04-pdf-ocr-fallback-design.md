# PDF OCR Fallback Design

## Goal

Add reliable local text extraction for scanned Chinese resume PDFs. Keep `pypdf` as the fast path and invoke PaddleOCR only when the normalized PDF text layer contains fewer than 50 characters.

## Extraction Pipeline

1. Detect PDF files by extension or `%PDF-` signature instead of trusting MIME type.
2. Extract every page with `pypdf` and normalize whitespace while preserving one line break between logical blocks.
3. Return the text-layer result when at least 50 non-whitespace Unicode code points remain.
4. Otherwise render each page with PyMuPDF at 240 DPI, up to 30 pages.
5. Run a lazily initialized Chinese PaddleOCR model on each rendered page.
6. Sort OCR blocks by page number, then top coordinate, then left coordinate. Join blocks with one line break and collapse repeated spaces and blank lines.
7. Compute aggregate confidence as the character-count-weighted mean of non-empty OCR blocks. Empty pages do not contribute.
8. Persist the extraction method, aggregate confidence, total page count, processed page count, warning/error, and completion time.
9. Classify the email and extract candidate fields from the email body, attachment filename, and extracted attachment text.

## Status Rules

- `success`: usable text extracted by `pypdf`.
- `ocr_success`: PaddleOCR returned at least 50 non-whitespace characters with aggregate confidence at least 0.75 and processed every page.
- `manual_review`: OCR returned less than 50 characters, confidence below 0.75, or processed fewer pages than the PDF contains.
- `failed`: the PDF is encrypted, corrupt, missing, or cannot be rendered.

## Data Changes

Add nullable columns to `attachments` with an explicit idempotent migration. Read `PRAGMA table_info(attachments)` and execute one `ALTER TABLE ... ADD COLUMN` for each missing column. Running the migration repeatedly must be a no-op:

- `extraction_method`
- `ocr_confidence`
- `ocr_page_count`
- `ocr_total_pages`
- `extraction_error`
- `extracted_at`

Keep `extracted_text` as the canonical normalized text used by classification and export.

Use `TEXT` for method, error, and timestamp, `REAL` for confidence, and `INTEGER` for page counts. Test migration from the current production schema and a second migration pass.

Apply the same `PRAGMA table_info` migration pattern to add `candidates.active INTEGER NOT NULL DEFAULT 1`, `messages.received_at_utc TEXT`, and `messages.imap_uidvalidity TEXT`. Existing candidate rows become active. Existing messages leave the two new message fields null until a source mailbox refresh provides authoritative values.

Attachment extraction state and message classification state remain separate. Any attachment in `manual_review` or `failed` forces the parent message to `manual_review` unless another attachment has a successful extraction that independently supplies at least 50 characters and the classifier confirms the submission. An attachment state never directly marks a message as `confirmed`.

## Candidate Extraction

Extract name, phone, email, years of experience, applied position, and skills from the combined source text. Treat a filename such as `刘欣 7年.pdf` as supporting evidence. Explicit content inside the resume takes precedence, and missing fields remain null.

## Recovery And Reprocessing

Provide a command that reprocesses PDF attachments in `manual_review` or `failed` state. Persist the selected mailbox folder and the mailbox UIDVALIDITY on every IMAP message. During normal sync, obtain UID, `INTERNALDATE`, and RFC822 in the same fetch, store UIDVALIDITY from the selected mailbox response, and normalize `INTERNALDATE` to `messages.received_at_utc`. Recovery selects the stored folder and compares its current UIDVALIDITY with `messages.imap_uidvalidity` before fetching the stored UID; a missing legacy UIDVALIDITY requires manual review rather than an unsafe fetch. A changed UIDVALIDITY or moved/deleted message also remains manual review. For Graph, fetch the stored message ID, persist Graph `receivedDateTime` as `received_at_utc`, and follow attachment pagination; an expired token produces an account authentication error without changing the attachment row.

Match a restored attachment by SHA-256, not filename. Write it to a temporary sibling path, verify the digest, atomically replace the final path, and update `stored_path` only after replacement succeeds. A digest mismatch or missing source remains `manual_review` with a concise error category.

Limit the immediate recovery run to messages whose authoritative `received_at_utc` falls within today in fixed UTC+8. For IMAP this value comes only from `INTERNALDATE`; for Graph it comes from `receivedDateTime`. The sender-controlled MIME `Date` header remains display metadata and is never used for the today filter. Legacy rows with a null authoritative timestamp must first be refreshed from the source mailbox; if refresh is unsafe or unavailable, they do not qualify for automatic today-only recovery.

Reprocessing updates the existing attachment and message rows and UPSERTs the candidate by unique `message_id`. Explicit resume text overrides body text, which overrides filename hints. Every rerun replaces derived candidate fields, including clearing stale values to null. If a rerun becomes non-resume, retain the candidate row for audit but mark it inactive through `candidates.active INTEGER NOT NULL DEFAULT 1`. Repeated runs must produce the same rows and values.

## Resource And Privacy Constraints

- Support 64-bit Windows with Python 3.11. Pin compatible major ranges: `PyMuPDF>=1.24,<2`, `paddleocr>=3,<4`, and CPU `paddlepaddle>=3,<4`. Verify wheel availability during installation.
- Hide PaddleOCR API differences behind an injectable `OcrEngine` adapter that returns normalized blocks `(text, confidence, top, left)`; unit tests use a fake engine.
- Load PaddleOCR only when OCR is required.
- Provide an interactive `ocr setup` command that records consent in the local configuration and preloads the Chinese model before scheduled OCR is enabled. Scheduled or other unattended runs never prompt and never download models. Without recorded consent and a ready model, they set `ocr_unavailable` and continue.
- Store model/cache data under `%LOCALAPPDATA%\RecruitmentMail\models`; model or dependency unavailability records `ocr_unavailable` and continues other mail.
- Render at 240 DPI and never above 300 DPI.
- Process no more than 30 pages per PDF. PDFs above 30 pages record total and processed counts, set warning `page_limit`, and always enter attachment `manual_review` even when recognized text is otherwise strong.
- Delete rendered page images immediately after OCR.
- Keep all PDF and OCR data local; do not send resume content to a cloud model.

## Error Handling

An OCR failure affects only the current attachment. Store a concise error category without resume content or credentials, set the attachment to `manual_review` or `failed`, and continue processing other messages. Write originals and rendered files to temporary paths; delete temporary and orphan files on exception. Commit database paths and derived values only after final files are atomically in place. If the database commit fails, remove newly created final files when they are not referenced by another row.

## Tests And Acceptance

- Existing five tests continue to pass.
- Old-schema migration adds attachment OCR fields, candidate active state, authoritative receipt time, and IMAP UIDVALIDITY; it succeeds twice without data loss.
- Text PDFs use `pypdf` without loading PaddleOCR.
- Scanned Chinese PDFs trigger the OCR fallback.
- OCR method, confidence, page count, text, and status persist correctly.
- Low-confidence OCR enters manual review.
- Missing attachment recovery restores the original file and reprocesses it.
- Reprocessing is idempotent.
- The `刘欣 7年.pdf` case produces usable text and extracts `刘欣` and seven years of experience.
- Today's reprocessing does not scan or modify unrelated historical messages.
- Unit tests cover an unavailable OCR model, encrypted/corrupt PDF, per-page OCR exception, 30-page truncation, extensionless `%PDF` detection, IMAP non-INBOX recovery, UIDVALIDITY change, deleted source, SHA mismatch, candidate UPSERT twice, and orphan cleanup.
- UTC+8 boundary tests cover exactly 00:00 and 23:59:59. Real PaddleOCR is isolated to one small optional Chinese integration fixture; ordinary tests use the injected fake engine.
