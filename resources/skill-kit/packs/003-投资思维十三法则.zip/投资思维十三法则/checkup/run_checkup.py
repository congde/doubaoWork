#!/usr/bin/env python3
"""
十三法则持仓体检生成器（纯标准库，零依赖）

用法:
  python3 run_checkup.py checkup_input.json -o 输出目录/

输入: checkup_input.json（格式见 checkup_workflow.md）
输出: checkup_report.md（结构化测试分析报告）
      risk_heatmap.html（交互式风险热力图看板）
"""
import argparse
import json
import os
import sys
from datetime import datetime

RULE_ORDER = [
    "能力圈", "机会四问", "趋势为王", "增速为王", "垄断为王",
    "应用vs生态", "简单为王", "零杠杆", "反脆弱冗余",
    "正反馈临界点", "认知偏误防御", "第一性原理", "稀缺定价权",
]
STAGE_MAP = {
    "能力圈": "入场前", "机会四问": "入场前", "趋势为王": "入场前",
    "增速为王": "选标的", "垄断为王": "选标的", "应用vs生态": "选标的",
    "简单为王": "定方式", "零杠杆": "定方式", "反脆弱冗余": "定方式",
    "正反馈临界点": "持仓中", "认知偏误防御": "持仓中",
    "第一性原理": "底层心法", "稀缺定价权": "底层心法",
}


def status_of(score):
    if score is None:
        return "gap"
    if score >= 80:
        return "pass"
    if score >= 60:
        return "warn"
    return "fail"


def level_of(total):
    if total >= 80:
        return "绿色·健康"
    if total >= 60:
        return "黄色·警戒"
    return "红色·高危"


def load_and_validate(path):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    meta = data.get("meta", {})
    raw = data.get("scores", [])
    by_rule = {}
    for item in raw:
        rule = item.get("rule")
        if rule not in RULE_ORDER:
            raise SystemExit(f"未知法则名: {rule}（合法值: {'/'.join(RULE_ORDER)}）")
        score = item.get("score")
        if score is not None and not (isinstance(score, (int, float)) and 0 <= score <= 100):
            raise SystemExit(f"法则 [{rule}] 评分非法: {score}（0-100 或 null）")
        by_rule[rule] = item
    scores = []
    for rule in RULE_ORDER:
        item = by_rule.get(rule)
        if item is None:
            scores.append({"rule": rule, "score": None, "evidence": "未评估",
                           "risk": "", "actions": []})
        else:
            score = item.get("score")
            score = round(float(score)) if score is not None else None
            scores.append({
                "rule": rule,
                "score": score,
                "evidence": item.get("evidence", ""),
                "risk": item.get("risk", ""),
                "actions": item.get("actions", []),
            })
    return meta, scores


def summarize(scores):
    valid = [s["score"] for s in scores if s["score"] is not None]
    total = round(sum(valid) / len(valid), 1) if valid else None
    counts = {"pass": 0, "warn": 0, "fail": 0, "gap": 0}
    for s in scores:
        counts[status_of(s["score"])] += 1
    weakest = sorted(
        [s for s in scores if s["score"] is not None], key=lambda x: x["score"]
    )[:3]
    return total, counts, weakest


def esc(t):
    return (str(t).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def build_report(meta, scores, total, counts, weakest):
    lines = []
    date = meta.get("date") or datetime.now().strftime("%Y-%m-%d")
    level = level_of(total) if total is not None else "无法评级（信息不足）"
    lines.append(f"# 十三法则持仓体检报告")
    lines.append("")
    lines.append(f"- **体检对象**: {meta.get('target', '未提供')}")
    lines.append(f"- **仓位结构**: {meta.get('position', '未提供')}")
    lines.append(f"- **在考虑操作**: {meta.get('pending_action') or '无'}")
    lines.append(f"- **体检日期**: {date}")
    lines.append("")
    lines.append("## 一、结论")
    verdict = (
        f"十三法则综合得分 **{total}/100**，判定为 **{level}**。"
        if total is not None else "有效评分不足，无法给出综合判定。"
    )
    lines.append(verdict)
    lines.append(
        f"违规 {counts['fail']} 项 / 警戒 {counts['warn']} 项 / "
        f"通过 {counts['pass']} 项 / 信息缺口 {counts['gap']} 项。"
    )
    lines.append("")
    lines.append("## 二、最薄弱点 Top3")
    if weakest:
        for i, s in enumerate(weakest, 1):
            lines.append(f"{i}. **{s['rule']}**（{s['score']} 分）— {s['risk'] or s['evidence']}")
    else:
        lines.append("无有效评分。")
    lines.append("")
    lines.append("## 三、隐藏假设（信息缺口即假设）")
    gaps = [s for s in scores if s["score"] is None]
    if gaps:
        for s in gaps:
            lines.append(f"- **{s['rule']}**：未提供足够信息 → 默认按\"不合规\"对待，补充信息后复检")
    else:
        lines.append("无信息缺口。")
    lines.append("")
    lines.append("## 四、逐法则明细")
    lines.append("| 法则 | 阶段 | 得分 | 状态 | 评分依据 | 违规风险 |")
    lines.append("|---|---|---|---|---|---|")
    icon = {"pass": "✅", "warn": "⚠️", "fail": "❌", "gap": "❓"}
    for s in scores:
        st = status_of(s["score"])
        lines.append(
            f"| {s['rule']} | {STAGE_MAP[s['rule']]} | "
            f"{s['score'] if s['score'] is not None else '—'} | {icon[st]} | "
            f"{s['evidence'] or '—'} | {s['risk'] or '—'} |"
        )
    lines.append("")
    lines.append("## 五、失败路径推演")
    fail_chain = [s for s in scores if status_of(s["score"]) in ("fail", "warn")]
    if fail_chain:
        parts = [f"{s['rule']}({s['score']}分)" for s in fail_chain]
        lines.append(
            "当前偏离的法则构成如下传导链：**" + " → ".join(parts) + "**。"
            "最先断裂的环节通常是最薄弱点；任何一环触发，其违规风险会沿持仓放大。"
        )
    else:
        lines.append("无 fail/warn 项，未推演出明显失败路径（仍需按信息缺口补全复检）。")
    lines.append("")
    lines.append("## 六、下一步行动清单（按优先级）")
    prio = {"fail": 1, "warn": 2, "gap": 3, "pass": 4}
    todo = sorted(scores, key=lambda s: (prio[status_of(s["score"])], -(s["score"] or 0)))
    n = 0
    for s in todo:
        st = status_of(s["score"])
        if st == "pass" and not s["actions"]:
            continue
        for a in s["actions"]:
            n += 1
            tag = {"fail": "🔴立即", "warn": "🟡尽快", "gap": "❓补信息", "pass": "🟢保持"}[st]
            lines.append(f"{n}. [{tag}] **{s['rule']}** — {a}")
    if n == 0:
        lines.append("无待办。保持现状并定期复检。")
    lines.append("")
    lines.append("---")
    lines.append("*本报告由十三法则体检器生成，评分依据 13 条法则的可执行步骤；不构成投资建议。*")
    return "\n".join(lines)


HEAT_COLOR = {"pass": "#2e9e5b", "warn": "#e8a13a", "fail": "#d9463e", "gap": "#9aa0a6"}


def build_heatmap(meta, scores, total, counts, weakest):
    date = meta.get("date") or datetime.now().strftime("%Y-%m-%d")
    rows_html = []
    for s in scores:
        st = status_of(s["score"])
        color = HEAT_COLOR[st]
        score_txt = str(s["score"]) if s["score"] is not None else "—"
        badge = {"pass": "✅ 通过", "warn": "⚠️ 警戒", "fail": "❌ 违规", "gap": "❓ 信息缺口"}[st]
        actions_html = "".join(f"<li>{esc(a)}</li>" for a in s["actions"]) or "<li>—</li>"
        rows_html.append(f"""
        <tr class="rule-row" data-rule="{esc(s['rule'])}">
          <td class="stage">{esc(STAGE_MAP[s['rule']])}</td>
          <td class="rule-name">{esc(s['rule'])}</td>
          <td class="score-cell" style="background:{color}22;border-left:4px solid {color}">
            <span class="score-num" style="color:{color}">{score_txt}</span>
          </td>
          <td><span class="badge" style="background:{color}1a;color:{color}">{badge}</span></td>
          <td class="evi">{esc(s['evidence'] or '—')}</td>
        </tr>
        <tr class="detail-row" data-detail="{esc(s['rule'])}">
          <td colspan="5">
            <div class="detail-box">
              <p><b>违规风险：</b>{esc(s['risk'] or '—')}</p>
              <p><b>改进行动：</b></p><ul>{actions_html}</ul>
            </div>
          </td>
        </tr>""")
    rows = "".join(rows_html)
    level = level_of(total) if total is not None else "无法评级"
    total_color = HEAT_COLOR["pass"] if total and total >= 80 else (
        HEAT_COLOR["warn"] if total and total >= 60 else HEAT_COLOR["fail"])
    weakest_parts = []
    for s in weakest:
        c = HEAT_COLOR[status_of(s["score"])]
        weakest_parts.append(
            f"<div class='weak-card' style='border-left:4px solid {c}'>"
            f"<b>{esc(s['rule'])}</b><span>{s['score']} 分</span>"
            f"<small>{esc((s['risk'] or s['evidence'] or '')[:40])}</small></div>")
    weakest_html = "".join(weakest_parts)
    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>十三法则风险热力图 — {esc(meta.get('target', '持仓体检'))}</title>
<style>
  :root {{ --bg:#f7f8fa; --card:#fff; --text:#1f2329; --sub:#6b7280; --line:#e5e7eb; }}
  * {{ margin:0; padding:0; box-sizing:border-box; }}
  body {{ font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;
         background:var(--bg); color:var(--text); padding:24px; }}
  .wrap {{ max-width:1080px; margin:0 auto; }}
  h1 {{ font-size:22px; margin-bottom:4px; }}
  .meta {{ color:var(--sub); font-size:13px; margin-bottom:20px; }}
  .cards {{ display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:16px; }}
  .card {{ background:var(--card); border:1px solid var(--line); border-radius:10px;
          padding:14px 16px; }}
  .card .num {{ font-size:26px; font-weight:700; }}
  .card .lbl {{ font-size:12px; color:var(--sub); margin-top:2px; }}
  .weak {{ display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:16px; }}
  .weak-card {{ background:var(--card); border:1px solid var(--line); border-radius:10px;
               padding:12px 14px; display:flex; flex-direction:column; gap:4px; }}
  .weak-card span {{ font-size:18px; font-weight:700; }}
  .weak-card small {{ color:var(--sub); font-size:12px; }}
  table {{ width:100%; border-collapse:collapse; background:var(--card);
          border:1px solid var(--line); border-radius:10px; overflow:hidden; }}
  th {{ background:#f0f1f3; font-size:12px; color:var(--sub); text-align:left;
       padding:10px 12px; border-bottom:1px solid var(--line); }}
  td {{ padding:10px 12px; border-bottom:1px solid var(--line); font-size:14px; }}
  .stage {{ font-size:12px; color:var(--sub); white-space:nowrap; }}
  .rule-name {{ font-weight:600; white-space:nowrap; }}
  .score-cell {{ width:90px; }}
  .score-num {{ font-size:18px; font-weight:700; }}
  .badge {{ font-size:12px; padding:2px 10px; border-radius:20px; white-space:nowrap; }}
  .evi {{ color:var(--sub); font-size:13px; }}
  .detail-row {{ display:none; }}
  .detail-row.open {{ display:table-row; }}
  .detail-box {{ background:#fafbfc; padding:12px 16px; font-size:13px; }}
  .detail-box ul {{ margin:6px 0 0 18px; }}
  .rule-row {{ cursor:pointer; }}
  .rule-row:hover {{ background:#f5f6f8; }}
  .foot {{ color:var(--sub); font-size:12px; margin-top:16px; text-align:center; }}
</style>
</head>
<body>
<div class="wrap">
  <h1>十三法则风险热力图</h1>
  <div class="meta">体检对象：{esc(meta.get('target', '未提供'))} ｜ 仓位：{esc(meta.get('position', '未提供'))} ｜ 在考虑操作：{esc(meta.get('pending_action') or '无')} ｜ {esc(date)}</div>
  <div class="cards">
    <div class="card"><div class="num" style="color:{total_color}">{total if total is not None else '—'}</div><div class="lbl">综合得分 / 100（{level}）</div></div>
    <div class="card"><div class="num" style="color:{HEAT_COLOR['fail']}">{counts['fail']}</div><div class="lbl">违规项</div></div>
    <div class="card"><div class="num" style="color:{HEAT_COLOR['warn']}">{counts['warn']}</div><div class="lbl">警戒项</div></div>
    <div class="card"><div class="num" style="color:{HEAT_COLOR['gap']}">{counts['gap']}</div><div class="lbl">信息缺口</div></div>
  </div>
  <div class="weak">{weakest_html}</div>
  <table>
    <thead><tr><th>阶段</th><th>法则</th><th>得分</th><th>状态</th><th>评分依据</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
  <div class="foot">点击任意行展开风险与行动详情 ｜ 由十三法则体检器生成 ｜ 不构成投资建议</div>
</div>
<script>
  document.querySelectorAll('.rule-row').forEach(function(row) {{
    row.addEventListener('click', function() {{
      var d = document.querySelector(
        '.detail-row[data-detail="' + row.dataset.rule + '"]');
      if (d) d.classList.toggle('open');
    }});
  }});
</script>
</body>
</html>"""


def main():
    ap = argparse.ArgumentParser(description="十三法则持仓体检生成器")
    ap.add_argument("input", help="checkup_input.json 路径")
    ap.add_argument("-o", "--outdir", default=".", help="输出目录")
    args = ap.parse_args()

    meta, scores = load_and_validate(args.input)
    total, counts, weakest = summarize(scores)
    os.makedirs(args.outdir, exist_ok=True)

    report = build_report(meta, scores, total, counts, weakest)
    rp = os.path.join(args.outdir, "checkup_report.md")
    with open(rp, "w", encoding="utf-8") as f:
        f.write(report)

    heatmap = build_heatmap(meta, scores, total, counts, weakest)
    hp = os.path.join(args.outdir, "risk_heatmap.html")
    with open(hp, "w", encoding="utf-8") as f:
        f.write(heatmap)

    print(f"综合得分: {total}  违规 {counts['fail']} / 警戒 {counts['warn']} / "
          f"通过 {counts['pass']} / 缺口 {counts['gap']}")
    print(f"报告: {rp}")
    print(f"热力图: {hp}")


if __name__ == "__main__":
    main()
