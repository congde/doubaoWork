# shot-analysis-assistant

> 本 Skill 由非叔 Levie 开发，欢迎使用交流。

把一个视频拆成可复盘、可复刻、可沉淀的镜头数据库。

![shot-analysis-assistant 项目信息图](assets/shot-analysis-assistant-infographic.png)

`shot-analysis-assistant` 是一个面向 Codex / OpenCode Agent 的视频拉片 Skill：上传视频后，它会用 `ffmpeg` 自动抽取镜头截图和时间段，引导 Agent 逐镜头分析画面、叙事作用、景别、运镜、声音和节奏，并把结果连同截图幂等写入飞书多维表格 Base。

更重要的是，它不只做“看懂视频”，还会倒推出三类可复刻资产：

- **生成分镜提示词**：用于生成单张分镜图、故事板或关键帧。
- **生成视频提示词**：用于即梦、Seedance、可灵、Runway 等视频模型的时间轴 prompt。
- **负面提示词**：约束文字错误、人物漂移、镜头抖动、构图和风格偏差。

适合做短视频拆解、广告案例复盘、课程内容结构化、竞品视频学习、AI 视频工作流沉淀。

## 它解决什么问题

很多视频拉片最后都散落在截图、文档和脑子里。真正有价值的东西很难复用：

- 这个镜头为什么放在这里？
- 它承担的是开场钩子、产品信任、情绪推进，还是转场承接？
- 如果我要复刻它，应该怎么写分镜提示词？
- 如果我要让视频模型生成类似片段，时间轴 prompt 应该怎么写？
- 这些分析能不能直接沉淀到团队共享的飞书表格里？

这个 skill 把上面的流程变成一个稳定链路：**视频 → 镜头截图 → 拉片分析 → 倒推提示词 → 飞书 Base**。

## 核心功能

- 自动检测视频镜头切点，生成每个镜头的代表截图。
- 输出镜头、分析帧、音频信号、OCR、ASR 和工作稿等结构化产物。
- 使用稳定唯一键幂等写入飞书 Base，同时上传代表帧和分析帧。
- 使用独立专业 schema，覆盖资产版本、摄影语言、声音文本、叙事营销、生成提示词和质检复核。
- 支持短视频逐镜头精拆，长视频先自动切分再按段落合并。

## 输出字段

默认写入 59 个专业字段，完整定义见 `references/base-schema.json`：

| 字段 | 作用 |
| --- | --- |
| 资产与版本 | 项目、文件名、SHA-256、批次、分析版本、镜头唯一键 |
| 时间轴与附件 | 代表帧、分析帧、分段类型、起始/结束秒、时间码、时长 |
| 摄影语言 | 景别、机位、构图、运镜、主体动作、表演、场景、光线、色彩、景深、剪辑 |
| 声音与文字 | 屏幕文字、OCR、ASR、口播、声音设计、BGM、音频信号摘要 |
| 叙事与营销 | 叙事阶段/功能、注意力、卖点证据、信任、CTA、受众、风险合规 |
| 生成与质检 | 关键帧/视频/负面提示词、分析来源、置信度、状态、人工复核 |

## 安装

把本 Skill 目录复制到你的外部 skill 目录：

```bash
cp -R /path/to/shot-analysis-assistant ~/.config/opencode/skills/shot-analysis-assistant
```

如果你使用的是 Codex skill 目录，也可以放到：

```bash
mkdir -p ~/.codex/skills
cp -R /path/to/shot-analysis-assistant ~/.codex/skills/shot-analysis-assistant
```

## 依赖

本 skill 依赖：

- `python3`
- `ffmpeg`
- `ffprobe`
- `lark-cli`
- 已配置好的飞书/Lark 应用权限

你可以先检查：

```bash
python3 --version
ffmpeg -version
ffprobe -version
lark-cli --help
```

## 快速开始

先用脚本抽取镜头候选和代表截图：

```bash
python3 scripts/extract_shots.py ./demo.mp4 \
  --out-dir ./lapian_output \
  --threshold 0.32 \
  --min-gap 0.45
```

输出目录会包含：

```text
lapian_output/
├── analysis_prompt.md
├── shots.csv
├── shots.json
├── audio_analysis.json
├── asr_transcript.json
├── ocr_timeline.json
├── extract_audio.wav
├── frames/
    ├── shot_001.jpg
    ├── shot_002.jpg
    └── ...
└── analysis_frames/
    └── ...
```

然后在 Agent 里说：

```text
使用 $shot-analysis-assistant 分析这个视频，把结果上传到这个飞书 Base：<你的 Base 链接或 token>
```

Agent 会按 skill 流程读取 `lark-base` 规范，创建或补齐字段，逐条写入记录，并上传每个镜头截图附件。

## 典型工作流

1. 上传视频或给出本地视频路径。
2. 自动抽取镜头段和代表截图。
3. Agent 逐镜头分析：
   - 画面发生了什么
   - 它承担什么叙事作用
   - 用了什么景别、运镜、转场
   - 声音、字幕、节奏如何配合
4. 倒推三类 prompt：关键帧、时间轴视频和负面约束。
5. 写入飞书 Base，形成可检索、可复盘、可复用的视频案例库。

## 参数建议

`extract_shots.py` 常用参数：

| 参数 | 默认值 | 说明 |
| --- | --- | --- |
| `--threshold` | `0.32` | 场景变化检测阈值，越高切得越少 |
| `--min-gap` | `0.45` | 两个镜头切点之间的最短间隔 |
| `--fallback-interval` | `2.0` | 没检测到切点时按固定间隔补采样 |
| `--max-shots` | `160` | 最大镜头数，避免长视频爆量 |
| `--width` | `720` | 截图宽度，兼顾清晰度和飞书附件体积 |

如果切得太碎：

```bash
python3 scripts/extract_shots.py ./demo.mp4 --threshold 0.42 --min-gap 0.8
```

如果漏切明显：

```bash
python3 scripts/extract_shots.py ./demo.mp4 --threshold 0.22 --min-gap 0.3
```

## 飞书 Base 注意事项

- 截图字段必须是附件字段。
- 附件上传必须走 `lark-cli base +record-upload-attachment`。
- 写入前先用 `+field-list` 读取真实字段结构，避免重复建字段。
- 如果用户给的是 `/wiki/` 链接，要先解析真实 `obj_token`，再作为 Base token 使用。
- 普通飞书电子表格不适合存镜头附件和单选标签，默认优先用多维表格 Base。

## 开发者与开源协议

开发者：非叔 Levie。

Copyright (c) 2026 非叔 Levie。项目采用 MIT License。欢迎 fork、改字段、改 prompt、接入你自己的视频生成工具链，也欢迎使用交流。

如果你用它搭出了一个好用的视频案例库，欢迎给这个仓库一个 star。
