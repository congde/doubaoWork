"""Optional OCR and ASR enrichment."""

# Copyright (c) 2026 非叔 Levie
# SPDX-License-Identifier: MIT

from __future__ import annotations

import json
import shutil
from pathlib import Path

from .common import run


def tesseract_languages() -> set[str]:
    if shutil.which("tesseract") is None:
        return set()
    proc = run(["tesseract", "--list-langs"])
    if proc.returncode != 0:
        return set()
    return {line.strip() for line in proc.stdout.splitlines()[1:] if line.strip()}


def ocr_frame(image: Path, languages: str) -> dict[str, object]:
    proc = run(["tesseract", str(image), "stdout", "-l", languages, "--psm", "6", "tsv"])
    if proc.returncode != 0:
        return {"status": "error", "text": "", "confidence": 0.0, "error": proc.stderr.strip()}
    words: list[str] = []
    confidences: list[float] = []
    for line in proc.stdout.splitlines()[1:]:
        parts = line.split("\t")
        if len(parts) < 12:
            continue
        try:
            confidence = float(parts[10])
        except ValueError:
            continue
        word = parts[11].strip()
        if word and confidence >= 35:
            words.append(word)
            confidences.append(confidence)
    return {
        "status": "ok",
        "text": " ".join(words),
        "confidence": round(sum(confidences) / len(confidences), 2) if confidences else 0.0,
    }


def run_asr(audio: Path, out_dir: Path, mode: str, model: str, language: str) -> dict[str, object]:
    if mode == "off":
        return {"status": "disabled", "source": "audio_asr", "confidence": "unavailable"}
    whisper = shutil.which("whisper")
    if whisper is None:
        return {
            "status": "unavailable",
            "source": "audio_asr",
            "confidence": "unavailable",
            "hint": "Install the OpenAI Whisper CLI or rerun with --asr-mode off.",
        }
    asr_dir = out_dir / "asr"
    asr_dir.mkdir(parents=True, exist_ok=True)
    proc = run(
        [
            whisper,
            str(audio),
            "--model",
            model,
            "--language",
            language,
            "--output_format",
            "json",
            "--output_dir",
            str(asr_dir),
        ]
    )
    result_path = asr_dir / f"{audio.stem}.json"
    if proc.returncode != 0 or not result_path.exists():
        return {
            "status": "error",
            "source": "audio_asr",
            "confidence": "unavailable",
            "error": proc.stderr.strip() or "Whisper produced no JSON output",
        }
    payload = json.loads(result_path.read_text(encoding="utf-8"))
    return {
        "status": "ok",
        "source": "audio_asr",
        "confidence": "model_generated",
        "model": model,
        "language": language,
        "text": payload.get("text", "").strip(),
        "segments": payload.get("segments", []),
    }
