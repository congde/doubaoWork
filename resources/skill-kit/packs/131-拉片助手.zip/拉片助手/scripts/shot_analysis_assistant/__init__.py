"""Core helpers for the shot-analysis-assistant Skill."""

# Copyright (c) 2026 非叔 Levie
# SPDX-License-Identifier: MIT

__version__ = "2.0.0"
