"""Shot and analysis-segment boundary policies."""

# Copyright (c) 2026 非叔 Levie
# SPDX-License-Identifier: MIT

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class SegmentationResult:
    bounds: list[float]
    detection_mode: str
    segment_type: str


def merge_short_tail(bounds: list[float], minimum: float) -> list[float]:
    if len(bounds) > 2 and bounds[-1] - bounds[-2] < minimum:
        return bounds[:-2] + [bounds[-1]]
    return bounds


def dedupe_times(times: list[float], duration: float, min_gap: float) -> list[float]:
    cleaned = [0.0]
    for timestamp in sorted(times):
        if 0.0 < timestamp < duration and timestamp - cleaned[-1] >= min_gap:
            cleaned.append(timestamp)
    cleaned.append(duration)
    return merge_short_tail(cleaned, min_gap)


def fallback_times(duration: float, interval: float, min_segment_duration: float) -> list[float]:
    interval = interval if interval > 0 else 2.0
    count = max(1, math.ceil(duration / interval))
    bounds = [index * interval for index in range(count) if index * interval < duration]
    if not bounds or bounds[0] != 0.0:
        bounds.insert(0, 0.0)
    bounds.append(duration)
    return merge_short_tail(bounds, min_segment_duration)


def limit_segments(bounds: list[float], max_segments: int) -> list[float]:
    segment_count = max(0, len(bounds) - 1)
    if max_segments <= 0 or segment_count <= max_segments:
        return bounds
    step = math.ceil(segment_count / max_segments)
    kept = [bounds[0], *[bounds[index] for index in range(step, segment_count, step)], bounds[-1]]
    return sorted(set(kept))


def choose_segments(
    detected: list[float],
    duration: float,
    min_gap: float,
    short_video_threshold: float,
    fallback_interval: float,
    min_segment_duration: float,
    max_segments: int,
) -> SegmentationResult:
    if detected:
        bounds = dedupe_times(detected, duration, min_gap)
        mode, kind = "scene_detection", "real_shot"
    elif duration <= short_video_threshold:
        bounds = [0.0, duration]
        mode, kind = "single_continuous_shot", "continuous_shot"
    else:
        bounds = fallback_times(duration, fallback_interval, min_segment_duration)
        mode, kind = "fallback_analysis_segments", "analysis_segment"
    return SegmentationResult(limit_segments(bounds, max_segments), mode, kind)


def analysis_timestamps(start: float, end: float, count: int) -> list[float]:
    if count <= 1 or end - start < 0.3:
        return [start + (end - start) / 2]
    fractions = [0.15 + index * (0.70 / (count - 1)) for index in range(count)]
    return [start + (end - start) * fraction for fraction in fractions]
