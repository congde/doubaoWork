"""FFmpeg and FFprobe media operations."""

# Copyright (c) 2026 非叔 Levie
# SPDX-License-Identifier: MIT

from __future__ import annotations

import json
import re
from pathlib import Path

from .common import run


def ffprobe_media(video: Path) -> tuple[float, bool]:
    proc = run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration:stream=codec_type",
            "-of",
            "json",
            str(video),
        ]
    )
    if proc.returncode != 0:
        raise SystemExit(proc.stderr.strip() or "ffprobe failed")
    try:
        payload = json.loads(proc.stdout)
        duration = float(payload["format"]["duration"])
        has_audio = any(stream.get("codec_type") == "audio" for stream in payload["streams"])
        return duration, has_audio
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise SystemExit(f"Cannot parse ffprobe output: {proc.stdout!r}") from exc


def detect_scene_times(video: Path, threshold: float) -> list[float]:
    vf = f"select='gt(scene,{threshold})',showinfo"
    proc = run(
        ["ffmpeg", "-hide_banner", "-loglevel", "info", "-i", str(video), "-vf", vf, "-f", "null", "-"]
    )
    return sorted(
        {
            float(match.group(1))
            for match in re.finditer(r"pts_time:([0-9]+(?:\.[0-9]+)?)", proc.stderr or "")
        }
    )


def extract_frame(video: Path, timestamp: float, output: Path, width: int) -> None:
    scale = f"scale='min({width},iw)':-2"
    proc = run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-ss",
            f"{timestamp:.3f}",
            "-i",
            str(video),
            "-frames:v",
            "1",
            "-vf",
            scale,
            "-q:v",
            "2",
            str(output),
        ]
    )
    if proc.returncode != 0:
        raise SystemExit(proc.stderr.strip() or f"Failed to extract {output}")


def extract_audio(video: Path, output: Path) -> None:
    proc = run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-i",
            str(video),
            "-vn",
            "-ac",
            "1",
            "-ar",
            "16000",
            "-c:a",
            "pcm_s16le",
            str(output),
        ]
    )
    if proc.returncode != 0:
        raise SystemExit(proc.stderr.strip() or "Audio extraction failed")


def analyze_audio(audio: Path, duration: float) -> dict[str, object]:
    volume = run(
        ["ffmpeg", "-hide_banner", "-nostats", "-i", str(audio), "-af", "volumedetect", "-f", "null", "-"]
    )
    silence = run(
        [
            "ffmpeg",
            "-hide_banner",
            "-nostats",
            "-i",
            str(audio),
            "-af",
            "silencedetect=noise=-40dB:d=0.25",
            "-f",
            "null",
            "-",
        ]
    )
    mean_match = re.search(r"mean_volume:\s*([-\d.]+) dB", volume.stderr or "")
    max_match = re.search(r"max_volume:\s*([-\d.]+) dB", volume.stderr or "")
    starts = [float(value) for value in re.findall(r"silence_start:\s*([\d.]+)", silence.stderr or "")]
    ends = [float(value) for value in re.findall(r"silence_end:\s*([\d.]+)", silence.stderr or "")]
    intervals = []
    for index, start in enumerate(starts):
        end = ends[index] if index < len(ends) else duration
        intervals.append({"start": round(start, 3), "end": round(end, 3), "duration": round(end - start, 3)})
    silent_duration = sum(item["duration"] for item in intervals)
    return {
        "status": "ok",
        "source": "ffmpeg_signal_analysis",
        "mean_volume_db": float(mean_match.group(1)) if mean_match else None,
        "max_volume_db": float(max_match.group(1)) if max_match else None,
        "silence_threshold_db": -40,
        "silence_intervals": intervals,
        "silence_ratio": round(silent_duration / duration, 4) if duration > 0 else 0.0,
        "bgm_detection": "not_inferred_from_signal_only",
    }
