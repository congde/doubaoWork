"""Artifact serialization and analyst work-prompt generation."""

# Copyright (c) 2026 非叔 Levie
# SPDX-License-Identifier: MIT

from __future__ import annotations

import csv
import json
from pathlib import Path


def write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        fieldnames = list(rows[0].keys()) if rows else ["镜头序号"]
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    key: json.dumps(value, ensure_ascii=False) if isinstance(value, (list, dict)) else value
                    for key, value in row.items()
                }
            )


def write_prompt(out_dir: Path, rows: list[dict[str, object]], video: Path) -> None:
    labels = {"real_shot": "真实镜头", "continuous_shot": "连续镜头", "analysis_segment": "分析时间段"}
    lines = [
        "# 拉片分析工作稿",
        "",
        f"- 视频：{video}",
        f"- 分析记录数：{len(rows)}",
        "",
        "逐条查看代表帧与 analysis_frame_paths，并结合 audio_analysis.json、asr_transcript.json、ocr_timeline.json 分析。",
        "声音或字幕结论必须注明来源：音频识别、画面字幕或模型推断。",
        "",
    ]
    for row in rows:
        label = labels.get(str(row["segment_type"]), str(row["segment_type"]))
        lines.append(
            f"{row['镜头序号']}. [{label}] {row['起止时间码']} / {row['时长']}s / {row['frame_path']}"
        )
    (out_dir / "analysis_prompt.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
