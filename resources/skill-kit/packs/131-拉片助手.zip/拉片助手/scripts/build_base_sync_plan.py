#!/usr/bin/env python3
"""Build an idempotent Base create/update/delete plan from shots.json and exported NDJSON."""

# Copyright (c) 2026 非叔 Levie
# SPDX-License-Identifier: MIT

from __future__ import annotations

import argparse
import json
from pathlib import Path


LOCAL_ONLY_FIELDS = {
    "frame_path",
    "analysis_frame_paths",
    "analysis_frame_timestamps",
    "segment_type",
    "is_real_cut",
    "sync_mode",
    "分析来源/置信度",
}

ATTACHMENT_FIELDS = {"镜头截图", "代表帧", "分析帧"}


def read_ndjson(path: Path) -> list[dict[str, object]]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def base_fields(shot: dict[str, object]) -> dict[str, object]:
    def has_value(value: object) -> bool:
        return value is not None and value != "" and value != [] and value != {}

    return {
        key: value
        for key, value in shot.items()
        if key not in LOCAL_ONLY_FIELDS and key not in ATTACHMENT_FIELDS and has_value(value)
    }


def add_attachment_plans(
    plans: list[dict[str, object]],
    target: dict[str, object],
    shot: dict[str, object],
    current: dict[str, object] | None = None,
    refresh: bool = False,
) -> None:
    specs = [
        ("代表帧", [shot["frame_path"]]),
        ("分析帧", list(shot.get("analysis_frame_paths", []))),
    ]
    for field, files in specs:
        if not files:
            continue
        has_attachment = bool(current and current.get(field))
        action = "replace" if refresh and has_attachment else "skip" if has_attachment else "upload"
        plans.append({"target": target, "field": field, "files": files, "action": action})


def main() -> int:
    parser = argparse.ArgumentParser(description="Plan idempotent Base synchronization.")
    parser.add_argument("shots_json", type=Path)
    parser.add_argument("existing_ndjson", type=Path)
    parser.add_argument("--mode", choices=["create-only", "resume", "replace-existing"], required=True)
    parser.add_argument("--refresh-attachments", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    payload = json.loads(args.shots_json.read_text(encoding="utf-8"))
    shots = payload.get("shots", [])
    fingerprint = payload.get("meta", {}).get("video_sha256")
    if not fingerprint:
        raise SystemExit("shots.json is missing meta.video_sha256")
    existing = read_ndjson(args.existing_ndjson)
    same_video = [row for row in existing if row.get("视频指纹") == fingerprint]
    by_key = {row.get("镜头唯一键"): row for row in same_video if row.get("镜头唯一键")}

    creates: list[dict[str, object]] = []
    updates: dict[str, dict[str, object]] = {}
    deletes: list[str] = []
    attachments: list[dict[str, object]] = []

    if args.mode == "replace-existing":
        deletes = [str(row["record_id"]) for row in same_video if row.get("record_id")]
        for index, shot in enumerate(shots):
            creates.append(base_fields(shot))
            add_attachment_plans(attachments, {"create_index": index}, shot)
    elif args.mode == "resume":
        for shot in shots:
            unique_key = shot.get("镜头唯一键")
            current = by_key.get(unique_key)
            if current and current.get("record_id"):
                record_id = str(current["record_id"])
                updates[record_id] = base_fields(shot)
                add_attachment_plans(
                    attachments,
                    {"record_id": record_id},
                    shot,
                    current=current,
                    refresh=args.refresh_attachments,
                )
            else:
                create_index = len(creates)
                creates.append(base_fields(shot))
                add_attachment_plans(attachments, {"create_index": create_index}, shot)
    else:
        for index, shot in enumerate(shots):
            creates.append(base_fields(shot))
            add_attachment_plans(attachments, {"create_index": index}, shot)

    plan = {
        "mode": args.mode,
        "video_sha256": fingerprint,
        "create_records": creates,
        "update_records": updates,
        "delete_record_ids": deletes,
        "attachments": attachments,
        "summary": {
            "create_count": len(creates),
            "update_count": len(updates),
            "delete_count": len(deletes),
            "attachment_upload_count": sum(item["action"] != "skip" for item in attachments),
            "attachment_file_count": sum(
                len(item["files"]) for item in attachments if item["action"] != "skip"
            ),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(plan["summary"], ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
