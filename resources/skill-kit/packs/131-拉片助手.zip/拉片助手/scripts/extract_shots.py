#!/usr/bin/env python3
"""CLI orchestrator for video shot analysis artifact extraction."""

# Copyright (c) 2026 非叔 Levie
# SPDX-License-Identifier: MIT

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from shot_analysis_assistant.common import file_sha256, fmt_time, require_bin
from shot_analysis_assistant import __version__
from shot_analysis_assistant.enrichment import ocr_frame, run_asr, tesseract_languages
from shot_analysis_assistant.media import analyze_audio, detect_scene_times, extract_audio, extract_frame, ffprobe_media
from shot_analysis_assistant.reporting import write_csv, write_json, write_prompt
from shot_analysis_assistant.segmentation import analysis_timestamps, choose_segments


SEGMENT_LABELS = {
    "real_shot": "真实镜头",
    "continuous_shot": "连续镜头",
    "analysis_segment": "分析时间段",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Extract shots, analysis frames, audio signals, OCR, and ASR.")
    parser.add_argument("video", type=Path)
    parser.add_argument("--out-dir", type=Path, default=Path("lapian_output"))
    parser.add_argument("--threshold", type=float, default=0.32)
    parser.add_argument("--min-gap", type=float, default=0.45)
    parser.add_argument("--min-segment-duration", type=float, default=0.75)
    parser.add_argument("--fallback-interval", type=float, default=2.0)
    parser.add_argument("--short-video-threshold", type=float, default=15.0)
    parser.add_argument("--analysis-frames", type=int, default=3)
    parser.add_argument("--max-shots", type=int, default=160)
    parser.add_argument("--width", type=int, default=720)
    parser.add_argument("--ocr", choices=["auto", "off"], default="auto")
    parser.add_argument("--asr-mode", choices=["auto", "off"], default="auto")
    parser.add_argument("--asr-model", default="small")
    parser.add_argument("--asr-language", default="zh")
    parser.add_argument("--analysis-batch")
    sync_group = parser.add_mutually_exclusive_group()
    sync_group.add_argument("--create-only", action="store_true", help="Always create rows; may produce duplicates.")
    sync_group.add_argument("--resume", action="store_true", help="Update matches and create missing rows (default).")
    sync_group.add_argument("--replace-existing", action="store_true", help="Replace rows for the same fingerprint.")
    return parser.parse_args()


def sync_mode(args: argparse.Namespace) -> str:
    if args.create_only:
        return "create_only"
    if args.replace_existing:
        return "replace_existing"
    return "resume"


def setup_output(out_dir: Path) -> tuple[Path, Path]:
    frames_dir = out_dir / "frames"
    analysis_frames_dir = out_dir / "analysis_frames"
    frames_dir.mkdir(parents=True, exist_ok=True)
    analysis_frames_dir.mkdir(parents=True, exist_ok=True)
    return frames_dir, analysis_frames_dir


def selected_ocr_languages(mode: str) -> str:
    if mode == "off":
        return ""
    available = tesseract_languages()
    return "+".join(language for language in ("chi_sim", "eng") if language in available)


def build_rows(
    video: Path,
    bounds: list[float],
    segment_type: str,
    fingerprint: str,
    frames_dir: Path,
    analysis_frames_dir: Path,
    width: int,
    frame_count: int,
    ocr_languages: str,
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    rows: list[dict[str, object]] = []
    ocr_entries: list[dict[str, object]] = []
    for index, (start, end) in enumerate(zip(bounds[:-1], bounds[1:]), start=1):
        if end <= start:
            continue
        midpoint = start + (end - start) / 2
        representative = frames_dir / f"shot_{index:03d}.jpg"
        extract_frame(video, midpoint, representative, width)

        timestamps = analysis_timestamps(start, end, max(1, frame_count))
        analysis_paths: list[str] = []
        for frame_index, timestamp in enumerate(timestamps, start=1):
            frame = analysis_frames_dir / f"segment_{index:03d}_{frame_index:02d}.jpg"
            extract_frame(video, timestamp, frame, width)
            analysis_paths.append(str(frame))
            if ocr_languages:
                ocr_entries.append(
                    {
                        "segment_index": index,
                        "timestamp": round(timestamp, 3),
                        "timecode": fmt_time(timestamp),
                        "frame_path": str(frame),
                        "source": "frame_ocr",
                        **ocr_frame(frame, ocr_languages),
                    }
                )

        start_ms = int(round(start * 1000))
        rows.append(
            {
                "镜头标题": f"{video.stem}｜镜头 {index:03d}",
                "项目名称": video.stem,
                "视频文件名": video.name,
                "镜头序号": index,
                "起始秒": round(start, 3),
                "结束秒": round(end, 3),
                "起止时间码": f"{fmt_time(start)} - {fmt_time(end)}",
                "时长": round(end - start, 3),
                "frame_path": str(representative),
                "analysis_frame_paths": analysis_paths,
                "analysis_frame_timestamps": [round(value, 3) for value in timestamps],
                "segment_type": segment_type,
                "is_real_cut": segment_type == "real_shot",
                "分段类型": [SEGMENT_LABELS[segment_type]],
                "是否真实切镜": segment_type == "real_shot",
                "视频指纹": fingerprint,
                "镜头唯一键": f"{fingerprint}:{start_ms}",
                "分析版本": f"shot-analysis-assistant/{__version__}",
                "画面摘要": "",
                "叙事阶段": [],
                "叙事功能": [],
                "核心信息点": "",
                "景别": [],
                "机位角度": [],
                "构图方式": [],
                "摄影机运动": [],
                "主体与动作": "",
                "人物表演": "",
                "场景与环境": "",
                "道具与产品": "",
                "光线设计": "",
                "色彩设计": "",
                "焦点与景深": "",
                "视觉风格": "",
                "转场与剪辑": "",
                "屏幕文字": "",
                "口播与台词": "",
                "OCR识别结果": "",
                "ASR识别结果": "",
                "声音设计": "",
                "BGM与音效": "",
                "音频分析摘要": "",
                "情绪标签": [],
                "节奏强度": None,
                "信息密度": None,
                "注意力机制": "",
                "卖点与证据": "",
                "信任机制": "",
                "互动与CTA": "",
                "目标受众": "",
                "可复刻要点": "",
                "风险与合规": "",
                "关键帧生成提示词": "",
                "视频生成提示词": "",
                "负面提示词": "",
                "分析来源": ["视觉观察"],
                "分析置信度": None,
                "分析状态": ["待分析"],
                "需人工复核": False,
                "复核说明": "",
                "分析备注": "",
                "分析来源/置信度": {
                    "audio_asr": "pending",
                    "frame_ocr": "available" if ocr_languages else "unavailable",
                    "model_inference": "must_be_labeled",
                },
            }
        )
    return rows, ocr_entries


def enrich_audio(
    video: Path,
    out_dir: Path,
    duration: float,
    has_audio: bool,
    args: argparse.Namespace,
) -> tuple[Path | None, dict[str, object], dict[str, object]]:
    if not has_audio:
        return (
            None,
            {"status": "no_audio_stream", "source": "ffprobe"},
            {"status": "no_audio_stream", "source": "audio_asr", "confidence": "unavailable"},
        )
    audio_path = out_dir / "extract_audio.wav"
    extract_audio(video, audio_path)
    audio_analysis = analyze_audio(audio_path, duration)
    asr = run_asr(audio_path, out_dir, args.asr_mode, args.asr_model, args.asr_language)
    return audio_path, audio_analysis, asr


def main() -> int:
    args = parse_args()
    require_bin("ffmpeg")
    require_bin("ffprobe")
    video = args.video.expanduser().resolve()
    if not video.is_file():
        raise SystemExit(f"Video not found: {video}")

    out_dir = args.out_dir.expanduser().resolve()
    frames_dir, analysis_frames_dir = setup_output(out_dir)
    duration, has_audio = ffprobe_media(video)
    fingerprint = file_sha256(video)
    segmentation = choose_segments(
        detect_scene_times(video, args.threshold),
        duration,
        args.min_gap,
        args.short_video_threshold,
        args.fallback_interval,
        args.min_segment_duration,
        args.max_shots,
    )
    ocr_languages = selected_ocr_languages(args.ocr)
    rows, ocr_entries = build_rows(
        video,
        segmentation.bounds,
        segmentation.segment_type,
        fingerprint,
        frames_dir,
        analysis_frames_dir,
        args.width,
        args.analysis_frames,
        ocr_languages,
    )
    audio_path, audio_analysis, asr = enrich_audio(video, out_dir, duration, has_audio, args)

    mode = sync_mode(args)
    analysis_batch = args.analysis_batch or f"{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}-{fingerprint[:12]}"
    for row in rows:
        row["分析批次"] = analysis_batch
        row["sync_mode"] = mode
        row["分析来源/置信度"]["audio_asr"] = asr.get("status", "unknown")
        segment_ocr = [
            str(entry.get("text", "")).strip()
            for entry in ocr_entries
            if entry.get("segment_index") == row["镜头序号"] and str(entry.get("text", "")).strip()
        ]
        row["OCR识别结果"] = " / ".join(dict.fromkeys(segment_ocr))
        if row["OCR识别结果"]:
            row["分析来源"].append("OCR识别")
        if asr.get("status") == "ok":
            start, end = float(row["起始秒"]), float(row["结束秒"])
            texts = [
                str(segment.get("text", "")).strip()
                for segment in asr.get("segments", [])
                if float(segment.get("end", 0)) > start and float(segment.get("start", 0)) < end
            ]
            row["ASR识别结果"] = " ".join(text for text in texts if text)
            if row["ASR识别结果"]:
                row["分析来源"].append("音频识别")
        if audio_analysis.get("status") == "ok":
            row["音频分析摘要"] = (
                f"均值 {audio_analysis.get('mean_volume_db')} dB；峰值 {audio_analysis.get('max_volume_db')} dB；"
                f"静音占比 {audio_analysis.get('silence_ratio')}"
            )
            row["分析来源"].append("信号分析")

    write_json(out_dir / "audio_analysis.json", audio_analysis)
    write_json(out_dir / "asr_transcript.json", asr)
    write_json(
        out_dir / "ocr_timeline.json",
        {
            "status": "ok" if ocr_languages else "unavailable",
            "source": "frame_ocr",
            "languages": ocr_languages or None,
            "entries": ocr_entries,
        },
    )
    meta = {
        "video": str(video),
        "video_sha256": fingerprint,
        "analysis_batch": analysis_batch,
        "sync_mode": mode,
        "duration": round(duration, 3),
        "has_audio": has_audio,
        "audio_path": str(audio_path) if audio_path else None,
        "detection_mode": segmentation.detection_mode,
        "segment_type": segmentation.segment_type,
        "threshold": args.threshold,
        "min_gap": args.min_gap,
        "min_segment_duration": args.min_segment_duration,
        "record_count": len(rows),
        "real_shot_count": len(rows) if segmentation.segment_type == "real_shot" else 0,
        "analysis_frame_count": sum(len(row["analysis_frame_paths"]) for row in rows),
        "ocr_status": "ok" if ocr_languages else "unavailable",
        "asr_status": asr.get("status", "unknown"),
    }
    write_json(out_dir / "shots.json", {"meta": meta, "shots": rows})
    write_csv(out_dir / "shots.csv", rows)
    write_prompt(out_dir, rows, video)
    print(json.dumps(meta, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
