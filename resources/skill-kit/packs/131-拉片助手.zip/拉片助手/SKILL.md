---
name: shot-analysis-assistant
description: "镜头分析助手：当用户上传视频并要求拉片、拆镜头、分析分镜、复盘爆款视频、倒推生成分镜提示词或视频生成提示词，并把结果写入飞书表格/Base 时使用。基于 ffmpeg 抽镜头截图，基于 lark-cli 幂等写入飞书 Base。"
---

# Shot Analysis Assistant

把用户上传的视频拆成镜头级记录，分析每个镜头的画面、时长、叙事作用、景别、运镜、声音/字幕，并倒推出可复刻的「生成分镜提示词」和「生成视频提示词」，最后写入飞书多维表格。

> 本 Skill 由非叔 Levie 开发，欢迎使用交流。

## 必用依赖

- 先按任务读取 `lark-shared` 与 `lark-base` skill；如果用户明确要求普通电子表格，再读取 `lark-sheets`。
- 使用本 skill 的 `scripts/extract_shots.py` 先抽镜头段和代表截图。
- 用 `lark-cli base +...` 操作多维表格；附件截图必须用 `+record-upload-attachment` 上传，不能手写附件 token。

## 输入判断

最少需要：

- 本地视频路径，或用户上传的视频文件。
- 飞书目标：Base 链接/token + 表名/table-id；如果用户没有给目标，只问这一项。

如果用户只说“建一个表”，默认创建名为 `视频拉片分析` 的 Base 表。截图里的结构属于 Base，不默认用普通 Sheets。

## 专业 Base Schema

先完整读取 [`references/base-schema.json`](references/base-schema.json)。该 schema 是字段创建与写入的唯一准则，不沿用旧版拉片表字段。

字段按六个维度组织：

1. 资产与版本：项目、文件、SHA-256、批次、分析版本、唯一键。
2. 时间轴与分段：真实切镜、起始/结束秒、时间码、时长、代表帧与分析帧。
3. 摄影语言：景别、机位、构图、运镜、表演、场景、光线、色彩、景深、剪辑。
4. 声音与文本：屏幕文字、OCR、ASR、口播、声音设计、BGM、音频信号摘要。
5. 叙事与营销：叙事阶段/功能、注意力、卖点、证据、信任、CTA、受众、风险。
6. 生成与质检：关键帧/视频/负面提示词、来源、置信度、分析状态、人工复核。

创建字段前必须先 `+field-list`。只创建 schema 中缺失的字段；同名字段类型不一致时停止并报告，不得静默创建近似字段名。

## 工作流

1. **准备素材**
   - 确认视频路径存在。
   - 运行：
     ```bash
     python3 <skill目录>/scripts/extract_shots.py \
       "/path/to/video.mp4" \
       --out-dir "./lapian_output" \
       --threshold 0.32 \
       --min-gap 0.45 \
       --min-segment-duration 0.75 \
       --resume
     ```
   - 输出包括 `shots.json`、`shots.csv`、`frames/*.jpg`、`analysis_frames/*.jpg`、`extract_audio.wav`、`audio_analysis.json`、`asr_transcript.json`、`ocr_timeline.json`、`analysis_prompt.md`。
   - 无真实切镜且视频不超过 `--short-video-threshold` 时，只保留一个 `连续镜头`，另抽多张分析帧；不要按固定间隔制造伪镜头。
   - 长视频无切点时才生成 `分析时间段`；小于 `--min-segment-duration` 的尾段合并到上一段。

2. **镜头分析**
   - 逐张查看代表截图和 `analysis_frame_paths`；短视频要尽量逐镜头分析，不要只粗略概括。
   - 如果同一镜头内信息变化大，必要时回看该片段或补抽帧。
   - 记录每个镜头：发生了什么、为什么放在这里、怎么引导观众、可复刻的镜头语言。
   - `segment_type=continuous_shot/analysis_segment` 时使用“连续镜头/分析时间段”，不要描述成真实切镜。

3. **音频、ASR 与 OCR**
   - 先读取 `audio_analysis.json` 的音量、峰值、静音区间；不得仅凭这些信号断言存在 BGM。
   - `asr_transcript.json.status=ok` 时用 ASR 文本和时间段；`unavailable/error` 时明确标注未识别，不得补写成音频事实。
   - 读取 `ocr_timeline.json` 并用分析帧复核字幕；OCR 低置信或误识别时以可见画面人工校正。
   - 所有声音/字幕结论标注来源：`音频识别`、`画面字幕` 或 `模型推断`，并给出置信度。

4. **倒推提示词**
   - `倒推生成分镜提示词`：写给图片/分镜生成模型，关注静态画面、构图、人物/界面、景别、光线、文字。
   - `倒推生成视频提示词`：写给视频生成模型，必须包含时间轴、镜头运动、动作、声音/台词、转场和结尾停帧。
   - 如果画面含中文 UI/字幕，提示词里明确“所有可见文字使用简体中文，禁止英文界面词”。

5. **幂等写入 Base**
   - 先读取真实结构：
     ```bash
     lark-cli base +table-list --base-token <base_token>
     lark-cli base +field-list --base-token <base_token> --table-id <table_id>
     ```
   - 读取 `references/base-schema.json`，将缺失字段组成一个 JSON 数组，用一次 `+field-create --json '[...]'` 创建。
   - 以 `视频指纹`（SHA-256）限定视频，以 `镜头唯一键=<视频指纹>:<起始毫秒>` 定位记录；不得把无 `record-id` 的 `+record-upsert` 当成业务键 upsert。
   - 默认 `--resume`：导出同一视频指纹的现有记录，用 `scripts/build_base_sync_plan.py --mode resume` 生成计划；已有唯一键走 batch update，缺失键走 batch create，已有附件默认跳过。
   - `--replace-existing`：必须先获得用户对删除同一视频旧记录的明确确认，再用计划中的 `delete_record_ids` 删除，之后重建并上传附件。
   - `--create-only`：仅在用户明确允许产生重复记录时使用。
   - 同步计划示例：
     ```bash
     python3 <skill目录>/scripts/build_base_sync_plan.py \
       ./lapian_output/shots.json ./lapian_output/existing.ndjson \
       --mode resume --output ./lapian_output/base_sync_plan.json
     ```
   - 先执行计划中的 `update_records` / `create_records`，保存返回的 `record_id_list`，再处理附件计划。
   - 再上传截图：
     ```bash
     lark-cli base +record-upload-attachment \
       --base-token <base_token> \
       --table-id <table_id> \
       --record-id <record_id> \
       --field-id "代表帧" \
       --file "./lapian_output/frames/shot_001.jpg"
     ```

6. **校验**
   - 上传后按 `视频指纹` 过滤读取本批记录；不要使用无过滤的 `+record-list --limit 3`。
   - 确认每个 `镜头唯一键` 唯一、`镜头标题`/`画面摘要`存在、`代表帧`非空；`--resume` 重跑后记录数不得增加。
   - 汇报总镜头数、写入成功数、附件成功数、失败项和飞书链接。

## 专业分析口径

- 先写事实字段（画面、声音、文字），再写解释字段（叙事、营销、情绪），不得混写。
- `画面摘要` 保持客观；主体、动作、环境、道具分别落入对应字段。
- `叙事阶段` 只选一个主阶段；`叙事功能` 可多选，并在注意力/卖点/信任/CTA 中写机制与证据。
- `节奏强度`、`信息密度` 使用 1–5 整数；`分析置信度` 使用 0–1 小数。
- `分析来源` 必须反映真实依据；模型补全的判断加入“模型推断”，不可冒充 OCR/ASR 事实。
- OCR/ASR 失败、字幕歧义、人物身份不确定或音画不同步时设置 `需人工复核=true` 并填写 `复核说明`。
- `分段类型`：场景检测边界写“真实镜头”；短视频无切点写“连续镜头”；长视频兜底采样写“分析时间段”。
- 三类生成提示词分别覆盖正向关键帧、时间轴视频动作、以及应避免的画面/文字/运动缺陷。

## 长视频策略

- 3 分钟以内：逐镜头完整分析。
- 3-20 分钟：先自动切镜头，再按段落合并明显重复的屏录/口播镜头，但保留关键转折点。
- 超过 20 分钟：先输出章节级结构，让用户确认是否继续做逐镜头 Base。

## 失败处理

- ffmpeg 场景检测结果过碎：提高 `--threshold` 到 `0.42` 或提高 `--min-gap`。
- 场景检测漏切：降低 `--threshold` 到 `0.22`，或用 `--fallback-interval 1.5` 补采样。
- 无切镜短视频：保留单个连续镜头和多张分析帧；不要降低阈值强行造切点。
- 截图超过 20MB 附件限制：脚本默认缩到 720px 宽；仍超限就用 `--width 480` 重跑。
- Base 链接是 `/wiki/`：先用 wiki 节点解析真实 `obj_token`，再作为 `--base-token`。

## 版权声明

本 Skill 由非叔 Levie 开发，欢迎使用交流。

Copyright (c) 2026 非叔 Levie。本项目采用 MIT License；复制、修改或分发时请一并保留 `LICENSE`。
