---
name: wechat-article-to-pdf
description: "将微信公众号文章（mp.weixin.qq.com 链接）读取并转换为排版整洁的 PDF 文件。当用户粘贴公众号文章链接、要求把这篇公众号文章存成 PDF / 导出 PDF / 转成 PDF、或需要对公众号文章做离线留存时使用本 skill。自动提取标题、作者、发布时间和正文，修复微信懒加载图片并保留图片与排版。"
agent_created: true
---

# 公众号文章转 PDF

## 概述

读取微信公众号文章链接，抓取正文内容，修复微信特有的懒加载图片（`data-src`），
用 Playwright 无头浏览器渲染为排版整洁的 A4 PDF。输出文件可直接分享、打印或归档。

## 何时使用

- 用户粘贴 `https://mp.weixin.qq.com/s/...` 之类的链接，并希望得到 PDF。
- 用户说"把这篇公众号文章转成 PDF / 导出 PDF / 存成 PDF / 留个档"。
- 用户需要离线保存某篇公众号文章（含图片）。

## 依赖（通常无需安装）

PDF 渲染**优先使用系统已安装的 Chrome / Edge**（Chromium 内核），绝大多数电脑
开箱即用，无需任何安装。仅在系统完全没有浏览器时，才回退到 Playwright：

```bash
pip install playwright
playwright install chromium
```

也可用环境变量 `CHROMIUM_BIN` 显式指定浏览器可执行文件路径。

> 说明：抓取与解析均为 Python 标准库实现，唯一可能需要的第三方依赖就是上面的
> Playwright（兜底用）。若系统有 Chrome/Edge，直接运行即可，不要先去装 Playwright。

## 使用方式

### 基本用法

拿到链接后直接运行脚本：

```bash
python <skill_dir>/scripts/fetch_and_convert.py "<用户粘贴的公众号文章URL>"
```

默认在当前工作目录生成 `<文章标题>_<时间戳>.pdf`。

### 指定输出路径

```bash
python <skill_dir>/scripts/fetch_and_convert.py "<URL>" --out "/path/to/output.pdf"
```

### 在 WorkBuddy 中的标准流程

1. 确认用户给出的是 `mp.weixin.qq.com` 链接；若不是公众号链接，先用通用方式抓取并提示用户。
2. 若依赖未安装，先执行上面的安装命令（仅首次）。
3. 运行脚本，将输出 PDF 路径指向当前工作区（便于回传）。
4. 用 `present_files` 把生成的 PDF 呈现给用户。

## 实现要点（脚本已封装，了解即可）

- **抓取**：`requests` + 浏览器 UA，自动识别编码。
- **解析**：`BeautifulSoup` 提取 `#activity-name`（标题）、`#js_name`（作者）、
  `#publish_time`（发布时间）、`#js_content`（正文）。
- **图片修复**：微信把真实图片地址放在 `data-src`/`data-backsrc`，占位图放在 `src`；
  脚本把真实地址写回 `src`，否则 PDF 里图片是灰块。
- **PDF 渲染**：Playwright `page.pdf(print_background=True)`，A4、保留背景与图片；
  视口宽度 820px 贴近手机阅读宽度。
- **兼容处理**：视频/音频标签（mpvideo/mpvoice/iframe）替换为"不可播放"提示文字，
  避免渲染报错。

## 限制

- 部分公众号文章设置了"禁止复制/转载"或需要微信内登录才能看全文，可能抓取不全。
- 视频、音频、互动投票等内容无法嵌入 PDF，仅保留文字提示。
- 链接需在微信外可访问（多数历史文章公开可读；个别需关注后可见的文章会失败）。

## 资源

- `scripts/fetch_and_convert.py` —— 抓取 + 解析 + 转 PDF 的主脚本。
