#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
公众号文章链接 -> PDF

读取微信公众号文章（mp.weixin.qq.com 链接），提取正文、标题、作者、发布时间，
将懒加载图片修复为真实地址后，用 Playwright 渲染成排版整洁的 PDF。

纯标准库实现抓取与解析（无需 bs4 / requests）。PDF 渲染优先使用系统已装的
Chrome / Edge（Chromium 内核，零安装）；找不到时才回退到 Playwright。

用法:
  python fetch_and_convert.py "<公众号文章URL>" [--out output.pdf]

可选依赖（仅当系统无 Chrome/Edge 时才需要）:
  pip install playwright
  playwright install chromium
（也可用环境变量 CHROMIUM_BIN 指定浏览器可执行文件路径）
"""
import argparse
import os
import re
import sys
import tempfile
import time
import urllib.request
from datetime import datetime
from html import escape
from html.parser import HTMLParser

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

VOID_TAGS = {"img", "br", "hr", "meta", "link", "source", "area",
             "base", "col", "embed", "param", "track", "wbr", "input"}


# ---------------------------------------------------------------------------
# 抓取
# ---------------------------------------------------------------------------
def fetch_html(url: str, retries: int = 3) -> str:
    """抓取文章 HTML。微信对短时间高频请求可能返回验证页/空页，
    这里做带退避的重试，尽量自愈偶发的风控拦截。"""
    last_err = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": UA,
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    "Accept-Language": "zh-CN,zh;q=0.9",
                },
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read()
            charset = resp.headers.get_content_charset()
            if not charset:
                m = re.search(rb'<meta[^>]+charset=["\']?([\w-]+)', raw, re.I)
                charset = m.group(1).decode() if m else "utf-8"
            text = raw.decode(charset, errors="replace")
            # 命中微信验证/风控页：没有正文容器，视为可重试的软失败
            if "环境异常" in text or "请输入验证码" in text or "访问过于频繁" in text:
                last_err = RuntimeError("命中微信验证页")
                if attempt < retries - 1:
                    time.sleep(3 + attempt * 4)
                    continue
                return text
            return text
        except Exception as e:  # 网络错误/超时 → 退避重试
            last_err = e
            if attempt < retries - 1:
                time.sleep(2 + attempt * 3)
    raise last_err if last_err else RuntimeError("抓取失败")


# ---------------------------------------------------------------------------
# 提取标题 / 作者 / 发布时间（针对微信固定结构）
# ---------------------------------------------------------------------------
def _between(raw: str, start_pat: str, end_pat: str) -> str:
    m = re.search(start_pat + r"(.*?)" + end_pat, raw, re.S | re.I)
    if not m:
        return ""
    txt = re.sub(r"<[^>]+>", "", m.group(1))  # 去标签
    return txt.strip()


def _meta_content(raw: str, prop: str) -> str:
    m = re.search(r'<meta[^>]+property=["\']' + re.escape(prop) +
                  r'["\'][^>]+content=["\']([^"\']+)', raw, re.I)
    if not m:
        m = re.search(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+'
                      r'property=["\']' + re.escape(prop) + r'["\']', raw, re.I)
    return m.group(1).strip() if m else ""


def _js_var(raw: str, name: str) -> str:
    """从页面内联 JS（如 var msg_title = "..."）提取变量值。"""
    m = re.search(r'var\s+' + re.escape(name) + r'\s*=\s*["\'](.*?)["\']', raw, re.S)
    return m.group(1).strip() if m else ""


def extract_meta(raw: str):
    title = (_between(raw, r'id=["\']activity-name["\'][^>]*>', r'</h1>')
             or _meta_content(raw, "og:title")
             or _js_var(raw, "msg_title")
             or "公众号文章")
    author = (_between(raw, r'id=["\']js_name["\'][^>]*>', r'</a>')
              or _between(raw, r'id=["\']js_author["\'][^>]*>', r'</')
              or _js_var(raw, "msg_author"))
    pub = (_between(raw, r'id=["\']publish_time["\'][^>]*>', r'</')
           or _between(raw, r'id=["\']post-date["\'][^>]*>', r'</')
           or _js_var(raw, "msg_publish_time"))
    return title, author, pub


# ---------------------------------------------------------------------------
# 提取正文（html.parser 序列化 #js_content 内部）
# ---------------------------------------------------------------------------
class ContentExtractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.in_content = False
        self.depth = 0            # 仅统计 div 嵌套深度，用于定位 js_content 的闭合
        self.capture = []
        self._buf = []

    def _emit(self, s: str):
        self.capture.append(s)

    def _attrs(self, tag, attrs):
        out = []
        fix_src = None
        drop = set()
        if tag == "img":
            for k, v in attrs:
                if k in ("data-src", "data-backsrc") and v:
                    fix_src = v
                if k in ("data-src", "data-backsrc", "data-ratio",
                         "data-w", "data-type"):
                    drop.add(k)
        for k, v in attrs:
            if k in drop:
                continue
            if tag == "img" and k == "src" and fix_src:
                continue  # 由下面的 fix_src 覆盖
            if v is None:
                out.append(k)
            else:
                out.append(f'{k}="{escape(v)}"')
        if tag == "img" and fix_src:
            out.append(f'src="{escape(fix_src)}"')
        return " ".join(out)

    def handle_starttag(self, tag, attrs):
        if not self.in_content:
            if tag == "div":
                for k, v in attrs:
                    if k == "id" and v == "js_content":
                        self.in_content = True
                        self.depth = 0
                        return
            return
        # 已进入正文
        if tag == "div":
            self.depth += 1
        if tag in VOID_TAGS:
            self._emit(f"<{tag} {self._attrs(tag, attrs)} />")
        else:
            self._emit(f"<{tag} {self._attrs(tag, attrs)}>")

    def handle_startendtag(self, tag, attrs):
        if self.in_content:
            self._emit(f"<{tag} {self._attrs(tag, attrs)} />")

    def handle_endtag(self, tag):
        if not self.in_content:
            return
        if tag == "div":
            if self.depth == 0:
                self.in_content = False  # 关闭 js_content
                return
            self.depth -= 1
        if tag not in VOID_TAGS:
            self._emit(f"</{tag}>")

    def handle_data(self, data):
        if self.in_content:
            self._emit(escape(data))

    def get_content(self) -> str:
        return "".join(self.capture)


def extract_content(raw: str) -> str:
    p = ContentExtractor()
    p.feed(raw)
    html = p.get_content()
    # 视频/音频/iframe 无法嵌入 PDF，替换为提示
    html = re.sub(
        r"<(mpvideo|mpvoice|iframe)\b[^>]*>.*?</\1>",
        lambda m: f'<p style="color:#999;border:1px dashed #ccc;'
                  f'padding:8px;">▷ {escape(m.group(1))} 内容（PDF 中不可播放）</p>',
        html, flags=re.S | re.I,
    )
    return html


# ---------------------------------------------------------------------------
# 组装独立 HTML 文档
# ---------------------------------------------------------------------------
def build_html(title: str, author: str, pub: str, content_html: str, url: str) -> str:
    meta_bits = []
    if author:
        meta_bits.append(f"作者：{escape(author)}")
    if pub:
        meta_bits.append(f"发布：{escape(pub)}")
    info = " ｜ ".join(meta_bits)
    header = f"""
    <div class="meta">
      <h1>{escape(title)}</h1>
      {f'<div class="info">{info}</div>' if info else ''}
      <div class="src">来源：{escape(url)}</div>
    </div>
    """
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<style>
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "PingFang SC",
                 "Microsoft YaHei", "Hiragino Sans GB", sans-serif;
    max-width: 720px; margin: 0 auto; padding: 28px 20px;
    color: #1f1f1f; line-height: 1.85; font-size: 16px;
  }}
  .meta {{ border-bottom: 1px solid #eee; padding-bottom: 14px; margin-bottom: 22px; }}
  h1 {{ font-size: 23px; line-height: 1.4; margin: 0 0 10px; font-weight: 700; }}
  .info, .src {{ font-size: 13px; color: #999; margin-top: 6px; word-break: break-all; }}
  img {{ max-width: 100% !important; height: auto !important; display: block;
         margin: 14px auto; border-radius: 4px; }}
  pre {{ background: #f6f6f6; padding: 14px; overflow: auto; border-radius: 8px;
         font-size: 14px; line-height: 1.6; }}
  code {{ background: #f2f2f2; padding: 2px 5px; border-radius: 4px; font-size: 14px; }}
  blockquote {{ border-left: 4px solid #d8d8d8; margin: 16px 0; padding: 4px 16px;
                color: #666; background: #fafafa; }}
  table {{ border-collapse: collapse; width: 100%; margin: 16px 0; font-size: 14px; }}
  td, th {{ border: 1px solid #e0e0e0; padding: 8px 10px; }}
  a {{ color: #576b95; word-break: break-all; }}
  h2, h3, h4 {{ line-height: 1.4; margin: 24px 0 12px; }}
</style>
</head>
<body>
{header}
{content_html}
</body>
</html>"""


# ---------------------------------------------------------------------------
# 渲染 PDF
# 优先用系统已装的 Chromium 内核浏览器（Chrome / Edge），零安装即可用；
# 找不到时才回退到 Playwright。
# ---------------------------------------------------------------------------
def find_chromium() -> str | None:
    """查找系统里已安装的 Chrome / Edge / Chromium。"""
    import os
    import shutil
    env = os.environ.get("CHROMIUM_BIN")
    if env and os.path.exists(env):
        return env
    for name in ("google-chrome", "chrome", "chromium", "chromium-browser", "msedge"):
        p = shutil.which(name)
        if p:
            return p
    candidates = [
        "C:/Program Files/Google/Chrome/Application/chrome.exe",
        "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
        "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
        "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
    ]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None


def _chrome_pdf(bin_path: str, html_str: str, out_path: str):
    import subprocess
    out_path = os.path.abspath(out_path)  # Chrome 的 --print-to-pdf 相对路径是相对它自身 cwd
    tmp = None
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".html",
                                         encoding="utf-8", delete=False) as f:
            f.write(html_str)
            tmp = f.name
        cmd = [
            bin_path, "--headless=new", "--disable-gpu", "--no-sandbox",
            "--no-pdf-header-footer", "--virtual-time-budget=20000",
            f"--print-to-pdf={out_path}", "file://" + tmp,
        ]
        subprocess.run(cmd, check=True, capture_output=True, timeout=180)
    finally:
        if tmp and os.path.exists(tmp):
            os.unlink(tmp)


def html_to_pdf(html_str: str, out_path: str):
    bin_path = find_chromium()
    if bin_path:
        print(f"      使用系统浏览器: {bin_path}")
        _chrome_pdf(bin_path, html_str, out_path)
        return
    # 回退：Playwright
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        sys.exit(
            "未找到系统浏览器，且未安装 Playwright。请任选其一：\n"
            "  1) 安装 Chrome / Edge 浏览器；或\n"
            "  2) 运行: pip install playwright && playwright install chromium\n"
            "（也可设置环境变量 CHROMIUM_BIN 指向浏览器可执行文件）"
        )
    tmp = None
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".html",
                                         encoding="utf-8", delete=False) as f:
            f.write(html_str)
            tmp = f.name
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 820, "height": 1100})
            page.goto("file://" + tmp, wait_until="networkidle")
            page.pdf(
                path=out_path,
                format="A4",
                print_background=True,
                margin={"top": "15mm", "bottom": "15mm",
                        "left": "14mm", "right": "14mm"},
            )
            browser.close()
    finally:
        if tmp and os.path.exists(tmp):
            os.unlink(tmp)


def safe_filename(title: str) -> str:
    name = re.sub(r'[\\/:*?"<>|\r\n\t]+', "_", title).strip()
    return name[:40] if name else "公众号文章"


def main():
    ap = argparse.ArgumentParser(description="公众号文章链接转 PDF")
    ap.add_argument("url", help="微信公众号文章链接")
    ap.add_argument("--out", default=None, help="输出 PDF 路径（默认当前目录）")
    args = ap.parse_args()

    print(f"[1/3] 抓取文章: {args.url}")
    html = fetch_html(args.url)

    print("[2/3] 解析正文与图片...")
    title, author, pub = extract_meta(html)
    content = extract_content(html)
    print(f"      标题: {title}")
    if author:
        print(f"      作者: {author}")
    if pub:
        print(f"      发布: {pub}")
    # 正文为空：很可能是抓取时撞了验证页，重抓一次再试
    for retry in range(2):
        if content.strip():
            break
        print(f"      ⚠️ 正文为空，重试抓取（{retry + 1}/2）...")
        time.sleep(5 + retry * 5)
        html = fetch_html(args.url)
        title, author, pub = extract_meta(html)
        content = extract_content(html)
    if not content.strip():
        sys.exit("⚠️ 未能提取到正文，可能不是标准公众号文章链接，"
                 "或文章需要微信内登录。")

    out_path = args.out or (safe_filename(title) + "_"
                            + datetime.now().strftime("%Y%m%d_%H%M%S") + ".pdf")

    doc = build_html(title, author, pub, content, args.url)
    print(f"[3/3] 渲染 PDF: {out_path}")
    html_to_pdf(doc, out_path)
    print(f"✅ 完成: {os.path.abspath(out_path)}")


if __name__ == "__main__":
    main()
