---
name: safe-file-organizer
description: 整理文件夹中的文件，按类型、扩展名、名称规则或自定义规则分类到对应子文件夹，支持下载目录、桌面、素材目录、混合文件夹的扫描、预览、确认执行和回滚。
---

# 文件整理

安全整理本地文件夹。默认先扫描并输出整理计划，用户确认后再移动文件；执行时记录 manifest，便于回滚。不要在没有确认的情况下删除文件、覆盖文件或改动系统目录。

## 先判断场景

根据用户描述选择整理策略：

- 下载目录：按文件类型整理，跳过未下载完成、最近仍在变化的文件。
- 桌面：先生成预览，提醒用户可能有临时文件和快捷方式；默认不递归。
- 素材目录：保留原文件名，可按图片、视频、音频、设计稿、压缩包分类。
- 项目目录：谨慎处理。默认跳过 `.git`、`node_modules`、虚拟环境、构建产物和隐藏配置文件。
- 票据/合同/截图等业务目录：优先使用名称关键词和自定义规则，而不是只看扩展名。
- 混合目录：先统计类型、大小、数量、冲突，再建议分类方案。

如果目标目录不明确，先问用户要整理哪个文件夹。不要猜测并直接整理家目录、根目录、整个磁盘或云盘同步根目录。

## 安全边界

- 默认只预览，不移动。只有用户明确同意执行，或命令显式使用 `--apply`，才可以移动文件。
- 不删除文件，不清空文件夹，不覆盖同名文件。
- 遇到同名冲突时，默认给新文件追加序号。
- 跳过目录、符号链接、隐藏文件、系统文件和仍在变化的文件，除非用户明确要求处理。
- 跳过 `.git`、`.svn`、`.hg`、`node_modules`、`vendor`、`.venv`、`venv`、`__pycache__`、`dist`、`build`、`.next`、`.cache`。
- 处理项目代码目录前，先说明风险并建议只整理指定收件箱或下载目录。
- 对发票、合同、身份证、银行卡、客户资料等敏感文件，只按本地规则分类，不在回复中暴露完整文件名里的隐私信息。

## 推荐流程

1. 明确目标目录和整理目标。
2. 扫描文件，统计文件数量、类型、大小、最近修改时间和潜在冲突。
3. 给出整理计划：目标子文件夹、命中文件数、示例文件、跳过原因。
4. 等用户确认执行。
5. 用脚本执行移动，并生成 manifest。
6. 汇报移动数量、跳过数量、冲突处理和 manifest 路径。
7. 如果用户不满意，用 manifest 回滚。

## 脚本

优先使用内置脚本：

```bash
python3 /Users/fengpeng/study/sk-codex/new-skills/safe-file-organizer/scripts/organize_files.py /path/to/folder
```

默认是预览模式。确认执行：

```bash
python3 /Users/fengpeng/study/sk-codex/new-skills/safe-file-organizer/scripts/organize_files.py /path/to/folder --apply
```

回滚：

```bash
python3 /Users/fengpeng/study/sk-codex/new-skills/safe-file-organizer/scripts/organize_files.py --undo /path/to/manifest.json
```

常用参数：

- `--recursive`：递归扫描子目录。
- `--max-depth N`：递归时限制深度。
- `--rules /path/to/rules.json`：加载自定义分类规则。
- `--group-by-month`：在分类目录下按 `YYYY-MM` 继续归档。
- `--include-hidden`：包含隐藏文件。
- `--min-age-seconds N`：跳过最近 N 秒内修改过的文件，避免移动未完成下载。
- `--json`：输出机器可读 JSON。

## 默认分类

默认规则在 `references/default-rules.json`。常见分类：

- Documents：pdf、doc、docx、txt、rtf、epub、pages。
- Spreadsheets：xls、xlsx、csv、tsv、numbers。
- Presentations：ppt、pptx、key。
- Images：jpg、jpeg、png、gif、webp、heic、svg、tiff、bmp。
- Videos：mp4、mov、avi、mkv、webm、m4v、wmv。
- Audio：mp3、wav、flac、m4a、aac、ogg。
- Archives：zip、7z、rar、tgz、tar、gz、xz、bz2、zst。
- Installers：dmg、pkg、exe、msi、deb、rpm、appimage、iso。
- Code：py、js、ts、tsx、jsx、java、go、rs、c、cpp、h、php、rb、swift、kt、sh、sql、ipynb、json、yaml、toml。
- Design：psd、ai、sketch、fig、xd、indd。
- Fonts：ttf、otf、woff、woff2。
- Other：无法识别或无扩展名文件。

## 自定义规则写法

当用户提出“发票放 invoices”“截图按月份放”“安装包单独归档”等需求时，创建临时 JSON 规则文件，再传给脚本。

规则示例：

```json
{
  "categories": {
    "Invoices": [".pdf", ".jpg", ".png"],
    "Installers": [".dmg", ".pkg", ".exe"]
  },
  "name_rules": [
    {
      "category": "Invoices",
      "contains": ["invoice", "receipt", "发票", "收据"]
    },
    {
      "category": "Screenshots",
      "starts_with": ["screenshot", "截屏", "屏幕截图"]
    }
  ],
  "exclude_names": [".DS_Store"],
  "exclude_extensions": [".tmp", ".crdownload", ".part"]
}
```

名称规则优先于扩展名规则。自定义分类会覆盖或补充默认分类。

## 输出给用户

预览后用简洁表格汇报：

```markdown
| 目标分类 | 文件数 | 示例 | 说明 |
|---|---:|---|---|
| Documents | 12 | report.pdf | 按扩展名识别 |
| Images | 34 | photo.png | 可按月份继续归档 |
| Skipped | 3 | download.part | 未完成或被排除 |
```

执行后汇报：

- 已移动多少个文件。
- 跳过多少个文件及主要原因。
- 是否发生同名冲突，如何处理。
- manifest 路径。
- 回滚命令。

不要在聊天中列出大量完整文件名。文件很多时只给示例和统计。

## 质量检查

交付前确认：

- 已先预览，或用户明确要求直接执行。
- 目标路径不是系统根目录、用户家目录、代码仓库根目录或云盘根目录。
- 没有删除、覆盖或清空目录。
- 同名冲突已用重命名或跳过处理。
- 执行后有 manifest。
- 重要跳过项已说明。
- 用户能用一条命令回滚。
