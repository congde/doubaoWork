#!/usr/bin/env python3
import argparse
import json
import os
import shutil
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path


DEFAULT_EXCLUDE_DIRS = {
    ".git",
    ".svn",
    ".hg",
    "node_modules",
    "vendor",
    ".venv",
    "venv",
    "__pycache__",
    "dist",
    "build",
    ".next",
    ".cache",
}


def normalize_ext(ext):
    ext = str(ext).strip().lower()
    if not ext:
        return ""
    return ext if ext.startswith(".") else f".{ext}"


def default_rules_path():
    return Path(__file__).resolve().parents[1] / "references" / "default-rules.json"


def load_rules(path):
    with Path(path).expanduser().open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    data.setdefault("categories", {})
    data.setdefault("name_rules", [])
    data.setdefault("exclude_names", [])
    data.setdefault("exclude_extensions", [])
    data["categories"] = {
        category: sorted({normalize_ext(ext) for ext in exts})
        for category, exts in data["categories"].items()
    }
    data["exclude_extensions"] = {normalize_ext(ext) for ext in data["exclude_extensions"]}
    data["exclude_names"] = {name.lower() for name in data["exclude_names"]}
    return data


def is_relative_to(path, parent):
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def iter_files(root, recursive, max_depth, include_hidden, exclude_dirs):
    root = root.resolve()
    if recursive:
        for current, dirnames, filenames in os.walk(root):
            current_path = Path(current)
            rel = current_path.relative_to(root)
            depth = len(rel.parts)
            dirnames[:] = [
                d
                for d in dirnames
                if d not in exclude_dirs and (include_hidden or not d.startswith("."))
            ]
            if max_depth is not None and depth >= max_depth:
                dirnames[:] = []
            for name in filenames:
                if not include_hidden and name.startswith("."):
                    continue
                yield current_path / name
    else:
        for path in root.iterdir():
            if not include_hidden and path.name.startswith("."):
                continue
            if path.is_file():
                yield path


def should_skip(path, root, rules, min_age_seconds):
    lower_name = path.name.lower()
    if path.is_symlink():
        return "symlink"
    if not path.is_file():
        return "not_file"
    if lower_name in rules["exclude_names"]:
        return "excluded_name"
    if path.suffix.lower() in rules["exclude_extensions"]:
        return "excluded_extension"
    if min_age_seconds > 0:
        age = datetime.now().timestamp() - path.stat().st_mtime
        if age < min_age_seconds:
            return "recently_modified"
    if any(part in DEFAULT_EXCLUDE_DIRS for part in path.relative_to(root).parts[:-1]):
        return "excluded_directory"
    return None


def match_name_rule(path, rules):
    name = path.name.lower()
    for rule in rules["name_rules"]:
        category = rule.get("category")
        if not category:
            continue
        starts = [str(x).lower() for x in rule.get("starts_with", [])]
        contains = [str(x).lower() for x in rule.get("contains", [])]
        ends = [str(x).lower() for x in rule.get("ends_with", [])]
        if starts and any(name.startswith(x) for x in starts):
            return category, "name_rule"
        if contains and any(x in name for x in contains):
            return category, "name_rule"
        if ends and any(name.endswith(x) for x in ends):
            return category, "name_rule"
    return None, None


def categorize(path, rules):
    category, reason = match_name_rule(path, rules)
    if category:
        return category, reason
    ext = path.suffix.lower()
    for category, extensions in rules["categories"].items():
        if ext in extensions:
            return category, "extension"
    return "Other", "fallback"


def unique_destination(dest):
    if not dest.exists():
        return dest, False
    stem = dest.stem
    suffix = dest.suffix
    counter = 2
    while True:
        candidate = dest.with_name(f"{stem} {counter}{suffix}")
        if not candidate.exists():
            return candidate, True
        counter += 1


def month_folder(path):
    dt = datetime.fromtimestamp(path.stat().st_mtime)
    return dt.strftime("%Y-%m")


def build_plan(args, rules):
    root = Path(args.folder).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise SystemExit(f"Target folder does not exist or is not a directory: {root}")

    exclude_dirs = DEFAULT_EXCLUDE_DIRS | set(args.exclude_dir or [])
    moves = []
    skipped = []
    counts = Counter()

    for path in iter_files(root, args.recursive, args.max_depth, args.include_hidden, exclude_dirs):
        reason = should_skip(path, root, rules, args.min_age_seconds)
        if reason:
            skipped.append({"path": str(path), "reason": reason})
            continue

        category, basis = categorize(path, rules)
        dest_dir = root / category
        if args.group_by_month:
            dest_dir = dest_dir / month_folder(path)
        dest, conflict = unique_destination(dest_dir / path.name)

        if path.resolve() == dest.resolve() or is_relative_to(path.resolve(), dest_dir.resolve()):
            skipped.append({"path": str(path), "reason": "already_in_target"})
            continue

        moves.append(
            {
                "source": str(path),
                "destination": str(dest),
                "category": category,
                "basis": basis,
                "size": path.stat().st_size,
                "conflict_renamed": conflict,
            }
        )
        counts[category] += 1

    return {
        "root": str(root),
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "apply": bool(args.apply),
        "moves": moves,
        "skipped": skipped,
        "summary": {
            "planned_moves": len(moves),
            "skipped": len(skipped),
            "by_category": dict(sorted(counts.items())),
        },
    }


def write_manifest(root, moves, skipped):
    manifest_dir = root / ".file-organizer"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    manifest = manifest_dir / f"manifest-{stamp}.json"
    payload = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "root": str(root),
        "moves": moves,
        "skipped": skipped,
    }
    manifest.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def apply_plan(plan):
    executed = []
    root = Path(plan["root"])
    for item in plan["moves"]:
        src = Path(item["source"])
        dst = Path(item["destination"])
        if not src.exists():
            item = dict(item)
            item["status"] = "source_missing"
            executed.append(item)
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        final_dst, conflict = unique_destination(dst)
        if final_dst != dst:
            item = dict(item)
            item["destination"] = str(final_dst)
            item["conflict_renamed"] = True
        shutil.move(str(src), str(final_dst))
        item = dict(item)
        item["status"] = "moved"
        executed.append(item)
    manifest = write_manifest(root, executed, plan["skipped"])
    return executed, manifest


def undo(manifest_path):
    manifest = Path(manifest_path).expanduser().resolve()
    data = json.loads(manifest.read_text(encoding="utf-8"))
    restored = []
    skipped = []
    for item in reversed(data.get("moves", [])):
        if item.get("status") != "moved":
            skipped.append({"item": item, "reason": "not_moved"})
            continue
        src = Path(item["destination"])
        dst = Path(item["source"])
        if not src.exists():
            skipped.append({"item": item, "reason": "destination_missing"})
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        final_dst, conflict = unique_destination(dst)
        shutil.move(str(src), str(final_dst))
        restored.append({"from": str(src), "to": str(final_dst), "conflict_renamed": conflict})
    return {"manifest": str(manifest), "restored": restored, "skipped": skipped}


def print_human(plan, executed=None, manifest=None):
    summary = plan["summary"]
    mode = "EXECUTED" if plan["apply"] else "PREVIEW"
    print(f"[{mode}] {plan['root']}")
    print(f"Planned moves: {summary['planned_moves']}")
    print(f"Skipped: {summary['skipped']}")
    if summary["by_category"]:
        print("\nBy category:")
        for category, count in summary["by_category"].items():
            examples = [Path(x["source"]).name for x in plan["moves"] if x["category"] == category][:3]
            print(f"- {category}: {count} ({', '.join(examples)})")
    if plan["skipped"]:
        reasons = Counter(x["reason"] for x in plan["skipped"])
        print("\nSkipped reasons:")
        for reason, count in sorted(reasons.items()):
            print(f"- {reason}: {count}")
    conflicts = sum(1 for x in plan["moves"] if x.get("conflict_renamed"))
    if conflicts:
        print(f"\nName conflicts resolved by renaming: {conflicts}")
    if executed is not None:
        moved = sum(1 for x in executed if x.get("status") == "moved")
        print(f"\nMoved: {moved}")
    if manifest:
        print(f"Manifest: {manifest}")
        print(f"Undo: python3 {Path(__file__).resolve()} --undo {manifest}")


def parse_args(argv):
    parser = argparse.ArgumentParser(description="Preview, apply, or undo safe file organization.")
    parser.add_argument("folder", nargs="?", help="Folder to organize.")
    parser.add_argument("--apply", action="store_true", help="Move files. Omit for preview only.")
    parser.add_argument("--rules", default=str(default_rules_path()), help="Rules JSON path.")
    parser.add_argument("--recursive", action="store_true", help="Scan subfolders.")
    parser.add_argument("--max-depth", type=int, default=None, help="Maximum depth when recursive.")
    parser.add_argument("--include-hidden", action="store_true", help="Include hidden files.")
    parser.add_argument("--min-age-seconds", type=int, default=30, help="Skip recently modified files.")
    parser.add_argument("--group-by-month", action="store_true", help="Put files under category/YYYY-MM.")
    parser.add_argument("--exclude-dir", action="append", default=[], help="Extra directory name to skip.")
    parser.add_argument("--json", action="store_true", help="Print JSON output.")
    parser.add_argument("--undo", help="Undo a prior manifest.")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv or sys.argv[1:])
    if args.undo:
        result = undo(args.undo)
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"Restored: {len(result['restored'])}")
            print(f"Skipped: {len(result['skipped'])}")
        return 0
    if not args.folder:
        raise SystemExit("folder is required unless --undo is used")
    rules = load_rules(args.rules)
    plan = build_plan(args, rules)
    if args.apply:
        executed, manifest = apply_plan(plan)
        if args.json:
            plan["executed"] = executed
            plan["manifest"] = str(manifest)
            print(json.dumps(plan, ensure_ascii=False, indent=2))
        else:
            print_human(plan, executed=executed, manifest=manifest)
    else:
        if args.json:
            print(json.dumps(plan, ensure_ascii=False, indent=2))
        else:
            print_human(plan)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
