#!/usr/bin/env python3
"""Validate an AI product pricing report for cost and margin evidence."""
import argparse
from pathlib import Path

REQUIRED = {
    "provider_cost": ["provider cost", "供应商成本", "单位成本"],
    "usage_assumptions": ["usage assumption", "用量假设", "平均用量"],
    "plan_limits": ["plan limit", "套餐上限", "额度上限"],
    "gross_margin": ["gross margin", "毛利"],
    "failure_refund": ["失败率", "退款率", "failure rate", "refund rate"],
    "source_date": ["查询日期", "price checked", "source url", "来源 url"],
}

def main():
    p=argparse.ArgumentParser(description="Validate AI pricing report structure")
    p.add_argument("report")
    args=p.parse_args()
    path=Path(args.report)
    if not path.is_file(): raise SystemExit(f"ERROR file not found: {path}")
    text=path.read_text(encoding="utf-8").lower()
    missing=[name for name,words in REQUIRED.items() if not any(w.lower() in text for w in words)]
    if missing:
        print("FAIL missing:", ", ".join(missing)); raise SystemExit(1)
    print("OK pricing report contains cost, limits, assumptions and margin evidence")

if __name__ == "__main__": main()
