# AI generation SaaS: credits, assets, and subscription loop

Use this reference for image/video generation products whose variable inference cost must be recovered through credits or subscriptions.

## Smallest real commercial loop

```text
SEO/landing page
→ generator visible above the fold
→ authenticate
→ one-time free credits
→ submit a real asynchronous generation job
→ show progress, failure, and result
→ persist result in Assets/history
→ low balance
→ upgrade/subscribe
→ entitlement and credit renewal
```

A polished playground that only swaps in a canned preview is not a generation product. Do not market “live generation,” free credits, or purchasable plans until a real provider call and its failure path are exercised in production.

## Prerequisites before pricing

- Provider chosen and server-side API credential configured as a platform secret.
- Current official price for every exposed model, resolution, duration, and optional audio mode.
- Persistent users, jobs, assets, credit ledger, and subscription/entitlement state.
- Abuse controls: verified identity, per-user limits, rate limiting, and bounded free grants.
- Success, timeout, cancellation, provider rejection, moderation, and refund behavior.

Never enforce credits only in browser state. Never expose the provider key to the client.

## Credit ledger contract

Prefer an append-only ledger over mutating one balance without history:

- `grant` — signup, monthly renewal, promotion, manual adjustment.
- `reserve` — atomically reserve maximum job cost before provider submission.
- `capture` — finalize actual cost after success.
- `release` — idempotently refund a failed/cancelled reservation.
- `purchase` — credits attached to a verified payment event.

Every provider request needs a stable internal job ID and idempotency strategy. The same webhook, polling result, or retry must not charge or refund twice.

## Minimum persistent model

- `users`: provider subject, email, created time, plan.
- `credit_ledger`: user, amount, type, job/payment reference, idempotency key.
- `generation_jobs`: user, mode, model, normalized input, status, reserved cost, provider request ID, error, timestamps.
- `assets`: user, job, media type, durable URL/storage key, dimensions/duration, prompt, created time.
- `subscriptions`: user, provider customer/subscription IDs, plan, status, renewal time.

Use durable object storage for generated media if provider URLs are temporary or retention is not guaranteed.

## Cost calibration

For each exposed option, calculate:

```text
unit variable cost
+ storage/egress/payment overhead
+ failure and abuse allowance
= internal cost floor

internal cost floor / target gross-margin remainder
= minimum customer-equivalent price
```

Then run a **worst-credit-burn test** for every subscription tier. Assume a rational heavy user spends every included Credit on the exposed workflow with the highest provider cost per Credit—not on the average image/video mix:

```text
net subscription revenue
= list price - conservative payment/Billing/FX fees

worst provider cost
= included credits × highest provider cost per consumed credit

contribution remainder
= net subscription revenue
  - worst provider cost
  - failure/storage/egress/abuse buffer
```

Require a positive remainder and an explicit target margin before launch. Keep payment assumptions conservative when the account currency, customer card region, or currency conversion can add fees. Re-run the table for all-image, all-edit, and all-video usage, but use the most expensive case as the pricing gate. Free signup Credits are acquisition cost and must also fit the abuse budget.

Credits do not need to equal provider cost one-for-one. For example, a model costing `$0.04/second` may charge `6 Credits/second` when `1 Credit` represents `$0.01` of customer usage allowance; the spread pays for payment fees, failures, storage, and margin. State this as a usage allowance, not as a claim that each Credit equals one cent of provider cost.

Use measured provider bills and observed completion rates after launch. Do not copy a competitor’s credit number because “20 credits” has no universal monetary meaning.

## Dated provider research example — verify again before use

As checked from official fal.ai model documentation on 2026-07-26:

- FLUX.2 text-to-image: `fal-ai/flux-2`, listed at $0.012 per output megapixel.
  - https://fal.ai/models/fal-ai/flux-2
- FLUX.2 image editing: `fal-ai/flux-2/edit`, listed at $0.012 per input/output megapixel.
  - https://fal.ai/models/fal-ai/flux-2/edit
- LTX 2.3 Fast text-to-video: `fal-ai/ltx-2.3/text-to-video/fast`, observed at $0.04 per generated second. Its API uses `duration`, `resolution`, `aspect_ratio`, and `fps`; the checked schema supported 6–20 seconds and defaulted to 1080p/25fps.
  - https://fal.ai/models/fal-ai/ltx-2.3/text-to-video/fast/api
- LTX 2.3 Fast image-to-video: `fal-ai/ltx-2.3/image-to-video/fast`; the start-image field is `image_url`.
  - https://fal.ai/models/fal-ai/ltx-2.3/image-to-video/fast/api
- Wan 2.2 A14B text-to-video: `fal-ai/wan/v2.2-a14b/text-to-video`, listed by resolution per generated second.
  - https://fal.ai/models/fal-ai/wan/v2.2-a14b/text-to-video
- Wan 2.2 A14B image-to-video:
  - https://fal.ai/models/fal-ai/wan/v2.2-a14b/image-to-video
- fal recommends persistent asynchronous queue submission with status/result polling or webhooks:
  - https://fal.ai/docs/documentation/model-apis/inference/queue

These model IDs, prices, schemas, licenses, and availability are dated observations, not permanent defaults. Re-read official model pages before implementation or repricing.

## Stripe-first sequencing for an existing credits app

When an image/video app already has authentication, a persistent credit ledger, real provider jobs, and free signup credits, connect monetization in this order:

1. Inspect the actual Stripe account mode, existing products/prices, account readiness, and deployed Cloudflare secret names without printing secret values.
2. Freeze the intended recurring price and monthly credit entitlement before creating a formal product. Do not silently reuse an unrelated `$1` live-validation product as the public plan.
3. Add idempotent `orders`, `subscriptions`, `payment_events`, and `entitlements` persistence plus Checkout, webhook, and customer-portal endpoints.
4. Prove Checkout → webhook → D1 entitlement in test mode or by stopping at the live Checkout payment page unless the owner explicitly authorizes a charge.
5. Only after that loop works, reduce the signup grant and enable the insufficient-balance subscription wall. This avoids stranding users behind a paywall whose checkout or entitlement path is not ready.

Changing `WELCOME_CREDITS` affects only newly inserted users. Do not rewrite existing balances merely to match a new signup offer; existing balances and append-only ledger history should remain intact unless the owner explicitly requests a migration. Keep the base migration default, runtime grant constant, public copy, API response, and tests aligned for new databases/users.

For subscription credits, grant once per paid billing period using a stable idempotency key such as the Stripe invoice or subscription-period identifier. A webhook retry must not duplicate monthly credits. Cancellation should normally preserve access through the paid period end, and generation authorization must read server-side entitlement state rather than browser state.

## Conversion and compliance gates

- Pricing CTA must match a working checkout, contact, or waitlist path.
- Do not show “commercial use” unless provider/model terms support it.
- Privacy/Terms must disclose AI provider processing, prompt/upload handling, generated-asset retention, payment provider, and user deletion route before activation.
- Add a Refund Policy before accepting paid subscriptions where the commercial flow calls for one.
