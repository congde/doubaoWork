# Marketplace 发布说明

- Skill：`wechat-article-writing-workflow`
- 定位：通用公众号实战文章写作，不模仿或冒充任何具名创作者。
- API：核心工作流无付费 API；搜索、排版、图片生成和公众号发布均为可选适配器。
- 配置：作者名、账号名、目标读者、语气、CTA 和转化目标均由用户配置。
- 安全：禁止打包 Cookie、AppSecret、Token、聊天记录、内部截图和真实账号资料。
- 许可：上传前由权利人选择并添加 `LICENSE`。
