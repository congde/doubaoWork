from pathlib import Path
import re
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 count_chars.py ARTICLE.md')

text = Path(sys.argv[1]).read_text(encoding='utf-8')
non_whitespace = len(re.sub(r'\s+', '', text))
chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
print(f'non_whitespace_chars={non_whitespace}')
print(f'chinese_chars={chinese_chars}')
