# High-Risk Python Patterns

这些是“审查入口”，不是看到就直接判 Bug。

## Mutable default

```python
def append_item(item, items=[]):
    items.append(item)
```

风险：默认对象跨调用共享。

## Queue command references mutable shared state

```python
self.target_voltage = 100
self.queue.put("SET_VOLTAGE")
self.target_voltage = 200

def worker(self):
    cmd = self.queue.get()
    send(self.target_voltage)
```

风险：队列保存的是命令类型，不是命令时刻的数据快照。

优先：

```python
self.queue.put(("SET_VOLTAGE", 100))
```

## Async function calls blocking library

```python
async def update():
    requests.get(url)
```

风险：阻塞 event loop。

## Blind exception swallowing

```python
try:
    device.write(data)
except Exception:
    pass
```

风险：设备命令失败但上层仍继续流程。

## No request timeout

```python
requests.get(url)
```

风险：长期等待，尤其在控制线程或任务中。

## `is` for value comparison

```python
if status is 1:
    ...
```

风险：identity 与 equality 语义不同。

## Protocol assumes one read is one frame

```python
data = serial.read(64)
parse_frame(data)
```

如果协议帧可能拆分/粘连，需要累计缓冲和帧边界解析。

## SEND then NEXT

```python
send_start()
state = RUNNING
```

如果 `send_start()` 只是发送/入队而不是确认设备已启动，则可能提前切状态。

## Stale state satisfies new command

```python
send_stop()

if device_state == STOPPED:
    next_step()
```

如果 `device_state` 是发送命令前遗留值，则会把旧状态当作本次确认。

## Retry without request identity

```python
send(req)
timeout()
send(req_again)
```

迟到的第一次响应可能被第二次请求误接收，需要结合协议和状态机判断。

## Busy loop

```python
while True:
    check_status()
```

如果没有阻塞、sleep 或 await，可能持续占用 CPU。

## Non-atomic important config write

```python
with open(config_path, "w") as f:
    json.dump(config, f)
```

进程崩溃/磁盘失败时可能破坏原配置。关键数据可考虑临时文件 + replace。
