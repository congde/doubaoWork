# Python Industrial Review Checklist

## 1. 项目结构
- [ ] 找到入口。
- [ ] 找到主线程 / event loop。
- [ ] 找到所有后台线程、executor、Task。
- [ ] 找到设备通信模块。
- [ ] 找到状态机。
- [ ] 找到关键全局/单例状态。
- [ ] 找到配置和数据持久化路径。

## 2. Python 语义
- [ ] mutable default argument。
- [ ] `None` 与 falsey value 混淆。
- [ ] `is` 错用于值比较。
- [ ] late-binding closure。
- [ ] shallow copy。
- [ ] dict KeyError。
- [ ] 空 list/tuple 索引。
- [ ] bytes/str。
- [ ] float 阈值。
- [ ] 未初始化局部变量。

## 3. 线程 / asyncio
- [ ] 共享变量有哪些 writer？
- [ ] check-then-act 是否受保护？
- [ ] Queue 数据是否携带完整快照？
- [ ] 锁是否可能反向获取？
- [ ] 锁内是否执行阻塞 I/O？
- [ ] Thread 退出和 join 是否完整？
- [ ] async 函数内是否调用同步阻塞 I/O？
- [ ] create_task 的异常是否被观察？
- [ ] cancellation 是否正确处理？
- [ ] shutdown 是否会遗留任务？

## 4. 设备通信
- [ ] 请求、队列、发送、接收、确认是否分离？
- [ ] write/send 返回结果是否检查？
- [ ] read/recv 是否正确处理拆包粘包？
- [ ] CRC/checksum？
- [ ] 地址/功能码/长度？
- [ ] response 是否和当前 request 匹配？
- [ ] timeout 的起止点？
- [ ] retry 是否可能和迟到响应冲突？
- [ ] 非幂等命令是否安全重发？
- [ ] polling 是否影响控制命令？
- [ ] 掉线时状态是否失效？
- [ ] 重连后是否重新同步真实状态？

## 5. 状态机
- [ ] action 是否只执行一次或明确允许重复？
- [ ] success 是否基于新鲜状态？
- [ ] timeout 是否正确初始化/递减/清零？
- [ ] retry 是否正确初始化/清零？
- [ ] failure 是否明确落到异常状态？
- [ ] pause/resume？
- [ ] abort？
- [ ] SEND 后是否在确认前 NEXT？
- [ ] 是否存在死状态/永久等待？

## 6. 异常
- [ ] bare except。
- [ ] except + pass。
- [ ] 错误是否被吞掉？
- [ ] traceback 是否保留？
- [ ] cleanup 是否在异常时执行？
- [ ] 后台线程异常是否能被主流程感知？

## 7. 文件 / 数据库
- [ ] encoding。
- [ ] partial write。
- [ ] disk full。
- [ ] 原文件覆盖风险。
- [ ] transaction。
- [ ] commit/rollback。
- [ ] concurrent write。
- [ ] SQLite lock/thread。
- [ ] close/resource release。

## 8. 网络 / subprocess / 安全
- [ ] HTTP timeout。
- [ ] HTTP status。
- [ ] JSON decode。
- [ ] shell=True。
- [ ] eval/exec。
- [ ] pickle untrusted input。
- [ ] SQL injection。
- [ ] path traversal。
- [ ] secret hardcode/logging。

## 9. 长期运行
- [ ] queue 无界增长。
- [ ] cache/list 无界增长。
- [ ] timer/task/thread 重复创建。
- [ ] 日志增长。
- [ ] 重连风暴。
- [ ] busy loop。
- [ ] 资源泄漏。
- [ ] stale device state。

## 10. 最终检查
- [ ] 每个 P0/P1 都有具体执行证据。
- [ ] 没把静态扫描命中直接当 Bug。
- [ ] 没把风格问题抬高严重度。
- [ ] 给出了修复顺序。
- [ ] 标出需要运行验证的问题。
