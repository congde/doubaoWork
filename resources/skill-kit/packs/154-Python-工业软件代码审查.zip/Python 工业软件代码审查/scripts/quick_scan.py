#!/usr/bin/env python3
"""
Lightweight candidate-risk scanner for Python projects.

This script intentionally reports candidates, not confirmed bugs.
It uses only the Python standard library.
"""

from __future__ import annotations

import argparse
import ast
import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, List, Optional


SKIP_DIRS = {
    ".git", ".hg", ".svn", ".idea", ".vscode",
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".venv", "venv", "env", "site-packages",
    "build", "dist", "node_modules",
}

HTTP_NAMES = {"requests", "httpx"}
DANGEROUS_CALLS = {"eval", "exec"}
MUTABLE_DEFAULT_NODES = (ast.List, ast.Dict, ast.Set)


@dataclass
class Finding:
    severity: str
    rule: str
    file: str
    line: int
    message: str


def dotted_name(node: ast.AST) -> Optional[str]:
    parts = []
    cur = node
    while isinstance(cur, ast.Attribute):
        parts.append(cur.attr)
        cur = cur.value
    if isinstance(cur, ast.Name):
        parts.append(cur.id)
        return ".".join(reversed(parts))
    return None


def is_literal_value(node: ast.AST) -> bool:
    if isinstance(node, ast.Constant):
        return node.value is not None and node.value is not True and node.value is not False
    return isinstance(node, (ast.List, ast.Dict, ast.Set, ast.Tuple))


def has_keyword(call: ast.Call, name: str) -> bool:
    return any(k.arg == name for k in call.keywords)


def keyword_bool(call: ast.Call, name: str, value: bool) -> bool:
    for k in call.keywords:
        if k.arg == name and isinstance(k.value, ast.Constant):
            return k.value.value is value
    return False


class Scanner(ast.NodeVisitor):
    def __init__(self, filename: str):
        self.filename = filename
        self.findings: List[Finding] = []
        self.async_depth = 0

    def add(self, severity: str, rule: str, node: ast.AST, message: str):
        self.findings.append(
            Finding(severity, rule, self.filename, getattr(node, "lineno", 0), message)
        )

    def visit_FunctionDef(self, node: ast.FunctionDef):
        self._check_defaults(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef):
        self._check_defaults(node)
        self.async_depth += 1
        self.generic_visit(node)
        self.async_depth -= 1

    def _check_defaults(self, node):
        defaults = list(node.args.defaults) + [
            d for d in node.args.kw_defaults if d is not None
        ]
        for default in defaults:
            if isinstance(default, MUTABLE_DEFAULT_NODES):
                self.add(
                    "P2", "mutable-default", default,
                    "Mutable default argument is shared across calls."
                )
            elif isinstance(default, ast.Call):
                name = dotted_name(default.func)
                if name in {"list", "dict", "set"}:
                    self.add(
                        "P2", "mutable-default", default,
                        f"Default argument calls {name}(); verify the object is not unintentionally shared."
                    )

    def visit_ExceptHandler(self, node: ast.ExceptHandler):
        if node.type is None:
            self.add(
                "P2", "bare-except", node,
                "Bare except catches BaseException subclasses such as KeyboardInterrupt/SystemExit."
            )

        only_pass = len(node.body) == 1 and isinstance(node.body[0], ast.Pass)
        if only_pass:
            self.add(
                "P1", "exception-swallowed", node,
                "Exception handler contains only pass; failures may be silently ignored."
            )
        self.generic_visit(node)

    def visit_Compare(self, node: ast.Compare):
        operators = node.ops
        comparators = node.comparators
        left = node.left
        for op, right in zip(operators, comparators):
            if isinstance(op, (ast.Is, ast.IsNot)):
                if is_literal_value(left) or is_literal_value(right):
                    self.add(
                        "P2", "identity-value-compare", node,
                        "Uses 'is/is not' for a non-singleton value comparison; verify equality was intended."
                    )
            left = right
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        name = dotted_name(node.func)

        if name in DANGEROUS_CALLS:
            self.add(
                "P1", "dynamic-code-execution", node,
                f"Call to {name}(); verify input is fully trusted."
            )

        if name == "subprocess.run":
            if keyword_bool(node, "shell", True):
                self.add(
                    "P1", "subprocess-shell", node,
                    "subprocess.run(..., shell=True) can enable command injection if any argument is untrusted."
                )

        if name == "subprocess.Popen":
            if keyword_bool(node, "shell", True):
                self.add(
                    "P1", "subprocess-shell", node,
                    "subprocess.Popen(..., shell=True) can enable command injection if any argument is untrusted."
                )

        if name:
            first = name.split(".", 1)[0]
            method = name.rsplit(".", 1)[-1]
            if first in HTTP_NAMES and method in {
                "get", "post", "put", "patch", "delete", "head", "options", "request"
            }:
                if not has_keyword(node, "timeout"):
                    self.add(
                        "P2", "http-no-timeout", node,
                        f"{name}() has no explicit timeout."
                    )
                if self.async_depth > 0 and first == "requests":
                    self.add(
                        "P1", "blocking-http-in-async", node,
                        "Synchronous requests call is inside async code and can block the event loop."
                    )

        self.generic_visit(node)


def iter_py_files(root: Path) -> Iterable[Path]:
    if root.is_file():
        if root.suffix == ".py":
            yield root
        return

    for path in root.rglob("*.py"):
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        yield path


def scan_file(path: Path, root: Path) -> List[Finding]:
    try:
        text = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        try:
            text = path.read_text(encoding="gb18030")
        except Exception as exc:
            return [Finding("P2", "read-error", str(path), 0, f"Cannot decode file: {exc}")]
    except Exception as exc:
        return [Finding("P2", "read-error", str(path), 0, f"Cannot read file: {exc}")]

    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError as exc:
        return [
            Finding(
                "P1", "syntax-error", str(path),
                exc.lineno or 0,
                f"SyntaxError: {exc.msg}"
            )
        ]

    try:
        display = str(path.relative_to(root)) if root.is_dir() else path.name
    except ValueError:
        display = str(path)

    scanner = Scanner(display)
    scanner.visit(tree)
    return scanner.findings


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Scan Python files for candidate reliability/security risks."
    )
    parser.add_argument("path", help="Python file or project directory")
    parser.add_argument("--json", action="store_true", help="Output JSON")
    args = parser.parse_args()

    root = Path(args.path).expanduser().resolve()
    if not root.exists():
        print(f"Path does not exist: {root}", file=sys.stderr)
        return 2

    findings: List[Finding] = []
    files = list(iter_py_files(root))
    for path in files:
        findings.extend(scan_file(path, root))

    order = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
    findings.sort(key=lambda f: (order.get(f.severity, 9), f.file, f.line))

    if args.json:
        print(json.dumps([asdict(x) for x in findings], ensure_ascii=False, indent=2))
    else:
        print(f"Scanned {len(files)} Python file(s).")
        print(f"Candidate findings: {len(findings)}")
        for f in findings:
            print(f"[{f.severity}] {f.file}:{f.line} {f.rule} - {f.message}")

        print("\nNOTE: These are candidate findings only. Review the actual call path before classifying a bug.")

    return 1 if findings else 0


if __name__ == "__main__":
    import sys
    raise SystemExit(main())
