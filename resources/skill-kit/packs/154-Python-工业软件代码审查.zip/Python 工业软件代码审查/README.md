# python-industrial-code-review

面向 Python 工业软件、自动化、设备通信和长期运行程序的 Codex/Agent Skill。

## 目录

```text
python-industrial-code-review/
├─ SKILL.md
├─ README.md
├─ references/
│  ├─ review-checklist.md
│  ├─ severity-model.md
│  └─ risk-patterns.md
└─ scripts/
   └─ quick_scan.py
```

## Windows 安装

将整个目录复制到：

```text
C:\Users\<你的用户名>\.agents\skills\python-industrial-code-review
```

例如：

```text
C:\Users\13421\.agents\skills\python-industrial-code-review
```

注意不要多套一层目录。正确结构应直接存在：

```text
...\python-industrial-code-review\SKILL.md
```

## 项目级安装

如果只想让某个项目使用，可以放在项目根目录：

```text
<project>\.agents\skills\python-industrial-code-review\
```

## 使用示例

```text
$python-industrial-code-review

审查整个 Python 项目。
重点检查线程、串口、命令队列、状态机、超时重试和长期运行稳定性。
先不要修改代码。
```

也可以：

```text
使用 python-industrial-code-review 审查当前项目。
只报告 P0-P2，先不要修改代码。
```

## quick_scan.py

这是一个无第三方依赖的候选风险扫描器：

```bash
python scripts/quick_scan.py C:\path\to\project
```

或输出 JSON：

```bash
python scripts/quick_scan.py C:\path\to\project --json
```

它不会替代正式代码审查。扫描结果只是候选位置，最终必须结合调用链确认。

## 建议使用方式

第一次审查：

```text
使用 python-industrial-code-review 对整个项目做全面审查。
优先 P0/P1/P2。
先不要改代码。
每个问题必须给代码证据和触发条件。
```

修复后：

```text
再次使用 python-industrial-code-review。
只复查上次 P0/P1/P2 是否真正修复，并检查修改是否引入新的时序或并发问题。
```
