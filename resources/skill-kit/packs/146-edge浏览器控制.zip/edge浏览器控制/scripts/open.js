#!/usr/bin/env node
const { openPage, CDP_URL } = require('./edge');

const url = process.argv[2];

if (!url) {
  console.error('用法: node scripts/open.js <url>');
  console.error('示例: node scripts/open.js https://example.com');
  process.exit(1);
}

(async () => {
  try {
    console.log('CDP:', CDP_URL);
    const page = await openPage(url);
    console.log('Title:', await page.title());
    console.log('URL:', page.url());
    await page.context().browser().close();
  } catch (e) {
    console.error('Error:', e.message);
    process.exit(1);
  }
})();
