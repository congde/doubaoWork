#!/usr/bin/env node
const { ensureBrowser, resolveEdgePath, CDP_PORT, CDP_URL } = require('./edge');

(async () => {
  console.log('Edge 路径:', resolveEdgePath());
  console.log('CDP 地址:', CDP_URL);
  const result = await ensureBrowser();
  if (result.ok) {
    console.log('CDP 端口:', result.port, result.reused ? '(复用已有 Edge)' : '(新启动)');
  }
  process.exit(result.ok ? 0 : 1);
})();
