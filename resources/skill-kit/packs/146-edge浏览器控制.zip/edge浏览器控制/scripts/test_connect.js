#!/usr/bin/env node
const { ensureBrowser, connectBrowser, findPage, CDP_URL } = require('./edge');

(async () => {
  try {
    const ensured = await ensureBrowser();
    if (!ensured.ok) process.exit(1);

    console.log('Connecting to Edge CDP...', CDP_URL);
    const browser = await connectBrowser({ port: ensured.port });
    const page = await findPage(browser);

    await page.waitForTimeout(1000);
    console.log('Current URL:', page.url());
    console.log('Page title:', await page.title());
    console.log('Contexts:', browser.contexts().length);
    console.log('✓ CDP 连接成功');

    await browser.close();
  } catch (e) {
    console.error('Error:', e.message);
    process.exit(1);
  }
})();
