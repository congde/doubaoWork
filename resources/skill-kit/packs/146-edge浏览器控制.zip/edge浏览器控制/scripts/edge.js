/**
 * Microsoft Edge CDP 浏览器管理
 * 优先连接已有 Edge（保留登录态），必要时再以默认用户配置启动
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const { execSync, spawn } = require('child_process');

const EDGE_CANDIDATES = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
];

const CDP_PORT = Number(process.env.EDGE_CDP_PORT) || 9223;
const CDP_URL = `http://127.0.0.1:${CDP_PORT}`;
const CDP_PROBE_PORTS = [
  CDP_PORT,
  9222,
  9223,
  9333,
];

const sleep = ms => new Promise(r => setTimeout(r, ms));

function resolveEdgePath() {
  if (process.env.EDGE_PATH && fs.existsSync(process.env.EDGE_PATH)) {
    return process.env.EDGE_PATH;
  }
  for (const p of EDGE_CANDIDATES) {
    if (fs.existsSync(p)) return p;
  }
  return process.env.EDGE_PATH || EDGE_CANDIDATES[0];
}

function resolveUserDataDir() {
  if (process.env.EDGE_USER_DATA_DIR) {
    return process.env.EDGE_USER_DATA_DIR;
  }
  const localAppData = process.env.LOCALAPPDATA;
  if (localAppData) {
    return path.join(localAppData, 'Microsoft', 'Edge', 'User Data');
  }
  return null;
}

function getPlaywright() {
  try {
    return require('playwright');
  } catch {
    const { createRequire } = require('module');
    const req = createRequire(__filename);
    return req('playwright');
  }
}

function isPortOpen(port) {
  try {
    execSync(
      `powershell -NoProfile -Command "(New-Object Net.Sockets.TcpClient).Connect('127.0.0.1',${port})"`,
      { encoding: 'utf8', timeout: 5000, stdio: 'pipe' }
    );
    return true;
  } catch {
    return false;
  }
}

function isEdgeProcessRunning() {
  try {
    const out = execSync(
      'tasklist /FI "IMAGENAME eq msedge.exe" /NH',
      { encoding: 'utf8', timeout: 5000, stdio: 'pipe' }
    );
    return /msedge\.exe/i.test(out);
  } catch {
    return false;
  }
}

function fetchCdpVersion(port) {
  return new Promise(resolve => {
    const req = http.get(`http://127.0.0.1:${port}/json/version`, res => {
      let body = '';
      res.on('data', chunk => { body += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(body));
        } catch {
          resolve(null);
        }
      });
    });
    req.on('error', () => resolve(null));
    req.setTimeout(3000, () => {
      req.destroy();
      resolve(null);
    });
  });
}

async function findActiveCdpPort(ports = CDP_PROBE_PORTS) {
  const seen = new Set();
  for (const port of ports) {
    if (seen.has(port)) continue;
    seen.add(port);
    if (!isPortOpen(port)) continue;
    const version = await fetchCdpVersion(port);
    if (version?.webSocketDebuggerUrl) {
      return port;
    }
  }
  return null;
}

function buildEdgeLaunchArgs(port, userDataDir) {
  const args = [
    `--remote-debugging-port=${port}`,
    '--no-first-run',
    '--no-default-browser-check',
  ];
  if (userDataDir) {
    args.push(`--user-data-dir=${userDataDir}`);
  }
  return args;
}

async function ensureBrowser(options = {}) {
  const port = options.port ?? CDP_PORT;
  const edgePath = options.edgePath ?? resolveEdgePath();
  const userDataDir = options.userDataDir ?? resolveUserDataDir();
  const probePorts = options.probePorts ?? CDP_PROBE_PORTS;

  const activePort = await findActiveCdpPort(probePorts);
  if (activePort) {
    console.log(`✓ 已检测到运行中的 Edge CDP（端口 ${activePort}），直接复用`);
    return { ok: true, port: activePort, reused: true };
  }

  if (!fs.existsSync(edgePath)) {
    console.error(`✗ 找不到 Edge: ${edgePath}`);
    console.error('  设置环境变量 EDGE_PATH 或安装 Microsoft Edge');
    return { ok: false, port };
  }

  const edgeRunning = isEdgeProcessRunning();
  if (edgeRunning) {
    console.log('Edge 正在运行，但尚未开启 CDP，需要以调试模式重启以保留登录态...');
    try {
      execSync('taskkill /F /IM msedge.exe', { encoding: 'utf8', stdio: 'pipe' });
      await sleep(2000);
    } catch (e) {
      console.error('✗ 无法关闭现有 Edge 进程:', e.message);
      return { ok: false, port };
    }
  } else {
    console.log('Edge 未运行，正在以默认用户配置启动...');
  }

  try {
    const proc = spawn(edgePath, buildEdgeLaunchArgs(port, userDataDir), {
      detached: true,
      stdio: 'ignore',
    });
    proc.unref();
  } catch (e) {
    console.error('✗ Edge 启动失败:', e.message);
    return { ok: false, port };
  }

  const maxWait = options.maxWait ?? 20;
  for (let i = 0; i < maxWait; i++) {
    await sleep(1000);
    const readyPort = await findActiveCdpPort([port]);
    if (readyPort) {
      console.log('✓ CDP 就绪（默认用户配置，登录态已保留）');
      return { ok: true, port: readyPort, reused: false };
    }
    process.stdout.write('.');
  }

  console.error('\n✗ Edge 启动超时');
  return { ok: false, port };
}

async function connectBrowser(options = {}) {
  const probePorts = options.probePorts ?? CDP_PROBE_PORTS;
  const port = options.port ?? (await findActiveCdpPort(probePorts)) ?? CDP_PORT;
  const url = `http://127.0.0.1:${port}`;
  const { chromium } = getPlaywright();
  return chromium.connectOverCDP(url);
}

async function findPage(browser, urlFilter) {
  const contexts = browser.contexts();

  if (urlFilter) {
    for (const ctx of contexts) {
      for (const p of ctx.pages()) {
        try {
          if (p.url().includes(urlFilter)) return p;
        } catch { /* 页面可能已关闭 */ }
      }
    }
  }

  for (const ctx of contexts) {
    const pages = ctx.pages().filter(p => {
      try {
        const u = p.url();
        return u && u !== 'about:blank';
      } catch {
        return false;
      }
    });
    if (pages.length > 0) return pages[0];
  }

  const ctx = contexts[0];
  if (!ctx) {
    throw new Error(
      '未找到已有浏览器上下文。请确认 Edge 以默认用户配置运行，且未使用无痕模式。'
    );
  }

  const pages = ctx.pages();
  return pages.length > 0 ? pages[0] : ctx.newPage();
}

async function openPage(url, options = {}) {
  const ensured = await ensureBrowser(options);
  if (!ensured.ok) {
    throw new Error('Edge 启动失败');
  }
  const browser = await connectBrowser({ ...options, port: ensured.port });
  const page = await findPage(browser, options.urlFilter);
  if (url) await page.goto(url, { waitUntil: 'domcontentloaded', ...options.gotoOptions });
  return page;
}

module.exports = {
  EDGE_CANDIDATES,
  CDP_PORT,
  CDP_URL,
  CDP_PROBE_PORTS,
  resolveEdgePath,
  resolveUserDataDir,
  getPlaywright,
  isPortOpen,
  isEdgeProcessRunning,
  findActiveCdpPort,
  sleep,
  ensureBrowser,
  connectBrowser,
  findPage,
  openPage,
};
