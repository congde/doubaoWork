---
name: web-edge
description: Automates the user's local Microsoft Edge on Windows via CDP. Prefer connecting to an already-running Edge (login state, cookies, tabs) with connectOverCDP; only launch Edge with the default user profile when CDP is unavailable. Use when the user mentions Edge browser, CDP, or Windows Edge automation.
---

# Web Edge

在 Windows 上通过 **CDP** 操控本机 **Microsoft Edge**。

**首要原则：优先复用用户正在使用的 Edge**，读取已有登录态、Cookie 和标签页；不要新建隔离上下文。

## Skill 位置

本 skill 为独立模块，推荐安装到全局 skills 目录：

```
~/.agents/skills/web-edge/
├── SKILL.md
├── reference.md
├── package.json
└── scripts/
    ├── edge.js
    ├── ensure.js
    ├── open.js
    └── test_connect.js
```

首次使用，在 skill 根目录安装依赖：

```bash
cd ~/.agents/skills/web-edge
npm install
```

提交到技能市场时，只打包 skill 本体（`SKILL.md`、`reference.md`、`package.json`、`scripts/*.js`）。不要包含 `node_modules/` 或 `package-lock.json`（里面的 `sha512-...` 会被扫描器当成密钥）。在本目录执行 `npm run pack` 生成 `web-edge.zip`。

## 核心原则

| 优先级 | 做法 | 说明 |
|:---:|:---|:---|
| 1 | 连接已有 Edge CDP | 探测端口后 `connectOverCDP` |
| 2 | 复用已有标签 / 上下文 | `findPage` 优先匹配 URL 或已有页面，不 `newContext()` |
| 3 | 必要时才启动 Edge | 使用默认用户配置目录，保留登录态 |

## 快速命令

在 skill 根目录执行：

```bash
npm run ensure    # 检测/连接已有 Edge，必要时以默认配置启动
npm run test      # 测试 CDP 连接并读取当前页面
npm run open -- https://example.com   # 在已有 Edge 中打开 URL
```

## 在脚本中引用

```javascript
const path = require('path');
const skillRoot = path.join(process.env.USERPROFILE, '.agents', 'skills', 'web-edge');
const { ensureBrowser, connectBrowser, findPage, openPage } = require(path.join(skillRoot, 'scripts', 'edge'));

(async () => {
  const page = await openPage('https://example.com');
  console.log(await page.title());
  await page.context().browser().close();
})();
```

在 skill 目录下写脚本时也可：

```javascript
const { ensureBrowser, connectBrowser, findPage } = require('./scripts/edge');
```

## Agent 工作流

1. 确认 Windows + Edge 已安装
2. 在 skill 目录执行 `npm install`（若未安装过）
3. **先** `connectBrowser()` 或探测 CDP——若 Edge 已开启调试，直接连接
4. 连接失败再 `ensureBrowser()`：仅在 Edge 未运行或 CDP 未开启时，以**默认用户配置**启动
5. `findPage(browser, urlFilter?)` 复用已有标签；需要新页面时在**已有上下文**中 `newPage()`
6. 完成后 `browser.close()` — 仅断开 CDP，Edge 窗口保持打开

### 推荐：让 Edge 常驻开启 CDP

为 Edge 快捷方式追加参数，每次打开即带 CDP：

```
--remote-debugging-port=9223
```

登录态、扩展、书签与日常使用的 Edge 一致。

## 配置

| 环境变量 | 默认 | 说明 |
|:---|:---|:---|
| `EDGE_PATH` | 自动检测 | Edge 可执行文件 |
| `EDGE_CDP_PORT` | `9223` | 首选 CDP 端口 |
| `EDGE_USER_DATA_DIR` | `%LOCALAPPDATA%\Microsoft\Edge\User Data` | 默认用户配置目录 |

自动检测路径（按顺序）：
- `C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`
- `C:\Program Files\Microsoft\Edge\Application\msedge.exe`

## 生命周期

| 场景 | 处理 |
|:---|:---|
| CDP 端口已开放 | **直接连接**，复用已有窗口与登录态 |
| Edge 已运行但无 CDP | 关闭后以默认配置 + `--remote-debugging-port` 重启（保留 Cookie） |
| Edge 未运行 | 以默认用户配置启动 |

## 故障排查

- **找不到 Edge**：`where msedge` 或设置 `EDGE_PATH`
- **CDP 失败**：`Test-NetConnection 127.0.0.1 -Port 9223`
- **连上但无登录态**：确认未调用 `newContext()`，应使用已有 Edge 默认上下文
- **缺少依赖**：在 skill 根目录 `npm install`

## 参考

详见 [reference.md](reference.md)
