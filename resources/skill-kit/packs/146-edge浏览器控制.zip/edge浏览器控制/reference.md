# Web Edge — 参考

## 架构

```
Node 脚本
  ├─ 1. 探测本机 Edge CDP（9223 / 9222 / …）
  ├─ 2. connectOverCDP → 复用已有 context / page
  └─ 3. 仅在无 CDP 时 spawn(msedge.exe, --remote-debugging-port, --user-data-dir=默认配置)
```

## 正确连接方式

```javascript
// ✅ 连接本机正在使用的 Edge
await chromium.connectOverCDP('http://127.0.0.1:9223');
const page = browser.contexts()[0].pages()[0]; // 复用已有标签

// ❌ 不要新建隔离上下文（会丢失已有 Cookie）
const ctx = await browser.newContext();
```

## 为何优先连接已有 Edge

- 默认用户配置中有登录 Cookie、扩展、本地存储
- 已有标签页可直接读取或继续操作
- 与日常使用的 Edge 是同一实例

## 端口探测

连接前会依次探测：

| 端口 | 说明 |
|:---|:---|
| `EDGE_CDP_PORT`（默认 9223） | skill 首选 / 默认启动端口 |
| 9222 | 常见 CDP 备用端口 |
| 9333 | 备用端口 |

任一端口返回 `/json/version` 即视为可用。

## browser.close()

`connectOverCDP` 下调用 `browser.close()` 只断开自动化会话，**不关闭 Edge 窗口**。

## API 一览

| 函数 | 作用 |
|:---|:---|
| `resolveEdgePath()` | 解析 Edge 可执行文件路径 |
| `resolveUserDataDir()` | 解析默认用户配置目录 |
| `findActiveCdpPort(ports?)` | 探测已开放的 CDP 端口 |
| `isEdgeProcessRunning()` | 检测 msedge.exe 是否在运行 |
| `ensureBrowser(options?)` | 优先连接已有 CDP；必要时以默认配置启动 Edge |
| `connectBrowser(options?)` | 连接并返回 Browser |
| `findPage(browser, urlFilter?)` | 在已有上下文中查找或创建 Page |
| `openPage(url, options?)` | 连接本机 Edge + 打开 URL |

`ensureBrowser()` 返回 `{ ok, port, reused }`：
- `reused: true` — 直接连上已在运行的 Edge
- `reused: false` — 新启动了带 CDP 的 Edge（仍使用默认用户配置）
