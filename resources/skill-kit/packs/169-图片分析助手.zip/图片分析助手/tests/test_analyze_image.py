"""analyze_image 技能脚本的单元测试（标准库 unittest，无第三方依赖）。"""

import contextlib
import io
import json
import sys
import tempfile
import unittest
import unittest.mock
import urllib.error
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import analyze_image as ai

PNG_1PX = (
    b"\x89PNG\r\n\x1a\n"
    + b"\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89"
    + b"\x00\x00\x00\x0aIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\x0d\x0a\x2d\xb4"
    + b"\x00\x00\x00\x00IEND\xaeB\x60\x82"
)


class FakeResponse:
    def __init__(self, body, status=200):
        self.body = body
        self.status = status

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self):
        return json.dumps(self.body).encode("utf-8")


def ok_opener(request, timeout=120):
    return FakeResponse({"choices": [{"message": {"content": "这是一只猫"}}]})


def http_error_opener(request, timeout=120):
    raise urllib.error.HTTPError(request.full_url, 500, "error", {}, io.BytesIO(b"boom"))


def url_error_opener(request, timeout=120):
    raise urllib.error.URLError("connection refused")


def make_config():
    return {"base_url": "http://x", "api_key": "k", "model": "m", "max_tokens": 64}


class AnalyzeImageTest(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.img = Path(self._tmp.name) / "test.png"
        self.img.write_bytes(PNG_1PX)

    def test_detect_mime_supported(self):
        self.assertEqual(ai.detect_mime("a.png"), "image/png")
        self.assertEqual(ai.detect_mime("a.JPG"), "image/jpeg")
        self.assertEqual(ai.detect_mime("a.webp"), "image/webp")

    def test_detect_mime_unsupported(self):
        with self.assertRaises(ai.ImageError):
            ai.detect_mime("a.txt")

    def test_build_payload_structure(self):
        payload = ai.build_payload({"model": "m", "max_tokens": 64}, str(self.img), "这是什么")
        self.assertEqual(payload["model"], "m")
        self.assertEqual(payload["max_tokens"], 64)
        content = payload["messages"][0]["content"]
        self.assertEqual(content[0], {"type": "text", "text": "这是什么"})
        self.assertEqual(content[1]["type"], "image_url")
        self.assertTrue(content[1]["image_url"]["url"].startswith("data:image/png;base64,"))

    def test_extract_answer_text(self):
        self.assertEqual(ai.extract_answer({"choices": [{"message": {"content": "答案"}}]}), "答案")

    def test_extract_answer_list(self):
        body = {"choices": [{"message": {"content": [{"type": "text", "text": "a"}, {"type": "text", "text": "b"}]}}]}
        self.assertEqual(ai.extract_answer(body), "ab")

    def test_extract_answer_missing_choices(self):
        with self.assertRaises(ai.ApiError):
            ai.extract_answer({"foo": 1})

    def test_extract_answer_empty(self):
        with self.assertRaises(ai.ApiError):
            ai.extract_answer({"choices": [{"message": {"content": "   "}}]})

    def test_analyze_image_success(self):
        self.assertEqual(ai.analyze_image(str(self.img), config=make_config(), opener=ok_opener), "这是一只猫")

    def test_analyze_image_http_error(self):
        with self.assertRaisesRegex(ai.ApiError, "HTTP 500"):
            ai.analyze_image(str(self.img), config=make_config(), opener=http_error_opener)

    def test_analyze_image_url_error(self):
        with self.assertRaisesRegex(ai.ApiError, "无法连接接口"):
            ai.analyze_image(str(self.img), config=make_config(), opener=url_error_opener)

    def test_ensure_utf8_stdio_reconfigures_textiowrapper(self):
        path = Path(self._tmp.name) / "stream.txt"
        with path.open("w", encoding="gbk", errors="replace") as stream:
            ai.ensure_utf8_stdio(stream)
            self.assertEqual(stream.encoding, "utf-8")

    def test_ensure_utf8_stdio_noop_on_stringio(self):
        stream = io.StringIO()
        ai.ensure_utf8_stdio(stream)  # 不应抛异常
        stream.write("ok")
        self.assertEqual(stream.getvalue(), "ok")

    def test_main_output_file_writes_utf8(self):
        out = Path(self._tmp.name) / "result.txt"
        with unittest.mock.patch.object(ai, "urlopen", ok_opener):
            rc = ai.main([str(self.img), "--output-file", str(out)], config=make_config())
        self.assertEqual(rc, 0)
        self.assertEqual(out.read_text(encoding="utf-8"), "这是一只猫")

    def test_main_output_file_json(self):
        out = Path(self._tmp.name) / "result.json"
        with unittest.mock.patch.object(ai, "urlopen", ok_opener):
            rc = ai.main([str(self.img), "--json", "--output-file", str(out)], config=make_config())
        self.assertEqual(rc, 0)
        data = json.loads(out.read_text(encoding="utf-8"))
        self.assertTrue(data["ok"])
        self.assertEqual(data["answer"], "这是一只猫")

    def test_main_prints_answer_to_stdout(self):
        captured = io.StringIO()
        with unittest.mock.patch.object(ai, "urlopen", ok_opener), contextlib.redirect_stdout(captured):
            rc = ai.main([str(self.img)], config=make_config())
        self.assertEqual(rc, 0)
        self.assertEqual(captured.getvalue().strip(), "这是一只猫")


if __name__ == "__main__":
    unittest.main()

