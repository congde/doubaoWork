"""调用本地 MiniMax-M3 识图接口并返回分析文本。"""

import argparse
import base64
import json
import os
import sys
import urllib.error
import urllib.request
from urllib.request import urlopen
from pathlib import Path

DEFAULT_BASE_URL = "http://<your-minimax-host>:<port>"
DEFAULT_MODEL = "MiniMax-M3"
DEFAULT_MAX_TOKENS = 1024
DEFAULT_QUESTION = "请详细描述这张图片的内容。"

MIME_BY_SUFFIX = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".gif": "image/gif",
    ".bmp": "image/bmp",
}


class ConfigError(RuntimeError):
    pass


class ImageError(RuntimeError):
    pass


class ApiError(RuntimeError):
    pass


def ensure_utf8_stdio(stream=None):
    """把标准输出/错误流的编码固定为 UTF-8。

    中文 Windows 下 Python 默认用 GBK 输出，被按 UTF-8 读取的调用方
    （管道、终端、日志采集）读取时会产生乱码；这里统一改为 UTF-8。
    对不支持 reconfigure 的流（如 io.StringIO）静默跳过。
    """
    targets = [stream] if stream is not None else (sys.stdout, sys.stderr)
    for target in targets:
        reconfigure = getattr(target, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            reconfigure(encoding="utf-8", errors="replace")
        except (ValueError, OSError):
            pass


def load_config(env=None, config_dir=None, require_api_key=True):
    env = env if env is not None else os.environ
    config_dir = Path(config_dir) if config_dir is not None else Path(__file__).resolve().parents[1]

    config = {
        "base_url": DEFAULT_BASE_URL,
        "model": DEFAULT_MODEL,
        "max_tokens": DEFAULT_MAX_TOKENS,
        "api_key": "",
    }

    for filename in ("config.local.json", "config.json"):
        path = config_dir / filename
        if path.is_file():
            with path.open(encoding="utf-8") as fh:
                file_config = json.load(fh)
            config.update({k: v for k, v in file_config.items() if v not in (None, "")})
            break

    env_mapping = {
        "MINIMAX_BASE_URL": "base_url",
        "MINIMAX_MODEL": "model",
        "MINIMAX_API_KEY": "api_key",
        "MINIMAX_MAX_TOKENS": "max_tokens",
    }
    for env_key, config_key in env_mapping.items():
        value = env.get(env_key)
        if value not in (None, ""):
            if config_key == "max_tokens":
                config[config_key] = int(value)
            else:
                config[config_key] = value

    if require_api_key and not config["api_key"]:
        raise ConfigError("未找到 MiniMax API Key：请设置 MINIMAX_API_KEY 环境变量，或创建 config.local.json")
    return config


def detect_mime(path):
    suffix = Path(path).suffix.lower()
    try:
        return MIME_BY_SUFFIX[suffix]
    except KeyError:
        raise ImageError(f"不支持的图片格式：{suffix or '无扩展名'}")


def build_payload(config, image_path, question):
    mime = detect_mime(image_path)
    encoded = base64.b64encode(Path(image_path).read_bytes()).decode("ascii")
    question = question or DEFAULT_QUESTION
    return {
        "model": config["model"],
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": question},
                    {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{encoded}"}},
                ],
            }
        ],
        "max_tokens": int(config.get("max_tokens", DEFAULT_MAX_TOKENS)),
    }


def extract_answer(response):
    choices = response.get("choices") or []
    if not choices:
        raise ApiError("接口返回中缺少 choices 字段")
    content = choices[0].get("message", {}).get("content", "")
    if isinstance(content, list):
        content = "".join(part.get("text", "") for part in content if part.get("type") == "text")
    if not isinstance(content, str) or not content.strip():
        raise ApiError("接口返回内容为空")
    return content.strip()


def analyze_image(image_path, question=None, config=None, opener=None):
    image_path = Path(image_path)
    if not image_path.is_file():
        raise ImageError(f"图片文件不存在：{image_path}")

    config = config if config is not None else load_config()
    payload = build_payload(config, image_path, question)
    endpoint = f"{config['base_url'].rstrip('/')}/v1/chat/completions"
    request = urllib.request.Request(
        endpoint,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {config['api_key']}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    opener = opener if opener is not None else urlopen
    try:
        with opener(request, timeout=120) as response:
            status = getattr(response, "status", 200)
            body = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:500]
        raise ApiError(f"接口 HTTP {exc.code} 错误：{detail}")
    except urllib.error.URLError as exc:
        raise ApiError(f"无法连接接口 {endpoint}：{exc.reason}")

    if status != 200:
        raise ApiError(f"接口返回状态 {status}：{json.dumps(body, ensure_ascii=False)[:500]}")
    return extract_answer(body)


def main(argv=None, config=None):
    ensure_utf8_stdio()
    parser = argparse.ArgumentParser(prog="analyze_image", description="调用 MiniMax-M3 识图")
    parser.add_argument("image", help="图片文件路径")
    parser.add_argument("question", nargs="?", default=None, help="针对图片的问题，缺省时让模型描述图片")
    parser.add_argument("--json", action="store_true", help="以 JSON 形式输出结果")
    parser.add_argument("--output-file", default=None, help="把结果写入 UTF-8 文件（替代标准输出，规避终端/管道编码问题）")
    parser.add_argument("--config-dir", default=None, help="配置文件所在目录，默认取脚本上级目录")
    args = parser.parse_args(argv)

    try:
        config = config if config is not None else load_config(config_dir=args.config_dir)
        answer = analyze_image(args.image, args.question, config=config)
    except (ConfigError, ImageError, ApiError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 1

    if args.json:
        output_text = json.dumps({"ok": True, "answer": answer, "model": config["model"]}, ensure_ascii=False)
    else:
        output_text = answer
    if args.output_file:
        Path(args.output_file).write_text(output_text, encoding="utf-8")
    else:
        print(output_text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
