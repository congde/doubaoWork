---
name: image-analyze
description: 当用户发送图片、粘贴图片路径、或要求读取/识别/描述/分析图片内容时使用。当前会话模型为纯文本模型，无法直接看到图片，必须调用本技能自带脚本，把图片交给 MiniMax-M3 识图分析，再把结果返回给用户。不要回复"我看不到图片"或拒绝分析。
---

# 图片分析（MiniMax-M3）

## 使用步骤

1. 从用户消息中定位图片文件的绝对路径（可能是 Markdown 图片链接、附件路径或用户给出的路径）。
2. 运行识别脚本：

```powershell
python scripts/analyze_image.py "<图片路径>" "<针对图片的问题>"
```

3. 脚本直接输出 MiniMax-M3 的分析文本；把该文本作为识图结果整理进回复。

缺省问题不传即可，脚本默认让模型"详细描述这张图片的内容"。

## 输出编码

- 脚本已强制 stdout/stderr 使用 UTF-8 输出，正常情况下不会出现乱码。
- 若个别终端/管道环境下仍出现乱码，用 `--output-file` 把结果写入 UTF-8 文件再读取：

```powershell
python scripts/analyze_image.py "<图片路径>" --output-file "result.txt"
Get-Content -Encoding UTF8 "result.txt"
```

- `--json` 可与 `--output-file` 组合使用，输出结构化 JSON。

## 配置

配置读取优先级：环境变量 > `config.local.json` > `config.json`。

- `MINIMAX_BASE_URL`：接口地址，默认 `http://<your-minimax-host>:<port>`
- `MINIMAX_MODEL`：模型名，默认 `MiniMax-M3`
- `MINIMAX_API_KEY`：API Key

真实 Key 放在技能目录的 `config.local.json`，该文件已被 `.gitignore` 忽略。

## 失败处理

- 图片路径找不到时，提示用户提供正确的本地图片路径。
- 接口报错时，把脚本 stderr 中的错误信息转述给用户，不要假装成功。
- 连接失败出现 `WinError 10013`（访问套接字的权限被拒）时，通常是 Codex 沙箱拦截了对局域网接口的访问：请以 `python <脚本绝对路径> analyze_image.py ...` 的原样命令形式运行（命中已批准 prefix rule 时会放行），或在沙箱外/申请提升权限后重试。
- 其他输出（例如 `--json`）可用于需要结构化结果的场景。

## 测试

- 单元测试（标准库，无第三方依赖）：`python -m unittest discover -s tests -v`
- 覆盖：MIME 识别、payload 构造、答案解析、错误分支、UTF-8 输出、`--output-file`。
