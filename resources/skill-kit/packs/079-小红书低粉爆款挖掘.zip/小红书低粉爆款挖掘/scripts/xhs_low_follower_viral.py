#!/usr/bin/env python3
"""Collect Xiaohongshu search notes for low-follower viral analysis."""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

BASE_URL = "https://api.tikhub.io"
CONFIG_PATH = Path(__file__).resolve().parents[1] / "config" / "tikhub.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="采集小红书关键词笔记并筛选低粉高互动候选")
    parser.add_argument("--keyword", required=True, help="搜索关键词")
    parser.add_argument("--pages", type=int, default=1, help="搜索页数，默认 1")
    parser.add_argument("--sort", default="popularity_descending", help="general/time_descending/popularity_descending/comment_descending/collect_descending")
    parser.add_argument("--note-type", default="不限", help="不限/视频笔记/普通笔记/直播笔记")
    parser.add_argument("--time-filter", default="不限", help="不限/一天内/一周内/半年内")
    parser.add_argument("--max-followers", type=int, default=10000, help="低粉阈值")
    parser.add_argument("--detail-limit", type=int, default=20, help="最多补充详情的笔记数")
    parser.add_argument("--out", default="", help="保存 JSON 路径")
    return parser.parse_args()


def request_json(path: str, params: dict[str, Any], token: str) -> dict[str, Any]:
    url = BASE_URL + path + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0",
        },
    )
    with urllib.request.urlopen(req, timeout=45) as resp:
        return json.loads(resp.read().decode("utf-8", errors="replace"))


def load_api_key() -> str:
    token = os.environ.get("TIKHUB_API_KEY", "").strip()
    if token:
        return token
    if not CONFIG_PATH.exists():
        return ""
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ""
    value = str(data.get("api_key", "")).strip()
    if not value or "填在这里" in value or value.startswith("把你的"):
        return ""
    return value


def walk_values(obj: Any):
    if isinstance(obj, dict):
        yield obj
        for value in obj.values():
            yield from walk_values(value)
    elif isinstance(obj, list):
        for item in obj:
            yield from walk_values(item)


def first_value(obj: dict[str, Any], keys: list[str], default: Any = "") -> Any:
    for key in keys:
        if key in obj and obj[key] not in (None, ""):
            return obj[key]
    return default


def to_int(value: Any) -> int:
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        text = value.strip().replace(",", "")
        multiplier = 1
        if text.endswith(("万", "w", "W")):
            multiplier = 10000
            text = text[:-1]
        try:
            return int(float(text) * multiplier)
        except ValueError:
            return 0
    return 0


def extract_note_candidates(payload: dict[str, Any]) -> list[dict[str, Any]]:
    notes: dict[str, dict[str, Any]] = {}
    for item in walk_values(payload):
        note_id = first_value(item, ["note_id", "noteId", "id"])
        title = first_value(item, ["title", "display_title", "displayTitle", "desc", "description"])
        if not note_id or not title:
            continue
        user_obj = first_value(item, ["user", "author", "user_info", "userInfo"], {})
        interact = first_value(item, ["interact_info", "interactInfo", "interaction"], {})
        if not isinstance(user_obj, dict):
            user_obj = {}
        if not isinstance(interact, dict):
            interact = {}
        notes[str(note_id)] = {
            "note_id": str(note_id),
            "title": str(title),
            "type": first_value(item, ["type", "note_type", "noteType"]),
            "url": first_value(item, ["url", "webUrl", "web_url", "share_link", "shareLink"]),
            "user_id": first_value(user_obj, ["user_id", "userId", "userid", "id"]),
            "nickname": first_value(user_obj, ["nickname", "nick_name", "name"]),
            "liked_count": to_int(first_value(item, ["liked_count", "likedCount", "like_count", "likeCount"], first_value(interact, ["liked_count", "likedCount", "like_count", "likeCount"]))),
            "collected_count": to_int(first_value(item, ["collected_count", "collectedCount", "collect_count", "collectCount"], first_value(interact, ["collected_count", "collectedCount", "collect_count", "collectCount"]))),
            "comment_count": to_int(first_value(item, ["comments_count", "comment_count", "commentCount"], first_value(interact, ["comment_count", "commentCount"]))),
            "share_count": to_int(first_value(item, ["shared_count", "share_count", "shareCount"], first_value(interact, ["share_count", "shareCount"]))),
            "desc": str(first_value(item, ["desc", "description"], ""))[:160],
            "publish_hint": first_value(item, ["timestamp", "last_update_time", "update_time"], ""),
        }
    return list(notes.values())


def enrich_user(note: dict[str, Any], token: str) -> None:
    user_id = note.get("user_id")
    if not user_id:
        return
    try:
        payload = request_json("/api/v1/xiaohongshu/app_v2/get_user_info", {"user_id": user_id}, token)
    except Exception as exc:  # noqa: BLE001
        note["user_warning"] = str(exc)
        return
    best = {}
    fallback = {}
    for item in walk_values(payload):
        item_user_id = str(first_value(item, ["user_id", "userId", "userid", "id"]))
        item_fans = first_value(item, ["fans", "fans_count", "follower_count", "followers", "fansCount"])
        if item_user_id == str(user_id) and item_fans:
            best = item
            break
        if item_user_id == str(user_id):
            fallback = item
        elif item_fans and not fallback:
            fallback = item
    if not best:
        best = fallback or (payload.get("data", {}) if isinstance(payload.get("data"), dict) else {})
    fans_value = first_value(best, ["fans", "fans_count", "follower_count", "followers", "fansCount"], None)
    if fans_value is not None:
        note["followers"] = to_int(fans_value)


def score_note(note: dict[str, Any]) -> None:
    followers = to_int(note.get("followers"))
    liked = to_int(note.get("liked_count"))
    collected = to_int(note.get("collected_count"))
    comments = to_int(note.get("comment_count"))
    note["like_follower_ratio"] = round(liked / followers, 4) if followers else None
    note["collect_follower_ratio"] = round(collected / followers, 4) if followers else None
    note["comment_like_ratio"] = round(comments / liked, 4) if liked else None
    note["collect_like_ratio"] = round(collected / liked, 4) if liked else None


def main() -> int:
    args = parse_args()
    token = load_api_key()
    result: dict[str, Any] = {
        "status": "missing_api_key" if not token else "ok",
        "query": vars(args),
        "notes": [],
        "warnings": [],
    }
    if not token:
        result["warnings"].append("未检测到 TikHub 密钥，无法自动检索。请把密钥填到本技能目录的 config/tikhub.json 里的 api_key 字段，或设置环境变量 TIKHUB_API_KEY；暂时没有密钥时，可以粘贴搜索结果、互动数据和作者粉丝数后继续分析。")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    try:
        all_notes: dict[str, dict[str, Any]] = {}
        for page in range(1, max(args.pages, 1) + 1):
            payload = request_json(
                "/api/v1/xiaohongshu/app_v2/search_notes",
                {
                    "keyword": args.keyword,
                    "page": page,
                    "sort_type": args.sort,
                    "note_type": args.note_type,
                    "time_filter": args.time_filter,
                    "source": "explore_feed",
                    "ai_mode": 0,
                },
                token,
            )
            for note in extract_note_candidates(payload):
                all_notes[note["note_id"]] = note
            time.sleep(0.2)
        notes = list(all_notes.values())
        for note in notes[: args.detail_limit]:
            enrich_user(note, token)
            score_note(note)
        result["notes"] = sorted(
            notes,
            key=lambda n: (
                to_int(n.get("followers")) <= args.max_followers if n.get("followers") else False,
                n.get("like_follower_ratio") or 0,
                to_int(n.get("liked_count")),
            ),
            reverse=True,
        )
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
        result["status"] = "failed"
        result["warnings"].append(str(exc))

    if args.out:
        Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] in {"ok", "missing_api_key"} else 1


if __name__ == "__main__":
    sys.exit(main())
