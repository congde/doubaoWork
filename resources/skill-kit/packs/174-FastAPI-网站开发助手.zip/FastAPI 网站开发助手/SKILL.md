---
name: fastapi-admin-system-guide
description: Python FastAPI 全栈管理系统开发向导，用于从零构建完整的 FastAPI + SQLAlchemy + MySQL + Vue 3 前后端分离管理系统，包含管理员端、用户端、数据库脚本、依赖安装、命令行启动、上传资源、界面优化和功能验证。当用户提出开发管理系统、后台管理系统、管理后台、前后端分离项目、FastAPI 项目、Python 后端项目、Vue 项目，或说“帮我开发一个XX管理系统”“做一个后台管理系统”“写管理后台”“用 Python/FastAPI 做管理系统”时使用此技能。
---

# FastAPI 管理系统开发向导

## 角色定位

作为全栈开发工程师，负责把管理系统从需求到可运行项目完整落地：信息收集、需求分析、功能设计、文件创建、代码生成、依赖安装、命令行启动、错误排查、界面优化和功能验证。用户只需要回答少量产品问题，并在浏览器里确认最终效果。

默认技术栈如下，除非用户明确要求调整：

- 后端：Python 3.11+、FastAPI、Uvicorn、SQLAlchemy 2.x、PyMySQL、Pydantic、python-jose、passlib[bcrypt]、python-multipart、python-dotenv
- 数据库：MySQL 5.7 或兼容版本，默认数据库密码 `123456`
- 前端：Vue 3、Vite、Element Plus、Pinia、Vue Router、Axios、ECharts
- 认证：JWT Bearer Token
- 上传：本地 `backend/uploads` 目录，通过 `/uploads/**` 静态资源访问

## 核心原则

- 主动完成开发工作。能直接创建文件、生成代码、安装依赖、运行检查、修复 bug 的，不把操作推给用户。
- 不向用户输出“让用户自己复制给其他 AI 的提示词”，也不让用户承担通用实现工作。
- 遇到报错时，优先读取相关代码、配置和日志，能修复就直接修复；只有缺少外部信息时才请用户补充。
- 在每个关键阶段向用户简短说明进度。
- 所有文件和回复中的 `PROJECT_PATH`、`SYSTEM_NAME`、`DB_NAME`、`PACKAGE_NAME`、`USER_ROLES` 都必须替换成真实值。
- `USER_ROLES` 必须来自用户明确回答或确认，不得根据系统类型、常见项目模板、历史上下文或默认习惯自行推导。若用户没有明确给出角色，必须先询问并等待回答。
- `需求分析.md` 生成后必须展示给用户确认，并在用户明确确认后才能生成功能设计。
- `功能设计.md` 生成后必须展示给用户确认，并在用户明确确认后才能生成代码。
- 遵循 Codex 编辑方式：手动改文件优先使用 `apply_patch`，检查和构建使用 shell，前端效果尽量用浏览器验证。

## 工作流程

### 1. 信息收集

触发技能后，先一次性询问：

```text
我来帮你开发这个 FastAPI 管理系统，你只需要回答几个问题，其他的我来搞定。

1. 你的系统叫什么？（例如：图书商城系统、学生管理系统、商品管理系统）
2. 系统涉及哪些用户角色？（例如：管理员、普通用户、会员、商家）
3. 项目要创建在哪个目录下？请告诉我完整路径（例如：D:\projects\bookstore）
```

收到用户回答后，提取以下变量：

- `SYSTEM_NAME`：系统名称，例如“图书商城系统”。
- `USER_ROLES`：用户角色，例如“管理员、普通用户”。必须由用户明确给出或确认；如果缺失、含糊或只是由系统名称间接暗示，先追问“系统涉及哪些用户角色？”并等待回答。
- `PROJECT_PATH`：项目根目录的绝对路径。
- `DB_NAME`：数据库名，使用英文小写，例如 `bookstore`。
- `PACKAGE_NAME`：Python 包名片段，使用英文小写，例如 `bookstore`。

然后回复：`好，信息收集完成，我开始帮你构建 FastAPI 管理系统，稍等一会儿。`

### 2. 生成需求分析

在 `PROJECT_PATH` 下创建 `需求分析.md`。

内容要求：

- 根据 `SYSTEM_NAME` 和 `USER_ROLES` 合理规划 6-8 个业务功能模块。
- 每个模块包含 3-5 个具体功能，每个功能用一句话说明。
- 只写业务功能，不写技术实现细节。
- 一级标题为系统名称，二级标题为模块名称，三级标题为具体功能。

写完后，把生成的需求分析内容展示给用户，并询问：

```text
需求分析已生成，以上是为你规划的 6-8 个功能模块，请确认：

1. 模块和功能是否符合你的预期？
2. 有没有需要增加、删除或调整的功能？

确认没问题后我开始生成功能设计。
```

等待用户明确确认或提出修改意见。若用户提出调整，先更新 `需求分析.md`，再次展示并等待确认；确认后再进入生成功能设计阶段。

### 3. 生成功能设计

在 `PROJECT_PATH` 下创建 `功能设计.md`。

内容必须包括：

- 数据库设计：每个模块的表结构使用 Markdown 表格展示，列出字段、类型、大小、说明；不要使用 `TINYINT`，状态和标记字段使用 `INT`。
- API 接口设计：每个模块列出接口端点、请求方法和功能描述；接口统一以 `/api` 开头。
- 后端功能说明：说明每个模块的 FastAPI 路由、服务逻辑、SQLAlchemy 模型和 Pydantic Schema。
- 前端功能说明：按管理端和用户端分别说明页面与交互；必须明确非管理员用户端不使用左侧菜单栏布局。

写完后，把生成的功能设计内容展示给用户，并询问：

```text
功能设计已生成，以上是系统的数据表、接口和前后端功能设计，请确认：

1. 数据表和字段是否符合你的业务预期？
2. 接口和页面功能是否需要增加、删除或调整？

确认没问题后我开始生成代码，这一步时间较长，请耐心等待。
```

等待用户明确确认或提出修改意见。若用户提出调整，先更新 `功能设计.md`，再次展示并等待确认；确认后再进入代码生成阶段。

### 4. 生成完整项目代码

在 `PROJECT_PATH` 下创建完整项目：

```text
PROJECT_PATH/
├── backend/
│   ├── requirements.txt
│   ├── .env.example
│   ├── uploads/
│   └── app/
│       ├── __init__.py
│       ├── main.py
│       ├── core/
│       │   ├── config.py
│       │   ├── database.py
│       │   ├── security.py
│       │   └── deps.py
│       ├── models/
│       ├── schemas/
│       ├── routers/
│       ├── services/
│       └── utils/
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   └── src/
│       ├── main.js
│       ├── App.vue
│       ├── api/
│       ├── router/index.js
│       ├── stores/user.js
│       ├── utils/request.js
│       ├── layouts/
│       └── views/
└── DB_NAME.sql
```

后端要求：

- `requirements.txt` 使用明确依赖，至少包含 `fastapi`、`uvicorn[standard]`、`sqlalchemy`、`pymysql`、`pydantic`、`python-jose[cryptography]`、`passlib[bcrypt]`、`python-multipart`、`python-dotenv`。
- `app/main.py` 创建 FastAPI 应用，启用 CORS，注册所有路由，并挂载 `/uploads` 静态资源到 `backend/uploads`。
- `app/core/config.py` 从环境变量读取数据库、JWT、上传目录等配置，并提供合理默认值。
- `app/core/database.py` 创建 SQLAlchemy engine、SessionLocal 和 Base。
- `app/core/security.py` 提供密码 hash、密码校验、JWT 创建和解析。
- `app/core/deps.py` 提供数据库会话依赖、当前用户依赖、管理员权限依赖。
- SQLAlchemy 模型集中在 `models/`，Pydantic 请求和响应模型集中在 `schemas/`，路由集中在 `routers/`，业务逻辑集中在 `services/`。
- API 响应统一为 `{ "code": 200, "msg": "success", "data": ... }`；错误响应保持结构清晰。
- 登录接口返回 token、用户信息和角色信息；注册接口必须对密码进行 bcrypt hash。
- 必须创建上传接口 `POST /api/upload`，接收 `UploadFile`，保存到 `backend/uploads`，返回可直接访问的相对路径 `/uploads/文件名`。
- 系统中涉及业务图片、头像、封面、附件预览图等字段时，必须使用本地上传路径 `/uploads/...`，不得默认使用公网图片 URL 作为测试数据或前端展示数据。
- 业务分页接口必须支持页码、每页数量和关键字查询，返回总数、列表、页码和每页数量。

前端要求：

- `vite.config.js` 配置开发端口 `3000`，代理 `/api` 到 `http://localhost:8000`，代理 `/uploads` 到 `http://localhost:8000`。
- `request.js` 封装 Axios，自动携带 token，并在收到 `401` 时跳转登录页。
- 路由需要守卫，未登录访问受保护页面时跳转 `/login`。
- 管理端和用户端使用独立 Layout。
- 非管理员角色（普通用户、会员、客户、学生等）不得使用左侧菜单栏、后台侧边栏或管理后台式侧栏布局；必须使用顶部导航、底部导航、标签栏或内容型导航。个人中心、消息、通知、修改密码、退出登录等入口优先收纳到右上角头像/用户菜单中。
- 涉及图片或附件字段的新增/编辑页面必须提供上传控件，上传到 `/api/upload`，保存接口返回的 `/uploads/文件名` 到对应业务字段；前端展示时直接使用该本地路径。
- 登录页和注册页必须使用本地全屏背景图，背景图保存到 `backend/uploads`，例如 `/uploads/auth-bg.jpg`；表单卡片居中显示且尺寸舒展，不得使用公网背景图。
- 登录页不得默认填充 `admin / 123456`，也不得在页面内展示演示账号提示；管理员账号只可写在文档、启动说明或最终回复里。
- 管理端数据看板必须使用 ECharts 展示系统核心指标，至少包含统计卡片、主要业务排行/趋势图、状态分布环图/饼图、关键金额或数量对比图，并做好窗口 resize 处理；指标必须贴合当前系统领域。
- 页面使用 Element Plus 组件，配色简洁专业，避免紫色渐变；管理端字号、表格、菜单、弹窗和分页器必须清晰可读。
- 管理端列表页、审核页、看板页等首屏页面必须在首次进入时自动拉取数据；路由切换复用同一组件时，也必须重新初始化并刷新数据。
- “刷新”按钮只能作为补充操作，不能代替页面首屏加载。新增、编辑、删除、审核、切换分页、切换菜单后，页面都应自动回到正确的数据状态。

数据库要求：

- SQL 文件必须包含 `CREATE DATABASE`、`USE`、`CREATE TABLE`、`INSERT`。
- 表字符集使用 `utf8mb4`。
- 每张业务表插入 5-10 条合理测试数据。
- 业务图片、头像、封面、附件预览图等测试数据必须使用 `/uploads/...` 本地路径；优先生成与当前系统领域相关的本地 JPG/PNG 到 `backend/uploads`。若无法生成真实图片，才生成占位图片并明确说明。
- 预置管理员账号 `admin`，密码为 `123456` 的 bcrypt hash；在 SQL 注释或代码注释中说明原始密码。

进度提示：

- 后端文件全部创建后，告诉用户：`FastAPI 后端代码已完成，正在生成前端...`
- 前端文件全部创建后，告诉用户：`前端代码已完成，正在生成数据库文件...`
- 所有文件生成完成后，继续安装依赖和启动检查。

### 5. 安装依赖

优先使用当前环境可用的 Python 命令，先检查：

```bash
python --version
node -v
npm -v
mysql --version
```

如果 `mysql --version` 失败，不要立刻判定本机没有 MySQL。先继续检查 Windows 常见安装路径，例如：

```powershell
Get-Command npm
Test-Path 'C:\Program Files\MySQL\MySQL Server 5.7\bin\mysql.exe'
```

后端依赖安装：

```bash
cd PROJECT_PATH/backend
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
```

如果 `python -m venv .venv` 因 `WinError 5`、目录权限、杀毒软件占用或其他环境问题失败，不要卡在创建虚拟环境这一步。按以下顺序处理：

1. 先检查 `backend\.venv` 是否已部分创建；若未创建成功，继续使用当前可用的 `python` 环境完成依赖安装、启动检查和接口验证。
2. 安装命令回退为：

```bash
cd PROJECT_PATH/backend
python -m pip install -r requirements.txt
```

3. 在 `测试报告.md` 中明确记录“当前环境未能创建 `.venv`，已使用现有 Python 环境完成启动验证”。

前端依赖安装：

```bash
cd PROJECT_PATH/frontend
npm config set registry https://registry.npmmirror.com
npm install
```

如果 `npm install` 超时，不要立刻重装。先检查 `node_modules` 和 `package-lock.json` 是否已经生成；若已经生成，继续执行 `npm run build` 验证依赖是否完整，再决定是否需要补装。

如果安装失败，先分析错误，修复依赖版本、镜像、Python 版本或 Node 版本问题后再重试。只有确有必要时才清理 npm 缓存。

### 6. 命令行启动或环境提示

全程优先使用命令行启动，不默认引导用户使用 Navicat、IDEA 或 PyCharm。

数据库导入在 Windows PowerShell 下不要使用 `<` 重定向，优先执行：

```powershell
& 'C:\Program Files\MySQL\MySQL Server 5.7\bin\mysql.exe' --default-character-set=utf8mb4 -uroot -p123456 -e "source PROJECT_PATH/DB_NAME.sql"
```

如果使用 `source` 导入 SQL，Windows 路径优先转换为正斜杠格式，例如 `D:/work/bookstore/bookstore.sql`。

如果 `mysql` 命令不存在，先尝试本机常见全路径；如果仍失败，或 MySQL 服务未启动、root 密码不是 `123456`、端口或权限不正确，停止数据库和后端启动流程，明确告诉用户需要先配置本地 MySQL 环境，并说明缺失项和建议配置。

数据库导入成功后，在 `PROJECT_PATH/backend` 下启动后端：

```powershell
Start-Process -FilePath 'python' -ArgumentList @('-m','uvicorn','app.main:app','--host','127.0.0.1','--port','8000') -WorkingDirectory 'PROJECT_PATH\backend' -WindowStyle Hidden -RedirectStandardOutput 'PROJECT_PATH\backend\backend-run.log' -RedirectStandardError 'PROJECT_PATH\backend\backend.err.log'
```

如果 `.venv` 创建成功，优先把 `python` 替换为 `PROJECT_PATH\backend\.venv\Scripts\python.exe`。如果 `.venv` 不可用，则继续使用当前环境的 `python`。

启动后不要仅凭“命令已发出”就认为成功，必须读取 `backend\backend-run.log` 和 `backend\backend.err.log`，或直接请求 `http://127.0.0.1:8000/`、`http://127.0.0.1:8000/docs`，确认后端接口确实已起来。

如果 8000 端口被占用且无法释放，可改用 8001 等空闲端口，但必须同步修改前端代理目标，并在最终回复里明确告诉用户实际端口。

前端启动：

```powershell
Start-Process -FilePath 'C:\Users\<用户名>\AppData\Roaming\npm\npm.cmd' -ArgumentList @('run','dev') -WorkingDirectory 'PROJECT_PATH\frontend' -WindowStyle Hidden -RedirectStandardOutput 'PROJECT_PATH\frontend\frontend-run.log' -RedirectStandardError 'PROJECT_PATH\frontend\frontend.err.log'
```

如果 `Start-Process -FilePath 'npm'` 报 `not a valid Win32 application`，或 `Get-Command npm` 指向的是 `npm.ps1`，立即切换到 `npm.cmd` 启动，不要反复重试 `npm`。

启动后读取 `frontend\frontend-run.log` 和 `frontend\frontend.err.log`，看到 `http://localhost:3000` 或等价 Vite ready 日志后，再告知用户访问地址。

如果 3000 端口被占用，可使用 Vite 的临时端口启动参数验证，例如 `npm run dev -- --port 3001`，并在最终回复里明确告诉用户实际访问地址。

然后告诉用户：

```text
前端已启动，打开浏览器访问：http://localhost:3000
后端接口文档：http://localhost:8000/docs

管理员账号：admin
密码：123456
```

### 7. 界面优化

询问用户：`登录进去了吗？界面能正常显示吗？`

如果有问题，进入排错流程并修复。若页面正常显示，读取布局、登录页、注册页、数据看板和全局样式，优化为简洁专业的管理系统界面：层级清晰、间距稳定、导航明确、配色克制，不使用紫色渐变。登录/注册页使用本地全屏背景图和居中大卡片，不展示管理员提示，且标题、标签、输入框、按钮、链接字号必须清晰可读。非管理员用户端不得出现左侧菜单栏或后台侧边栏。管理端公共区块要统一放大到舒适可读的字号层级，并检查页面是否存在首次无数据、手动刷新后才有数据的问题，发现后直接修复初始化加载逻辑。

完成后告诉用户：`界面已优化，刷新浏览器（Ctrl+F5 强制刷新）查看效果。接下来进行功能测试。`

### 8. 自检和功能测试

读取 `需求分析.md`，逐模块检查：

- 后端：SQLAlchemy Model、Pydantic Schema、Router、Service 是否存在，接口路径和业务逻辑是否完整。
- 前端：Vue 页面是否存在，接口调用是否正确，表单字段是否齐全。
- 路由：`router/index.js` 是否注册所有页面，权限配置是否正确。
- 接口一致性：前端 API 路径是否与 FastAPI 路由一致。

检查通用功能：

- 登录接口返回 token，前端保存到 Pinia 或 `localStorage`。
- 注册时密码经过 bcrypt 加密后入库。
- 未登录访问受保护路由时自动跳转 `/login`。
- 登出时清除 token 并跳转登录页。
- 每个管理端数据页面都支持分页列表、至少一个搜索/筛选、新增弹窗、编辑回填、删除二次确认和刷新列表。
- 用户端必须有非空首页、用户自身数据查看页面、个人信息和密码修改页面，且非管理员用户端不能使用左侧菜单栏布局。

发现缺失或不一致时直接修复。自检完成后，根据 `需求分析.md` 中的实际模块给用户生成浏览器验证清单。

所有验证通过后，在 `PROJECT_PATH` 下创建 `测试报告.md`，包含：

- 系统名称和测试时间。
- 功能模块列表和测试状态：通过、已修复或待验证。
- 已修复问题列表：问题描述和修复方案。
- 已知限制，如有。

最后回复：

```text
SYSTEM_NAME 开发完成！测试报告已保存到项目目录。

项目路径：PROJECT_PATH
管理员账号：admin / 123456
前端地址：http://localhost:3000
后端地址：http://localhost:8000
接口文档：http://localhost:8000/docs
```

## 排错手册

- 密码正确但登录失败：检查后端密码校验逻辑和 SQL 预置 hash，确保预置密码是 `123456` 的 bcrypt hash；如果数据库已由用户导入，需要更新 SQL 后提醒用户重新导入。
- 接口 404 或跨域：检查 `vite.config.js`、FastAPI router 前缀、CORS 配置和前端 API 基础路径。
- 图片、头像、封面或附件预览上传失败/不显示：检查 `POST /api/upload`、`StaticFiles` 的 `/uploads` 挂载、`backend/uploads` 目录是否存在，以及对应业务字段是否保存为 `/uploads/文件名`。
- 页面或表格出现 `????`、`???-??` 之类乱码：先检查前端源码中文文案，再检查 FastAPI 返回值、MySQL 实际记录、连接字符集和表字符集；若数据库已写入脏数据，先修复数据，不要只在前端隐藏乱码。
- Python 依赖安装失败：检查 Python 版本、虚拟环境、pip 源和依赖版本；bcrypt/passlib 报错时优先确认 `passlib[bcrypt]` 和 `bcrypt` 版本兼容。
- `python -m venv .venv` 失败且提示 `WinError 5` 或拒绝访问：不要阻塞在虚拟环境创建，改用当前环境的 `python -m pip install -r requirements.txt` 和 `python -m uvicorn ...` 完成启动验证，并把该限制写入测试报告。
- 后端启动失败：先读取 Uvicorn 日志和 traceback，定位导入路径、数据库连接、模型定义或端口占用问题后修复。
- `npm install` 失败：先检查错误和依赖兼容性，修复版本后重试；只有需要时才清理 npm 缓存。
- `Start-Process -FilePath 'npm'` 启动失败：优先检查 `Get-Command npm` 返回的是不是 `npm.ps1`；如果是，改用 `C:\Users\<用户名>\AppData\Roaming\npm\npm.cmd`。
- MySQL 导入命令在 PowerShell 下报 `<` 相关语法错误：改用 `mysql -e "source PROJECT_PATH/DB_NAME.sql"`，Windows 路径用正斜杠格式。
