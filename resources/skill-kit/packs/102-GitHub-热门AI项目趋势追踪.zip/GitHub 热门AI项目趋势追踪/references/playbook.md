# GitHub AI 趋势追踪 Playbook

## 运行流程

1. 明确用户需求：时间范围、赛道、输出格式、是否有指定仓库。
2. 先取数：运行 `scripts/fetch_github_ai_trends.py`，或读取用户给的 JSON/CSV/仓库列表。
3. 看 JSON 快照：确认 `data_quality`、`missing_fields`、`excluded_repositories`。
4. 再写报告：只基于快照字段输出结论。
5. 最后自检：链接、时间、缺失字段、AI 判定证据、增长口径。

不要跳过第 2 步直接写排行榜。没有取数结果时，只能输出取数计划和模板。

## 推荐命令

综合榜：

```bash
python3 scripts/fetch_github_ai_trends.py --period week --limit 20 --out /tmp/github-ai-trends.md --json-out /tmp/github-ai-trends.json
```

指定赛道：

```bash
python3 scripts/fetch_github_ai_trends.py --period month --track rag --limit 20 --out /tmp/github-ai-rag.md --json-out /tmp/github-ai-rag.json
```

用户给仓库：

```bash
python3 scripts/fetch_github_ai_trends.py --repos-file /tmp/repos.txt --out /tmp/github-ai-repos.md --json-out /tmp/github-ai-repos.json
```

离线验证：

```bash
python3 scripts/fetch_github_ai_trends.py --fixture examples/sample_repos.json --out /tmp/github-ai-sample.md --json-out /tmp/github-ai-sample.json
```

## 赛道关键词

| 赛道 | 关键词 |
| --- | --- |
| Agent 与自动化 | agent, agents, autonomous, workflow, tool use, function calling, browser automation |
| RAG 与知识库 | rag, retrieval, embedding, vector, knowledge base, semantic search |
| LLM 应用框架 | llm, chatbot, copilot, prompt, ai app, openai, anthropic |
| 模型训练与微调 | training, finetune, fine-tuning, lora, dataset, distributed training |
| 推理与部署 | inference, serving, quantization, vllm, onnx, tensorrt, deployment |
| 多模态与生成 | vision, image generation, video generation, diffusion, multimodal, audio |
| 数据、评测与可观测 | eval, benchmark, observability, tracing, dataset, monitoring |
| AI 开发者工具 | ai ide, coding agent, code assistant, devtool, mcp |

分类不确定时写 `混合/待确认`，并说明证据不足。

## 报告写法

结论要遵守数据边界：

- 有增长字段：可以写“本期增长最快”“短期爆发”。
- 无增长字段：写“按总热度和近期维护排序”，不要写“新增 star”。
- 有多个同赛道项目集中出现：可以写“该方向候选集中”。
- 只有单个项目：写“单点项目值得观察”，不要扩大成赛道趋势。
- license 或维护不清楚：不能给生产推荐，只能建议 PoC 或阅读源码。

## 榜单字段

Top 榜单每行至少包含：

- 排名。
- 项目和链接。
- 一句话定位。
- 赛道。
- 语言。
- star、fork、open issue、最近更新时间。
- 趋势标签。
- 上榜原因。
- 风险或待确认点。

## 数据缺失处理

| 缺失项 | 写法 |
| --- | --- |
| 增长数据缺失 | `缺少增长口径，本榜按总热度和近期维护排序` |
| README 读取失败 | `README 未核验，AI 判定仅基于描述/topic` |
| license 缺失 | `license 未声明，团队选型需谨慎` |
| issue 字段缺失 | `issue 活跃度未知` |
| 候选太少 | `样本不足，不做赛道趋势判断` |
| API 限流 | `GitHub API 限流，建议设置 GITHUB_TOKEN 后重跑` |

## HTML 输出模板

HTML 可以由 Markdown 报告改写，但必须保留相同数据口径。页面结构：

1. 顶部：标题、取数时间、范围、完整度。
2. 摘要指标：候选数、入榜数、排除数、缺失字段。
3. Top 榜单：表格或卡片。
4. 赛道观察：分组列表。
5. 风险提示：license、维护、增长口径、数据不足。
6. 数据口径：数据源、命令、缺失字段。

不要用远程字体、外链脚本、动态图表库。移动端表格允许横向滚动。

## 边界样例

用户说“最新 GitHub AI 榜”：

- 先运行脚本并写取数时间。
- 如果没有增长字段，不能写“本周新增最多”。

用户给 5 个 repo 要比较：

- 逐个拉取仓库字段。
- 非 AI 项目放到排除清单，不强行入榜。

用户要“找能生产使用的 Agent 框架”：

- 榜单不是最终选型结论。
- 必须额外看 license、release、issue、文档、社区活跃和安全风险。

用户要求 HTML：

- 先生成 JSON 快照。
- 再用同一份快照生成 HTML，不要重新编一份数据。
