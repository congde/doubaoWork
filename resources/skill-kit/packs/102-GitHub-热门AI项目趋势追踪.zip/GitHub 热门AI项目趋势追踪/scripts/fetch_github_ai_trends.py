#!/usr/bin/env python3
"""Fetch GitHub AI repository candidates and build an evidence-first report."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import sys
import textwrap
import urllib.error
import urllib.parse
import urllib.request


AI_TERMS = {
    "ai", "artificial intelligence", "llm", "large language model", "agent",
    "rag", "retrieval", "embedding", "vector", "machine learning", "ml",
    "deep learning", "inference", "finetune", "fine-tuning", "lora",
    "multimodal", "diffusion", "prompt", "openai", "anthropic", "mcp",
}

TRACK_TERMS = {
    "agent": ["ai agent", "agent", "tool use", "function calling", "workflow"],
    "rag": ["rag", "retrieval", "embedding", "vector", "knowledge base"],
    "llm": ["llm", "chatbot", "prompt", "copilot", "openai", "anthropic"],
    "training": ["training", "finetune", "fine-tuning", "lora", "dataset"],
    "inference": ["inference", "serving", "quantization", "vllm", "onnx"],
    "multimodal": ["multimodal", "vision", "diffusion", "image generation", "video"],
    "eval": ["eval", "benchmark", "observability", "tracing", "monitoring"],
    "devtool": ["ai ide", "coding agent", "code assistant", "mcp", "devtool"],
}


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def github_request(path: str) -> dict:
    url = "https://api.github.com" + path
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "github-ai-trend-radar-skill",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    token = os.environ.get("GITHUB_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def period_cutoff(period: str) -> str:
    today = dt.datetime.now(dt.timezone.utc).date()
    days = {"today": 1, "day": 1, "week": 7, "month": 30}.get(period, 7)
    return (today - dt.timedelta(days=days)).isoformat()


def build_queries(period: str, track: str | None) -> list[str]:
    cutoff = period_cutoff(period)
    terms = TRACK_TERMS.get(track or "", ["llm", "ai agent", "rag", "inference", "embedding"])
    queries = []
    for term in terms[:5]:
        normalized = term.replace(" ", "-")
        queries.append(f"topic:{normalized} pushed:>={cutoff} stars:>50")
    for term in terms[:3]:
        queries.append(f"{term} in:name,description pushed:>={cutoff} stars:>50")
    return queries


def search_repositories(period: str, track: str | None, limit: int) -> list[dict]:
    seen = set()
    repos = []
    per_page = min(max(limit, 10), 30)
    errors = []
    for raw_query in build_queries(period, track):
        query = urllib.parse.quote(raw_query)
        path = f"/search/repositories?q={query}&sort=stars&order=desc&per_page={per_page}"
        try:
            data = github_request(path)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{raw_query}: {exc}")
            continue
        for item in data.get("items", []):
            full_name = item.get("full_name")
            if full_name and full_name not in seen:
                seen.add(full_name)
                repos.append(item)
        if len(repos) >= limit * 2:
            break
    if not repos and errors:
        raise RuntimeError("; ".join(errors[:3]))
    return repos


def fetch_repo(full_name: str) -> dict:
    return github_request("/repos/" + full_name.strip())


def load_fixture(path: str) -> list[dict]:
    with open(path, "r", encoding="utf-8") as handle:
        data = json.load(handle)
    if isinstance(data, list):
        return data
    return data.get("items", [])


def load_repo_list(path: str) -> list[str]:
    repos = []
    with open(path, "r", encoding="utf-8") as handle:
        for line in handle:
            value = line.strip()
            if value and not value.startswith("#"):
                repos.append(value)
    return repos


def text_blob(repo: dict) -> str:
    fields = [
        repo.get("full_name") or "",
        repo.get("description") or "",
        " ".join(repo.get("topics") or []),
    ]
    return " ".join(fields).lower()


def ai_evidence(repo: dict) -> list[str]:
    blob = text_blob(repo).replace("-", " ")
    evidence = []
    for term in sorted(AI_TERMS, key=len, reverse=True):
        normalized = term.replace("-", " ")
        if re.search(r"(?<![a-z0-9])" + re.escape(normalized) + r"(?![a-z0-9])", blob):
            evidence.append(term)
    return evidence[:5]


def classify_track(repo: dict) -> str:
    blob = text_blob(repo)
    labels = [
        ("Agent 与自动化", TRACK_TERMS["agent"]),
        ("RAG 与知识库", TRACK_TERMS["rag"]),
        ("LLM 应用框架", TRACK_TERMS["llm"]),
        ("模型训练与微调", TRACK_TERMS["training"]),
        ("推理与部署", TRACK_TERMS["inference"]),
        ("多模态与生成", TRACK_TERMS["multimodal"]),
        ("数据、评测与可观测", TRACK_TERMS["eval"]),
        ("AI 开发者工具", TRACK_TERMS["devtool"]),
    ]
    for label, terms in labels:
        if any(term in blob for term in terms):
            return label
    return "混合/待确认"


def parse_time(value: str | None) -> dt.datetime | None:
    if not value:
        return None
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def repo_score(repo: dict) -> int:
    stars = int(repo.get("stargazers_count") or 0)
    forks = int(repo.get("forks_count") or repo.get("forks") or 0)
    issues = int(repo.get("open_issues_count") or 0)
    pushed = parse_time(repo.get("pushed_at"))
    recency = 0
    if pushed:
        days = max((dt.datetime.now(dt.timezone.utc) - pushed).days, 0)
        recency = max(0, 60 - min(days, 60)) * 40
    issue_penalty = min(issues, 500) * 2
    return stars + forks * 3 + recency - issue_penalty + len(ai_evidence(repo)) * 500


def normalize_repo(repo: dict) -> dict:
    license_obj = repo.get("license") or {}
    evidence = ai_evidence(repo)
    item = {
        "full_name": repo.get("full_name") or "未知",
        "url": repo.get("html_url") or "",
        "description": repo.get("description") or "未知",
        "language": repo.get("language") or "未知",
        "stars": repo.get("stargazers_count", "未知"),
        "forks": repo.get("forks_count", repo.get("forks", "未知")),
        "open_issues": repo.get("open_issues_count", "未知"),
        "pushed_at": repo.get("pushed_at") or "未知",
        "created_at": repo.get("created_at") or "未知",
        "topics": repo.get("topics") or [],
        "license": license_obj.get("spdx_id") or "未知",
        "homepage": repo.get("homepage") or "",
        "track": classify_track(repo),
        "ai_evidence": evidence,
        "score": repo_score(repo),
        "trend_label": "稳定" if evidence and repo.get("pushed_at") else "观察",
    }
    missing = []
    for key in ["url", "description", "language", "stars", "forks", "open_issues", "pushed_at"]:
        if item[key] in ("", None, "未知"):
            missing.append(key)
    item["missing_fields"] = missing
    return item


def quality_level(items: list[dict]) -> str:
    if not items:
        return "取数失败"
    mostly_complete = sum(1 for item in items if not item["missing_fields"]) >= max(1, len(items) // 2)
    if mostly_complete:
        return "B 级"
    return "C 级"


def build_snapshot(args: argparse.Namespace) -> dict:
    errors = []
    raw_items = []
    source = "GitHub Search API"
    try:
        if args.fixture:
            raw_items = load_fixture(args.fixture)
            source = f"fixture:{args.fixture}"
        elif args.repos_file:
            source = f"repos-file:{args.repos_file}"
            for repo in load_repo_list(args.repos_file):
                try:
                    raw_items.append(fetch_repo(repo))
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"{repo}: {exc}")
        else:
            raw_items = search_repositories(args.period, args.track, args.limit)
    except urllib.error.HTTPError as exc:
        errors.append(f"GitHub API HTTP {exc.code}: {exc.reason}")
    except urllib.error.URLError as exc:
        errors.append(f"GitHub API network error: {exc.reason}")
    except Exception as exc:  # noqa: BLE001
        errors.append(f"取数失败: {exc}")

    included = []
    excluded = []
    for repo in raw_items:
        item = normalize_repo(repo)
        if item["ai_evidence"]:
            included.append(item)
        else:
            excluded.append({
                "full_name": item["full_name"],
                "url": item["url"],
                "reason": "未发现明确 AI 关键词或 topic 证据",
            })

    included.sort(key=lambda item: item["score"], reverse=True)
    included = included[: args.limit]
    all_missing = sorted({field for item in included for field in item["missing_fields"]})
    if included:
        all_missing.append("growth")
    return {
        "generated_at_utc": utc_now(),
        "period": args.period,
        "track": args.track or "综合",
        "source": source,
        "data_quality": quality_level(included),
        "growth_policy": "未提供历史快照或 Trending 新增 star，不能声称近期新增 star",
        "missing_fields": all_missing,
        "errors": errors,
        "repositories": included,
        "excluded_repositories": excluded[:50],
    }


def md_table_row(index: int, item: dict) -> str:
    data = f"{item['stars']} star / {item['forks']} fork / {item['open_issues']} issue / pushed {item['pushed_at']}"
    reason = "AI 证据：" + ", ".join(item["ai_evidence"])
    risk_parts = []
    if item["license"] == "未知":
        risk_parts.append("license 未知")
    risk_parts.append("增长口径缺失")
    if item["missing_fields"]:
        risk_parts.append("字段缺失：" + ", ".join(item["missing_fields"]))
    risk = "；".join(risk_parts)
    return (
        f"| {index} | [{item['full_name']}]({item['url']}) | {item['track']} | "
        f"{item['language']} | {item['trend_label']} | {data} | {reason} | {risk} |"
    )


def render_markdown(snapshot: dict) -> str:
    repos = snapshot["repositories"]
    if not repos:
        errors = "\n".join(f"- {error}" for error in snapshot["errors"]) or "- 未取得有效仓库数据"
        return clean_markdown(textwrap.dedent(f"""\
        # GitHub AI 趋势排行榜：{snapshot['period']}

        ## 报告口径
        - 取数时间 UTC：{snapshot['generated_at_utc']}
        - 数据源：{snapshot['source']}
        - 数据完整度：取数失败

        ## 取数失败
        {errors}

        ## 下一步
        - 设置 `GITHUB_TOKEN` 后重跑脚本。
        - 或提供一行一个 `owner/repo` 的仓库列表。
        - 在没有可核验数据前，不生成排行榜。
        """))

    track_counts = {}
    for item in repos:
        track_counts[item["track"]] = track_counts.get(item["track"], 0) + 1
    strongest = max(track_counts.items(), key=lambda pair: pair[1])[0]
    missing = ", ".join(snapshot["missing_fields"]) or "无"
    rows = "\n".join(md_table_row(i + 1, item) for i, item in enumerate(repos))
    observations = "\n".join(f"- {track}：{count} 个入榜项目。" for track, count in sorted(track_counts.items()))
    risks = [
        "- 缺少增长口径，本榜按总热度、近期维护和 AI 相关证据排序。"
    ]
    if snapshot["excluded_repositories"]:
        risks.append(f"- 已排除 {len(snapshot['excluded_repositories'])} 个 AI 证据不足的候选仓库。")
    if snapshot["errors"]:
        risks.extend(f"- {error}" for error in snapshot["errors"])
    risk_text = "\n".join(risks)
    return clean_markdown(textwrap.dedent(f"""\
    # GitHub AI 趋势排行榜：{snapshot['period']}

    ## 报告口径
    - 取数时间 UTC：{snapshot['generated_at_utc']}
    - 数据源：{snapshot['source']}
    - 赛道：{snapshot['track']}
    - 入榜项目：{len(repos)}
    - 数据完整度：{snapshot['data_quality']}
    - 缺失字段：{missing}
    - 增长口径：{snapshot['growth_policy']}

    ## 结论
    - 本期最集中的方向：{strongest}
    - 本榜不声称新增 star 或增长率，除非另有历史快照补充。
    - 适合先做项目观察和 PoC 候选筛选，不直接作为生产选型结论。

    ## Top 榜单
    | 排名 | 项目 | 赛道 | 语言 | 趋势标签 | 关键数据 | 上榜原因 | 风险 |
    | --- | --- | --- | --- | --- | --- | --- | --- |
    {rows}

    ## 赛道观察
    {observations}

    ## 风险和待确认
    {risk_text}
    """))


def clean_markdown(content: str) -> str:
    lines = []
    for line in content.splitlines():
        if line.startswith("    "):
            lines.append(line[4:])
        else:
            lines.append(line)
    return "\n".join(lines).strip() + "\n"


def write_text(path: str, content: str) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(content)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--period", default="week", choices=["today", "day", "week", "month"])
    parser.add_argument("--track", choices=sorted(TRACK_TERMS))
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--repos-file")
    parser.add_argument("--fixture")
    parser.add_argument("--out", required=True)
    parser.add_argument("--json-out", required=True)
    args = parser.parse_args()

    snapshot = build_snapshot(args)
    write_text(args.json_out, json.dumps(snapshot, ensure_ascii=False, indent=2))
    write_text(args.out, render_markdown(snapshot))
    print(f"wrote {args.out}")
    print(f"wrote {args.json_out}")
    print(f"data_quality={snapshot['data_quality']}")
    if snapshot["errors"]:
        print("errors=" + "; ".join(snapshot["errors"]), file=sys.stderr)
    return 0 if snapshot["repositories"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
