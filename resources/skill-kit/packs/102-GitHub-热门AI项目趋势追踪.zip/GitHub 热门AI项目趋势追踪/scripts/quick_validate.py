#!/usr/bin/env python3
"""Dependency-free validation for the GitHub AI trend radar skill."""

from __future__ import annotations

import json
import pathlib
import subprocess
import sys
import tempfile


ROOT = pathlib.Path(__file__).resolve().parents[1]


def fail(message: str) -> int:
    print("FAIL:", message)
    return 1


def main() -> int:
    required = [
        ROOT / "SKILL.md",
        ROOT / "agents" / "openai.yaml",
        ROOT / "references" / "playbook.md",
        ROOT / "scripts" / "fetch_github_ai_trends.py",
        ROOT / "examples" / "sample_repos.json",
    ]
    for path in required:
        if not path.exists():
            return fail(f"missing {path}")

    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    for needle in ["默认动作", "数据完整度", "增长口径", "不要生成看似完整的趋势结论"]:
        if needle not in skill:
            return fail(f"SKILL.md missing {needle}")

    with tempfile.TemporaryDirectory() as tmp:
        out = pathlib.Path(tmp) / "report.md"
        json_out = pathlib.Path(tmp) / "snapshot.json"
        command = [
            sys.executable,
            str(ROOT / "scripts" / "fetch_github_ai_trends.py"),
            "--fixture",
            str(ROOT / "examples" / "sample_repos.json"),
            "--out",
            str(out),
            "--json-out",
            str(json_out),
        ]
        result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, check=False)
        if result.returncode != 0:
            return fail(result.stderr or result.stdout)
        snapshot = json.loads(json_out.read_text(encoding="utf-8"))
        repos = snapshot.get("repositories", [])
        excluded = snapshot.get("excluded_repositories", [])
        if len(repos) != 2:
            return fail(f"expected 2 AI repos, got {len(repos)}")
        if not excluded:
            return fail("expected non-AI fixture repo to be excluded")
        report = out.read_text(encoding="utf-8")
        if "缺少增长口径" not in report:
            return fail("report must disclose missing growth data")
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
