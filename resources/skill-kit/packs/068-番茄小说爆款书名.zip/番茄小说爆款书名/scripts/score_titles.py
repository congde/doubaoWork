#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
番茄小说书名打分器

用法:
    python score_titles.py "书名1" "书名2" "书名3"
    python score_titles.py --file titles.txt      # 每行一个书名
    echo "书名1\n书名2" | python score_titles.py  # 支持stdin

输出每个书名的总分(0-100)及分项明细, 按总分降序排列。
评分维度: 长度、钩子词、结构(冒号/逗号切分)、数字冲击、身份词、违禁词。
"""

import sys
import json
import argparse

# ---------- 维度配置 ----------

# 高频钩子词 (命中间距加分)
HOOK_WORDS = [
    "开局", "重生", "穿越", "穿成", "穿书", "离婚", "闪婚", "替嫁",
    "系统", "签到", "神豪", "首富", "亿", "万倍", "返利",
    "杀疯", "悔疯", "掀桌", "掉马", "马甲", "团宠", "真千金", "假千金",
    "赘婿", "寡妇", "炮灰", "女配", "反派", "老祖", "大佬", "总裁",
    "国师", "女帝", "玄学", "锦鲤", "快穿", "高武", "全民", "觉醒",
    "天赋", "隐藏", "诡异", "规则", "怪谈", "复苏", "空间", "囤货",
    "随军", "军婚", "养崽", "崽崽", "认亲", "退婚", "摆烂", "苟",
    "死后", "第二天", "一觉醒来", "竟是", "是京圈", "百亿", "千亿",
]

# 身份词 (代入感)
IDENTITY_WORDS = [
    "千金", "总裁", "寡妇", "赘婿", "外卖员", "打工人", "女配",
    "后妈", "军嫂", "影后", "大佬", "女帝", "国师", "老祖", "夜班",
    "炮灰", "白月光", "馆长", "老板娘",
]

# 审核红线词 (命中直接 0 分并标记)
BANNED_WORDS = [
    # 占位示例, 平台红线随时间调整, 见 references/platform-rules.md
    "改命", "真实算命", "包治", "一夜暴富秘籍",
]

STRONG_ENDINGS = ["疯了", "杀疯了", "麻了", "翻车了", "掀桌了", "爆红", "赢麻", "跪求", "杀疯"]


def score_title(title: str) -> dict:
    """对单个书名打分, 返回明细 dict。"""
    title = title.strip()
    detail = {"title": title, "issues": [], "breakdown": {}}

    if not title:
        detail["total"] = 0
        detail["issues"].append("空书名")
        return detail

    # 1) 违禁词 (一票否决)
    banned = [w for w in BANNED_WORDS if w in title]
    if banned:
        detail["total"] = 0
        detail["issues"].append(f"命中违禁词: {banned}")
        return detail

    # 2) 长度 (满分25): 6-16 最佳
    n = len(title)
    if 6 <= n <= 16:
        length_score = 25
    elif n < 6:
        length_score = 10
        detail["issues"].append("过短(<6字), 钩子信息不足")
    elif n <= 22:
        length_score = 15
        detail["issues"].append("偏长(17-22字), 前10字须承载核心钩子")
    else:
        length_score = 3
        detail["issues"].append(f"过长({n}字), 手机端将被截断")

    # 3) 钩子词 (满分35): 每个命中+10, 上限35
    hooks = [w for w in HOOK_WORDS if w in title]
    hook_score = min(35, len(hooks) * 10)
    if len(hooks) >= 2:
        pass  # 叠加钩子是好现象
    elif len(hooks) == 0:
        detail["issues"].append("无钩子词, 信息流场景下点击率会很低")

    # 4) 结构 (满分15): 冒号/逗号切分 或 强动词收尾
    struct_score = 0
    if "：" in title or ":" in title:
        struct_score += 8  # 题材标签前置结构
    if "，" in title or "," in title:
        struct_score += 7  # 主副标题结构
    if struct_score == 0 and len(hooks) >= 2:
        struct_score = 8  # 钩子密度足够高时, 无切分结构也可接受
    struct_score = min(15, struct_score)

    # 5) 数字冲击 (满分10)
    digit_score = 10 if any(c.isdigit() for c in title) else 0

    # 6) 身份词 (满分10)
    identities = [w for w in IDENTITY_WORDS if w in title]
    identity_score = min(10, len(identities) * 6)

    # 7) 文艺含蓄惩罚 (满分5, 含蓄则扣)
    vague_words = ["岁月", "时光", "无声", "流年", "彼岸", "远方", "心事", "余晖", "浅唱"]
    if any(w in title for w in vague_words) and len(hooks) == 0:
        aura_score = 0
        detail["issues"].append("书名偏文艺含蓄, 不适合免费阅读信息流")
    else:
        aura_score = 5

    total = length_score + hook_score + struct_score + digit_score + identity_score + aura_score
    detail["breakdown"] = {
        "长度": length_score,
        "钩子词": hook_score,
        "结构": struct_score,
        "数字": digit_score,
        "身份感": identity_score,
        "气质": aura_score,
    }
    if hooks:
        detail["hooks"] = hooks
    detail["total"] = total
    return detail


def grade(total: int) -> str:
    if total >= 75:
        return "S (强推)"
    if total >= 55:
        return "A (可用)"
    if total >= 40:
        return "B (需打磨)"
    return "C (不建议)"


def main():
    parser = argparse.ArgumentParser(description="番茄小说书名打分器")
    parser.add_argument("titles", nargs="*", help="待打分的书名")
    parser.add_argument("--file", "-f", help="从文件读取书名, 每行一个")
    parser.add_argument("--json", action="store_true", help="输出JSON格式")
    args = parser.parse_args()

    titles = list(args.titles)
    if args.file:
        with open(args.file, encoding="utf-8") as f:
            titles.extend(line.strip() for line in f if line.strip())
    if not titles and not sys.stdin.isatty():
        titles.extend(line.strip() for line in sys.stdin if line.strip())

    if not titles:
        print(__doc__)
        sys.exit(1)

    results = sorted((score_title(t) for t in titles), key=lambda r: r["total"], reverse=True)

    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return

    print(f"{'排名':<4}{'书名':<28}{'总分':<6}{'评级':<12}钩子词")
    print("-" * 78)
    for i, r in enumerate(results, 1):
        print(f"{i:<4}{r['title']:<28}{r['total']:<6}{grade(r['total']):<12}{','.join(r.get('hooks', []))}")
    print("-" * 78)
    for i, r in enumerate(results, 1):
        if r["issues"]:
            print(f"[{i}] {r['title']}: {'; '.join(r['issues'])}")


if __name__ == "__main__":
    main()
