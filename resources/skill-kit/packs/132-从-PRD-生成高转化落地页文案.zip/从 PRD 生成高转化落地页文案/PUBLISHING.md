# Marketplace 发布说明

- Skill：`landing-page-copywriter`
- 状态：已生成脱敏候选包，上传前仍需确认原创/授权与选择许可证。
- 凭据：不得写入包内；如需外部服务，必须通过环境变量或宿主 Secret Store 配置。
- 隐私：不得附带 Cookie、Token、聊天记录、截图、数据库、日志或真实账号信息。
- 许可：当前未擅自替作者指定开源许可证。请在确认权属后添加 `LICENSE`。
