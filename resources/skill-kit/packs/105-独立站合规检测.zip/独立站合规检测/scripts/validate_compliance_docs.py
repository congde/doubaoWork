#!/usr/bin/env python3
"""Validate a website compliance report for required evidence sections."""
import argparse
from pathlib import Path

REQUIRED = {
    "scope": ["范围", "scope"],
    "data_inventory": ["数据清单", "data inventory", "data flow"],
    "third_parties": ["第三方服务", "third-party", "third party"],
    "risk_matrix": ["风险矩阵", "risk matrix"],
    "draft_pages": ["privacy", "terms", "cookie", "refund", "法律页面"],
    "disclaimer": ["不构成法律意见", "not legal advice"],
}

def main():
    p=argparse.ArgumentParser(description="Validate website compliance report structure")
    p.add_argument("report", help="Markdown/text report path")
    args=p.parse_args()
    path=Path(args.report)
    if not path.is_file(): raise SystemExit(f"ERROR file not found: {path}")
    text=path.read_text(encoding="utf-8").lower()
    missing=[name for name,words in REQUIRED.items() if not any(w.lower() in text for w in words)]
    if missing:
        print("FAIL missing:", ", ".join(missing)); raise SystemExit(1)
    print("OK compliance report contains all required evidence sections")

if __name__ == "__main__": main()
