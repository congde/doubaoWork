# Production legal footer and contact verification

Use this checklist when a public site needs baseline overseas compliance pages and a working contact route.

## Content must match reality

Before drafting, inspect the live implementation rather than copying a generic template:

- Authentication provider and exact profile fields processed.
- Cookie names, purpose, security flags, and expiry.
- Whether prompts, uploads, waitlist emails, generated assets, or payments actually leave the browser.
- Hosting/CDN/security providers and external media sources.
- Current analytics, advertising, storage, AI inference, and payment providers.

Do not invent a company name, postal address, governing jurisdiction, retention period, payment flow, or data use. If the operator identity or jurisdiction is unknown, keep the language accurate and limited, and flag it for owner/legal review.

## Minimum route contract

- `/privacy/` — Privacy Policy with canonical metadata.
- `/terms/` — Terms of Service with canonical metadata.
- Footer links to both routes.
- A domain contact address using `mailto:`.
- Both legal routes in `sitemap.xml`.
- Legal pages must be indexable and return HTTP 200.

Update Privacy/Terms before enabling a new AI provider, file upload, persistent asset history, analytics, advertising, payment, subscription, or email collection flow.

## Verification

1. Build the production artifact and confirm both legal HTML files exist.
2. Assert home HTML contains legal route links and the source contains the intended contact link before deployment.
3. Verify canonical URLs, titles, support address, required disclosures, and absence of `TBD`, `example.com`, or placeholder company names.
4. Verify production HTTP 200 for home, Privacy, Terms, and Sitemap.
5. Use a real browser to verify rendered links, desktop layout, and a viewport below the mobile breakpoint.
6. Click or inspect the rendered contact link and confirm its final `href` is `mailto:<domain-address>`.

## Cloudflare email obfuscation pitfall

Cloudflare Email Address Obfuscation may rewrite a literal email and `mailto:` in the raw response into `/cdn-cgi/l/email-protection` plus a `__cf_email__` span. A raw `curl` search can therefore falsely report that the email is missing. Inspect the transformed marker in raw HTML, then verify the hydrated browser DOM restores the readable address and `mailto:` target. Do not disable the protection merely to make a raw-string test pass.
