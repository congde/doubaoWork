# Cloudflare 静态站法律页与 Footer 验证

适用于 Next.js 静态导出 + Cloudflare Pages / Pages Functions 的海外小站。

## 1. 先从代码还原真实数据处理

不要从通用模板猜。检查并记录：

- OAuth scope 与回调实际读取的字段。
- Session / OAuth state Cookie 的名称、属性和有效期。
- 是否有用户数据库、分析工具、广告 Cookie、支付、上传和邮件采集。
- 表单提交是否真实发出网络请求；仅更新浏览器状态时，Privacy 必须明确“当前不传输、不存储”。
- 提示词和参考文件是在浏览器内预览，还是会送到 AI 服务商。
- 托管、CDN、认证、媒体等第三方服务。

法律页必须描述当前实现。未来接入 analytics、支付、数据库、邮件收集、文件上传或 AI provider 前，先更新政策再启用处理。

## 2. 基础 route contract

默认：

- `/privacy/` — Privacy Policy
- `/terms/` — Terms of Service
- Footer 同时提供两个法律链接和真实域名邮箱的 `mailto:` 链接。
- Sitemap 收录两个 canonical URL。
- 每页包含独立 Title、Description、Canonical、Last updated、联系邮箱和相互导航。

不要虚构公司名称、地址、法域、注册主体或 DPO。缺失时采用不夸大的通用表述并标记后续律师复核。

## 3. 最小内容覆盖

Privacy：数据类别、用途、Cookie、第三方、保留、安全、国际处理、用户权利、儿童隐私、更新、联系。

Terms：接受条款、产品真实状态、账号安全、用户素材责任、可接受使用、知识产权、外部服务、可用性、免责声明、责任限制、终止、争议、更新、联系。

独立预览站还要明确非官方、无背书，以及演示输出/额度/价格不构成承诺。

## 4. 构建与自动检查

构建后验证：

- `out/privacy/index.html`、`out/terms/index.html` 存在。
- 首页包含 Privacy、Terms、邮箱入口。
- 两个法律页均有 canonical 和 `mailto:`。
- Sitemap 包含 `/privacy/` 与 `/terms/`。
- 无 `TBD`、`TODO`、`example.com`、`Your Company` 等占位符。
- lint、build、diff check 均通过。

## 5. 必须做真实浏览器 QA

- 桌面端：标题、正文列、Footer、链接无重叠或溢出。
- 小于移动断点的 viewport：标题自然换行，正文无横向滚动，Footer 可读。
- 逐个访问生产 `/`、`/privacy/`、`/terms/`、`/sitemap.xml`，确认 HTTP 200。
- 在浏览器 DOM 中读取支持邮箱链接，确认最终 `href` 为 `mailto:support@domain`。

## 6. Cloudflare Email Address Obfuscation 陷阱

Cloudflare 开启 Email Address Obfuscation 后，原始 HTML 会把邮箱改写成：

- `/cdn-cgi/l/email-protection#...`
- `<span class="__cf_email__">[email protected]</span>`

因此 `curl | grep 'mailto:support@domain'` 可能误报失败。正确验证顺序：

1. 原始 HTML 确认存在 `email-protection` / `__cf_email__`，表示 Cloudflare 已改写。
2. 真实浏览器等待 Cloudflare 解码脚本运行。
3. 从最终 DOM 读取链接文本和 `href`，应恢复为真实邮箱与 `mailto:`。

这是反爬虫保护，不是部署漏项。不要为了让 curl 找到明文而关闭保护。
